
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cloud Navigator</title>
    <link rel="icon" type="image/x-icon" href="img/webicon.png" />
    <!-- <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet"> -->

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN"
        crossorigin="anonymous"></script>
    <!-- <script src="https://code.jquery.com/jquery-3.5.1.js"></script> -->
    <script src="lib/jquery-uncompressed (Development).js"></script>
    <script src="lib/jquery-ui-uncompressed.js"></script>

    <link rel="stylesheet" href="css/bootstrap-icons.css">
    <link rel="stylesheet" href="css/custom-user.css">


    <style>
        /* * {
            transition: 1s;
        } */
    </style>
</head>

<body class="bg-light">
    <header class="fixed-top bg-light p-2 border-bottom shadow-sm">
        <div class="container-fluid heder">
            <div class="d-flex flex-wrap align-items-center justify-content-between">
                <div class="d-flex align-items-center">
                    <img src="logo.png" alt="Website Logo" class="img-fluid">
                    <h4 class="mb-0 mx-4 alvin-color-1">Cloud Navigator</h4>
                </div>

                <div class="w-25">
                    <!-- <form class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3" role="search"> -->
                    <form class="" role="search">
                        <!-- <input id="home_search" type="search" class="form-control" placeholder="Search..." aria-label="Search"> -->
                        <input id="search_main" type="search" list="home_search" name="search" class="form-control" placeholder="Search...">
                        <datalist id="home_search"></datalist>


                    </form>
                    <!-- <div id="suggest" style="position: absolute;background-color: lightgray;width: 200px;height: 200px;"></div> -->
                </div>

                <div class="dropdown d-flex align-items-center">
                    <ul class="nav">
                        <!-- <li><a href="" class="nav-link link-dark" target="_self">Home</a></li> -->
                        <li><a href="http://kdt-ph/" class="nav-link link-dark" target="_blank">KDT Portal</a></li>
                        <li><a href="https://globalkawasaki.sharepoint.com/sites/msteams_9f69f4/SitePages/EventPlanHome.aspx"
                                class="nav-link link-dark" target="_blank">Sharepoint</a></li>
                    </ul>

                    <h6 class="mb-0 mx-3">Alvin John Aganan</h6>
                    <a href="#" class="d-block link-dark text-decoration-none dropdown-toggle" data-bs-toggle="dropdown"
                        aria-expanded="false">
                        <img src="img/avatar/1.png" alt="Picture" width="32" height="32" class="rounded-circle">
                    </a>
                    <ul class="dropdown-menu text-small">
                        <li><a class="dropdown-item" href="./Admin">Admin</a></li>
                        <li><a class="dropdown-item" href="./Profile">Profile</a></li>
                        <li><a class="dropdown-item" href="./Uploads">Uploads</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="#">Sign out</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </header>


    <div class="container fs-7">
        <div class="row header-space-7 mx-lg-5 mx-md-4">

            <aside class="col-xxl-2 col-xl-3 col-lg-4 col-md-5 col-sm-6">
                <div class="border fs-7 p-3 vin-filter">
                    <p class="text-center p-2 fw-semibold">SEARCH FILTER</p>
                    <div class="checkbox-jar my-4">
                        <p class="mb-2">FILE TYPES</p>
                        <div class="form-check">
                            <input id="check_filetype_all" class="form-check-input" type="checkbox" checked/>
                            <label for="check_filetype_all" class="form-check-label">All (0)</label>
                        </div>
                        <div class="form-check">
                            <input id="check_filetype_docu" class="form-check-input" type="checkbox" data-chk-filetype />
                            <label for="check_filetype_docu" class="form-check-label">Documents (0)</label>
                        </div>
                        <div class="form-check">
                            <input id="check_filetype_photos" class="form-check-input" type="checkbox" data-chk-filetype />
                            <label for="check_filetype_photos" class="form-check-label">Photos (0)</label>
                        </div>
                        <div class="form-check">
                            <input id="check_filetype_videos" class="form-check-input" type="checkbox" data-chk-filetype />
                            <label for="check_filetype_videos" class="form-check-label">Videos (0)</label>
                        </div>
                        <div class="form-check">
                            <input id="check_filetype_others" class="form-check-input" type="checkbox" data-chk-filetype />
                            <label for="check_filetype_others" class="form-check-label">Others (0)</label>
                        </div>
                    </div>


                    <div class="checkbox-jar my-4">
                        <p class="mb-2">CATEGORIES</p>
                        <!-- <div class="form-check">
                            <input id="check1" class="form-check-input" type="checkbox" checked/>
                            <label for="check1" class="form-check-label">All (0)</label>
                        </div> -->

                        <p id="filter_plant" class="mt-2 mb-2 fw-semibold">Plant Type</p>

                        <!-- <div class="form-check">
                            <input id="check2" class="form-check-input" type="checkbox" />
                            <label for="check2" class="form-check-label">Cement Plant (0)</label>
                        </div> -->

                        <p id="filter_project" class="mt-2 mb-2 fw-semibold">Project Name</p>

                        <!-- <div class="form-check">
                            <input id="check4" class="form-check-input" type="checkbox" />
                            <label for="check4" class="form-check-label">Anshun Power Plant (0)</label>
                        </div> -->

                    </div>


                    <div class="checkbox-jar my-4">
                        <p class="mb-2">OTHERS</p>
                        <div class="form-check">
                            <input id="check1" class="form-check-input" type="checkbox" />
                            <label for="check1" class="form-check-label">QMS (0)</label>
                        </div>
                        <div class="form-check">
                            <input id="check2" class="form-check-input" type="checkbox" />
                            <label for="check2" class="form-check-label">3D Models (0)</label>
                        </div>
                        <div class="form-check">
                            <input id="check3" class="form-check-input" type="checkbox" />
                            <label for="check3" class="form-check-label">Drawings (0)</label>
                        </div>
                    </div>

                    <div class="checkbox-jar-group my-4">
                        <p class="mb-2">BUSINESS UNITS</p>
                        <!-- <div class="form-check">
                            <input id="filter_bu_all" class="form-check-input" type="checkbox" checked/>
                            <label for="filter_bu_all" class="form-check-label">All (0)</label>
                        </div> -->
                    </div>



                    <div class="d-grid mx-1">
                        <button id="clearfilter_home" type="button" class="btn btn-outline-primary text-center">Clear Filters</button>
                    </div>

                </div> <!--Search Filter-->
            </aside>


            <section class="col-xxl-10 col-xl-9 col-lg-8 col-md-7 col-sm-6">
                <div class="d-flex justify-content-between align-items-center">
                    <p id="search_result" class="mb-0">Showing all results</p>
                    <div class="d-flex align-items-center">
                        <p class="mb-0 px-1">Sort by: </p>
                        <select class="form-select w-auto fs-7" aria-label="Default select example">
                            <option value="" selected>Newest</option>
                            <option value="">Oldest</option>
                            <option value="">A - Z</option>
                            <option value="">Z - A</option>
                        </select>
                    </div>
                </div>


                <section class="my-2" data-sec-documents>
                    <div class="w-100 bg-secondary">
                        <p class="text-white py-2 px-3 alvin-bgcolor-1">Documents</p>
                    </div>
                    <div class="d-flex flex-wrap" data-jar-documents>
                        <!-- <p class="text-center w-100">No results found.</p> -->

                        <!-- <div class="m-2 w-11">
                            <div class="card p-4" data-item>
                                <img src="img/docs/Docx.jpg" class="card-img-top" alt="...">
                            </div>
                            <p class="text-center mb-0">Pipes</p>
                        </div> -->

                    </div>
                </section>


                <section class="my-2" data-sec-photos>
                    <div class="w-100 bg-secondary">
                        <p class="text-white py-2 px-3 alvin-bgcolor-1">Photos</p>
                    </div>
                    <div class="d-flex flex-wrap jar-photos" data-jar-photos>
                        <!-- <p class="text-center w-100">No results found.</p> -->

                        <!-- <div class="m-2 w-11">
                            <div class="card p-2" data-item>
                                <img src="img/avatar/1.png" class="card-img-top" alt="...">
                            </div>
                            <p class="text-center mb-0">Pipes</p>
                        </div> -->

                    </div>
                </section>


                <section class="my-2" data-sec-videos>
                    <div class="w-100 bg-secondary">
                        <p class="text-white py-2 px-3 alvin-bgcolor-1">Videos</p>
                    </div>
                    <div class="d-flex flex-wrap" data-jar-videos>
                        <!-- <p class="text-center w-100">No results found.</p> -->

                        <div class="m-2 w-18">
                            <div class="card p-2" data-item>
                                <video controls >
                                    <source src="vids/CHEM, CEM and MIL Group.MOV">
                                  Your browser does not support the video tag.
                                  </video>
                            </div>
                            <p class="text-center mb-0">Pipes</p>
                        </div>

                    </div>
                </section>


                <section class="my-2" data-sec-others>
                    <div class="w-100 bg-secondary">
                        <p class="text-white py-2 px-3 alvin-bgcolor-1">Others</p>
                    </div>
                    <div class="d-flex flex-wrap" data-jar-others>
                        <!-- <p class="text-center w-100">No results found.</p> -->

                        <!-- <div class="m-2 w-11">
                            <div class="card p-2" data-item>
                                <img src="img/docs/Unknown.png" class="card-img-top" alt="...">
                            </div>
                            <p class="text-center mb-0">Pipes</p>
                        </div> -->
                    </div>
                </section>

                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
                <br>


            </section>
        </div>
    </div>

    <!-- <script src="js/home.js"></script> -->
    <script src="js/home.js"></script>

</body>

</html>