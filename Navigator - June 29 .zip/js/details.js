
let data_uploads = new Array();
let data_id;

$(document).ready(function () {

    fnGet_Uploads();

    $('#download').click(function () {
        let a = fnRequest_Data(data_id, "FileName");
        console.log(data_id);
        console.log(a);
        $(this).prop('href', './Storage/Uploads/' + data_id);
    });




    function fnLoad_Details(item) {
        let name = fnRequest_Data(item, "FileName");
        let type = fnRequest_Data(item, "FileType");
        let cats = fnRequest_Data(item, "Categories");
        let tags = fnRequest_Data(item, "Tags");
        let plant = fnRequest_Data(item, "PlantType");
        let project = fnRequest_Data(item, "ProjectName");
        let uploader = fnRequest_Data(item, "Uploader");
        let group = fnRequest_Data(item, "BusinessUnit");
        let remarks = fnRequest_Data(item, "Notes");
        let uploaded = fnRequest_Data(item, "DateUploaded");
        let captured = fnRequest_Data(item, "DateCaptured");
        let forPhotoDB = fnRequest_Data(item, "forPhotoDB");
        forPhotoDB = parseInt(forPhotoDB);

        $('#FileName').text(name);
        fnLoad_Display(item, type);

        if (Array.isArray(cats)) {
            $.each(cats, function (index, value) {
                let add = "<div class='d-flex align-items-center rounded-pill border py-1 px-3 m-1'>";
                add += `<p class='m-0'>${value}</p>`;
                add += "</div>";

                $('#category_container').append(add);
            });
        } else {
            $('#category_container').append('<p class="w-100 text-center text-muted m-0"><i>No Data Found</i></p>');
        }


        if (Array.isArray(tags)) {
            $.each(tags, function (index, value) {
                let add = "<div class='d-flex align-items-center rounded-pill border py-1 px-3 m-1'>";
                add += `<p class='m-0'>${value}</p>`;
                add += "</div>";

                $('#tags_container').append(add);
            });
        } else {
            $('#tags_container').append('<p class="w-100 text-center text-muted m-0"><i>No Data Found</i></p>');
        }


        if (forPhotoDB) {
            $('[data-forPhotoDB]').show();
            $('#projectName').text(project);
            $('#plantType').text(plant);
            $('#location').text();
            $('#dateCaptured').text(captured);
        }

        $('#uploader').text(uploader);
        $('#group').text(group);
        $('#dateUploaded').text(uploaded);
        $('#uploader').text(uploader);
        $('#group').text(group);
        $('#dateUploaded').text(uploaded);
        $('#projectName').text(project);
    }



    function fnLoad_Display(item, type) {

        if(type == "picture"){
            $('#FileImage').attr('src', 'Storage/Uploads/' + item);
        }
        else if(type == "document"){
            let icon;

            let regex = /(?:\.([^.]+))?$/;
            let ext = regex.exec(item)[1];

            switch (ext) {
                case "pdf": icon = "PDF.png"; break;
                case "xlsx": icon = "Excel.png"; break;
                case "ppt": icon = "PPT.png"; break;
                case "pptx": icon = "PPT.png"; break;
                case "doc": icon = "Docx.jpg"; break;
                case "docx": icon = "Docx.jpg"; break;
                case "txt": icon = "txt.png"; break;
                default: icon = "Unknown.png"; break;
            }
            $('#FileImage').attr('src', './img/docs/'+icon);
        }
        else if(type == "video"){
            $('#FileImage').hide();
            $('#filetag_video').show();
            $('#filetag_video video').attr('src', './Storage/Uploads/'+item);
        }
        else{
            $('#FileImage').attr('src', './img/docs/Unknown.png');
        }
    }



    function fnRequest_Data(id, request) {
        let requested;
        $.each(data_uploads, function (index, value) {
            if (value.FileNameDB == id) {
                let cats = (fnCheck_JSON(value.Categories)) ? JSON.parse(value.Categories) : value.Categories;
                let tags = (fnCheck_JSON(value.Tags)) ? JSON.parse(value.Tags) : value.Tags;

                switch (request) {
                    case "FileName": requested = value.FileName; break;
                    case "FileType": requested = value.FileType; break;
                    case "Tags": requested = tags; break;
                    case "Categories": requested = cats; break;
                    case "PlantType": requested = value.PlantType; break;
                    case "ProjectName": requested = value.ProjectName; break;
                    case "Uploader": requested = value.Uploader; break;
                    case "BusinessUnit": requested = value.BusinessUnit; break;
                    case "Notes": requested = value.Notes; break;
                    case "DateUploaded": requested = value.DateUploaded; break;
                    case "DateCaptured": requested = value.DateCaptured; break;
                    case "forPhotoDB": requested = value.forPhotoDB; break;
                    default: requested = "unknown request"; break;
                }
                return false;
            }
        });
        return requested;
    }



    function fnGet_Uploads() {
        $.post("./includes/get_data.php",
            {
                table_name: 'tbl_uploads'
            },
            function (data, status) {
                if (status == "success") {
                    data = JSON.parse(data);
                    data_uploads = data;
                    fnRead_URL(data);
                }
                else {
                    console.log("Details Page: Error on fetching Data from Database");
                }
            });
    }



    function fnCheck_JSON(data) {
        try {
            JSON.parse(data);
        } catch (e) {
            console.log(e);
            return false;
        }
        return true;
    }



    function fnRead_URL(data) {
        let urlParams = new URLSearchParams(window.location.search);
        let hasItem = urlParams.has('Item'); // checks if it has 'changes' on URL parameters
        let item = urlParams.get('Item');

        if (hasItem) {
            $.each(data, function (index, value) {
                let ediwow = value.FileNameDB;
                if (ediwow.includes(item)) {
                    item = value.FileNameDB;
                    data_id = value.FileNameDB;

                    return false;
                }
            });

            fnLoad_Details(item);

        }
    }



}); //Document