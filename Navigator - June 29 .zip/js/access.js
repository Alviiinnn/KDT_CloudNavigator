import Storage from './oop.js';

const stor = new Storage();
console.table(stor.data);


class Hehe extends Storage{


    Hehe(){
        // const stor = new Storage();
        return "Talking";
    }

    function method1(){

    }
}

