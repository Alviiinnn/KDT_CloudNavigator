

class Storage {
    constructor() {
        this.id = [1, 2, 3];

        this.data = {
            1: {
                filename: "Picture.jpg",
                dateuploaded: 2023,
                uploader: "alvin"
            },
            2: {
                filename: "Picture2.jpg",
                dateuploaded: 2024,
                uploader: "alvin2"
            },
            3: {
                filename: "Picture3.jpg",
                dateuploaded: 2025,
                uploader: "alvin3"
            }
        };
    }
}


const stor = new Storage();

console.log(stor.data[1].filename);
stor.id.push(5);

stor.data[5] = {
    filename: "Picture 5", 
    dateuploaded: 2026,
    uploader: "alvin5"
};

console.table(stor.data);