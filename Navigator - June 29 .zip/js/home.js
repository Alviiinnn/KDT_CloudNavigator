
let boboKa = "";
let data_all;

$(document).ready(function () {
    // $('#rootReactVNB').remove();    //WARNING! DO NOT REMOVE THIS. This is an unknown React code inserted inside the HTML Body
    // $('#videoNoteFrameStyle').remove();  //This bug was created when I install plugin to MS Edge Browser

    let data_uploads;
    let data_documents;
    let data_photos;
    let data_videos;
    let data_others;
    let data_bu_hasValue = new Array();
    let data_plant_hasValue = new Array();
    let data_project_hasValue = new Array();
    let current_result = new Array();
    let is_resultAll = true;

    fnRead_URL();

    $(document).on('click', '[data-item]', function () {
        let item = $(this).data('item');
        let maitem = item.split('.');

        window.location.href = "./Details?Item=" + maitem[0];
    });


    $('input[name=search]')
        .on('change', function (e) {
            var val = this.value;
            $('#search_result').html("Showing all results");
            if (val) {
                fnLoad_Results(val);
            } else {
                fnLoad_Home(data_uploads);
            }
        })

        .on('search', function (e) {
            var val = this.value;
            console.log("SEARCHHH");
            // $('#search_result').html("Showing 2");
            // fnLoad_Results(val);
        });



    $('#check_filetype_all').click(function () {

        let any = $('[data-chk-filetype]');
        // console.log(any[0].id);
        if (any.prop('checked') && $(this).prop('checked')) {
            // any.prop('checked', false);  //Gumana pa rin naman kahit nung ni-comment ko
            fnReload_Filter('all');
        }
        if (any.prop('checked', false)) {
            $(this).prop('checked', true);
        }
        $('[data-sec-documents], [data-sec-photos], [data-sec-videos], [data-sec-others]').show();
    });



    $('[data-chk-filetype]').click(() => {
        $('#check_filetype_all').prop('checked', false);
    });



    $('#check_filetype_docu').click(() => {
        let is_checked = $('#check_filetype_docu').is(':checked');
        if (is_checked) {
            let any = $('[data-chk-filetype]:checked').length;
            if (any == 1) {
                $('[data-sec-photos], [data-sec-videos], [data-sec-others]').hide();
            }
            $('[data-sec-documents]').show();
        }
        else {
            $('[data-sec-documents]').hide();
        }

        fnReload_Filter("document");
        
        // console.table(JSON.parse(localStorage.getItem('CNallData')));
    });



    $('#check_filetype_photos').click(() => {
        let is_checked = $('#check_filetype_photos').is(':checked');

        if (is_checked) {
            let any = $('[data-chk-filetype]:checked').length;

            if (any == 1) {
                $('[data-sec-documents], [data-sec-videos], [data-sec-others]').hide();
            }
            $('[data-sec-photos]').show();
        }
        else {
            $('[data-sec-photos]').hide();
        }

        fnReload_Filter("picture");
    });



    $('#check_filetype_videos').click(() => {
        let is_checked = $('#check_filetype_videos').is(':checked');

        if (is_checked) {
            let any = $('[data-chk-filetype]:checked').length;

            if (any == 1) {
                $('[data-sec-documents], [data-sec-photos], [data-sec-others]').hide();
            }
            $('[data-sec-videos]').show();
        }
        else {
            $('[data-sec-videos]').hide();
        }

        fnReload_Filter("video");
    });



    $('#check_filetype_others').click(() => {
        let is_checked = $('#check_filetype_others').is(':checked');

        if (is_checked) {
            let any = $('[data-chk-filetype]:checked').length;

            if (any == 1) {
                $('[data-sec-documents], [data-sec-photos], [data-sec-videos]').hide();
            }
            $('[data-sec-others]').show();
        }
        else {
            $('[data-sec-others]').hide();
        }

        fnReload_Filter("others");
    });



    $(document).on("click", ".vin-filter input[type=checkbox]", function(){
        const is_checked = $(this).is(':checked');
        if(is_checked){
            fnLoad_Result_Category(this.value, $(this).data('category'));
        }
        else{
            fnLoad_Unfilter_Category(this.value, $(this).data('category'));
        }
    });



    $('#clearfilter_home').click(function(){
        $('#check_filetype_all').trigger('click');
        location.reload();
    });







    // CUSTOM FUNCTIONS


    function fnLoad_Defaults() {

        fnGet_Uploads();

        boboKa = BoboBasaPa('newUser');

        // if (boboKa) {
        //     fnGet_Uploads();
        // }
        // else {
        //     window.location.href = "./Login.html";
        // }
    }


    function fnGet_Uploads() {

        // console.time("Uploads");
        $.post("./includes/get_data.php",
            {
                table_name: 'tbl_uploads'
            },
            function (data, status) {
                localStorage.setItem('CNallData', data);
                
                if (status == "success") {
                    if (data != "0 results") {
                        data = JSON.parse(data);
                        data_uploads = data;
                        fnLoad_Home(data);
                        fnLoad_Search(data);
                        fnLoad_Filter_FileType(data);
                        fnLoad_Filter_BU(data_bu_hasValue);
                    }
                    else {
                        $('[data-jar-documents]').append('<p class="text-center w-100">No results found.</p>');
                        $('[data-jar-photos]').append('<p class="text-center w-100">No results found.</p>');
                        $('[data-jar-videos]').append('<p class="text-center w-100">No results found.</p>');
                        $('[data-jar-others]').append('<p class="text-center w-100">No results found.</p>');
                    }
                }
                else {
                    console.log("Home Page: Error on fetching Data from Database");
                }
            }
        );
        // console.timeEnd("Uploads");

        // console.time("Category");
        $.post("./includes/get_data.php",
            {
                table_name: 'tbl_categories'
            },
            function (data, status) {
                if (status == "success") {
                    data = JSON.parse(data);
                    fnLoad_Filter_Categories(data);
                }
                else {
                    console.log("Home Page: Error on fetching Data from Database");
                }
            }
        );
        // console.timeEnd("Category");

    }//end fnGet_Uploads()


    function fnGet_Data_Uploads(){
        $.post("./includes/get_data.php",
        {
            table_name: 'tbl_uploads'
        },
        function (data, status) {
            if (status == "success") {
                if (data != "0 results") {
                    data = JSON.parse(data);
                    data_uploads = data;
                }
            }
            else {
                console.log("Home Page: Error on fetching Data from Database");
            }
        }
    );
    }


    function fnLoad_Home(data) {
        let a = localStorage.getItem('CNallData');
        console.log(JSON.parse(a));
        $('[data-jar-documents]').children().remove();
        $('[data-jar-photos]').children().remove();
        $('[data-jar-videos]').children().remove();
        $('[data-jar-others]').children().remove();

        $('[data-jar-documents]').append('<p class="text-center w-100" data-noresults>No results found.</p>');
        $('[data-jar-photos]').append('<p class="text-center w-100" data-noresults>No results found.</p>');
        $('[data-jar-videos]').append('<p class="text-center w-100" data-noresults>No results found.</p>');
        $('[data-jar-others]').append('<p class="text-center w-100" data-noresults>No results found.</p>');

        data_documents = data.filter(docu => docu.FileType == "document");    //Filter Get whole Row Value


        $.each(data, function (index, value) {

            if (value.Status == "Approved") {
                if (value.FileType == "picture") {
                    let addItem = `<div class='m-2 w-11' data-result='${value.FileNameDB}'>`;
                    addItem += `<div class='card kamay' data-item='${value.FileNameDB}'>`;
                    addItem += `<img src='./Storage/Uploads/${value.FileNameDB}' class='card-img-top' alt='Picture'>`;
                    addItem += "</div>";
                    addItem += `<p class='text-center mb-0'>${value.FileName}</p>`;
                    addItem += "</div>";

                    $('[data-jar-photos] p[data-noresults]').remove();
                    $('[data-jar-photos]').append(addItem);

                }
                else if (value.FileType == "document") {
                    let icon;

                    var regex = /(?:\.([^.]+))?$/;
                    var ext = regex.exec(value.FileNameDB)[1];


                    switch (ext) {
                        case "pdf": icon = "PDF.png"; break;
                        case "xlsx": icon = "Excel.png"; break;
                        case "ppt": icon = "PPT.png"; break;
                        case "pptx": icon = "PPT.png"; break;
                        case "doc": icon = "Docx.jpg"; break;
                        case "docx": icon = "Docx.jpg"; break;
                        case "txt": icon = "txt.png"; break;
                        default: icon = "Unknown.png"; break;
                    }

                    let addItem = `<div class='m-2 w-11' data-result='${value.FileNameDB}'>`;
                    addItem += `<div class='card kamay p-4' data-item='${value.FileNameDB}'>`;
                    addItem += `<img src='img/docs/${icon}' class='card-img-top' alt='Picture'>`;
                    addItem += "</div>";
                    addItem += `<p class='text-center mb-0'>${value.FileName}</p>`;
                    addItem += "</div>";

                    $('[data-jar-documents] p[data-noresults]').remove();
                    $('[data-jar-documents]').append(addItem);

                }
                else if (value.FileType == "video") {
                    let addItem = "";
                    addItem = `<div class='m-2 w-18' data-result='${value.FileNameDB}'>`;
                    addItem += `<div class='card kamay p-2' data-item='${value.FileNameDB}'>`;
                    addItem += "<video controls>";
                    addItem += "<source src='./Storage/Uploads/" + value.FileNameDB + "'>";
                    addItem += "Your browser does not support the video tag.";
                    addItem += "</video>";
                    addItem += "</div>";
                    addItem += `<p class='text-center mb-0'>${value.FileName}</p>`;
                    addItem += "</div>";

                    $('[data-jar-videos] p[data-noresults]').remove();
                    $('[data-jar-videos]').append(addItem);
                }
                else {
                    let addItem = `<div class='m-2 w-11' data-result='${value.FileNameDB}'>`;
                    addItem += `    <div class='card kamay p-2' data-item='${value.FileNameDB}'>`;
                    addItem += "        <img src='img/docs/Unknown.png' class='card-img-top' alt='Unknown'>";
                    addItem += "    </div>";
                    addItem += `    <p class='text-center mb-0'>${value.FileName}</p>`;
                    addItem += "</div>";

                    $('[data-jar-others] p[data-noresults]').remove();
                    $('[data-jar-others]').append(addItem);
                }
            }

        });
    } //fnLoad_Home()



    function fnLoad_AddedFilter(data){

        if(is_resultAll){
            $('[data-jar-documents]').children().remove();
            $('[data-jar-photos]').children().remove();
            $('[data-jar-videos]').children().remove();
            $('[data-jar-others]').children().remove();

            $('[data-jar-documents]').append('<p class="text-center w-100" data-noresults>No results found.</p>');
            $('[data-jar-photos]').append('<p class="text-center w-100" data-noresults>No results found.</p>');
            $('[data-jar-videos]').append('<p class="text-center w-100" data-noresults>No results found.</p>');
            $('[data-jar-others]').append('<p class="text-center w-100" data-noresults>No results found.</p>');

            is_resultAll = false;
        }




        $.each(data, (index, value)=>{
            if(value.Status == "Approved"){
                if(current_result.indexOf(value.FileNameDB) == -1){
                    current_result.push(value.FileNameDB);

                    if(value.FileType == "picture"){
                        let addItem = `<div class='m-2 w-11' data-result='${value.FileNameDB}'>`;
                        addItem += `<div class='card kamay' data-item='${value.FileNameDB}'>`;
                        addItem += `<img src='./Storage/Uploads/${value.FileNameDB}' class='card-img-top' alt='Picture'>`;
                        addItem += "</div>";
                        addItem += `<p class='text-center mb-0'>${value.FileName}</p>`;
                        addItem += "</div>";
    
                        $('[data-jar-photos] p[data-noresults]').remove();
                        $('[data-jar-photos]').append(addItem);
                    }
                    else if (value.FileType == "document") {
                        let icon;
    
                        var regex = /(?:\.([^.]+))?$/;
                        var ext = regex.exec(value.FileNameDB)[1];
    
                        switch (ext) {
                            case "pdf": icon = "PDF.png"; break;
                            case "xlsx": icon = "Excel.png"; break;
                            case "ppt": icon = "PPT.png"; break;
                            case "pptx": icon = "PPT.png"; break;
                            case "doc": icon = "Docx.jpg"; break;
                            case "docx": icon = "Docx.jpg"; break;
                            case "txt": icon = "txt.png"; break;
                            default: icon = "Unknown.png"; break;
                        }
    
                        let addItem = `<div class='m-2 w-11' data-result='${value.FileNameDB}'>`;
                        addItem += `<div class='card kamay p-4' data-item='${value.FileNameDB}'>`;
                        addItem += `<img src='img/docs/${icon}' class='card-img-top' alt='Picture'>`;
                        addItem += "</div>";
                        addItem += `<p class='text-center mb-0'>${value.FileName}</p>`;
                        addItem += "</div>";
    
                        $('[data-jar-documents] p[data-noresults]').remove();
                        $('[data-jar-documents]').append(addItem);
                    }
                    else if (value.FileType == "video") {
                        let addItem = `<div class='m-2 w-18' data-result='${value.FileNameDB}'>`;
                        addItem += `<div class='card kamay p-2' data-item='${value.FileNameDB}'>`;
                        addItem += "<video controls>";
                        addItem += "<source src='./Storage/Uploads/" + value.FileNameDB + "'>";
                        addItem += "Your browser does not support the video tag.";
                        addItem += "</video>";
                        addItem += "</div>";
                        addItem += `<p class='text-center mb-0'>${value.FileName}</p>`;
                        addItem += "</div>";
    
                        $('[data-jar-videos] p[data-noresults]').remove();
                        $('[data-jar-videos]').append(addItem);
                    }
                    else {
                        let addItem = `<div class='m-2 w-11' data-result='${value.FileNameDB}'>`;
                        addItem += `    <div class='card kamay p-2' data-item='${value.FileNameDB}'>`;
                        addItem += "        <img src='img/docs/Unknown.png' class='card-img-top' alt='Unknown'>";
                        addItem += "    </div>";
                        addItem += `    <p class='text-center mb-0'>${value.FileName}</p>`;
                        addItem += "</div>";
    
                        $('[data-jar-others] p[data-noresults]').remove();
                        $('[data-jar-others]').append(addItem);
                    }
                }
            }

        });
    }


    function BoboBasaPa(c_name) {
        if (document.cookie.length > 0) {
            c_start = document.cookie.indexOf(c_name + "=");
            if (c_start != -1) {
                c_start = c_start + c_name.length + 1;
                c_end = document.cookie.indexOf(";", c_start);
                if (c_end == -1) {
                    c_end = document.cookie.length;
                }
                return unescape(document.cookie.substring(c_start, c_end));
            }
        }
        return "";
    }


    function fnLoad_Search(data) {
        let arr_search = new Array();

        $.each(data, function (index, value) {

            if (value.Status == "Approved") {
                let tags = JSON.parse(value.Tags);
                $.each(tags, function (index, value) {
                    arr_search.push(value);
                });

                arr_search.push(value.FileName);
            }

            // UNCOMMENT KAPAG LAHATAN NA
            // arr_search.push(value.PlantType);
            // arr_search.push(value.ProjectName);

            // let tags = JSON.parse(value.Tags); 
            // if(tags != null){
            //     for(i=0; i<tags.length; i++){
            //         arr_search.push(tags[i]);
            //     }
            // }
        });

        // arr_search.sort();  //Not working properly
        arr_search.sort((a, b) => a.localeCompare(b));  //Working fine
        let unique_ito = [...new Set(arr_search)];  //Remove Duplicates

        $.each(unique_ito, function (index, value) {
            let str = `<option>${value}</option>`;
            $('#home_search').append(str);
        });
    }



    function fnLoad_Results(item) {
        let data = data_uploads;
        let arr_result = new Array();
        console.log("Data: ");
        console.table(data);
        $('#search_result').html(`Search result for <b>${item}</b>`);

        $.each(data, function (index, value) {
            if(value.FileName.includes(item)){
                arr_result.push(data[index]);
            }else if(value.Tags != null && value.Tags.includes(item)){
                arr_result.push(data[index]);
            }
            else{}
        });
        fnLoad_Home(arr_result);
    }



    function fnLoad_Result_Category(item, category) {
        let data = data_uploads;
        let arr_result = new Array();
        
        fnAppend_URL(category, item);

        $.each(data, function (index, value) {

            if(value.PlantType != null && value.ProjectName != null){
                if(category == "Plant")
                {
                    if(value.PlantType.includes(item)){
                        arr_result.push(data[index]);
                    }
                }
                else if(category == "Project")
                {
                    if(value.ProjectName.includes(item)){
                        console.log("Push - "+value.FileName);
    
                        arr_result.push(data[index]);
                    }
                }else
                {
                    if(value.Categories.includes(item)){
                        arr_result.push(data[index]);
                    }
                }
            } 

        });

        fnLoad_AddedFilter(arr_result);
    }



    function fnLoad_Unfilter_Category(item, category){
        let data = data_uploads;
        console.table(current_result);
        $.each(current_result, (index, value)=>{
            $(`[data-result="${value}"]`).remove();
        });
        
        // $('[data-result="20230602_132001_6047_E466.sql"]').remove();
        //get ID from Plant Type and Project Name
        // $('[data-result]').remove();
        // console.log($('[data-result]').html());



        // $.each(data, (index, value)=>{
        //     if(category == "Plant"){
        //         if(current_result.indexOf(value.PlantType) != -1){

        //             console.log($('[data-result]').val());
        //             // $('[data]').data('result').val(value.FileNameDB).remove();
        //             console.log(value.FileNameDB);
        //         }
        //     }else if(category == "Project"){

        //     }else{

        //     }
        // });
    }



    function fnLoad_Filter_FileType(data) {
        let ctr_all = 0;
        let ctr_docu = 0;
        let ctr_photos = 0;
        let ctr_videos = 0;
        let ctr_others = 0;

        $.each(data, function (index, value) {
            if (value.Status == "Approved") {
                switch (value.FileType) {
                    case "document": ctr_docu++; break;
                    case "picture": ctr_photos++; break;
                    case "video": ctr_videos++; break;
                    default: ctr_others++; break;
                }
                ctr_all++;
                data_bu_hasValue.push(value.BusinessUnit);
                data_plant_hasValue.push(value.PlantType);
                data_project_hasValue.push(value.ProjectName);
            }
        });

        $('label[for=check_filetype_all]').text(`All (${ctr_all})`);
        $('label[for=check_filetype_docu]').text(`Documents (${ctr_docu})`);
        $('label[for=check_filetype_photos]').text(`Photos (${ctr_photos})`);
        $('label[for=check_filetype_videos]').text(`Videos (${ctr_videos})`);
        $('label[for=check_filetype_others]').text(`Others (${ctr_others})`);
    }



    function fnLoad_Filter_BU(data){
        const counts = {};
        let uniq = [...new Set(data)];  //ES6 native object 'Set'
        
        uniq.sort((a, b) => a.localeCompare(b) );    //ES6 sort
        data.forEach( (x)=> { counts[x] = (counts[x] || 0) + 1; } );

        $.each(uniq, (index, value)=>{
            let bilang = counts[value];

            let addItem = `<div class="form-check">`;
            addItem += `    <input id="filter_bu_${value}" class="form-check-input rarara" type="checkbox" />`;
            addItem += `    <label for="filter_bu_${value}" class="form-check-label">${value} (${bilang})</label>`;
            addItem += `   </div>`;

            $('.checkbox-jar-group').append(addItem);
        });
    }



    function fnLoad_Filter_Categories(data) {
        const counts_plant = {};
        const counts_project = {};
        data_plant_hasValue.forEach(function (x) { counts_plant[x] = (counts_plant[x] || 0) + 1; });
        data_project_hasValue.forEach(function (x) { counts_project[x] = (counts_project[x] || 0) + 1; });

        $.each(data, (index, value) => {
            let name = value.CategoryName;

            if (value.CategoryType == "Plant") {
                let bilangPlant = 0;
                if(~data_plant_hasValue.indexOf(name)){
                    bilangPlant = counts_plant[name];
                    let addItem = `<div class="form-check">
                                    <input id="filter_plant_cat${value.ID}" class="form-check-input" type="checkbox" value="${value.CategoryName}" data-category="Plant"/>
                                    <label for="filter_plant_cat${value.ID}" class="form-check-label">${name} (${bilangPlant})</label>
                                </div>`;
                    $('#filter_plant').after(addItem);
                }
            }

            if (value.CategoryType == "Project") {
                let bilangProject = 0;
                if(~data_project_hasValue.indexOf(name)){
                    bilangProject = counts_project[name];
                    let addItem = `<div class="form-check">
                                    <input id="filter_project_proj${value.ID}" class="form-check-input" type="checkbox" data-category="Project" value="${name}"/>
                                    <label for="filter_project_proj${value.ID}" class="form-check-label">${name} (${bilangProject})</label>
                                </div>`;
                    $('#filter_project').after(addItem);
                }
            }
        });
    }



    function fnReload_Filter(filetype){

        // let any = $('[data-chk-filetype]');
        let count_checked = $('[data-chk-filetype]:checked').length;
        console.log(count_checked);
        if(filetype != "all"){
            if(count_checked == 1){
                $('.checkbox-jar-group').children('div').remove();
            }

            let data = data_uploads.filter((col)=> col.FileType == filetype && col.Status == 'Approved');
            const arrGroup = new Array();
            const counts = {};
    
            $.each(data, (index, value)=>{
                arrGroup.push(value.BusinessUnit);
            });
    
            fnLoad_Filter_BU(arrGroup);
        }
        else{
            fnLoad_Filter_BU(data_bu_hasValue);
        }
    }



    function fnAppend_URL(key, value){
        let urlParams = new URLSearchParams(window.location.search);
        let has_plant = urlParams.has('plant');
        let get_plant = urlParams.get('plant');
        key = key.toLowerCase();
        console.log(has_plant);
        urlParams.append("plant", "hello");
        
        if(has_plant){
            console.log(get_plant);
            window.history.replaceState({}, document.title, "/" + "Navigator?"+key+"="+value); // removes URL Parameters WITHOUT RELOADING the Page

        }else{
            window.history.replaceState({}, document.title, "/" + "Navigator?"+key+"="+value); // removes URL Parameters WITHOUT RELOADING the Page
        }


        // let url = new URL(window.location.href);
        // console.log(url);
        // console.log(url.has('plant'));
        // index = index.toLowerCase();
        // window.history.replaceState({}, document.title, "/" + "Navigator?"+index+"="+key); // removes URL Parameters WITHOUT RELOADING the Page

    }


    function fnRemove_URL(){

    }


    function fnRead_URL() {
        let urlParams = new URLSearchParams(window.location.search);
        let hanap = urlParams.has('search');
        
        if (hanap) {
            let hanapmo = urlParams.get('search');
            fnGet_Data_Uploads();
            fnLoad_Results(hanapmo);
        } else {
            fnLoad_Defaults();
        }
    }


}); //Document




// REFERENCES
// ----------

// let val = data_groups.filter(grp => grp.GroupCode == "ANA");    //Filter Get whole Row Value





// DUMP CODES
// ----------


// const counts = {};

// for(const num of data){
//     counts[num] = counts[num] ? counts[num] + 1 : 1;
// }

// console.log(counts);
// console.table(counts['FileType'][1]);



// function fnLoad_Filter_BU1() {
//     const data = data_bu_hasValue;
//     const dataGrp = data_groups;
//     let uniq = [...new Set(data)]; //ES6 native object 'Set'
//     const counts = {};
    
//     uniq.sort((a, b) => a.localeCompare(b));    //ES6 sort
//     data.forEach(function(x) { counts[x] = (counts[x] || 0) + 1; });
    
//     $.each(uniq, (index, value)=>{
//         let bilang = 0;
//         let temp = dataGrp.filter(grp => grp.GroupCode == value);   
//         console.log(temp);
//         let groupname = temp[0].GroupName;
//         bilang = counts[value];

//         let addItem = `<div class="form-check">`;
//         addItem += `    <input id="filter_bu_${value}" class="form-check-input rarara" type="checkbox" />`;
//         addItem += `    <label for="filter_bu_${value}" class="form-check-label" title="${groupname}">${value} (${bilang})</label>`;
//         addItem += `   </div>`;

//         $('.checkbox-jar-group').append(addItem);
//     });
// }