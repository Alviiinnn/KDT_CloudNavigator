
let data_uploads = new Array();





$(document).ready(function () {

    fLoad_Defaults();

    let tbl = $('[data-table]').DataTable();


    $('[data-table]').on('click', '[data-btn-approve]', function () {
        let row_id = $(this).parents('tr').attr('id');
        if (confirm("Sure ka na?")) {
            fUpdate_Status(row_id, "Approved");
        }
    });


    $('[data-table]').on('click', '[data-btn-reject]', function () {
        let row_id = $(this).parents('tr').attr('id');
        if (confirm("Awts, legit ba?")) {
            fUpdate_Status(row_id, "Rejected");
        }
    });




    function fLoad_Defaults() {
        $.post('../includes/get_data.php',
            {
                table_name: "tbl_uploads"
            },
            function (data, status) {
                data_uploads = JSON.parse(data);
                fLoad_ForChecking();
                fLoad_Approved();
                fLoad_Waiting();
                fLoad_Rejected();

            });
    }



    function fLoad_ForChecking() {
        let tableName = $('[data-table="forReview"]');
        let reqStatus = "For Checking";
        let reqActions =  `<button class="btn btn-primary" data-btn-approve>Approve</button> 
                           <button class="btn btn-danger" data-btn-reject>Reject</button>`;


        fLoad_FileTable(tableName, reqStatus, reqActions);
    }


    function fLoad_Waiting() {
        let tableName = $('[data-table="WaitingToTag"]');
        let reqStatus = "Waiting to Tag";
        let reqActions =  `<button class="btn btn-danger" data-btn-dikoalam>Delete</button>`;

        fLoad_FileTable(tableName, reqStatus, reqActions);
    }


    function fLoad_Approved() {
        let tableName = $('[data-table="Approved"]');
        let reqStatus = "Approved";
        let reqActions =  `<button class="btn btn-primary" data-btn-recheck>Recheck</button>`;

        fLoad_FileTable(tableName, reqStatus, reqActions);
    }


    function fLoad_Rejected() {
        let tableName = $('[data-table="Rejected"]');
        let reqStatus = "Rejected";
        let reqActions =  `<button class="btn btn-primary" data-btn-recheck>Recheck</button>`;

        fLoad_FileTable(tableName, reqStatus, reqActions);
    }


    function fLoad_FileTable(targetTable, status, action){
        let data = data_uploads;
        let tbl = targetTable.DataTable();
        let ctr = 0;

        $.each(data, function (index, value) {
            if (value.Status == status) {
                ctr++;
                var rowNode = tbl
                    .row.add(
                        [
                            ctr,
                            value.FileName,
                            value.Uploader,
                            value.DateUploaded,
                            value.Status,
                            action
                        ]
                    )
                    .draw()
                    .node();

                $(rowNode).attr('id', value.FileNameDB);
            }
        });
    }



    function fUpdate_Status(row_id, stats) {
        $.post("../includes/update.php",
            {
                request: "update_status",
                id: row_id,
                status: stats
            },
            function (data, status) {
                if (data.toLowerCase().indexOf('error') == -1) {
                    location.reload();
                } else {
                    alert("ERROR FOUND: " + data);
                }
            });
    }


});