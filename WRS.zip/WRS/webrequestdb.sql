-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2023 at 04:39 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webrequestdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `business_units`
--

CREATE TABLE `business_units` (
  `ID` int(11) NOT NULL,
  `BUCode` varchar(15) NOT NULL,
  `BUName` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `business_units`
--

INSERT INTO `business_units` (`ID`, `BUCode`, `BUName`) VALUES
(1, 'ACT', 'Accounting Group'),
(2, 'ADM', 'Admin'),
(3, 'ANA', 'Analysis Group'),
(4, 'ASH', 'Ash Handling Group'),
(5, 'CHE', 'Chemical Group'),
(6, 'CIV', 'Civil Group'),
(7, 'CM', 'Cement Group'),
(8, 'CRY', 'Cryogenic Group'),
(9, 'ECS', 'Electrical Control System'),
(10, 'EE1', 'Electrical Engineering 1 '),
(11, 'EE2', 'Electrical Engineering 2'),
(12, 'ENE', 'Energy Group'),
(13, 'ENV', 'Environmental Group'),
(14, 'ETCL', 'EarthTechnica Co., Ltd. Group'),
(15, 'IT', 'IT Group'),
(16, 'MCH', 'Machinery Group'),
(17, 'MH', 'Material Handling Group'),
(18, 'MIL', 'Mill Group'),
(19, 'MNG', 'Managerial Group'),
(20, 'PIP', 'Piping Group'),
(21, 'SYS', 'System Group'),
(22, 'TEG', 'Tunneling Equipment Group'),
(23, 'SHI', 'Ship Group'),
(24, 'EE', 'Electrical Engineering Group'),
(25, 'INT', 'Inventor Team');

-- --------------------------------------------------------

--
-- Table structure for table `control_locationpath`
--

CREATE TABLE `control_locationpath` (
  `ID` int(11) NOT NULL,
  `PathName` varchar(50) NOT NULL,
  `LocationPath` varchar(255) NOT NULL DEFAULT '-'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `control_locationpath`
--

INSERT INTO `control_locationpath` (`ID`, `PathName`, `LocationPath`) VALUES
(1, 'Initial Path', '//kdt-ph/c/WRS/UPLOADS'),
(2, 'Finish Public Path', '-'),
(3, 'Finish System Path', '//kdt-ph/c/WRS/PROJECTS'),
(4, 'Finish BU Path', '-'),
(5, '01 Application', '//157.116.72.26/WebRequest/WRS/PROJECTS/01 Application'),
(6, '02 CATIA', '//157.116.72.26/WebRequest/WRS/PROJECTS/02 CATIA'),
(7, '03 Microsoft Excel', '//157.116.72.26/WebRequest/WRS/PROJECTS/03 Microsoft Excel'),
(8, '04 AVEVA Marine', '//157.116.72.26/WebRequest/WRS/PROJECTS/04 AVEVA Marine'),
(9, '05 Autocad', '//157.116.72.26/WebRequest/WRS/PROJECTS/05 Autocad'),
(10, '06 Arduino', '//157.116.72.26/WebRequest/WRS/PROJECTS/06 Arduino'),
(11, '07 PDMS', '//157.116.72.26/WebRequest/WRS/PROJECTS/07 PDMS'),
(12, '08 Mobile Development', '//157.116.72.26/WebRequest/WRS/PROJECTS/08 Mobile Development'),
(13, '09 Web Development', '//157.116.72.26/WebRequest/WRS/PROJECTS/09 Web Development');

-- --------------------------------------------------------

--
-- Table structure for table `employee_list`
--

CREATE TABLE `employee_list` (
  `ID` int(11) NOT NULL,
  `EmployeeID` int(10) NOT NULL,
  `FullName` varchar(50) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `UserName` varchar(30) NOT NULL,
  `PC` varchar(20) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `BusinessUnit` varchar(50) NOT NULL,
  `Designation` varchar(20) NOT NULL,
  `AccessType` int(3) NOT NULL,
  `Access` varchar(15) NOT NULL DEFAULT 'Viewer',
  `UploadControl` text NOT NULL DEFAULT 'OFF',
  `ExportControl` text NOT NULL DEFAULT 'OFF',
  `RefreshStatus` varchar(10) NOT NULL DEFAULT '-',
  `RefreshStatusAdmin` varchar(10) NOT NULL DEFAULT '-'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee_list`
--

INSERT INTO `employee_list` (`ID`, `EmployeeID`, `FullName`, `FirstName`, `LastName`, `Gender`, `UserName`, `PC`, `Email`, `BusinessUnit`, `Designation`, `AccessType`, `Access`, `UploadControl`, `ExportControl`, `RefreshStatus`, `RefreshStatusAdmin`) VALUES
(1, 7, 'LAUREANO_TONI', 'TONI', 'LAUREANO', 'Male', 'toni', 'KDTW242', 'laureano-kdt@corp.khi.co.jp', 'ADM', 'SM', 4, 'Viewer', 'OFF', 'OFF', '-', '-'),
(2, 8, 'PANADO_VAN', 'VAN', 'PANADO', 'Female', 'van', 'KDTW241', 'panado-g1@hg.khi.co.jp', 'ADM/DRIVER', 'DM', 3, 'Viewer', 'OFF', 'OFF', '-', '-'),
(3, 10, 'TAN_ERWIN', 'ERWIN', 'TAN', 'Male', 'khi', 'KDTW280', 'tan-g1@hg.khi.co.jp', 'ANA/ADM/CIV/ECS/PIP/IT/SYS', 'SM', 4, 'Requestor', 'OFF', 'OFF', 'DONE', 'DONE'),
(4, 18, 'MATIBAG_WILSON', 'WILSON', 'MATIBAG', 'Male', 'wilson', 'KDTW281', 'matibag-kdt@corp.khi.co.jp', 'ANA/CIV/PIP/IT/SYS', 'DM', 3, 'Viewer', 'OFF', 'OFF', '-', '-'),
(5, 25, 'DERIGAY_OLIVER', 'OLIVER', 'DERIGAY', 'Male', 'OLIVER', 'KDTW292', 'derigay-g1@hg.khi.co.jp', 'CHE/CRY', 'DM', 3, 'Requestor', 'ON', 'OFF', 'DONE', '-'),
(6, 30, 'ABUAN_FHER', 'FHER', 'ABUAN', 'Male', 'fher', 'KDTW363', 'abuan-kdt@corp.khi.co.jp', 'TEG/ASH/MH', 'DM', 3, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(7, 37, 'LLANES_FERDINAND', 'FERDINAND', 'LLANES', 'Male', 'llanes', 'KDTW283', 'llanes-kdt@corp.khi.co.jp', 'ENE', 'AM', 2, 'Requestor', 'ON', 'OFF', 'DONE', '-'),
(8, 40, 'CABELLO_ARISTEO', 'ARISTEO', 'CABELLO', 'Male', 'aris', 'KDTW313', 'cabello-kdt@corp.khi.co.jp', 'CHE/ENV', 'AM', 2, 'Viewer', 'OFF', 'OFF', '-', '-'),
(9, 43, 'AMPIG_ROMMEL', 'ROMMEL', 'AMPIG', 'Male', 'rommel', 'KDTW328', 'ampig-kdt@corp.khi.co.jp', 'MIL', 'AM', 2, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(10, 55, 'PEREZ_APRIL', 'APRIL', 'PEREZ', 'Female', 'april', '', 'perez-kdt@corp.khi.co.jp', 'ACT', '', 4, 'Viewer', 'OFF', 'OFF', '-', '-'),
(11, 61, 'BALISBIS JR._CEZAR', 'CEZAR', 'BALISBIS JR.', 'Male', 'czar', 'KDTW298', 'balisbis-kdt@corp.khi.co.jp', 'ANA/SYS/IT', 'AM', 2, 'Admin', 'ON', 'OFF', 'DONE', 'DONE'),
(12, 101, 'SORIANO_SHARON ANN', 'SHARON ANN', 'SORIANO', 'Female', 'anne', 'KDTN009', 'soriano-kdt@corp.khi.co.jp', 'ADM', '', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(13, 104, 'VELOSO_ERNESTO LOU', 'ERNESTO LOU', 'VELOSO', 'Male', 'LOU', 'KDTW220', 'veloso-kdt@corp.khi.co.jp', 'MNG/ENV/ENE', 'SM', 4, 'Viewer', 'OFF', 'OFF', '-', '-'),
(14, 107, 'DIAZ_LORENZO', 'LORENZO', 'DIAZ', 'Male', 'etuc', 'KDTW314', 'diaz-kdt@corp.khi.co.jp', 'CM/ETCL/MCH', 'AM', 4, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(15, 117, 'VITALICIO_MAE ANNE', 'MAE ANNE', 'VITALICIO', 'Female', 'mae', 'KDTW309', 'vitalicio-kdt@corp.khi.co.jp', 'TEG', 'SSV', 2, 'Viewer', 'OFF', 'OFF', '-', '-'),
(16, 122, 'MAGNO_ARLENE', 'ARLENE', 'MAGNO', 'Female', 'arlene', 'KDTW239', 'magno-kdt@corp.khi.co.jp', 'ADM', 'ADE', 1, 'Viewer', 'OFF', 'OFF', '-', '-'),
(17, 134, 'BECINA_ARTEMIO ROEL', 'ARTEMIO ROEL', 'BECINA', 'Male', 'brix', 'KDTW222', 'becina-kdt@corp.khi.co.jp', 'ECS/EE', 'AM', 2, 'Viewer', 'OFF', 'OFF', '-', '-'),
(18, 145, 'BARADAS_RYAN', 'RYAN', 'BARADAS', 'Male', 'ryan', 'KDTW271', 'baradas-kdt@corp.khi.co.jp', 'CRY', 'SSV', 2, 'Viewer', 'OFF', 'OFF', '-', '-'),
(19, 158, 'VALDEZ_RAMIR', 'RAMIR', 'VALDEZ', 'Male', 'ramir', 'KDTW326', 'valdez-kdt@corp.khi.co.jp', 'ECS/EE', 'DM', 3, 'Viewer', 'OFF', 'OFF', '-', '-'),
(20, 172, 'VIRAY_JERMAINE', 'JERMAINE', 'VIRAY', 'Female', 'maine', 'KDTW316', 'marasigan-kdt@corp.khi.co.jp', 'MH/ASH', 'SV', 2, 'Viewer', 'OFF', 'OFF', '-', '-'),
(21, 173, 'AGUILAR_JOHN ISAAC', 'JOHN ISAAC', 'AGUILAR', 'Male', 'ice', 'KDTW340', 'aguilar-kdt@corp.khi.co.jp', 'ECS/EE', 'SSV', 2, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(22, 174, 'APOSTOL_ROEL BOY', 'ROEL BOY', 'APOSTOL', 'Male', 'roel', 'KDTW359', 'apostol-kdt@corp.khi.co.jp', 'ECS/EE', 'SSV', 2, 'Viewer', 'OFF', 'OFF', '-', '-'),
(23, 185, 'DE JESUS_RYAN', 'RYAN', 'DE JESUS', 'Male', 'ryanm', 'KDTW265', 'dejesus-kdt@corp.khi.co.jp', 'PIP', 'SV', 2, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(24, 194, 'CASTUERA_MAXWELL', 'MAXWELL', 'CASTUERA', 'Male', 'max', 'KDTW295', 'castuera-kdt@corp.khi.co.jp', 'ASH/MH', 'SV', 2, 'Viewer', 'OFF', 'OFF', '-', '-'),
(25, 209, 'LEAL JR._ERNESTO', 'ERNESTO', 'LEAL JR.', 'Male', 'ernesto', 'KDTW356', 'leal-kdt@corp.khi.co.jp', 'CM/ETCL/MCH', 'SV', 1, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(26, 212, 'LAZARO_EDMON', 'EDMON', 'LAZARO', 'Male', 'edmon', 'KDTW226', 'lazaro-kdt@corp.khi.co.jp', 'SYS', 'SV', 4, 'Developer', 'OFF', 'ON', 'DONE', 'DONE'),
(27, 215, 'PALMONES_MICHAEL', 'MICHAEL', 'PALMONES', 'Male', 'michaelp', 'KDTW293', 'palmones-kdt@corp.khi.co.jp', 'CM', 'SV', 1, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(28, 221, 'CAMATO JR._GERARDO', 'GERARDO', 'CAMATO JR.', 'Male', 'gerard', 'KDTW276', 'camato-kdt@corp.khi.co.jp', 'ENV', 'SV', 1, 'Viewer', 'OFF', 'OFF', '-', '-'),
(29, 222, 'BELTRAN_JEFFREY', 'JEFFREY', 'BELTRAN', 'Male', 'jeffrey', 'KDTW365', 'beltran-kdt@corp.khi.co.jp', 'MIL', 'SV', 1, 'Viewer', 'OFF', 'OFF', '-', '-'),
(30, 223, 'PAHEL_JOBERT', 'JOBERT', 'PAHEL', 'Male', 'jobert', 'KDTW245', 'pahel-kdt@corp.khi.co.jp', 'MIL', 'SV', 2, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(31, 224, 'DESOLOC_BLESSEL', 'BLESSEL', 'DESOLOC', 'Female', 'bles', 'KDTW282', 'desoloc-kdt@corp.khi.co.jp', 'ENV', 'SV', 1, 'Requestor', 'OFF', 'OFF', '-', '-'),
(32, 226, 'GULAPA_FRANCIS MARTEE', 'FRANCIS MARTEE', 'GULAPA', 'Male', 'martee', 'KDTW339', 'gulapa-kdt@corp.khi.co.jp', 'ECS', 'SV', 2, 'Requestor', 'ON', 'OFF', 'DONE', '-'),
(33, 230, 'OLIVEROS_MARK ANTHONY', 'MARK ANTHONY', 'OLIVEROS', 'Male', 'mark', 'KDTW297', 'oliveros-kdt@corp.khi.co.jp', 'ASH/MH', 'SDE', 2, 'Viewer', 'OFF', 'OFF', '-', '-'),
(34, 238, 'SESE_JOSEPH FERDINAND', 'JOSEPH FERDINAND', 'SESE', 'Male', 'sese', 'KDTW325', 'sese-kdt@corp.khi.co.jp', 'ENV', 'SV', 1, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(35, 243, 'MIRANDA_CHRISTIAN JAY', 'CHRISTIAN JAY', 'MIRANDA', 'Male', 'christian', 'KDTW258', 'miranda-kdt@corp.khi.co.jp', 'CM', 'DE2', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(36, 252, 'ARANETA_REX', 'REX', 'ARANETA', 'Male', 'rex-al', 'KDTW333', 'araneta-kdt@corp.khi.co.jp', 'CIV', 'SDE', 2, 'Requestor', 'ON', 'OFF', 'DONE', '-'),
(37, 256, 'SAHAGUN_MICHELLE', 'MICHELLE', 'SAHAGUN', 'Female', 'cheng', 'KDTW355', 'canalda-kdt@corp.khi.co.jp', 'CM', 'DE2', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(38, 257, 'ONOD_ABEEL', 'ABEEL', 'ONOD', 'Male', 'abel', 'KDTW252', 'onod-kdt@corp.khi.co.jp', 'MIL', 'DE3', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(39, 259, 'LUCENA_REY', 'REY', 'LUCENA', 'Male', 'rey', 'KDTW213', 'lucena-kdt@corp.khi.co.jp', 'CM', 'DE3', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(40, 260, 'VERANO_RONALD', 'RONALD', 'VERANO', 'Male', 'rv', 'KDTW233', 'verano-kdt@corp.khi.co.jp', 'ETCL', 'DE3', 1, 'Viewer', 'OFF', 'OFF', '-', '-'),
(41, 261, 'VILLAMOR_AMOR', 'AMOR', 'VILLAMOR', 'Male', 'amor', 'KDTW235', 'villamor-kdt@corp.khi.co.jp', 'CHE', 'SV', 2, 'Requestor', 'ON', 'OFF', 'DONE', '-'),
(42, 262, 'CANTARA_MARK JOEL', 'MARK JOEL', 'CANTARA', 'Male', 'cantara', 'KDTW310', 'cantara-kdt@corp.khi.co.jp', 'TEG', 'DE3', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(43, 263, 'PASCUA_HENRY', 'HENRY', 'PASCUA', 'Male', 'henry', 'KDTW231', 'pascua-kdt@corp.khi.co.jp', 'MH/ASH', 'DE3', 2, 'Viewer', 'OFF', 'OFF', '-', '-'),
(44, 264, 'CULAR_GIULIAN LOUIS', 'GIULIAN LOUIS', 'CULAR', 'Male', 'louis', 'KDTW219', 'cular-kdt@corp.khi.co.jp', 'CRY', 'DE2', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(45, 265, 'ONOD_AMALIA', 'AMALIA', 'ONOD', 'Female', 'amie', 'KDTW263', 'nodalo-kdt@corp.khi.co.jp', 'ENV', 'DE2', 1, 'Viewer', 'OFF', 'OFF', '-', '-'),
(46, 268, 'SANDOVAL_DAN CHRISTIAN', 'DAN CHRISTIAN', 'SANDOVAL', 'Male', 'sandoval', 'KDTW278', 'sandoval-kdt@corp.khi.co.jp', 'PIP', 'SV', 2, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(47, 270, 'CARINGAL_CARLO', 'CARLO', 'CARINGAL', 'Male', 'carlo', 'KDTW277', 'caringal-kdt@corp.khi.co.jp', 'PIP', 'SV', 2, 'Viewer', 'OFF', 'OFF', '-', '-'),
(48, 272, 'CAVEIRO_VINCENT', 'VINCENT', 'CAVEIRO', 'Male', 'vince', 'KDTW279', 'caveiro-kdt@corp.khi.co.jp', 'PIP', 'DE3', 1, 'Viewer', 'OFF', 'OFF', '-', '-'),
(49, 279, 'PANOPIO_LUISITO', 'LUISITO', 'PANOPIO', 'Male', 'lpanopio', 'KDTW232', 'panopio-kdt@corp.khi.co.jp', 'ASH/MH', 'DE3', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(50, 281, 'CURA_LEONARD RYAN', 'LEONARD RYAN', 'CURA', 'Male', 'cura', 'KDTW254', 'cura-kdt@corp.khi.co.jp', 'CHE', 'SV', 2, 'Viewer', 'OFF', 'OFF', '-', '-'),
(51, 283, 'CENIZAL_MARIA VANGIE', 'MARIA VANGIE', 'CENIZAL', 'Female', 'adami', 'KDTW291', 'adami-kdt@corp.khi.co.jp', 'EE', 'DE2', 1, 'Viewer', 'OFF', 'OFF', '-', '-'),
(52, 284, 'CIDRO_JAMES ERIC', 'JAMES ERIC', 'CIDRO', 'Male', 'james', 'KDTW380', 'cidro-kdt@corp.khi.co.jp', 'ECS/EE', 'DE2', 1, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(53, 288, 'GODOY_JHON RAY', 'JHON RAY', 'GODOY', 'Male', 'jhon', 'KDTW268', 'godoy-kdt@corp.khi.co.jp', 'EE', 'DE2', 0, 'Viewer', 'ON', 'OFF', '-', '-'),
(54, 290, 'ARIAP_JOMANIL', 'JOMANIL', 'ARIAP', 'Male', 'joma', 'KDTW366', 'ariap-kdt@corp.khi.co.jp', 'CRY', 'DE2', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(55, 291, 'LLOSALA_ROWEL', 'ROWEL', 'LLOSALA', 'Male', 'rowel', 'KDTW257', 'llosala-kdt@corp.khi.co.jp', 'CHE', 'DE2', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(56, 293, 'DIMAAPI_JASPER', 'JASPER', 'DIMAAPI', 'Male', 'jasper', 'KDTW256', 'dimaapi-kdt@corp.khi.co.jp', 'ETCL', 'DE2', 1, 'Viewer', 'OFF', 'OFF', '-', '-'),
(57, 296, 'MACALALAD_JOSEPH MICHAEL', 'JOSEPH MICHAEL', 'MACALALAD', 'Male', 'macalalad', 'KDTW324', 'macalalad-kdt@corp.khi.co.jp', 'ENV', 'SSV', 2, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(58, 295, 'MORENO_REX', 'REX', 'MORENO', 'Male', 'moreno', 'KDTW317', 'moreno-kdt@corp.khi.co.jp', 'MH/ASH', 'SV', 2, 'Requestor', 'ON', 'OFF', 'DONE', '-'),
(59, 299, 'CANO_BRYAN JAY', 'BRYAN JAY', 'CANO', 'Male', 'bryan', 'KDTW284', 'cano-kdt@corp.khi.co.jp', 'ENE', 'DE2', 2, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(60, 301, 'LINA_DOMINADOR JOSHUA', 'DOMINADOR JOSHUA', 'LINA', 'Male', 'joshua', 'KDTW214', 'lina-kdt@corp.khi.co.jp', 'ENE', 'DE2', 2, 'Viewer', 'OFF', 'OFF', '-', '-'),
(61, 302, 'SAMPAGA_LOUIE', 'LOUIE', 'SAMPAGA', 'Male', 'sampaga', 'KDTW269', 'sampaga-kdt@corp.khi.co.jp', 'EE', 'DE2', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(62, 304, 'MUNDO_DAISY', 'DAISY', 'MUNDO', 'Female', 'daisy', 'KDTW357', 'mundo-kdt@corp.khi.co.jp', 'ENV/CHE', 'DE1', 1, 'Viewer', 'OFF', 'OFF', '-', '-'),
(63, 305, 'ESCUETA_RODERICK', 'RODERICK', 'ESCUETA', 'Male', 'roderick', 'KDTW305', 'escueta-kdt@corp.khi.co.jp', 'PIP', 'DE2', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(64, 306, 'BELEN_KERVIN', 'KERVIN', 'BELEN', 'Male', 'kervin', 'KDTW304', 'belen-kdt@corp.khi.co.jp', 'PIP', 'DE2', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(65, 307, 'MENDOZA_VERONICA', 'VERONICA', 'MENDOZA', 'Female', 'vec', 'KDTW382', 'mendoza-kdt@corp.khi.co.jp', 'IT', 'SV', 4, 'Admin', 'ON', 'ON', 'DONE', 'DONE'),
(66, 310, 'TUMAOB_FERDINAND', 'FERDINAND', 'TUMAOB', 'Male', 'tommy', 'KDTW315', 'tumaob-kdt@corp.khi.co.jp', 'MIL', 'DE2', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(67, 311, 'PENETRANTE JR._JORGE', 'JORGE', 'PENETRANTE JR.', 'Male', 'jorge', 'KDTW244', 'penetrante-kdt@corp.khi.co.jp', 'ENE', 'DE2', 2, 'Viewer', 'OFF', 'OFF', '-', '-'),
(68, 312, 'LUCAS_ADEL', 'ADEL', 'LUCAS', 'Male', 'adel', 'KDTW372', 'lucas-kdt@corp.khi.co.jp', 'ENE', 'DE2', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(69, 313, 'AGUSTINES_ALBERT', 'ALBERT', 'AGUSTINES', 'Male', 'albert', 'KDTW358', 'agustines-kdt@corp.khi.co.jp', 'EE', 'DE2', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(70, 314, 'SANGALANG_DICKENSON', 'DICKENSON', 'SANGALANG', 'Male', 'dickenson', 'KDTW208', 'sangalang_d-kdt@corp.khi.co.jp', 'EE', 'DE2', 0, 'Requestor', 'OFF', 'OFF', 'DONE', '-'),
(71, 316, 'BAUTISTA JR._CELSO', 'CELSO', 'BAUTISTA JR.', 'Male', 'cj', 'KDTW296', 'bautista-kdt@corp.khi.co.jp', 'TEG', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(72, 320, 'ESCUETA JR._JUANITO', 'JUANITO', 'ESCUETA JR.', 'Male', 'jeckzay', 'KDTW299', 'escueta_j-kdt@corp.khi.co.jp', 'EE', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(73, 321, 'BIGTAS_KEITH CHARM', 'KEITH CHARM', 'BIGTAS', 'Female', 'charm', 'KDTW300', 'bigtas-kdt@corp.khi.co.jp', 'EE', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(74, 322, 'DELAROSA_ESTER', 'ESTER', 'DELAROSA', 'Female', 'ester', 'KDTW327', 'delarosa-kdt@corp.khi.co.jp', 'ECS/EE', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(75, 323, 'BORLAGON_ALVIN JAN', 'ALVIN JAN', 'BORLAGON', 'Male', 'vhin', 'KDTW371', 'borlagon-kdt@corp.khi.co.jp', 'ENE', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(76, 328, 'CALLEJA_NOMER', 'NOMER', 'CALLEJA', 'Male', 'nomer', 'KDTW370', 'calleja-kdt@corp.khi.co.jp', 'ENE', 'DE1', 1, 'Viewer', 'OFF', 'OFF', '-', '-'),
(77, 329, 'MARQUESES_JEFF EDWARD', 'JEFF EDWARD', 'MARQUESES', 'Male', 'je', 'KDTW285', 'marqueses_j-kdt@corp.khi.co.jp', 'ENE', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(78, 330, 'OMIZ_GILBERT JASON', 'GILBERT JASON', 'OMIZ', 'Male', 'bert', 'KDTW323', 'omiz-kdt@corp.khi.co.jp', 'PIP', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(79, 332, 'DE GUZMAN_CHRISTOPHER', 'CHRISTOPHER', 'DE GUZMAN', 'Male', 'chrisdegz', 'KDTW290', 'deguzman-kdt@corp.khi.co.jp', 'ENV', 'DE1', 1, 'Viewer', 'OFF', 'OFF', '-', '-'),
(80, 333, 'MATAUM_MICHAEL', 'MICHAEL', 'MATAUM', 'Male', 'kel', 'KDTW322', 'mataum-kdt@corp.khi.co.jp', 'PIP', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(81, 334, 'MIRANDA_JULEMIR', 'JULEMIR', 'MIRANDA', 'Male', 'jhun', 'KDTW262', 'miranda_j-kdt@corp.khi.co.jp', 'ENV', 'DE1', 1, 'Viewer', 'OFF', 'OFF', '-', '-'),
(82, 335, 'BALLON_AL JOHN', 'AL JOHN', 'BALLON', 'Male', 'aljohn', 'KDTW318', 'ballon-kdt@corp.khi.co.jp', 'TEG', 'DE1', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(83, 338, 'BULAN JR._ROSBELT', 'ROSBELT', 'BULAN JR.', 'Male', 'ross', 'KDTW301', 'bulan-kdt@corp.khi.co.jp', 'ENV', 'DE1', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(84, 343, 'RUBICO_RIZZIEL', 'RIZZIEL', 'RUBICO', 'Unknown', 'rizziel', 'KDTW289', 'rubico-kdt@corp.khi.co.jp', 'TEG', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(85, 344, 'PATRON_EDILAINE MAROSE', 'EDILAINE MAROSE', 'PATRON', 'Female', 'em', 'KDTW331', 'patron-kdt@corp.khi.co.jp', 'CHE', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(86, 345, 'CAUNGA_RUSTUM OLIVER', 'RUSTUM OLIVER', 'CAUNGA', 'Male', 'rocaunga', 'KDTW347', 'caunga-kdt@corp.khi.co.jp', 'CRY', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(87, 346, 'MIRABEL_MARIE ELEONOR', 'MARIE ELEONOR', 'MIRABEL', 'Female', 'yhelle', 'KDTW350', 'mirabel-kdt@corp.khi.co.jp', 'ECS/EE', 'DE1', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(88, 348, 'TOBIAS_JEOFFER', 'JEOFFER', 'TOBIAS', 'Male', 'jltobias', 'KDTW329', 'tobias-kdt@corp.khi.co.jp', 'ENV', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(89, 350, 'CAJES_JOSEPH', 'JOSEPH', 'CAJES', 'Male', 'josephcc', 'KDTW368', 'cajes-kdt@corp.khi.co.jp', 'CRY', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(90, 352, 'DUCAY_JOHN DAVID', 'JOHN DAVID', 'DUCAY', 'Male', 'johndavid', 'KDTW294', 'ducay-kdt@corp.khi.co.jp', 'ENV', 'DE1', 0, 'Requestor', 'ON', 'OFF', '-', '-'),
(91, 353, 'TORIO_RAFFY', 'RAFFY', 'TORIO', 'Male', 'raffy', 'KDTW351', 'torio-kdt@corp.khi.co.jp', 'SYS', 'SSE', 4, 'Developer', 'ON', 'ON', 'DONE', 'DONE'),
(92, 355, 'DE JESUS_JOMMUEL', 'JOMMUEL', 'DE JESUS', 'Male', 'jommuel', 'KDTW395', 'dejesus_j-kdt@corp.khi.co.jp', 'SYS', 'DE3', 4, 'Developer', 'OFF', 'OFF', 'DONE', 'DONE'),
(93, 356, 'CABRADILLA_LIAN MARIE', 'LIAN MARIE', 'CABRADILLA', 'Female', 'lian', 'KDTW349', 'cabradilla-kdt@corp.khi.co.jp', 'EE', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(94, 357, 'SANAO_JOMARI', 'JOMARI', 'SANAO', 'Male', 'jomari', 'KDTW337', 'sanao-kdt@corp.khi.co.jp', 'PIP', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(95, 358, 'SANAO_ROXANNE', 'ROXANNE', 'SANAO', 'Female', 'xanxane', 'KDTW336', 'velez-kdt@corp.khi.co.jp', 'PIP', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(96, 363, 'AGON_MARK PAUL', 'MARK PAUL', 'AGON', 'Male', 'paul', 'KDTW250', 'agon-kdt@corp.khi.co.jp', 'ENV/CHE', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(97, 364, 'BITANG_KIMBRIAN', 'KIMBRIAN', 'BITANG', 'Male', 'Kimbrian', 'KDTW393', 'bitang-kdt@corp.khi.co.jp', 'ENV', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(98, 365, 'DIMACULANGAN_LARA JOY', 'LARA JOY', 'DIMACULANGAN', 'Male', 'lara', 'KDTW286', 'dimaculangan-kdt@corp.khi.co.jp', 'ENV', 'DE1', 1, 'Viewer', 'OFF', 'OFF', '-', '-'),
(99, 367, 'MENDOZA_MARCIAL', 'MARCIAL', 'MENDOZA', 'Male', 'marci', 'KDTW264', 'mendoza_m-kdt@corp.khi.co.jp', 'ENV', 'DE1', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(100, 370, 'NOPRA_CANDY', 'CANDY', 'NOPRA', 'Female', 'candy', 'KDTW381', 'nopra-kdt@corp.khi.co.jp', 'IT', 'IT-E3', 4, 'Admin', 'ON', 'ON', 'DONE', '-'),
(101, 371, 'CORDOVA_YSABEL', 'YSABEL', 'CORDOVA', 'Female', 'ysay', 'KDTW288', 'cordova-kdt@corp.khi.co.jp', 'TEG', 'ADE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(102, 372, 'FRANE_GERALD CHRISTOPHER', 'GERALD CHRISTOPHER', 'FRANE', 'Male', 'gerald', 'KDTW249', 'frane-kdt@corp.khi.co.jp', 'ECS/EE', 'ADE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(103, 373, 'SABARILLO_NELMAR BONG', 'NELMAR BONG', 'SABARILLO', 'Male', 'bong', 'KDTW330', 'sabarillo-kdt@corp.khi.co.jp', 'CRY', 'ADE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(104, 374, 'FORTUS_DOMINI', 'DOMINI', 'FORTUS', 'Male', 'domini', 'KDTW273', 'fortus-kdt@corp.khi.co.jp', 'TEG', 'ADE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(105, 375, 'ILAGAN_ANGELLE', 'ANGELLE', 'ILAGAN', 'Female', 'angelle', 'KDTW230', 'ilagan-kdt@corp.khi.co.jp', 'MH', 'ADE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(106, 376, 'VALLESTERO_KAREN LORRAINE', 'KAREN LORRAINE', 'VALLESTERO', 'Female', 'karenv', 'KDTW261', 'vallestero-kdt@corp.khi.co.jp', 'EE', 'ADE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(107, 377, 'GUICO_ALDRIN', 'ALDRIN', 'GUICO', 'Male', 'gibo', 'KDTW342', 'guico-kdt@corp.khi.co.jp', 'MH', 'ADE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(108, 378, 'REYES_JENNELYN', 'JENNELYN', 'REYES', 'Female', 'jhen', 'KDTW341', 'reyes_j-kdt@corp.khi.co.jp', 'MH', 'ADE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(109, 381, 'FLORES_ANGELO', 'ANGELO', 'FLORES', 'Male', 'gelo', 'KDTW308', 'flores_a-kdt@corp.khi.co.jp', 'TEG', 'ADE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(110, 382, 'MARQUEZ_ARVIN DAVID', 'ARVIN DAVID', 'MARQUEZ', 'Male', 'arvin', 'KDTW259', 'marquez-kdt@corp.khi.co.jp', 'CIV', 'ADE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(111, 383, 'BELLEN_ABEGAIL', 'ABEGAIL', 'BELLEN', 'Female', 'bellenabi', 'KDTW345', 'bellen-kdt@corp.khi.co.jp', 'CIV', 'ADE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(112, 384, 'GALLARDO_AL SHARIFF', 'AL SHARIFF', 'GALLARDO', 'Male', 'al', 'KDTW378', 'gallardo-kdt@corp.khi.co.jp', 'ANA', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(113, 385, 'PEREZ_JEREMIA', 'JEREMIA', 'PEREZ', 'Female', 'mia', 'KDTW346', 'perez_j-kdt@corp.khi.co.jp', 'CIV', 'ADE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(114, 386, 'TAN_DENNIS', 'DENNIS', 'TAN', 'Male', 'dennistan', 'KDTW', 'tan_d-kdt@corp.khi.co.jp', 'MCH', 'ADE', 1, 'Viewer', 'OFF', 'OFF', '-', '-'),
(115, 387, 'BALGOMA_RAMIL', 'RAMIL', 'BALGOMA', 'Male', 'rbalgoma', 'KDTW307', 'balgoma-kdt@corp.khi.co.jp', 'MH', 'ADE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(116, 388, 'GUPIT_BERNICO', 'BERNICO', 'GUPIT', 'Male', 'bernico', 'KDTW362', 'gupit-kdt@corp.khi.co.jp', 'ASH/MH', 'ADE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(117, 389, 'MIRANDA_NIKKO', 'NIKKO', 'MIRANDA', 'Male', 'nikkomiranda', 'KDTW352', 'miranda_n-kdt@corp.khi.co.jp', 'MCH', 'DE2', 1, 'Viewer', 'OFF', 'OFF', '-', '-'),
(118, 390, 'GARCIA_CHRISTIAN JOSEPH', 'CHRISTIAN JOSEPH', 'GARCIA', 'Male', 'cmgarcia', 'KDTW375', 'garcia_c-kdt@corp.khi.co.jp', 'ENV', 'ADE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(119, 391, 'AUSTRIA_CATHERINE', 'CATHERINE', 'AUSTRIA', 'Female', 'catherine', '', 'austria-kdt@corp.khi.co.jp', 'ACT', '', 4, 'Viewer', 'OFF', 'OFF', '-', '-'),
(120, 393, 'DE SOTTO_FRANCIS JOHN', 'FRANCIS JOHN', 'DE SOTTO', 'Male', 'francis', '', 'desotto-kdt@corp.khi.co.jp', 'MH', '', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(121, 394, 'BANTA_LEAH MARIEL', 'LEAH MARIEL', 'BANTA', 'Female', 'leah', 'KDTW229', 'banta-kdt@corp.khi.co.jp', 'MH', 'ADE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(122, 395, 'VILLANUEVA_GLADYS', 'GLADYS', 'VILLANUEVA', 'Female', 'Gladys', 'KDTW267', 'villanueva-kdt@corp.khi.co.jp', 'ENV/CHE', 'ADE', 1, 'Viewer', 'OFF', 'OFF', '-', '-'),
(123, 396, 'LACSA_JOHN', 'JOHN', 'LACSA', 'Male', 'lacsa', 'KDTW361', 'lacsa-kdt@corp.khi.co.jp', 'MH', 'ADE', 2, 'Viewer', 'OFF', 'OFF', '-', '-'),
(124, 398, 'CANTOS_REN', 'REN', 'CANTOS', 'Male', 'ren', 'KDTW369', 'cantos-kdt@corp.khi.co.jp', 'ENE', 'ADE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(125, 401, 'LAUREANO_MIKI ANTONIO', 'MIKI ANTONIO', 'LAUREANO', 'Male', 'mikilaureano', 'KDTW373', 'laureano_m-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(126, 402, 'ORNIDO_MARVIN JOHN', 'MARVIN JOHN', 'ORNIDO', 'Male', 'marvz', 'KDTW234', 'ornido-kdt@corp.khi.co.jp', 'ENE', 'PDE', 2, 'Viewer', 'OFF', 'OFF', '-', '-'),
(127, 403, 'MANGALIMAN_LAARNI', 'LAARNI', 'MANGALIMAN', 'Female', 'laarni', 'KDTW212', 'tumamao-kdt@corp.khi.co.jp', 'TEG', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(128, 404, 'ARGENTE_GENE OWEN', 'GENE OWEN', 'ARGENTE', 'Male', 'geneowen', 'KDTW374', 'argente-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(129, 406, 'TUMBAGA_JEP', 'JEP', 'TUMBAGA', 'Male', 'jep', 'KDTW204', 'tumbaga-kdt@corp.khi.co.jp', 'CM', 'PDE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(130, 407, 'VILLATUYA_RUSSEL', 'RUSSEL', 'VILLATUYA', 'Male', 'rcvillatuya', 'KDTW246', 'villatuya-kdt@corp.khi.co.jp', 'ECS/EE', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(131, 408, 'PALEN_ANGELICA', 'ANGELICA', 'PALEN', 'Female', 'angelica', 'KDTW227', 'palen-kdt@corp.khi.co.jp', 'SYS', 'CAD/CAE', 4, 'Viewer', 'OFF', 'OFF', '-', '-'),
(132, 409, 'DELA CRUZ_EARVIN JAMES', 'EARVIN JAMES', 'DELA CRUZ', 'Male', 'earvinjames', 'KDTW228', 'delacruz-kdt@corp.khi.co.jp', 'SYS/INT', 'CAD/CAE', 4, 'Developer', 'OFF', 'OFF', 'DONE', 'DONE'),
(133, 410, 'PARRA_ELY', 'ELY', 'PARRA', 'Male', 'elyparra', 'KDTW243', 'parra-kdt@corp.khi.co.jp', 'TEG', 'PDE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(134, 411, 'MANALO_MARYLOU', 'MARYLOU', 'MANALO', 'Female', 'malou', 'KDTW275', 'manalo-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(135, 412, 'RIVERA_REENAN', 'REENAN', 'RIVERA', 'Male', 'reenan', '', 'rivera-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(136, 413, 'ANORICO_WENDY', 'WENDY', 'ANORICO', 'Female', 'wendz', 'KDTW', 'anorico-kdt@corp.khi.co.jp', 'ASH/MH', 'PDE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(137, 414, 'ANTONIO_WILHELM DENNIS', 'WILHELM DENNIS', 'ANTONIO', 'Male', 'wilhelm', '', 'antonio-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(138, 415, 'ASTRERA_PHILIP JHON', 'PHILIP JHON', 'ASTRERA', 'Male', 'philipj', '', 'astrera-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(139, 416, 'FLORESCA_GENE PHILIP', 'GENE PHILIP', 'FLORESCA', 'Male', 'gene', 'KDTW274', 'floresca-kdt@corp.khi.co.jp', 'TEG', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(140, 417, 'BINAY-AN_DARYL', 'DARYL', 'BINAY-AN', 'Male', 'darylb', 'KDTW', 'binayan-kdt@corp.khi.co.jp', 'ASH/MH', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(141, 419, 'MESIAS_MERIAM', 'MERIAM', 'MESIAS', 'Female', 'meriam', '', 'mesias-kdt@corp.khi.co.jp', 'ADM/DRIVER', '', 1, 'Viewer', 'OFF', 'OFF', '-', '-'),
(142, 420, 'BENEDICTO_ALVIN', 'ALVIN', 'BENEDICTO', 'Male', 'vin', '', 'benedicto-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(143, 421, 'NAZAR_JOHN JACOB', 'JOHN JACOB', 'NAZAR', 'Male', 'jjnazar', '', 'nazar-kdt@corp.khi.co.jp', 'MH', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(144, 422, 'PIMENTEL_LUCKY BOY', 'LUCKY BOY', 'PIMENTEL', 'Male', 'lux', '', 'pimentel-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(145, 423, 'CARO_RENSON', 'RENSON', 'CARO', 'Male', 'rensonc', '', 'caro-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(146, 424, 'PEREZ_RENZEL', 'RENZEL', 'PEREZ', 'Male', 'renzel', '', 'perez_r-kdt@corp.khi.co.jp', 'MH', 'PDE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(147, 425, 'BELEN_MARVIN', 'MARVIN', 'BELEN', 'Male', 'mbelen', '', 'belen_m-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(148, 426, 'TUAZON_KING LOUIS', 'KING LOUIS', 'TUAZON', 'Male', 'kdtuazon', '', 'tuazon-kdt@corp.khi.co.jp', 'ENE', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(149, 427, 'FERNANDEZ_JULIUS', 'JULIUS', 'FERNANDEZ', 'Male', 'julius', '', 'fernandez-kdt@corp.khi.co.jp', 'TEG', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(150, 428, 'VELASCO_VRYAN', 'VRYAN', 'VELASCO', 'Male', 'vryan', '', 'velasco-kdt@corp.khi.co.jp', 'TEG', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(151, 429, 'MORALITA_DENMARK', 'DENMARK', 'MORALITA', 'Male', 'dmoralita', '', 'moralita-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(152, 430, 'UCOL_ZENDY GRACE', 'ZENDY GRACE', 'UCOL', 'Female', 'zendy', '', 'ucol-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(153, 432, 'MACARAAN_CHRISTIAN', 'CHRISTIAN', 'MACARAAN', 'Male', 'cmacaraan', '', 'macaraan-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(154, 433, 'RAMOS_ALYSSA', 'ALYSSA', 'RAMOS', 'Female', 'alyssa', '', 'ramos-kdt@corp.khi.co.jp', 'MH', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(155, 434, 'PILIS_VILMER', 'VILMER', 'PILIS', 'Male', 'vilmer', '', 'pilis-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(156, 435, 'BASIBAS_KERSTIN PAULA', 'KERSTIN PAULA', 'BASIBAS', 'Female', 'kbasibas', '', 'basibas-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(157, 436, 'VINAS_EUGENE', 'EUGENE', 'VINAS', 'Male', 'eugene', '', 'vinas-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(158, 437, 'CALLORES_DICK FRANCIS', 'DICK FRANCIS', 'CALLORES', 'Male', 'dickfrancis', '', 'callores-kdt@corp.khi.co.jp', 'TEG', 'PDE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(159, 438, 'REYES_JUAN CARLOS', 'JUAN CARLOS', 'REYES', 'Male', 'jc', '', 'reyes_jc-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(160, 439, 'ARROYO_MICAH CAMILLE', 'MICAH CAMILLE', 'ARROYO', 'Female', 'carroyo', '', 'arroyo-kdt@corp.khi.co.jp', 'IT', 'PDE', 4, 'Admin', 'ON', 'ON', 'DONE', '-'),
(161, 440, 'PANGINBAYAN_ROCHELLE', 'ROCHELLE', 'PANGINBAYAN', 'Female', 'chelly', '', 'panginbayan-kdt@corp.khi.co.jp', 'IT', 'PDE', 4, 'Admin', 'ON', 'ON', 'DONE', '-'),
(162, 444, 'TOBIAS_KENNETH', 'KENNETH', 'TOBIAS', 'Male', 'ken', '', 'tobias_k-kdt@corp.khi.co.jp', 'CIV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(163, 445, 'HONRADO_RUTH ANNE', 'RUTH ANNE', 'HONRADO', 'Female', 'ruth', '', 'honrado-kdt@corp.khi.co.jp', 'ANA', 'PDE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(164, 446, 'TAKENAKA_YUKIHIRO', 'YUKIHIRO', 'TAKENAKA', 'Male', 'takenaka_yu', '', 'takenaka_yu@khi.co.jp', 'ADM', 'SM', 4, 'Requestor', 'ON', 'OFF', 'DONE', '-'),
(165, 447, 'MEDRANO_MARCO', 'MARCO', 'MEDRANO', 'Male', 'maco', '', 'medrano-kdt@corp.khi.co.jp', 'PIP', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(166, 448, 'SOLIVEN_CHERRY MAE', 'CHERRY MAE', 'SOLIVEN', 'Female', 'che', '', 'soliven-kdt@corp.khi.co.jp', 'PIP', 'PDE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(167, 449, 'VIADO_MEYRVIN', 'MEYRVIN', 'VIADO', 'Male', 'meyrvin', '', 'viado-kdt@corp.khi.co.jp', 'PIP', 'PDE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(168, 450, 'CASEM_KIMBERLY', 'KIMBERLY', 'CASEM', 'Female', 'kimmy', '', 'casem-kdt@corp.khi.co.jp', 'PIP', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(169, 451, 'GUIAO_NEIL STEPHEN', 'NEIL STEPHEN', 'GUIAO', 'Male', 'guiao', '', 'guiao-kdt@corp.khi.co.jp', 'PIP', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(170, 452, 'NIGOS_SCOTTEE JAIRUS', 'SCOTTEE JAIRUS', 'NIGOS', 'Male', 'scotty', '', 'nigos-kdt@corp.khi.co.jp', 'ANA', 'PDE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(171, 453, 'SAMANTE_PRINCESS JOY', 'PRINCESS JOY', 'SAMANTE', 'Female', 'cessy', '', 'samante-kdt@corp.khi.co.jp', 'ENE', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(172, 454, 'ARMAS_KENN JOHN', 'KENN JOHN', 'ARMAS', 'Male', 'armas', '', 'armas-kdt@corp.khi.co.jp', 'ENE', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(173, 455, 'MANALO_V_VINCEN', 'VINCEN', 'MANALO', 'Male', 'vincen', '', 'manalo_v-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(174, 456, 'RIVERA_M_MAX VINCENT', 'MAX VINCENT', 'RIVERA', 'Male', 'maxxs', '', 'rivera_m-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(175, 457, 'BAUTISTA_J_JUSTINE LLOYD', 'JUSTINE LLOYD', 'BAUTISTA', 'Male', 'justine', '', 'bautista_j-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(176, 458, 'PONCE_ALLYSHA ELLAINE', 'ALLYSHA ELLAINE', 'PONCE', 'Female', 'allysha', '', '', 'ADM', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(177, 459, 'CUTARAN_RENNEL MAE', 'RENNEL MAE', 'CUTARAN', 'Female', 'rennel', 'KDTW', 'cutaran-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(178, 460, 'BERONGOY_EURJHON', 'EURJHON', 'BERONGOY', 'Male', 'eurjhon', 'KDTW', 'berongoy-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(179, 461, 'BAYQUEN_HANNAH MILLACE', 'HANNAH MILLACE', 'BAYQUEN', 'Female', 'hannah', 'KDTW', 'bayquen-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(180, 462, 'SANTOS_LUIZE NICOLE', 'LUIZE NICOLE', 'SANTOS', 'Male', 'luize', 'KDTW', 'santos-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(181, 463, 'REYES_RIZCHELLE', 'RIZCHELLE', 'REYES', 'Female', 'riz', 'KDTW', 'reyes_r-kdt@corp.khi.co.jp', 'ENV', 'PDE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(182, 464, 'COQUIA_JOSHUA MARI', 'JOSHUA MARI', 'COQUIA', 'Male', 'josh', 'KDTW444', 'coquia-kdt@corp.khi.co.jp', 'SYS', 'PDE', 0, 'Developer', 'ON', 'ON', 'DONE', 'DONE'),
(183, 465, 'PETATE_FELIX EDWIN', 'FELIX EDWIN', 'PETATE', 'Male', 'felix', 'KDTW408', 'petate-kdt@corp.khi.co.jp', 'SYS', 'PDE', 0, 'Developer', 'ON', 'ON', 'DONE', 'DONE'),
(184, 466, 'AGANAN_ALVIN JOHN', 'ALVIN JOHN', 'AGANAN', 'Male', 'aganan-kdt', 'KDTW358', 'aganan-kdt@corp.khi.co.jp', 'SYS', 'PDE', 0, 'Developer', 'ON', 'ON', 'DONE', 'DONE'),
(185, 467, 'CAMUNGGOL_ALDRIN JERICK', 'ALDRIN JERICK', 'CAMUNGGOL', 'Male', 'aldrin', 'KDTW', 'camunggol-kdt@corp.khi.co.jp', 'ENE', 'PDE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(186, 468, 'GAMEZ_AARON GODFREY', 'AARON GODFREY', 'GAMEZ', 'Male', 'aarongamez', 'KDTW', 'gamez-kdt@corp.khi.co.jp', 'MIL', 'PDE', 0, 'Viewer', 'OFF', 'OFF', 'DONE', '-'),
(187, 41, 'NOGOMI_YASUHISA', 'YASUHISA', 'NOGOMI', 'Unknown', 'nogomi_y', '', 'nogomi_y@khi.co.jp', 'ADM', 'SM', 4, 'Viewer', 'OFF', 'OFF', '-', '-'),
(188, 10018, 'UENO_RYOSUKE', 'RYOSUKE', 'UENO', 'Unknown', 'ueno_r', 'KDTW', 'ueno_r@khi.co.jp', 'ENV', 'DM', 3, 'Viewer', 'OFF', 'OFF', '-', '-'),
(189, 10008, 'CHIBA_TATSUROU', 'TATSUROU', 'CHIBA', 'Unknown', 'chiba_ta', 'KDTW', 'chiba_ta@khi.co.jp', 'ENV', 'ADE', 3, 'Viewer', 'OFF', 'OFF', '-', '-'),
(196, 10035, 'IWAMURA_MUNECHIYO', 'MUNECHIYO', 'IWAMURA', 'Unknown', 'iwamura_m', 'KDTW', 'iwamura_m@khi.co.jp', 'ENV', 'SV', 3, 'Viewer', 'OFF', 'OFF', '-', '-'),
(197, 701, 'Common_Dev', 'Dev', 'Common', 'Unknown', 'dev_common', 'kdtw388', 'kdtdev01-kdt@corp.khi.co.jp', 'SYS', 'SV', 4, 'Viewer', 'OFF', 'OFF', '-', '-'),
(199, 702, 'Room 24P_Conference', 'Conference', 'Room 24P', 'Unknown', 'kdt-common', '', 'kdt-common@corp.khi.co.jp', 'SYS', '', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(202, 446, 'TAKENAKA_YUKIHIRO', 'YUKIHIRO', 'TAKENAKA', 'Male', 'president', '', 'takenaka_yu@khi.co.jp', '', '', 0, 'Requestor', 'ON', 'OFF', '-', '-'),
(203, 446, 'TAKENAKA_YUKIHIRO', 'YUKIHIRO', 'TAKENAKA', 'Male', 'kdtpresident', '', 'takenaka_yu@khi.co.jp', '', '', 0, 'Requestor', 'ON', 'OFF', '-', '-'),
(204, 30001, 'Yonezawa_', 'Yonezawa', ' ', 'Unknown', 'Yonezawa-bnc', '', '', '', '', 0, 'Viewer', 'OFF', 'OFF', '-', '-'),
(206, 487, 'MEDRANO_COLLENE KEITH', 'COLLENE KEITH', 'MEDRANO', 'Female', 'collene', '', 'medrano_c-kdt@corp.khi.co.jp', 'SYS', 'PDE', 0, 'Developer', 'OFF', 'OFF', 'DONE', 'DONE'),
(209, 488, 'GULAM_GLENDA ANN', 'GLENDA ANN', 'GULAM', 'Female', 'glenda', '', 'gulam-kdt@corp.khi.co.jp', 'SYS', 'PDE', 0, 'Developer', 'OFF', 'OFF', 'DONE', 'DONE');

-- --------------------------------------------------------

--
-- Table structure for table `request_list`
--

CREATE TABLE `request_list` (
  `ID` int(11) NOT NULL,
  `TicketNumber` varchar(20) NOT NULL,
  `RequestCode` varchar(30) DEFAULT NULL,
  `PriorityRank` int(11) NOT NULL DEFAULT 0,
  `Title` varchar(1000) DEFAULT NULL,
  `GroupBU` varchar(50) DEFAULT NULL,
  `Description` varchar(2000) NOT NULL,
  `ProjectType` varchar(50) NOT NULL DEFAULT '-',
  `ProjectCode` varchar(10) NOT NULL DEFAULT '-',
  `UploadedFiles` varchar(8000) NOT NULL,
  `InitialPath` varchar(255) NOT NULL DEFAULT '-',
  `FinishPath` varchar(255) NOT NULL DEFAULT '-',
  `KeyPerson` varchar(50) DEFAULT NULL,
  `KeyPersonEmail` varchar(50) NOT NULL,
  `ClientRepresentative` varchar(50) DEFAULT NULL,
  `ClientRepEmail` varchar(50) NOT NULL DEFAULT 'None',
  `Developer` varchar(255) DEFAULT '-',
  `DateRequested` date NOT NULL,
  `TimeRequested` time NOT NULL,
  `StartDate` date NOT NULL,
  `FinishDate` date NOT NULL,
  `Progress` int(3) NOT NULL,
  `Status` char(20) DEFAULT 'Pending',
  `Remarks` varchar(255) DEFAULT 'Your request is on queue.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request_list`
--

INSERT INTO `request_list` (`ID`, `TicketNumber`, `RequestCode`, `PriorityRank`, `Title`, `GroupBU`, `Description`, `ProjectType`, `ProjectCode`, `UploadedFiles`, `InitialPath`, `FinishPath`, `KeyPerson`, `KeyPersonEmail`, `ClientRepresentative`, `ClientRepEmail`, `Developer`, `DateRequested`, `TimeRequested`, `StartDate`, `FinishDate`, `Progress`, `Status`, `Remarks`) VALUES
(1, 'WRN-21-001', '20211117_105005_E212', 0, 'Web Request System (WRS)', 'SYS', 'Web Request System (WRS)', '09 Web Development', '09-0001', 'Chrome.png  -  132.63 KB', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20211117_105005_E212', '\\\\kdt-ph\\c\\WRS\\PROJECTS\\09 Web Development\\0001_Web Request System (WRS)\\2021\\20211117_105005_E212', 'Edmon Lazaro', 'aganan-kdt@corp.khi.co.jp', 'Alvin John Aganan', 'aganan-kdt@corp.khi.co.jp', 'alvinjohn', '2021-11-17', '10:50:05', '2021-11-22', '2022-02-25', 100, 'Finished', 'This request was already finished.'),
(2, 'WRN-21-002', '20211117_113410_E134', 0, 'Web QMS - Quality Management System', 'EE', 'This program will allow all employees to input, access and update their individual company information and activities in our KDT Intranet.', '09 Web Development', '09-0002', '20210929-0632 Re_ Intranet Input of Employees Individual History.eml  -  320.97 KB,20211015-0816 Re_ WEB QMS UI Draft (rev).eml  -  7.05 KB,20211102-1617 Re_ QMS WG_ Document Number & Cover Page.eml  -  358.73 KB,20211103-1608 Re_ QMS WG_ Document Number & Cover Page.eml  -  28.03 KB,20211103-1623 Re_ QMS WG_ Job History Database Input.eml  -  37.68 KB,20211103-1636 Re_ QMS WG_ Document Number & Cover Page.eml  -  28.52 KB,20211103-1655 QMS WG_ Additional Output Report.eml  -  207.68 KB,20211104-0706 Re_ QMS WG_ Document Number & Cover Page.eml  -  27.06 KB,20211111-1501 Fw_ QMS-Job History Selection.eml  -  140.46 KB,20211112-1124 Re_ Fw_ QMS-Job History Selection.eml  -  140.76 KB,20211112-1327 Fw_ QMS-Job History Selection.eml  -  142.29 KB,20211112-1426 Fw_ QMS-Job History Selection.eml  -  377.02 KB,20211115-1646 Re_ Fw_ QMS-Job History Selection.eml  -  287.58 KB,20211116-0711 QMS_ Revised UI.eml  -  347.67 KB,20211116-0743 Re_ QMS_ Revised UI.eml  -  349.5 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20211117_113410_E134', '//kdt-ph/c/WRS/PROJECTS/09 Web Development/0002_Web QMS - Quality Management System/2022/20211117_113410_E134', 'Artemio Roel Becina', 'aganan-kdt@corp.khi.co.jp', 'Rex Araneta', 'araneta-kdt@corp.khi.co.jp', 'felix, josh', '2021-11-17', '11:34:10', '2021-09-28', '2022-01-26', 100, 'Finished', 'This request was already finished.'),
(3, 'WRN-21-003', '20211118_111645_E212', 0, 'kdtCablewayBranchSplit', 'SHI', 'bway split with 2 table reference for 2 condition', '', '-', '20211006-0858 Add CHR Split Pattern.eml  -  62.02 KB,20211006-0858 CHR Split Pattern.xlsx  -  15.87 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20211118_111645_E212', '-', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp', 'None', 'None', 'edmon', '2021-11-18', '11:16:45', '0000-00-00', '0000-00-00', 20, 'Cancelled', 'neglect request'),
(4, 'WRN-21-004', '20211118_111807_E212', 0, 'kdtCablewayBranchSplit', 'SHI', '20211013-1037 SHI FB desc - Edmon', '04 AVEVA Marine', '04-0079', '20211013-1037 FB division information addition request.eml  -  340.02 KB,20211014-0930 Re_ FB division information addition request.eml  -  456.86 KB,20211015-1031 Re_ FB division information addition request.eml  -  511.55 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20211118_111807_E212', '//kdt-ph/c/WRS/PROJECTS/04 AVEVA Marine/0079_kdtCablewayBranchSplit/2022/20211118_111807_E212', 'Edmon Lazaro', 'aganan-kdt@corp.khi.co.jp', 'None', 'None', 'edmon', '2021-11-18', '11:18:07', '2022-04-27', '2022-04-27', 100, 'Finished', 'This request was already finished.'),
(5, 'WRN-21-005', '20211118_112000_E212', 0, 'kdtCablewayBranchSplit', 'SHI', '20211101-0938 SHI FBR - Edmon', '04 AVEVA Marine', '04-0079', '20211101-0938 (20211102-0723) Re_ kdtCablewayBranchSplit_20211029_FBR legs distances and legs rotation.eml  -  2.13 MB,20211102-0723 (20211102-0925) Re_ kdtCablewayBranchSplit_20211029_FBR legs distances and legs rotation.eml  -  2.18 MB,20211102-0925 Re_ kdtCablewayBranchSplit_20211029_FBR legs distances and legs rotation.eml  -  2.2 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20211118_112000_E212', '\\\\kdt-ph\\C\\WRS\\PROJECTS\\04 AVEVA Marine\\0079_kdtCablewayBranchSplit\\2022\\20211118_112000_E212', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp', 'None', 'None', 'edmon', '2021-11-18', '11:20:00', '0000-00-00', '0000-00-00', 100, 'Finished', 'This request was already finished.'),
(6, 'WRN-21-006', '20211118_112224_E212', 0, 'kdtCablewayBranchSplit', 'SHI', '20211026-1424 SHI - Edmon', '04 AVEVA Marine', '04-0079', '20211026-1424 (20211029-1757) Problems During Request.eml  -  6.35 MB,20211029-1757 kdtCablewayBranchSplit_Re_ Problems During Request.eml  -  27.56 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20211118_112224_E212', '\\\\kdt-ph\\C\\WRS\\PROJECTS\\04 AVEVA Marine\\0079_kdtCablewayBranchSplit\\2022\\20211118_112224_E212', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp', 'None', 'None', 'edmon', '2021-11-18', '11:22:24', '0000-00-00', '0000-00-00', 100, 'Finished', 'This request was already finished.'),
(7, 'WRN-21-007', '20211118_114709_E355', 0, 'kdtCwayReportPadMarking', 'SHI', '20211008-0840 SHI Cable Way Pad Marking - joms', '04 AVEVA Marine', '04-0090', 'Re_ PAD of main cable way_1.eml  -  448.24 KB,Re_ PAD of main cable way_2.eml  -  540.78 KB,Re_ PAD of main cable way_3.eml  -  972.23 KB,Re_ PAD of main cable way_4.eml  -  974.37 KB,Re_ PAD of main cable way_5.eml  -  0.98 MB,Re_ PAD of main cable way_6.eml  -  1.1 MB,Re_ PAD of main cable way_7.eml  -  1.11 MB,Shi.eml  -  793.47 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20211118_114709_E355', '\\\\kdt-ph\\c\\WRS\\PROJECTS\\04 AVEVA Marine\\0090_kdtCwayReportPadMarking\\2022\\20211118_114709_E355', 'Jommuel De Jesus', 'aganan-kdt@corp.khi.co.jp', 'Raffy Torio', 'torio-kdt@corp.khi.co.jp', 'jommuel, raffy', '2021-11-18', '11:47:10', '2021-10-08', '2021-12-13', 100, 'Finished', 'This request was already finished.'),
(8, 'WRN-21-008', '20211118_143045_E409', 0, 'INTMaterialLibraryPartName', 'INT', '20211105 INT MaterialLibraryMacro - ej', '03 Microsoft Excel', '03-0037', '20211105-1145  Request for excel Formula_Macro.eml  -  847.22 KB,B2301_管継手(ねじ込み可鍛鋳鉄製)_R2_MacroTest.xlsm  -  612.12 KB,Macro_request.xlsx  -  129.84 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20211118_143045_E409', '//kdt-ph/c/WRS/PROJECTS/03 Microsoft Excel/0037_INTMaterialLibraryPartName/2022/20211118_143045_E409', 'Earvin James Dela Cruz', 'aganan-kdt@corp.khi.co.jp', 'Ruth Anne Honrado', 'honrado-kdt@corp.khi.co.jp', 'earvinjames', '2021-11-18', '14:30:45', '2023-01-01', '2023-01-01', 100, 'Finished', 'This request was already finished.'),
(9, 'WRN-21-009', '20211118_160124_E173', 2, 'EE Site Supervision Application (QR)', 'EE', '20210914 - EE Site Supervision Application', '08 Mobile Development', '08-', 'Fw_ QR Code File.eml  -  6.3 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20211118_160124_E173', '-', 'Ramir Valdez', 'valdez-kdt@corp.khi.co.jp', 'Artemio Roel Becina', 'becina-kdt@corp.khi.co.jp', 'earvinjames', '2021-11-18', '16:01:24', '2022-07-02', '0000-00-00', 50, 'On Hold', 'Your request is ON HOLD due to prior requests.'),
(10, 'WRN-21-010', '20211118_162054_E104', 2, 'KDT Engineering Manhour Summary', 'MNG', '20211117-0730 MNG KDTManhourSummary', '01 Application', '-', '20211117-0730 merge name only.PNG  -  28.88 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20211118_162054_E104', '-', 'Ernesto Lou Veloso', 'veloso-kdt@corp.khi.co.jp', 'Ryosuke Ueno', 'ueno_r@khi.co.jp', 'edmon, raffy', '2021-11-18', '16:20:54', '2022-04-01', '2022-04-19', 100, 'Ongoing', 'The progress of your request is 100%. \r\nPlease communicate with System Developers if you have any concerns to your request.'),
(11, 'WRN-21-011', '20211206_092833_E212', 0, 'Web Request System (WRS)', 'SYS', 'Additional Features - Coding and Debugging (as of December 6, 2021)', '09 Web Development', '09-0001', '1.png  -  13.65 KB,2.png  -  20.52 KB,3.png  -  21.36 KB,4.png  -  47.1 KB,5.jfif  -  11.17 KB,6.png  -  105.01 KB,7.jfif  -  9.94 KB,8.png  -  56.44 KB', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20211206_092833_E212', '\\\\kdt-ph\\c\\WRS\\PROJECTS\\09 Web Development\\0001_Web Request System (WRS)\\2021\\20211206_092833_E212', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp', 'Alvin John Aganan', 'aganan-kdt@corp.khi.co.jp', 'alvinjohn, edmon', '2021-12-06', '09:28:33', '2021-12-06', '2022-04-13', 100, 'Finished', 'This request was already finished.'),
(12, 'WRN-21-012', '20211213_102341_E226', 14, 'Auto Support Fabrication V2.0', 'EE2', 'Auto Support Fabrication update', '-', '-', 'MTO.exe  -  1.64 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20211213_102341_E226', '-', 'Francis Martee Gulapa', 'gulapa-kdt@corp.khi.co.jp', 'Roel Boy Apostol', 'apostol-kdt@corp.khi.co.jp', 'jommuel', '2021-12-13', '10:23:42', '2022-02-22', '0000-00-00', 76, 'Ongoing', 'System group are now doing your request. \r\nYou can monitor here the progress.'),
(13, 'WRN-21-013', '20211215_142200_E355', 0, 'kdtCwayReportPadMarking', 'SYS', '20211008-0840 SHI Cable Way Pad Marking - joms', '04 AVEVA Marine', '04-0090', 'Re_ PAD of main cable way.eml  -  1.55 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20211215_142200_E355', '//kdt-ph/c/WRS/PROJECTS/04 AVEVA Marine/0090_kdtCwayReportPadMarking/2022/20211215_142200_E355', 'Jommuel De Jesus', 'aganan-kdt@corp.khi.co.jp', 'Raffy Torio', 'torio-kdt@corp.khi.co.jp', 'jommuel, raffy', '2021-12-15', '14:22:00', '2021-12-13', '2022-02-15', 100, 'Finished', 'This request was already finished.'),
(14, 'WRN-21-014', '20211217_080201_E226', 0, 'Cable tray MTO', 'EE2', '1. FIX THE NET QUANTITY FORMULA FOR CODE NUMBER CON(100) AND CON(150). 2. SORTING OF CODE NUMBER ', '07 PDMS', '07-0007', 'CTCODE1.csv  -  7.96 KB,KDTCableTrayList.pmlfrm  -  71.22 KB,KDTDictionary.pmlobj  -  3.93 KB,MODIFY_20211217.txt  -  0.11 KB', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20211217_080201_E226', '//kdt-ph/c/WRS/PROJECTS/07 PDMS/0007_Cable tray MTO/2022/20211217_080201_E226', 'Francis Martee Gulapa', 'aganan-kdt@corp.khi.co.jp', 'Dickenson Sangalang', 'sangalang_d-kdt@corp.khi.co.jp', 'jommuel', '2021-12-17', '08:02:01', '2021-12-17', '2022-02-03', 100, 'Finished', 'This request was already finished.'),
(15, 'WRN-21-015', '20220105_084802_E252', 14, 'Simplier Weekly Report and Monitoring for KDT Civil', 'CIV', 'Will be use as a present material for our Weekly meeting with KHI', '', '-', '2022_KDT Overall & weekly Schedule(Rex).xlsx  -  99.47 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20220105_084802_E252', '-', 'Rex Araneta', 'araneta-kdt@corp.khi.co.jp', 'None', 'None', '-', '2022-01-05', '08:48:02', '0000-00-00', '0000-00-00', 0, 'Pending', 'Your request is on queue.'),
(16, 'WRN-21-016', '20220106_080309_E353', 0, 'kdtCoordinatePosition', 'SHI', 'Get coordinate position based on graphical mouse pick', '04 AVEVA Marine', '04-0091', '20211222-1806 (20211224-1409) Sample macro create .eml  -  17.39 KB,20211224-1409 Re_ Sample macro create .eml  -  20.64 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20220106_080309_E353', '//kdt-ph/c/WRS/PROJECTS/04 AVEVA Marine/0091_kdtCoordinatePosition/2022/20220106_080309_E353', 'Raffy Torio', 'aganan-kdt@corp.khi.co.jp', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp', '-', '2022-01-06', '08:03:09', '2022-01-01', '2022-01-01', 100, 'Finished', 'This request was already finished.'),
(17, 'WRN-21-017', '20220118_092312_E466', 0, 'Test Project Name', 'SYS', 'Test Description', '-', '-', '', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20220118_092312_E466', '-', 'Alvin John Aganan', 'aganan-kdt@corp.khi.co.jp', 'Joshua Mari Coquia', 'coquia-kdt@corp.khi.co.jp', '-', '2022-01-18', '09:23:12', '0000-00-00', '0000-00-00', 0, 'Cancelled', 'For testing purposes only.'),
(18, 'WRN-21-018', '20220118_120417_E370', 0, 'KDT Breaktime Music', 'IT', 'Automatic command service for playing music in breaktime (10:00:15am). This will be installed in 2 KDT-IT Remote PC.', '01 Application', '01-0046', 'Bruno Mars, Anderson .Paak, Silk Sonic - Skate [Official Music Video] (320kbps).mp3  -  7.75 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20220118_120417_E370', '//kdt-ph/c/WRS/PROJECTS/01 Application/0046_KDT Breaktime Music/2022/20220118_120417_E370', 'Candy Nopra', 'aganan-kdt@corp.khi.co.jp', 'Erwin Tan', 'tan-g1@hg.khi.co.jp', 'earvinjames, josh', '2022-01-18', '12:04:17', '2022-01-18', '2022-01-29', 100, 'Finished', 'This request was already finished.'),
(19, 'WRN-21-019', '20220119_115058_E353', 3, 'AMS Auto Downloader', 'SYS', 'Automatically download logs generated from Attendance Management Server.', '01 Application', '-', 'Attendance Management Program.png  -  123.01 KB,Timelog Database v2.0.png  -  66.54 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20220119_115058_E353', '-', 'Raffy Torio', 'torio-kdt@corp.khi.co.jp', 'Micah Camille Arroyo', 'arroyo-kdt@corp.khi.co.jp', 'raffy', '2022-01-19', '11:50:58', '0000-00-00', '0000-00-00', 100, 'Ongoing', 'Your request is on queue.'),
(20, 'WRN-21-020', '20220124_102912_E212', 14, 'kdtMessagingSystem', 'SHI', ' Messaging system to be used for kdt communication.', '', '-', 'SYS MessegingSystem_R01_20210602-0832.pptx  -  1.53 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20220124_102912_E212', '-', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp', 'None', 'None', '-', '2022-01-24', '10:29:13', '0000-00-00', '0000-00-00', 0, 'Pending', 'Your request is on queue.'),
(21, 'WRN-21-021', '20220124_134449_E373', 0, 'Music - Lite Kaizen', 'CRY', 'Play one or two songs Monday-Friday at 10 am breaktime.', '-', '-', 'Playing Music during Breaktime Guidelines-R1_220107.xlsx  -  10.25 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20220124_134449_E373', '-', 'Nelmar Bong Sabarillo', 'sabarillo-kdt@corp.khi.co.jp', 'None', 'None', 'josh', '2022-01-24', '13:44:49', '0000-00-00', '0000-00-00', 0, 'Cancelled', 'This request is cancelled because this was already completed by Joshua Coquia.'),
(22, 'WRN-21-022', '20220125_141315_E307', 14, 'Meeting Room Reservation System', 'IT', 'Please see attached', '-', '-', 'Request_Meeting Room Reservation_25Jan2022.xlsx  -  10.66 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20220125_141315_E307', '-', 'Veronica Mendoza', 'mendoza-kdt@corp.khi.co.jp', 'Erwin Tan', 'tan-g1@hg.khi.co.jp', 'felix, josh', '2022-01-25', '14:13:15', '2022-01-25', '0000-00-00', 90, 'Ongoing', 'System group are now doing your request. \r\nYou can monitor here the progress.'),
(23, 'WRN-21-023', '20220201_105235_E224', 4, 'ENV SupplyPartsList', 'ENV', 'Modification and debugging for parts with two child part', '03 Microsoft Excel', '03-', '57_SL _Chita-Nanbu_with Comments.pdf  -  208.14 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20220201_105235_E224', '-', 'Blessel Desoloc', 'desoloc-kdt@corp.khi.co.jp', 'None', 'None', 'earvinjames', '2022-02-01', '10:52:35', '2023-01-09', '2023-01-20', 15, 'Ongoing', 'System group are now doing your request. \r\nYou can monitor here the progress.\r\n\\157.116.25.166common-117-Solutions\04_EnviSupply Parts ListMacro_Suppy Part List_220706'),
(24, 'WRN-21-024', '20220208_134828_E212', 0, 'kdtElectricalPartList', 'SYS', 'new FA fittings', '04 AVEVA Marine', '04-0088', '20211215-0904  灯具&各種取付台(4951区分).xls  -  760 KB,20211215-0904 (ElectricalPartList) KS Weight Output & FA-5 weight change.eml  -  2.16 MB,20211215-0904 FA-5.pdf  -  30.89 KB,20211215-0904 電路金物製作表(4961区分).xls  -  794.5 KB,20220131-1658 Re_ (ElectricalPartList) KS Weight Output & FA-5 weight change.eml  -  89.83 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20220208_134828_E212', '//kdt-ph/c/WRS/PROJECTS/04 AVEVA Marine/0088_kdtElectricalPartList/2022/20220208_134828_E212', 'Edmon Lazaro', 'aganan-kdt@corp.khi.co.jp', 'None', 'None', 'edmon', '2022-02-08', '13:48:28', '2022-02-04', '2022-03-07', 100, 'Finished', 'This request was already finished.'),
(25, 'WRN-21-025', '20220210_080729_E212', 0, 'kdtCablewayBranchSplit', 'SYS', 'CH multiple split', '04 AVEVA Marine', '04-0079', '20220208-1830 Re_ kdtCablewayBranchSplit_20220205_common.eml  -  1.54 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2021\\20220210_080729_E212', '//kdt-ph/c/WRS/PROJECTS/04 AVEVA Marine/0079_kdtCablewayBranchSplit/2022/20220210_080729_E212', 'Edmon Lazaro', 'aganan-kdt@corp.khi.co.jp', 'None', 'None', 'edmon', '2022-02-10', '08:07:30', '2022-02-08', '2022-02-10', 100, 'Finished', 'This request was already finished.'),
(26, 'WRN-22-026', '20220211_081612_E373', 0, 'KDT Breaktime Music', 'CRY', 'Play songs Monday-Friday at 10am and 3 pm breaktime. Different set of songs for 10 am and 3 pm.', '01 Application', '01-0046', 'Playing Music during Breaktime Guidelines-R2_220211.xlsx  -  10.31 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220211_081612_E373', '//kdt-ph/c/WRS/PROJECTS/01 Application/0046_KDT Breaktime Music/2022/20220211_081612_E373', 'Nelmar Bong Sabarillo', 'aganan-kdt@corp.khi.co.jp', 'Candy Nopra', 'nopra-kdt@corp.khi.co.jp', 'earvinjames, josh', '2022-02-11', '08:16:13', '2022-02-11', '2022-03-23', 100, 'Finished', 'This request was already finished.'),
(27, 'WRN-22-027', '20220217_113754_E288', 14, 'EE Photo Database', 'EE', '20210804-1317 EE Photo Database', '01 Application', '01-', '20210804-1317 Electrical Group Photo Database Software.pptx  -  5.26 MB,20210804-1317 Request for Software Development (EE Photo Database Software).eml  -  7.2 MB,20210820-1436 Re_ Request for Software Development (EE Photo Database Software).eml  -  8.41 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220217_113754_E288', '-', 'Jhon Ray Godoy', 'godoy-kdt@corp.khi.co.jp', 'Artemio Roel Becina', 'becina-kdt@corp.khi.co.jp;', 'alvinjohn', '2022-02-17', '11:37:54', '2022-06-20', '0000-00-00', 51, 'On Hold', 'Integrated in KDT Cloud Navigator.\r\nOfficially stopped.'),
(28, 'WRN-22-028', '20220217_142615_E212', 0, 'kdtCablewayBranchSplit', 'SYS', 'FB extend function & FBR Support distance', '04 AVEVA Marine', '04-0079', '20220217-1324 Re_ kdtCablewayBranchSplit_20220217_CH supp distance.eml  -  2.24 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220217_142615_E212', '//kdt-ph/c/WRS/PROJECTS/04 AVEVA Marine/0079_kdtCablewayBranchSplit/2022/20220217_142615_E212', 'Edmon Lazaro', 'aganan-kdt@corp.khi.co.jp', 'None', 'None;', 'edmon', '2022-02-17', '14:26:15', '2022-02-17', '2022-02-26', 100, 'Finished', 'This request was already finished.'),
(29, 'WRN-22-029', '20220301_135924_E212', 0, 'kdtCablewayBranchSplit', 'SYS', 'FBR single supp & FB supp1 extend bug', '04 AVEVA Marine', '04-0079', '20220228-1018 Re_ kdtCablewayBranchSplit_20220226_FBR supp distances and FB supp extend funct.eml  -  2.52 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220301_135924_E212', '//kdt-ph/c/WRS/PROJECTS/04 AVEVA Marine/0079_kdtCablewayBranchSplit/2022/20220301_135924_E212', 'Edmon Lazaro', 'aganan-kdt@corp.khi.co.jp', 'None', 'None;', 'edmon', '2022-03-01', '13:59:24', '2022-02-28', '2022-03-01', 100, 'Finished', 'This request was already finished.'),
(30, 'WRN-22-030', '20220302_130940_E212', 0, 'kdtSetGisouArea', 'SYS', 'compile to net4.6', '04 AVEVA Marine', '04-0083', '20220228-1519 Re_ kdtSetGisouArea_20201025_create.eml  -  605.25 KB,20220301-0850 Fw_ kdtSetGisouArea_20201025_create.eml  -  575.81 KB,20220301-1017 Re_ Fw_ kdtSetGisouArea_20201025_create.eml  -  580.25 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220302_130940_E212', '//kdt-ph/c/WRS/PROJECTS/04 AVEVA Marine/0083_kdtSetGisouArea/2022/20220302_130940_E212', 'Edmon Lazaro', 'aganan-kdt@corp.khi.co.jp', 'None', 'None;', 'edmon', '2022-03-02', '13:09:40', '2022-02-28', '2022-03-03', 100, 'Finished', 'This request was already finished.'),
(31, 'WRN-22-031', '20220302_145800_E307', 14, 'Squid Proxy Server', 'IT', 'Squid Proxy Server', '-', '-', 'DETAILS.txt  -  0.05 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220302_145800_E307', '-', 'Veronica Mendoza', 'mendoza-kdt@corp.khi.co.jp', 'Erwin Tan', 'tan-g1@hg.khi.co.jp;', '-', '2022-03-02', '14:58:00', '0000-00-00', '0000-00-00', 0, 'Pending', 'Your request is on queue.'),
(32, 'WRN-22-032', '20220303_114701_E212', 0, 'kdtCablewayProductionAddin', 'SYS', 'compile to net4.6', '04 AVEVA Marine', '04-0056', '20220302-1112 Re_ kdtSetGisouArea_20220302_compiled to 4.6dotNet.eml  -  611.39 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220303_114701_E212', '//kdt-ph/c/WRS/PROJECTS/04 AVEVA Marine/0056_kdtCablewayProductionAddin/2022/20220303_114701_E212', 'Edmon Lazaro', 'aganan-kdt@corp.khi.co.jp', 'None', 'None;', 'edmon', '2022-03-03', '11:47:01', '2022-02-28', '2022-03-02', 100, 'Finished', 'This request was already finished.'),
(33, 'WRN-22-033', '20220303_143104_E226', 0, 'Cable tray MTO', 'ECS', '1. output the pml cable tray MTO to cable tray MTO format excel file. 2. sort the output in the cable tray MTO format excel file by cable ladder and accessories.', '07 PDMS', '07-0007', 'CABLE TRAY MTO.xls  -  95 KB,CTCODE1.csv  -  8.01 KB,KDTCableTrayList.pmlfrm  -  71.58 KB,KDTDictionary.pmlobj  -  10.72 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220303_143104_E226', '//kdt-ph/c/WRS/PROJECTS/07 PDMS/0007_Cable tray MTO/2022/20220303_143104_E226', 'Francis Martee Gulapa', 'aganan-kdt@corp.khi.co.jp', 'Dickenson Sangalang', 'sangalang_d-kdt@corp.khi.co.jp;', 'jommuel', '2022-03-03', '14:31:16', '2022-03-07', '2022-04-04', 100, 'Finished', 'This request was already finished.'),
(34, 'WRN-22-034', '20220307_105917_E307', 1, 'KDT IT Helpdesk', 'IT', 'KDT IT Helpdesk', '', '-', 'Details.txt  -  0.04 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220307_105917_E307', '-', 'Veronica Mendoza', 'mendoza-kdt@corp.khi.co.jp', 'Candy Nopra, Micah Camille Arroyo, Rochelle Pangin', 'nopra-kdt@corp.khi.co.jp;arroyo-kdt@corp.khi.co.jp', 'felix, josh', '2022-03-07', '10:59:17', '0000-00-00', '0000-00-00', 0, 'Pending', 'Your request is on queue.'),
(35, 'WRN-22-035', '20220307_110014_E307', 14, 'ADMIN 201 Files', 'IT', 'ADMIN 201 Files', '09 Web Development', '09-', 'Details.txt  -  0.04 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220307_110014_E307', '-', 'Veronica Mendoza', 'mendoza-kdt@corp.khi.co.jp', 'Van Panado', 'panado-g1@hg.khi.co.jp;', 'felix, josh', '2022-03-07', '11:00:14', '2022-07-27', '0000-00-00', 70, 'Ongoing', 'System group are now doing your request. \r\nYou can monitor here the progress.'),
(36, 'WRN-22-036', '20220307_110151_E307', 14, 'KDT Survey  Portal', 'IT', 'KDT Survey  Portal', '', '-', 'Details.txt  -  0 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220307_110151_E307', '-', 'Veronica Mendoza', 'mendoza-kdt@corp.khi.co.jp', 'None', 'None;', 'felix, josh', '2022-03-07', '11:01:51', '0000-00-00', '0000-00-00', 0, 'Pending', 'Your request is on queue.'),
(37, 'WRN-22-037', '20220311_145622_E212', 4, 'amPipeSketches', 'SYS', 'SP5 bug', '04 AVEVA Marine', '-', '20220311-1050 ampipesketches.pmlboj has a problem with dimensions..eml  -  1.87 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220311_145622_E212', '-', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp', 'None', 'None;', 'edmon', '2022-03-11', '14:56:22', '0000-00-00', '0000-00-00', 30, 'On Hold', 'priority kdtElectricalPartLlist and kdtHvacAutolabel'),
(38, 'WRN-22-038', '20220315_101900_E353', 14, 'AutoDP Handrail', 'SYS', 'Automatic creation of Handrail production drawing', '04 AVEVA Marine', '04-', 'AUTO_DP_for Handrail_Dimension_control.xlsx  -  73.54 KB', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220315_101900_E353', '-', 'Raffy Torio', 'torio-kdt@corp.khi.co.jp', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp;', 'raffy', '2022-03-15', '10:19:01', '2022-03-15', '2022-06-10', 40, 'Ongoing', 'Fix ISO View ADDE Elements'),
(39, 'WRN-22-039', '20220316_144258_E464', 0, 'Web QMS - Quality Management System', 'SYS', 'Additional Features - Members List / All Job Reports / Manpower Info / Former Employees Report / Report(ALL) for SMs / Photo Gallery: Users can see group photos of every BU', '09 Web Development', '09-0002', 'Screenshot 2022-03-16 143948.png  -  1.04 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220316_144258_E464', '//kdt-ph/c/WRS/PROJECTS/09 Web Development/0002_Web QMS - Quality Management System/2022/20220316_144258_E464', 'Artemio Roel Becina', 'aganan-kdt@corp.khi.co.jp', 'Rex Araneta', 'araneta-kdt@corp.khi.co.jp', 'felix, josh', '2022-03-16', '14:42:58', '2022-03-02', '2022-03-21', 100, 'Finished', 'This request was already finished.'),
(40, 'WRN-22-040', '20220318_082423_E355', 0, 'kdtCwayReportPadMarking', 'SYS', 'update report MACRO for AM12SP5', '04 AVEVA Marine', '04-0090', 'Elec_report_problem_SP5_only.xlsx  -  455.56 KB,How to debug a Reporting.xlsx  -  739.91 KB,Reporting problem for AM12SP5.eml  -  1.78 MB,電路製作図用リストv16.repv  -  123.44 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220318_082423_E355', '//kdt-ph/c/WRS/PROJECTS/04 AVEVA Marine/0090_kdtCwayReportPadMarking/2022/20220318_082423_E355', 'Jommuel De Jesus', 'aganan-kdt@corp.khi.co.jp', 'Raffy Torio', 'torio-kdt@corp.khi.co.jp;', 'jommuel', '2022-03-18', '08:24:23', '2022-03-14', '2022-05-06', 100, 'Finished', 'This request was already finished.'),
(41, 'WRN-22-041', '20220321_085517_E464', 0, 'Web QMS - Quality Management System', 'SYS', 'My Team: Generate Team Reports for Managers', '09 Web Development', '09-0002', 'Screenshot 2022-03-21 085358.png  -  1.13 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220321_085517_E464', '//kdt-ph/c/WRS/PROJECTS/09 Web Development/0002_Web QMS - Quality Management System/2022/20220321_085517_E464', 'Artemio Roel Becina', 'aganan-kdt@corp.khi.co.jp', 'Rex Araneta', 'araneta-kdt@corp.khi.co.jp', 'felix, josh', '2022-03-21', '08:55:17', '2022-01-27', '2022-03-01', 100, 'Finished', 'This request was already finished.'),
(42, 'WRN-22-042', '20220321_090229_E464', 0, 'Web QMS - Quality Management System', 'SYS', 'Checking Function - function for comparing changes between latest input of employees and database', '09 Web Development', '09-0002', 'Screenshot 2022-03-21 090129.png  -  49.11 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220321_090229_E464', '//kdt-ph/c/WRS/PROJECTS/09 Web Development/0002_Web QMS - Quality Management System/2022/20220321_090229_E464', 'Artemio Roel Becina', 'aganan-kdt@corp.khi.co.jp', 'Rex Araneta', 'araneta-kdt@corp.khi.co.jp', 'felix, josh', '2022-03-21', '09:02:29', '2022-03-21', '2022-04-01', 100, 'Finished', 'This request was already finished.'),
(43, 'WRN-22-043', '20220322_143625_E464', 0, 'KDT Portal', 'SYS', 'Login page  - login interface for users/Forgot password-function to reset password/Email notification about password changes/Logout function/', '09 Web Development', '09-0007', 'Screenshot 2022-03-22 135738.png  -  44.04 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220322_143625_E464', '//kdt-ph/c/WRS/PROJECTS/09 Web Development/0007_KDT Portal/2022/20220322_143625_E464', 'Edmon Lazaro', 'aganan-kdt@corp.khi.co.jp', 'None', 'None;', 'felix, josh', '2022-03-22', '14:36:25', '2022-03-21', '2022-04-04', 100, 'Finished', 'This request was already finished.'),
(44, 'WRN-22-044', '20220322_144646_E212', 0, 'kdtElectricalPartList', 'SYS', 'revised KDS standard item', '04 AVEVA Marine', '04-0088', '20220316-1427 Request to Modify Electrical Parts List.eml  -  2.41 MB,20220316-1720 Re_ Request to Modify Electrical Parts List.eml  -  2.41 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220322_144646_E212', '//kdt-ph/c/WRS/PROJECTS/04 AVEVA Marine/0088_kdtElectricalPartList/2022/20220322_144646_E212', 'Edmon Lazaro', 'aganan-kdt@corp.khi.co.jp', 'None', 'None;', 'edmon', '2022-03-22', '14:46:47', '2022-03-23', '2022-03-29', 100, 'Finished', 'This request was already finished.'),
(45, 'WRN-22-045', '20220323_065751_E464', 0, 'Web QMS - Quality Management System', 'SYS', 'Additional Feature - Transportation Info/Reports', '09 Web Development', '09-0002', 'image_xh.png  -  1.13 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220323_065751_E464', '//kdt-ph/c/WRS/PROJECTS/09 Web Development/0002_Web QMS - Quality Management System/2022/20220323_065751_E464', 'Artemio Roel Becina', 'aganan-kdt@corp.khi.co.jp', 'Rex Araneta', 'araneta-kdt@corp.khi.co.jp', 'felix, josh', '2022-03-23', '06:57:51', '2022-03-22', '2022-03-30', 100, 'Finished', 'This request was already finished.'),
(46, 'WRN-22-046', '20220330_062857_E212', 4, 'kdtElectricalPartList', 'SYS', 'additional item revised KDS 2021 ', '04 AVEVA Marine', '-', '20220329-1300 Re_ Request to Modify Electrical Parts List.eml  -  305.05 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220330_062857_E212', '-', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp', 'None', 'None;', 'edmon', '2022-03-30', '06:28:57', '2022-03-30', '2022-04-08', 100, 'Ongoing', 'additional item revised KDS 2021'),
(47, 'WRN-22-047', '20220404_122920_E370', 0, 'KDT Breaktime Music', 'IT', 'Automatic command service for playing Exercise music at 12:01pm in 4ECOM only. Temporary solution while waiting for KDDI Support for Chime music ', '01 Application', '01-0046', 'Edited02_Radio Taiso Exercise Routine - English Language.mp2  -  3.19 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220404_122920_E370', '//kdt-ph/c/WRS/PROJECTS/01 Application/0046_KDT Breaktime Music/2022/20220404_122920_E370', 'Candy Nopra', 'aganan-kdt@corp.khi.co.jp', 'Veronica Mendoza, Erwin Tan', 'mendoza-kdt@corp.khi.co.jp;tan-g1@hg.khi.co.jp;', 'josh, earvinjames', '2022-04-04', '12:29:20', '2022-04-04', '2022-04-05', 100, 'Finished', 'This request was already finished.'),
(48, 'WRN-22-048', '20220406_121628_E464', 0, 'JMR - Web Bulletin Board', 'SYS', 'Additional Feature: Display Announcements on JMR with slideshow format / Control Function for selected users', '09 Web Development', '09-0004', 'jmrbb.png  -  193.37 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220406_121628_E464', '//kdt-ph/c/WRS/PROJECTS/09 Web Development/0004_JMR - Web Bulletin Board/2022/20220406_121628_E464', 'Edmon Lazaro', 'aganan-kdt@corp.khi.co.jp', 'None', 'None;', 'felix, josh', '2022-04-06', '12:16:28', '2022-04-04', '2022-04-29', 100, 'Finished', 'This request was already finished.'),
(49, 'WRN-22-049', '20220419_080701_E466', 0, 'Test Project A', 'SYS', 'Test Desc of Project A', '-', '-', 'Test.png  -  132.63 KB', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220419_080701_E466', '-', 'Alvin John Aganan', 'aganan-kdt@corp.khi.co.jp', 'Aaron Godfrey Gamez', 'gamez-kdt@corp.khi.co.jp', 'alvinjohn', '2022-04-19', '08:07:01', '0000-00-00', '0000-00-00', 0, 'Cancelled', 'For testing only '),
(50, 'WRN-22-050', '20220419_103448_E464', 0, 'KDT Breaktime Music', 'SYS', 'New Condition: After last song is played, player will stop.', '01 Application', '01-0046', 'Screenshot 2022-04-19 103140.png  -  19.06 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220419_103448_E464', '//kdt-ph/c/WRS/PROJECTS/01 Application/0046_KDT Breaktime Music/2022/20220419_103448_E464', 'Candy Nopra', 'aganan-kdt@corp.khi.co.jp', 'Nelmar Bong Sabarillo', 'sabarillo-kdt@corp.khi.co.jp;', 'josh', '2022-04-19', '10:34:48', '2022-04-18', '2022-04-19', 100, 'Finished', 'This request was already finished.'),
(51, 'WRN-22-051', '20220419_131858_E466', 13, 'Web Request System', 'SYS', 'General Controls', '09 Web Development', '09-', 'Test.png  -  132.63 KB', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220419_131858_E466', '-', 'Alvin John Aganan', 'aganan-kdt@corp.khi.co.jp', 'None', 'None;', 'alvinjohn', '2022-04-19', '13:19:05', '2022-04-18', '0000-00-00', 24, 'On Hold', 'Doing EE Photo Database Project '),
(52, 'WRN-22-052', '20220425_140104_E370', 0, 'Automatic Play of Last Wednesday Cleaning Announcement', 'IT', 'Automatic command service for playing Last Wednesday Cleaning Announcement in  (1:25pm). This will be installed in 2 KDT-IT Remote PC.', '01 Application', '01-0046', 'Test.txt  -  0 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220425_140104_E370', '//kdt-ph/c/WRS/PROJECTS/01 Application/0046_KDT Breaktime Music/2022/20220425_140104_E370', 'Candy Nopra', 'aganan-kdt@corp.khi.co.jp', 'Veronica Mendoza', 'mendoza-kdt@corp.khi.co.jp;', 'josh', '2022-04-25', '14:01:04', '2022-04-26', '2022-05-26', 100, 'Finished', 'This request was already finished.'),
(53, 'WRN-22-053', '20220505_131753_E212', 4, 'kdtPromachDrwgAutoLabel', 'SYS', 'hspool labelling', '', '-', '20220317-1547 Fw_ Macro development list.eml  -  406.71 KB,20220317-1547 Hvac_auto_label.xlsx  -  215.73 KB,20220413-1329 Fw_ Macro development list（HVAC　autolabel）.eml  -  539.04 KB,20220413-1329 Hvac_auto_label_r01.xlsx  -  359.41 KB,kdtpromachDrwgAutoLabel_20220503_hvac label.eml  -  747.01 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220505_131753_E212', '-', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp', 'None', 'None;', 'edmon', '2022-05-05', '13:17:53', '2022-03-17', '2022-05-03', 100, 'Ongoing', 'The progress of your request is 100%. \r\nPlease communicate with System Developers if you have any concerns to your request.'),
(54, 'WRN-22-054', '20220506_080722_E212', 5, 'KDT Engineering Manhour Summary', 'SYS', 'april comparison', '01 Application', '01-', '20220503-1057 Monthly MH Report Summary & Comparison Table as of APRIL 2022.eml  -  3.68 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220506_080722_E212', '-', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp', 'Ernesto Lou Veloso', 'veloso-kdt@corp.khi.co.jp', 'edmon, raffy', '2022-05-06', '08:07:22', '2022-05-03', '2022-05-13', 100, 'Ongoing', 'System group are now doing your request. \r\nYou can monitor here the progress.'),
(55, 'WRN-22-055', '20220506_080837_E212', 6, 'kdtElectricalPartList', 'SYS', 'comments', '', '-', '20220421-0944 Re_ kdtElectricalPartList_20220412_KDS2021 add item & KDS1998 weight change.eml  -  541.96 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220506_080837_E212', '-', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp', 'None', 'None;', 'edmon, raffy', '2022-05-06', '08:08:37', '2022-04-21', '2022-05-10', 100, 'Ongoing', 'comment apr21 and pad check'),
(56, 'WRN-22-056', '20220511_133834_E212', 7, 'kdtHvacDrwgAutolabel', 'SYS', 'macro rename from kdtPromachDrwgAutolabel', '04 AVEVA Marine', '-', '20220509-1018 Re_ kdtpromachDrwgAutoLabel_20220503_hvac label.eml  -  206.37 KB,20220509-1102 Fw_ kdtpromachDrwgAutoLabel_20220503_hvac label.eml  -  900.01 KB,20220510-0658 Fw_ kdtpromachDrwgAutoLabel_20220503_hvac label.eml  -  243.89 KB,20220510-0727 Fw_ kdtpromachDrwgAutoLabel_20220503_hvac label.eml  -  1.11 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220511_133834_E212', '-', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp', 'None', 'None;', '-', '2022-05-11', '13:38:34', '2022-05-11', '2022-05-11', 100, 'Ongoing', 'macro rename from kdtPromachDrwgAutolabel'),
(57, 'WRN-22-057', '20220518_081136_E212', 8, 'kdtHvacDrwgAutolabel', 'SYS', 'unwanted new view', '04 AVEVA Marine', '-', '20220511-1458 (20220512-1045) Re_ kdtHvacDrwgAutolabel_20220511 macro rename.eml  -  671.83 KB,20220511-1643 (20220518) Re_ kdtHvacDrwgAutolabel_20220511 macro rename.eml  -  842.46 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220518_081136_E212', '-', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp', 'None', 'None;', 'edmon', '2022-05-18', '08:11:37', '2022-05-16', '2022-05-18', 100, 'Ongoing', 'unwanted new view. 100% 2022May18'),
(58, 'WRN-22-058', '20220518_081523_E212', 9, 'kdtCablewayBranchSplit', 'SYS', 'legs change description', '04 AVEVA Marine', '04-', '20220513-1017 kdtCablewayBranchSplit FB.eml  -  101.83 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220518_081523_E212', '-', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp', 'None', 'None;', 'edmon', '2022-05-18', '08:15:23', '2022-05-18', '2022-05-26', 100, 'Ongoing', 'System group are now doing your request. \r\nYou can monitor here the progress.'),
(59, 'WRN-22-059', '20220519_143929_E355', 14, 'kdtCwayReportPadMarking', 'SYS', 'additional request', '-', '-', 'Re_ Reporting problem for AM12SP5.eml  -  609.54 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220519_143929_E355', '-', 'Jommuel De Jesus', 'dejesus_j-kdt@corp.khi.co.jp', 'Raffy Torio', 'torio-kdt@corp.khi.co.jp;', 'jommuel', '2022-05-19', '14:39:29', '0000-00-00', '0000-00-00', 40, 'Ongoing', 'System group are now doing your request. \r\nYou can monitor here the progress.'),
(60, 'WRN-22-060', '20220527_095721_E212', 10, 'kdtCablewayBranchSplit', 'SYS', 'legs desc info change', '04 AVEVA Marine', '04-', '20220526-1316 (20220527) Re_ kdtCablewayBranchSplit_20220526 fb desc change.eml  -  206.9 KB,20220527-0754 (20220527)  Re_ kdtCablewayBranchSplit_20220526 fb desc change.eml  -  274.69 KB,el.txt  -  13.68 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220527_095721_E212', '-', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp', 'None', 'None;', 'edmon', '2022-05-27', '09:57:21', '2022-05-27', '2022-05-27', 100, 'Ongoing', 'The progress of your request is 100%. \r\nPlease communicate with System Developers if you have any concerns to your request.'),
(61, 'WRN-22-061', '20220527_101819_E212', 12, 'kdtElectricalPartList', 'SYS', '-', '04 AVEVA Marine', '04-', '20220519-0753 Re_ kdtElectricalPartList_20220516_sf and rsa correction.eml  -  1.03 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220527_101819_E212', '-', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp', 'None', 'None;', 'edmon', '2022-05-27', '10:18:19', '2022-05-26', '2022-05-27', 10, 'On Hold', 'Your request is ON HOLD due to prior requests.'),
(62, 'WRN-22-062', '20220527_105406_E212', 11, 'kdtCablewayBranchSplit', 'SYS', '3 legs desc info  (no macro changes)', '04 AVEVA Marine', '04-', '20220527-1014 Re_ kdtCablewayBranchSplit_20220527 legs desc info change.eml  -  336.62 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220527_105406_E212', '-', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp', 'None', 'None;', 'edmon', '2022-05-27', '10:54:06', '2022-05-27', '2022-05-27', 100, 'Ongoing', 'no macro changes'),
(63, 'WRN-22-063', '20220531_123035_E261', 0, 'Smart Plant P&ID Software Report', 'CHE', 'This request is mainly regarding the generation of report from Smart Plant P&ID software.', '-', '-', '310SMRY001_RPC_Line List.xlsx  -  419.15 KB,Information for detailed request.xlsx  -  14 KB,KHI-Line List Generated.xlsm  -  357.53 KB,KHI-Line List_Original File.xlsm  -  370.32 KB,Line List_Step 1.xlsm  -  145.44 KB,Line List_Step 1_Remarks.xlsm  -  145.47 KB,P&ID Reference.pdf  -  1.68 MB,SPPID Line List single row.xlsm  -  284.61 KB,SPPID Line List.xlsm  -  85.26 KB,SPPID Pipe Run List.xlsm  -  65.48 KB,Eneos_Equipment List.xlsm  -  465.84 KB,機器リスト_R3_20210527.xlsm  -  1.03 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220531_123035_E261', '-', 'Amor Villamor', 'villamor-kdt@corp.khi.co.jp', 'Edilaine Marose Patron', 'patron-kdt@corp.khi.co.jp;', '-', '2022-05-31', '12:30:36', '2022-10-18', '0000-00-00', 0, 'Pending', 'Your request is on queue.'),
(64, 'WRN-22-064', '20220531_142053_E352', 14, 'ABEITA', 'ENV', 'Macro Modification', '03 Microsoft Excel', '03-', 'Exxxxx-71xxx1_Ver.2.4.xlsm  -  419.33 KB,Macro Modification for Ver.2.4.xlsx  -  29.87 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220531_142053_E352', '-', 'John David Ducay', 'ducay-kdt@corp.khi.co.jp', 'Gene Owen Argente', 'argente-kdt@corp.khi.co.jp;', 'earvinjames', '2022-05-31', '14:20:53', '2022-06-09', '2022-06-10', 95, 'Waiting', 'Waiting for comments / documents.'),
(65, 'WRN-22-065', '20220610_080622_E212', 14, 'kdtInternetMsEdge', 'SYS', 'switch IE to MsEdge', '04 AVEVA Marine', '04-', '20220609-0928 Macro fixes due to switching from Internet Explorer to Microsoft Edge.eml  -  104.62 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220610_080622_E212', '-', 'Edmon Lazaro', 'lazaro-kdt@corp.khi.co.jp', 'None', 'None;', 'edmon', '2022-06-10', '08:06:22', '2022-06-10', '0000-00-00', 5, 'Ongoing', 'System group are now doing your request. \r\nYou can monitor here the progress.'),
(66, 'WRN-22-066', '20220622_082229_E37', 0, 'JMR', 'ENE', 'Careless Mistakes Summary Report', '-', '-', 'Engineering Careless Mistake_Gen. Summary_May22.xlsx  -  210.27 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220622_082229_E37', '-', 'Ferdinand Llanes', 'llanes-kdt@corp.khi.co.jp', 'Bryan Jay Cano', 'cano-kdt@corp.khi.co.jp;', '-', '2022-06-22', '08:22:29', '0000-00-00', '0000-00-00', 0, 'Pending', 'Your request is on queue.'),
(67, 'WRN-22-067', '20220629_152145_E464', 0, 'KDT Portal - Admin Controls', 'SYS', 'Create Webpage for adding new employees, modifying KDT business units, and modifying KDT designations in the web database', '09 Web Development', '09-0007', 'admincontrolssample.png  -  32.47 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220629_152145_E464', '//kdt-ph/c/WRS/PROJECTS/09 Web Development/0007_KDT Portal/2022/20220629_152145_E464', 'Joshua Mari Coquia', 'aganan-kdt@corp.khi.co.jp', 'Felix Edwin Petate', 'petate-kdt@corp.khi.co.jp;', '-', '2022-06-29', '15:21:45', '2022-06-06', '2022-06-13', 100, 'Finished', 'This request was already finished.'),
(68, 'WRN-22-068', '20220802_075006_E464', 0, 'Web QMS - Quality Management System', 'SYS', 'Additional Function - Check if user has modified inputs in Group History, Job History, Dispatch History, and Training History', '09 Web Development', '09-0002', 'Screenshot 2022-08-01 144248.png  -  32.58 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220802_075006_E464', '//kdt-ph/c/WRS/PROJECTS/09 Web Development/0002_Web QMS - Quality Management System/2022/20220802_075006_E464', 'Joshua Mari Coquia', 'aganan-kdt@corp.khi.co.jp', 'None', 'None;', '-', '2022-08-02', '07:50:06', '2022-07-29', '2022-08-01', 100, 'Finished', 'This request was already finished.'),
(69, 'WRN-22-069', '20220812_081358_E409', 0, 'KDT Screen Time', 'SYS', 'Count time elapsed per software.', '01 Application', '01-0032', 'CEM KDT Screen Time.sln  -  1.13 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220812_081358_E409', '//kdt-ph/c/WRS/PROJECTS/01 Application/0032_KDT Screen Time/2022/20220812_081358_E409', 'Earvin James Dela Cruz', 'aganan-kdt@corp.khi.co.jp', 'None', 'None;', '-', '2022-08-12', '08:13:58', '2022-08-08', '2022-08-12', 100, 'Finished', 'This request was already finished.'),
(70, 'WRN-22-070', '20220819_131559_E295', 14, 'CATIA Macros for KAIZEN 2022 (Request to Solutions Group)', 'MH', 'Macros of CATIA for MAH Group ', '02 CATIA', '02-', 'CATIA Macros for KAIZEN 2022 (Request to Solutions Group).pdf  -  852.98 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220819_131559_E295', '-', 'Rex Moreno', 'moreno-kdt@corp.khi.co.jp', 'Ysabel Cordova', 'cordova-kdt@corp.khi.co.jp;', 'earvinjames', '2022-08-19', '13:15:59', '2022-09-14', '0000-00-00', 20, 'On Hold', 'No available Macro programmers.'),
(71, 'WRN-22-071', '20220825_155727_E409', 0, 'CHE.SmartPlantP&IDReport', 'SYS', 'Excel macro', '-', '-', 'Line List_Step 1\'\'_Edmon.xlsm  -  149.85 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220825_155727_E409', '-', 'Earvin James Dela Cruz', 'delacruz-kdt@corp.khi.co.jp', 'Edilaine Marose Patron', 'patron-kdt@corp.khi.co.jp;', 'earvinjames', '2022-08-25', '15:57:27', '0000-00-00', '0000-00-00', 0, 'Pending', 'Your request is on queue.'),
(72, 'WRN-22-072', '20220825_155808_E409', 14, 'KDT ScreenTime', 'SYS', 'Counter for software used', '-', '-', 'CEM KDT Screen Time.sln  -  1.13 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220825_155808_E409', '-', 'Earvin James Dela Cruz', 'delacruz-kdt@corp.khi.co.jp', 'None', 'None;', 'earvinjames', '2022-08-25', '15:58:08', '2022-08-22', '2022-09-16', 75, 'Ongoing', 'Debugging of missing data in logs tab. \r\nRevision of data sync.\r\nInvestigation for insufficient total time for other users.\r\n'),
(73, 'WRN-22-073', '20220908_081847_E464', 0, 'Web QMS - Quality Management System', 'SYS', 'Additional Feature - Certification Report(JLPT)', '09 Web Development', '09-0002', 'Screenshot 2022-09-08 081723.jpg  -  167.01 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220908_081847_E464', '//kdt-ph/c/WRS/PROJECTS/09 Web Development/0002_Web QMS - Quality Management System/2022/20220908_081847_E464', 'Artemio Roel Becina', 'aganan-kdt@corp.khi.co.jp', 'None', 'None;', 'josh, felix', '2022-09-08', '08:18:47', '2022-09-05', '2022-09-06', 100, 'Finished', 'This request was already finished.'),
(74, 'WRN-22-074', '20220919_132943_E307', 0, 'SURVEY: Jacket or Tumbler', 'IT', 'Survey all KDT members for yearly gift (Jacket or Tumbler) -request by Ma\'am Anne', '-', '-', 'SURVEY.txt  -  0.08 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20220919_132943_E307', '//157.116.72.26/WebRequest/WRS/PROJECTS/09 Web Development/0006_SURVEY: Jacket or Tumbler/2022/20220919_132943_E307', 'Veronica Mendoza', 'mendoza-kdt@corp.khi.co.jp', 'None', 'None;', '-', '2022-09-19', '13:29:43', '0000-00-00', '0000-00-00', 0, 'Pending', 'Your request is on queue.'),
(75, 'WRN-22-075', '20221004_144504_E464', 27, 'KDT Website', 'SYS', 'New KDT Website - http://www.kdt.com.ph/', '-', '-', 'kdtweb.jpg  -  219.77 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20221004_144504_E464', '-', 'Joshua Mari Coquia', 'coquia-kdt@corp.khi.co.jp', 'Erwin Tan', 'tan-g1@hg.khi.co.jp;', 'felix, collene', '2022-10-04', '14:45:10', '2022-10-12', '0000-00-00', 0, 'Ongoing', 'System group are now doing your request. \r\nYou can monitor here the progress.'),
(76, 'WRN-22-076', '20221004_144838_E464', 0, 'KDT Forms', 'SYS', 'Paperless Forms System', '09 Web Development', '09-0009', 'image_46.png  -  54.73 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20221004_144838_E464', '//kdt-ph/c/WRS/PROJECTS/09 Web Development/0001_Web Request System (WRS)/2023/20221004_144838_E464', 'Joshua Mari Coquia', 'coquia-kdt@corp.khi.co.jp', 'Erwin Tan', 'tan-g1@hg.khi.co.jp;', 'felix, josh, collene', '2022-10-04', '14:48:38', '2022-09-27', '2023-01-20', 100, 'Finished', 'This request was already finished.'),
(77, 'WRN-22-077', '20221012_152756_E61', 0, 'KDT Cloud Based File Finder', 'ANA', 'Kaizen Entry for EE, Mill and Analysis Group', '-', '-', '7. KDT Info Page (ANA).pptx  -  1.99 MB,9. KDT Cloud System (Mill).pptx  -  2.15 MB,10_Photo Database with Translator Software(EE).pptx  -  4.88 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20221012_152756_E61', '-', 'Cezar Balisbis Jr.', 'balisbis-kdt@corp.khi.co.jp', 'Jeffrey Beltran, Jhon Ray Godoy', 'beltran-kdt@corp.khi.co.jp;godoy-kdt@corp.khi.co.j', '-', '2022-10-12', '15:27:56', '0000-00-00', '0000-00-00', 0, 'Cancelled', 'Change Name from \"KDT Cloud Based File Finder\" into \"KDT Cloud Navigator\".'),
(78, 'WRN-22-078', '20221013_103948_E464', 29, 'Web JMR', 'SYS', 'JMR Migration to Web(SQL)', '09 Web Development', '09-', 'image_J4.png  -  2.01 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20221013_103948_E464', '-', 'Joshua Mari Coquia', 'coquia-kdt@corp.khi.co.jp', 'None', 'None;', 'josh, felix', '2022-10-13', '10:39:48', '2022-08-16', '0000-00-00', 20, 'Ongoing', 'System group are now doing your request. \r\nYou can monitor here the progress.'),
(79, 'WRN-22-079', '20221014_155436_E61', 34, 'KDT Cloud Navigator', 'ANA', 'Kaizen Entry for EE, Mill and Analysis Group', '09 Web Development', '09-', '7. KDT Info Page (ANA).pptx  -  1.99 MB,9. KDT Cloud System (Mill).pptx  -  2.15 MB,10_Photo Database with Translator Software(EE).pptx  -  4.88 MB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20221014_155436_E61', '-', 'Cezar Balisbis Jr.', 'balisbis-kdt@corp.khi.co.jp', 'Jeffrey Beltran, Jhon Ray Godoy', 'beltran-kdt@corp.khi.co.jp;godoy-kdt@corp.khi.co.j', 'alvinjohn', '2022-10-14', '15:54:37', '2022-10-20', '0000-00-00', 22, 'Ongoing', 'Updated Feb. 11, 2023'),
(80, 'WRN-22-080', '20221024_103111_E37', 0, 'JMR CM', 'ENE', 'Automated Careless Mistakes Summary Report', '-', '-', 'CarelessMistake_BOI_20220901-20220930_Summary.xlsx  -  309.1 KB,Engineering Careless Mistake_Gen. Summary_SEPT.22.xlsx  -  221.41 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20221024_103111_E37', '-', 'Ferdinand Llanes', 'llanes-kdt@corp.khi.co.jp', 'None', 'None;', '-', '2022-10-24', '10:31:12', '0000-00-00', '0000-00-00', 0, 'Pending', 'Your request is on queue.'),
(81, 'WRN-22-081', '20221124_102346_E314', 0, 'Cable Tray MTO for E3D', 'EE', 'Modification of the \"Kdt.CableTray.MTO.dll\" to run on E3D software and modify \"KDTCableTrayList\" pmlform to choose tray description from excel file \"CTCODE1 or CTCODE2 \".', '-', '-', 'CABLE TRAY MTO.xls  -  95 KB,CTCODE1.csv  -  7.96 KB,CTCODE2.csv  -  1.79 KB,Kdt.CableTray.MTO.dll  -  18 KB,KDTCableTrayList.pmlfrm  -  71.21 KB,KDTDictionary.pmlobj  -  3.93 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20221124_102346_E314', '-', 'Dickenson Sangalang', 'sangalang_d-kdt@corp.khi.co.jp', 'Francis Martee Gulapa', 'gulapa-kdt@corp.khi.co.jp;', '-', '2022-11-24', '10:23:46', '0000-00-00', '0000-00-00', 0, 'Pending', 'Your request is on queue.'),
(82, 'TEST-22-1', '20221208_144735_E466', 0, 'TEST ONLY!', 'SYS', 'TEST ONLY!!', '02 CATIA', '02-0001', '1.png  -  13.65 KB,3.png  -  21.36 KB,4.png  -  47.1 KB,', '\\\\kdt-ph\\c\\WRS\\UPLOADS\\2022\\20221208_144735_E466', '//kdt-ph/c/WRS/PROJECTS/02 CATIA/0001_TEST ONLY!/2022/20221208_144735_E466', 'Alvin John Aganan', 'aganan-kdt@corp.khi.co.jp', 'Earvin James Dela Cruz', 'delacruz-kdt@corp.khi.co.jp;', '-', '2022-12-08', '14:47:35', '2022-12-15', '2022-12-06', 0, 'Cancelled', 'This request was already finished.'),
(83, 'TEST-22-1', '20221208_145209_E466', 0, 'TEST', 'SYS', 'TEST', '01 Application', '01-', '6.png  -  105.01 KB,7.jfif  -  9.94 KB,8.png  -  56.44 KB,9.png  -  286.51 KB,', '\\\\kdt-ph\\C\\WRS\\Uploads\\2022\\20221208_145209_E466', '//157.116.25.159/c/WRS/PROJECTS/01 Application/0016_TEST/2022/20221208_145209_E466', 'Alvin John Aganan', 'aganan-kdt@corp.khi.co.jp', 'Rizchelle Reyes', 'reyes_r-kdt@corp.khi.co.jp;', '-', '2022-12-08', '14:52:09', '2022-12-14', '2022-12-14', 0, 'Cancelled', 'For testing only');

-- --------------------------------------------------------

--
-- Stand-in structure for view `systems group`
-- (See below for the actual view)
--
CREATE TABLE `systems group` (
`ID` int(11)
,`EmployeeID` int(10)
,`FullName` varchar(50)
,`UserName` varchar(30)
,`PC` varchar(20)
,`Email` varchar(50)
,`BusinessUnit` varchar(50)
,`Designation` varchar(20)
,`AccessType` int(3)
,`Access` varchar(15)
);

-- --------------------------------------------------------

--
-- Structure for view `systems group`
--
DROP TABLE IF EXISTS `systems group`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `systems group`  AS SELECT `employee_list`.`ID` AS `ID`, `employee_list`.`EmployeeID` AS `EmployeeID`, `employee_list`.`FullName` AS `FullName`, `employee_list`.`UserName` AS `UserName`, `employee_list`.`PC` AS `PC`, `employee_list`.`Email` AS `Email`, `employee_list`.`BusinessUnit` AS `BusinessUnit`, `employee_list`.`Designation` AS `Designation`, `employee_list`.`AccessType` AS `AccessType`, `employee_list`.`Access` AS `Access` FROM `employee_list` WHERE `employee_list`.`BusinessUnit` like '%SYS%' ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `business_units`
--
ALTER TABLE `business_units`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `control_locationpath`
--
ALTER TABLE `control_locationpath`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `employee_list`
--
ALTER TABLE `employee_list`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `request_list`
--
ALTER TABLE `request_list`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `business_units`
--
ALTER TABLE `business_units`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `control_locationpath`
--
ALTER TABLE `control_locationpath`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `employee_list`
--
ALTER TABLE `employee_list`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=210;

--
-- AUTO_INCREMENT for table `request_list`
--
ALTER TABLE `request_list`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
