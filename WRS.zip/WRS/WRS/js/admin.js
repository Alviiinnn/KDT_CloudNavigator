
$('#btnExport').click(function(){
  // window.open('data:application/vnd.ms-excel,' + $('#requestList').text());
  // $('#tableRequestList').find('th:nth-child(1)').attr('colspan', 100);

  $('#tableRequestList th').attr('data-f-bold', true);
  TableToExcel.convert(document.getElementById("tableRequestList"));
  $('#tableRequestList th').removeAttr('data-f-bold', true);

  $(this).text('EXPORTING . . .');

  setTimeout(() => {
    $(this).text('EXPORT');  
  }, 2000);

});


var uploadControl;

$('input[name=inputUploadControl], input[name=inputExportControl]').click(function(){
  
  if(this.checked){
    // $('span[name=uploadControl]').text("ON");
    $(this).parent().next('span').text("ON");
  }else{
    $(this).parent().next('span').text("OFF");
  }

});


// -----------------------------------
// -- Employee List Table Functions --
// -----------------------------------

$('table[name=employeeList] tr:not(:first)').on('click', function()
{
    var emp_name = $(this).find('td:nth-child(3)').html();
    var emp_id = $(this).attr("value");
    var emp_username = $(this).find('td:nth-child(4)').html();
    var emp_pc = $(this).find('td:nth-child(5)').html();
    var emp_email = $(this).find('td:nth-child(6)').html();
    var emp_BU = $(this).find('td:nth-child(7)').html();
    var emp_designation = $(this).find('td:nth-child(8)').html();
    var emp_access = $(this).find('td:nth-child(9)').html();
    var emp_upload = $(this).find('td:nth-child(10)').html();
    var emp_export = $(this).find('td:nth-child(11)').html();
    $('input[name=inputName]').val(emp_name);
    $('input[name=inputEmployeeID]').val(emp_id);
    $('input[name=inputUsername]').val(emp_username);
    $('input[name=inputEmail]').val(emp_email);
    $('input[name=inputBU]').val(emp_BU);
    $('input[name=inputDesignation]').val(emp_designation);
    $('input[name=inputPC]').val(emp_pc);
    $('select[name=inputAccess]').val(emp_access);
    $('span[name=uploadControl]').text(emp_upload);
    $('span[name=exportControl]').text(emp_export);

    if(emp_upload == "ON"){
        $('input[name=inputUploadControl]').prop("checked", true); // $(this).attr("checked", "checked") is not working well
    }else{
        $('input[name=inputUploadControl]').prop("checked", false);
    }

    if(emp_export == "ON"){
        $('input[name=inputExportControl]').prop("checked", true); // $(this).attr("checked", "checked") is not working well
    }else{
        $('input[name=inputExportControl]').prop("checked", false);
    }

});



$('button[name=updateEmpInfo]').click(function()
{
    $('#formEmployeeInfo select').removeAttr('disabled').prop('title', 'Click to change access.');
    $('button[name=saveEmpInfo], button[name=cancelEmpInfo]').show();
    $('input[name=inputUploadControl], input[name=inputExportControl]').removeAttr("disabled");
    $('.slider').css('cursor', 'pointer');
    $('.switch').css('opacity', '1');
    $(this).hide();
});



$('button[name=cancelEmpInfo]').click(function()
{
    $('#formEmployeeInfo select, input[name=inputUploadControl]').attr('disabled', '');
    $('#formEmployeeInfo select').prop('title', 'This field is disabled.');
    $('button[name=saveEmpInfo], button[name=cancelEmpInfo]').hide();
    $('.slider').css('cursor', 'not-allowed');
    $('.switch').css('opacity', '0.5');

    $('button[name=updateEmpInfo]').show();
});



$('button[name=saveEmpInfo]').click(function()
{
    $('input[name=inputEmployeeID]').removeAttr('disabled');
    $('#modalEmployeeInfo').hide();
});



// -- Global Variables --
var gUserName = $('span[name=username]').text();
var dataEmpty = $('input[name=dataChecker]').attr("data-empty");
var canPressESC = true;   // Checks if user can possibly press the ESC Key
var gReqCode, gKeyPersonEmail, gTitle, gDesc, gKeyPerson, gClientRep, gClientRepEmail, gStatus, gDev, gRemarks, gStartDate, gFinishDate, gProgress, gTicket, gFileLocation, gFinishPath, gProjectType, gProjectCode;  //for Reset to Default Functionality 
var mStatus, mRemarks; //M stands for Modified
var inputChanges = false;       //for Reset to Default Functionality
var dropdownChanges = false;    //for Reset to Default Functionality
var rankingIsClicked = false;   //to check if Ranking Priority is Clicked 
var index_row;    // for Ranking Priority Function
var selectedRow; // for Ranking Priority Function
var table_rows = document.getElementById('tableRequestList').rows;
var default_rows = []; // for Ranking Priority Function
var gFirstName = $('input[name=firstName]').val();
var gDBUsername = $('input[name=dbUsername]').val();
var gRefreshStatus = $('input[name=refreshStatus]').val();


let searchParams = new URLSearchParams(window.location.search);
let hasURLView = searchParams.has('view') // checks if it has 'view' on URL parameters
var statusView = searchParams.get('view'); // gets status view (Pending, Denied...)
let hasURLNav = searchParams.has('nav');
var navView = searchParams.get('nav');


$(document).ready(function()
{
    $('#btnReset').hide();
    $('#btnSave').hide();
    $('#btnCancel').hide();
    $('#navRanking').hide();
    $('#employeeList').hide();
    $('#modalReqDetails').hide();
    $('.divUpDown').hide();
    $('.dev-parent').hide();
    $('.rankingActions').hide();
    $('.dev-child label').hide();
    $('.location-path-section').hide();
    $('i[name=plusProject]').hide();
    $('input[name=projectNumber]').hide();
    $('label[name=projectNumberLabel]').hide();
    $('button[name=saveEmpInfo]').hide();
    $('button[name=cancelEmpInfo]').hide();
    $('button[name=chooseExisting]').hide();
    $('select[name=existingProjects]').hide();


    $(".dev-child img").css("opacity", "0.5");
    $("input[name=inputCode]").attr("title", "You cannot edit this field.");
    $("input[name=inputDateReq]").attr("title", "You cannot edit this field.");
    $("input[name=inputKeyPerson]").attr("title", "You cannot edit this field.");
    $("input[name=inputGroup]").attr("title", "You cannot edit this field.");


    fxTooltip_disabledField("input[name=inputTitle]");
    fxTooltip_disabledField("input[name=inputDesc]");
    fxTooltip_disabledField("input[name=inputReq]");
    fxTooltip_disabledField("input[name=inputDev]");
    fxTooltip_disabledField("form select");
    fxTooltip_disabledField("form textarea");
    fxTooltip_disabledField("input[type=date]");
    fxTooltip_disabledField("#formEmployeeInfo input");
    fxTooltip_disabledField("#formEmployeeInfo select");
    fxTooltip_disabledField("select[name=existingProjects]");
    fxTooltip_disabledField("input[name=projectNumber]");

    $('#navRequestList').addClass('w3-black');

    // -- Dynamically Loads Developers in Filter list --
    $.get("./includes/getDev.php",
        function(data,status){
            const devArray = JSON.parse(data); //converts String to Array
            
            $.each(devArray, function(index, value){
            $("select[name=viewByDev]").append($('<option>',{
                value: value,
                text: value}));
            });
        }
    );   

    var gInitialPath, gFinish_publicPath, gFinish_systemPath, gFinish_BUPath;

    fxGetControl_LocationPath();


    if(dataEmpty == 'true')
    {
        $('#requestList').hide();
        $("div[name=noRequestYet]").show();
        $('div[name=divToolsSection]').hide();
    }


    $('#modalHardRefresh .refresh-firstName').append(gFirstName+"!");
    if(gRefreshStatus == "DONE"){
        $('#modalHardRefresh').hide();
    }else{
        $('#modalHardRefresh').show();
    }

    if(hasURLView){ // Checks if true

    filterStatus = statusView;

    // $('select[name=viewByStatus] option[value=Denied]').prop('selected', true);
    if(filterStatus == 'ongoing'){
        $('select[name=viewByStatus] option[value=Ongoing]').prop('selected', true);
    }
    else if(filterStatus == 'pending'){
        $('select[name=viewByStatus] option[value=Pending]').prop('selected', true);
    }
    else if(filterStatus == 'finished'){
        $('select[name=viewByStatus] option[value=Finished]').prop('selected', true);
        $('select[name=existingProjects]').prop('disabled', true);
        // $('i[name=plusProject]').hide();
        // $('i[name=plusProject]').addClass('hide');
    }
    else if(filterStatus == 'cancelled'){
        $('select[name=viewByStatus] option[value=Cancelled]').prop('selected', true);
    }
    else if(filterStatus == 'denied'){
        $('select[name=viewByStatus] option[value=Denied]').prop('selected', true);
    }
    else{
        $('select[name=viewByStatus] option[value=All]').prop('selected', true);
    }
    $('select[name=viewByStatus]').trigger('change');
    }

    if(hasURLNav){
        if(navView == 'request'){
            $('#navRequestList').trigger('click');
        }
        if(navView == 'employee'){
            $('#navEmployeeList').trigger('click');
        }
        if(navView == 'controls'){
            $('#navControl').trigger('click');
        }
    }

    fxSet_MinMaxDate();
});


var ctrl_press = false;
var f5_press = false;

$('html').keydown(function(e)
{
    if(gRefreshStatus != "DONE")
    {
        e.preventDefault();

        if(e.which == 17){    // Key 17 = CTRL
            ctrl_press = true;
        }
    }

    if (e.which==27){     // Key 27 = ESC
        $("#modalReqDetails").fadeOut();
    }
});



$('html').keyup(function(e)
{
    if(gRefreshStatus != "DONE")
    {
        e.preventDefault();

        if(e.which == 17){    // Key 17 = CTRL
            ctrl_press = false;
        }

        if(e.which == 116)    // Key 116 = F5
        {   
            if(ctrl_press == true)
            {
                f5_press = true;

                $.post("./includes/update.php",
                {
                    requestChecker: "updateHardRefreshDone",
                    privilege: "admin",
                    username: gDBUsername
                }, 
                function(data, status)
                {
                    console.log(status);
                    console.log(data);
                    console.log("Hard Refresh!");
                });
                $('#modalHardRefresh').hide();

                window.location.href = window.location.href;
            }
        }

        // console.log("==============");
        // console.log("F5: "+f5_press);
        // console.log("CTRL: "+ctrl_press);
    }
});




setTimeout(function(){
  $('input[name=inputSearch], select[name=viewByStatus], select[name=viewByDev], #requestList').removeClass('w3-animate-opacity');
}, 500);


var selectedDev;

$("select[name=viewByDev]").change(function()
{
    $("table[name=requestList] tr:not(:first)").remove(); //This will remove all existing Rows to Update New Ones
    $('span[name=clearFilter]').removeClass('hide');
    
    selectedDev = $("select[name=viewByDev]").val();
    filterStatus = $("select[name=viewByStatus]").val();
    


    if(filterStatus === null){
        filterType = "developerFilter";
    }else{
        filterType = "devNstatusFilter";
    }

    $.post("./includes/userViewBy.php",
    {
        filterType: filterType,
        viewByDev: selectedDev,
        viewByStatus: filterStatus
    }, 
    function(data, status){
        
        const obj = JSON.parse("["+data+"]");
        
        fxFilterStatus(obj);
    });


    if(selectedDev !== null)    // If Dev Filter is not Null, Ranking Tab should be Hidden
    {
        $('nav a[name=navRanking]').slideUp();  
    }
});



var filterStatus; // for Status Filter

$('select[name=viewByStatus]').change(function()
{
    $('table[name=requestList] tr:not(:first)').remove();
    $('span[name=clearFilter]').removeClass('hide');

    filterStatus = $("select[name=viewByStatus]").val();
    selectedDev = $("select[name=viewByDev]").val();


    if(selectedDev === null){
        filterType = "statusFilter";
    }else{
        filterType = "devNstatusFilter";
    }


    if(filterStatus == 'All'){
        window.history.pushState( {} , '', '?'); 
        // $('nav a[name=navRanking]').hide(); 
        $('nav a[name=navRanking]').slideUp(); 
    }
    else if(filterStatus == 'Ongoing'){
        $('nav a[name=navRanking]').removeClass("hide");
        // $('nav a[name=navRanking]').show();
        $('nav a[name=navRanking]').slideDown();
        window.history.pushState( {} , '', '?view=ongoing' ); //this method adds Parameters on URL without Reloading the Page
    }
    else if(filterStatus == 'Pending'){
        window.history.pushState( {} , '', '?view=pending' ); 
        // $('nav a[name=navRanking]').hide(); 
        $('nav a[name=navRanking]').slideUp(); 

    }
    else if(filterStatus == 'Finished'){
        window.history.pushState( {} , '', '?view=finished' ); 
        // $('nav a[name=navRanking]').hide(); 
        $('nav a[name=navRanking]').slideUp(); 
        
    }
    else if(filterStatus == 'Cancelled'){
        window.history.pushState( {} , '', '?view=cancelled' ); 
        // $('nav a[name=navRanking]').hide(); 
        $('nav a[name=navRanking]').slideUp(); 

    }
    else if(filterStatus == 'Denied'){
        window.history.pushState( {} , '', '?view=denied' ); 
        // $('nav a[name=navRanking]').hide(); 
        $('nav a[name=navRanking]').slideUp(); 

    }
    else{
        // $('nav a[name=navRanking]').hide(); 
        $('nav a[name=navRanking]').slideUp(); 

        //window.history.pushState( {} , '', '?' ); //I purposely commented this for <header("Location: ../admin.php?view=$status");> in update.php
    }

    $.post("./includes/userViewBy.php", 
    {
        filterType: filterType,
        viewByStatus: filterStatus,
        viewByDev: selectedDev
    },
    function(data,status){
        

        const obj = JSON.parse("["+data+"]"); //get Object Data from userViewBy.php thru AJAX Post
        fxFilterStatus(obj);
    }); //end of AJAX POST

});



$("span[name=clearFilter]").click(function()
{
    // window.history.pushState( {}, '', '?');
    // location.reload();

    window.location.href = "/WRS/admin.php";

    // $('select[name=viewByStatus] option[value=All]').prop('selected', true).trigger('change');
});



$("#btnReset").click(function()
{
    var keyperson_value =  gKeyPerson+"~"+gKeyPersonEmail;  
    var status_value = gStatus.toLowerCase();
    status_value = (status_value == 'on hold')? 'onhold': status_value;
    gProjectType = (gProjectType == "")? "default": gProjectType;

    $('select[name=inputKeyPerson] option[value="'+keyperson_value+'"]').prop('selected', true);
    $('select[name=inputClientRep] option[value="'+gClientRep+'"]').prop('selected', true);
    $('select[name=inputStatus] option[value='+status_value+']').prop('selected', true);
    $('select[name=projectType] option[value="'+gProjectType+'"]').prop('selected', true);

    $('input[name=inputTitle]').val(gTitle);
    $('input[name=inputDesc]').val(gDesc);
    $('input[name=inputDev]').val(gDev);
    $('input[name=inputStartDate]').val(gStartDate);
    $('input[name=inputFinishDate]').val(gFinishDate);
    $('input[name=inputProgress]').val(gProgress);

    $('textarea[name=inputRemarks]').val(gRemarks);

    $('.dev-parent').slideUp();
    $(".dev-child").children("label").hide();
    $(".dev-child").children("img").css("opacity", "0.5");
    $('input[name=inputDev]').removeAttr("disabled");
    $(".projectNumber_list").slideUp();

    // $('input[name=inputDev]').trigger('click');
    // $('.dev-parent').children.('div').attr('data-active-dev', 'false');

    $(this).hide();
    $('#btnSave').hide();
});



$("input[name^=finishFile]").change(function(){

    $('div[name=fileList_Jar]').slideUp();

    $('#modalUpload').show();
    
    $('div[name=fileList_Jar]').children().remove();  //This will RESET the File List

    const fileList = this.files; 
    var ctr, file, fileSize, newFileSize, uploadedFiles = "";

    if(fileList.length == 0)
    {
        $('p[name=fileList_header]').hide();
        // $('#btn_uploadToServer').attr({'disabled':true, 'title':'Upload a file to enable this button'}); //Ni-comment ko kasi ginawan ko ng Function -Alvin
        fxDisableButton('#btn_uploadToServer', 'Upload files to enable this button');
    }
    else{
        $('p[name=fileList_header]').show();
        // $('#btn_uploadToServer').attr({'disabled':false, 'title':'Click to upload files to WRS Server'}); //Ni-comment ko kasi ginawan ko ng Function -Alvin March 3, 2022
        fxEnableButton('#btn_uploadToServer', 'Click to upload files to WRS Server');
    }

    for(ctr=0; ctr < fileList.length; ctr++)
    {
        fileName = fileList[ctr].name;
        fileSize = fileList[ctr].size;

        newFileSize = (fileSize / 1024).toFixed(2); //Rounds Up to the Nearest 2 Decimal Point

        if(newFileSize >= 1000){
        newFileSize = (newFileSize / 1024).toFixed(2); // Converts Kilobytes to Megabytes
        newFileSize += " MB";
        }else{
        newFileSize += " KB";
        }
        
        uploadedFiles += "<div class='w3-row-padding'>";
        uploadedFiles += "<label class='w3-col s1 m1 l1'>"+(ctr+1)+"</label>";
        uploadedFiles += "<label class='w3-col s8 m8 l8'>"+fileName+"</label>";
        uploadedFiles += "<label class='w3-col s3 m3 l3 kanan'>"+newFileSize+"</label>";
        uploadedFiles += "</div>";
    }

    $('div[name=fileList_Jar]').append(uploadedFiles);
    $('div[name=fileList_Jar]').slideDown();


});



$("#btn_uploadToServer").click(function(e)
{
    var fd = new FormData();
    var fileList = $('#finishFile')[0].files;
    const thiz = $(this);

    $.each(fileList, function(index, value){
        console.log("Index: "+index+" | Value: "+value);
        fd.append( "finishFile[]", $("#finishFile")[0].files[index]);
    });
    fd.append("fileLocation", $("input[name=fileLocation]").val());  
    fd.append("inputText", $("input[name=inputText]").val());
    fd.append("dbUsername", $("input[name=dbUsername]").val());
    fd.append("inputCode", $("input[name=inputCode]").val());

    $.ajax({
        url: './includes/uploadFile-admin.php',
        type: 'POST',
        cache: false,
        data: fd,
        processData: false,
        contentType: false,
        beforeSend: function(){
            thiz.html('<i class="fa fa-spinner c-loading"></i> Uploading . . .');
            thiz.attr({'disabled':true, 'title':'Uploading, please wait.'});
        },
        success: function(){
        },
        complete: function()
        {
            // $('#modalUpload').hide();
            setTimeout(() => {
                thiz.children().remove(); // Removes the Spinner
                thiz.text('Upload to Server');
                $('p[name=fileList_header], div[name=fileList_Jar]').slideUp();
                fxDisableButton('#btn_uploadToServer', 'Upload files to enable this button');
                $('div[name=notif-top-mid] p').text('Upload Success!');
                $('div[name=notif-top-mid]').show();
            }, 2000);
            $('div[name=notif-top-mid]').delay(10000).hide();
        },
        error: function(){
        alert("ERROR in Uploading Files\nPlease contact Alvin from System Group to fix this.");
        }

    });

    e.preventDefault();
});



$('button[name=copyBtn]').click(function(e)
{
    e.preventDefault();
    $('input[name=inputReq]').select(); //This will SELECT ALL the Text inside the Input Field
    document.execCommand("copy"); //This will run the Copy Command to copy the Selected Text above in Clipboard
    $('p[name=copied]').show().fadeOut(1000);
});



$('#btnEdit').click(function()
{  
    canPressESC = false;
    $("input[name=inputTitle], input[name=inputDesc], input[name=inputDev], form select, form textarea").removeAttr("title");
    $("input[name=inputTitle]").attr("title", "Possible Macro Name");
    $("input[name=inputDesc]").attr("title", "Describe this Macro Request");
    // $("input[name=inputReq]").attr("title", gFileLocation);
    $("select[name=inputClientRep]").attr("title", "Choose one Client Reqresentative");
    $("select[name=inputStatus]").attr("title", "Update Status");
    $("input[name=inputDev]").attr("title", "Click to assign developers.");
    $("textarea[name=inputRemarks]").attr("title", "Input Remarks");
    $('#btnEdit, #xButton, #btnUpload').hide();
    $('#btnCancel').show();
    $("#modalReqDetails input:not('.disabledField'), #modalReqDetails select, #modalReqDetails textarea").removeAttr("disabled");
    
    fxAddClass_cEnabled("form input:not('input[name=reqNumber],input[name=inputCode],input[name=inputDateReq],input[name=inputKeyPerson],input[name=inputGroup],input[name=inputReq]')");
    fxAddClass_cEnabled("form select");
    fxAddClass_cEnabled("form textarea");
});



$("#btnUpload").click(function(){
    $('#finishFile').trigger('click');
    // $('input[name=inputDev]').attr('disabled', true);   //Bug Prevention - Prevents Dev Input to Auto Unabled
});



$('input[name^=finishFile]').change(function(){
    $('#modalUpload').show();
});



$("#formUpdateRequest input[name^=input], #formUpdateRequest textarea").keyup(function(event)
{  
    // Current Values
    var title = $('input[name=inputTitle]').val(); 
    var desc = $('input[name=inputDesc]').val();
    var dev = $('input[name=inputDev]').val();
    var progress = $('input[name=inputProgress]').val();
    var remarks = $('textarea[name=inputRemarks]').val();
    var mRemarks = remarks;


    if(gTitle==title && gDesc==desc && gDev==dev && gRemarks==remarks && gProgress==progress)
    {
        inputChanges = false;
        if(dropdownChanges == false)
        {
            $("#btnReset").hide();
            $("#btnSave").hide();
        }
    }else{
        $("#btnReset").show();
        $("#btnSave").show();
        inputChanges = true;
    }
});



$("input[name=inputProgress]").keyup(function(event)
{
    var progress = $('input[name=inputProgress]').val();
    
    //---- INPUT NUMBER Type is accepting (-), (+), 'e', and 'E' Values
    // 189 & 109 is Minus (-) Key
    // 187 & 107 is Plus (+) Key
    // 69 is E Key
    if(event.keyCode == 189 || event.keyCode == 109 || event.keyCode == 187 || event.keyCode == 107 || event.keyCode == 69){
        $('input[name=inputProgress]').val(prev_progress);
    }

    if(progress >= 100){
        $('input[name=inputProgress]').val(100);
    }

    fxOngoingRemarks(progress, mStatus);   //Changes Remarks depending on the Progress Value
});



var prev_progress;  //Stores the previous Progress Input

$("input[name=inputProgress]").keydown(function()
{
    prev_progress = $('input[name=inputProgress]').val();
});



$("#formUpdateRequest select, input[name=inputStartDate], input[name=inputFinishDate]").change(function()
{
    var clientRep = $('select[name=inputClientRep]').val();
    var status = $('select[name=inputStatus]').val();
    var startDate = $('input[name=inputStartDate]').val();
    var finishDate = $('input[name=inputFinishDate]').val();


    if(gClientRep == clientRep && gStatus == status && gStartDate==startDate && gFinishDate==finishDate)
    {
        dropdownChanges = false;
        if(inputChanges == false)
        {
            $("#btnReset").hide();
            $("#btnSave").hide();
        }
    }
    else{
        $("#btnReset").show();
        $("#btnSave").show();
        dropdownChanges = true;
    }
});



$("input[name=inputStartDate], input[name=inputFinishDate]").click(function()
{
    $(this).removeClass('requiredField');
});



// balik ka dito
$('input[name=inputProgress]').click(function()
{
    var progress = $('input[name=inputProgress]').val();

    if(gProgress == progress){

        // inputChanges = false;
        if(dropdownChanges == false && inputChanges == false)
        {
            $("#btnReset").hide();
            $("#btnSave").hide();
        }
    }
    else{
        $("#btnReset").show();
        $("#btnSave").show();
        // inputChanges = true;
    }
    fxOngoingRemarks(progress, mStatus);

});



$('#btnCancel').click(function(e)
{
    e.preventDefault();
    canPressESC = true;
    $("input[name=inputTitle], input[name=inputDesc], input[name=inputDev], form select, form textarea").attr("title", "This field is disabled.");
    $("#btnEdit, #xButton, #btnUpload").show();
    $("#btnReset, #btnSave, #btnCancel").hide();
    $("#modalReqDetails input:not([readonly]), #modalReqDetails select, #modalReqDetails textarea").attr("disabled","");
    $('form input:not("input[name=inputCode],input[name=inputDateReq],input[name=inputKeyPerson],input[name=inputGroup]"), form select, form textarea').removeClass('c-enabled');
    $(".dev-parent").slideUp();
    $(".dev-child").children("label").hide();
    $(".dev-child").children("img").css("opacity", "0.5");
    $(".projectNumber_list").slideUp();
    $('form input, form select, form textarea').removeClass('requiredField');

});


// -- SAVE EVENT --
// ----------------
var readyToSave = true;

$('#btnSave').click(function(event)
{
    event.preventDefault();
    var progressChecker = $('input[name=progress]').val();

    mProjectNumber = $('input[name=projectNumber]').val();
    $('.projectNumber_list').hide();


    if(typeof progressChecker === "undefined"){
    // $('input[name=inputProgress]').val(0); //
    }

    
    if(mProjectNumber)
    {
        mProjectNumber = mProjectNumber.padStart(4, 0);   //Add Zeros if Value is 1 = 0001
        $('input[name=projectNumber]').val(mProjectNumber);
    }
    else{
        $('input[name=projectNumber]').val("");
    }


    let reasonVal = $('textarea[name=inputRemarks]').val();

    if(reasonEnabled == true && reasonVal == "")
    {
        $('textarea[name=inputRemarks]').addClass('requiredField').attr('placeholder', 'This is a required field!');
        fxShakeModal('modalReqDetails');
        readyToSave = false;
    }

    
    if(mStatus == "finished")
    {
        fxCheck_FinishDate();
        fxCheck_ProjectType();
    }

    
    
    if(mStatus == 'ongoing' || mStatus == 'onhold' || mStatus == 'waiting' || mStatus == 'finished')
    {
        fxCheck_StartDate();
    }
    
    
    fxExistingProject_ProjectCode();


    if( !fxCheck_namumula('#formUpdateRequest input') && !fxCheck_namumula('#formUpdateRequest select') && !fxCheck_namumula('#formUpdateRequest textarea')   )
    {
        readyToSave = true;
        console.log("true namumula");
    }
    else{
        console.log("false namumula");
        readyToSave = false;
    }


    if(mStatus == "finished")
    {
        readyToSave = false;
    }

    
    // let elementStartDate = $('input[name=inputStartDate]');
    // if(mStatus.toLowerCase() != gStatus.toLowerCase())  // This will check if Start Date is Filled-in
    // {
    //     if(mStatus == 'ongoing' || mStatus == 'onhold' || mStatus == 'waiting' || mStatus == 'finished')
    //     {
    //         if( !elementStartDate.val() )    
    //         {
    //             elementStartDate.addClass('requiredField');
    //             fxShakeModal('modalReqDetails');
    //             fxRemoveClass_setTimeOut(elementStartDate, 'requiredField', 10000);
    
    //             readyToSave = false;
    //         }
    //         else{
    //             $('#modalMoveToFinish').show();
    //         }
    //     }
    // }
    
    // fxCheck_namumula('#formUpdateRequest input');
    // fxCheck_namumula('#formUpdateRequest select');




    // This If Statement must be at the Bottom of #btnSave Click Event
    if(readyToSave == true)
    {
        $("#modalConfirm").show();
        $("#modalRequestDetails").addClass("c-blur");
    }
});


function fxCheck_namumula(element)
{
    if( $(element).hasClass('requiredField') || $(element).hasClass('errorField') )
    {
        return true;
    }
    else{
        return false;
    }
}


function fxExistingProject_ProjectCode()
{
    if(mProjectType !== null && mStatus == "finished")
    {
        readyToSave = false;
        if(existingProjGrp_show == true)
        {
            fxValidateInput('select[name=existingProjects]', 'modalReqDetails', 'Existing Project Grp');
        }
        else
        {
            fxValidateInput('input[name=projectNumber]', 'modalReqDetails', 'Project Number Grp');
        }
    }
}


function fxCheck_StartDate()
{
    let element = $('input[name=inputStartDate]');

    if(!element.val())
    {
        element.addClass('requiredField');
        fxShakeModal('modalReqDetails');
        fxRemoveClass_setTimeOut(element, 'requiredField', 10000);

        readyToSave = false;
    }
}


function fxCheck_FinishDate()
{
    let element = $('input[name=inputFinishDate]');

    if(!element.val())
    {
        element.addClass('requiredField');
        fxShakeModal('modalReqDetails');
        fxRemoveClass_setTimeOut(element, 'requiredField', 10000);

        readyToSave = false;
    }
}


function fxCheck_ProjectType()
{
    let element = $('select[name=projectType]');

    if(!element.val())
    {
        $('select[name=projectType]').addClass('requiredField');
        fxShakeModal('modalReqDetails');
        fxRemoveClass_setTimeOut(element, 'requiredField', 10000);

        readyToSave = false;
    }
}



$("#btnGoBack").click(function()
{
    $('#modalMoveToFinish').hide();
    $('div.info_modalBody').children().remove();
});



$("#btn_seeDetails").click(function()
{
    $('#modal_movingFilesInfo').show();

    $("#modal_movingFilesInfo #btn_ok").click(function(){
        $('#modal_movingFilesInfo').fadeOut();
    });
});



$("#btnProceed").click(function()
{  
    $.post("./includes/checkDirectory.php",
    {
        pathLocation: gFileLocation
    },
    function(data, status)
    {
        if(status = "success")
        {
            if(data == "true")
            {
                $('#modalConfirm').show();
                $('#modalMoveToFinish').hide();
            }
            else{
                // Cannot find Directory
                console.log("\nERROR: DIRECTORY DOES NOT EXISTS! \n\nFile Location - "+gFileLocation);
                $('#modalMoveToFinish').fadeOut();
                $('.error-fileLocation').show();
                $('input[name=inputReq]').addClass('errorField');

                fxShakeModal('modalReqDetails');

                setTimeout(() => {
                $('input[name=inputReq]').removeClass('errorField');
                $('.error-fileLocation').hide();
                }, 10000);
            }
        }
        else{
            console.log("Status Failed: Check if 'checkDirectory.php' exists.");
        }
    });
});



$("#modalConfirm #btnNo").click(function(){
    $("#modalConfirm").hide();
});



$("#modalConfirm #btnYes").click(function(event)
{
    $("input[name=inputCode]").removeAttr("disabled"); //to get the value of inputCode
    $("input[name=inputDev]").removeAttr("disabled"); //to get the value of inputDev
    $('#modalConfirm').hide();

    event.preventDefault();
    
    if(statusUpdated == true)
    {
        $('#modalSendReqStat').show();

        $('#modalSendReqStat button[name=yes]').click(function()
        {
            var updated_title = $('input[name=inputTitle]').val();
            var updated_desc = $('input[name=inputDesc]').val();
            var updated_keyPerson = $('select[name=inputKeyPerson] option:selected').text();
            var updated_clientRep = $('select[name=inputClientRep] option:selected').text();
            var updated_devs = $('input[name=inputDev]').val();
            var updated_remarks = $('textarea[name=inputRemarks]').val();
            
            $.post("./includes/sendEmail.php", 
            {
                emailType: 'StatusChanged',
                emailAdmin: gUserName,
                emailTicket: gTicket,
                emailRequestCode: gReqCode,
                emailTitle: updated_title,
                emailDesc: updated_desc,
                emailKeyPerson: updated_keyPerson,
                emailClientRep: updated_clientRep,
                emailKPersonEmail: gKeyPersonEmail,
                emailCRepEmail: gClientRepEmail,
                emailDevs: updated_devs,
                emailStatus: mStatus,
                emailRemarks: updated_remarks 
            }, function(data, status){
                console.log(data);
                console.log(status);
            });

            $("#formUpdateRequest").submit();
        });

        $('#modalSendReqStat button[name=no]').click(function(){
            $("#formUpdateRequest").submit();
        });
    }
    else{
        $("#formUpdateRequest").submit();
    } // end of If Else Statement

});


$("tr").hover(function()
{
    let a = $(this).find('td:last-child').hasClass('yellow-bg');

    if(a === true){
        $(this).find('td:last-child').css('font-weight', 'bold');
    }

},function(){
    $(this).find('td:last-child').css('font-weight', 'normal');
}
);


// ----------------------------------
// -- Request List Table Functions --
// ----------------------------------

// STATIC-PARENT              on  EVENT    DYNAMIC-CHILD
$("table[name=requestList]").on('click', '.rowClick', function()    //This code provides solutions on UNCLICKABLE APPENDED Elements
{ 
    if(rankingIsClicked === true)
    {
        index_row = $(this).index()+1;
        selectedRow = $(this);
        $(this).css({'background-color':'#ccc', 'font-weight':'bold'}); 
        $('tr').not($(this)).css({'background-color':'', 'font-weight':''});
        $('a[name=first], a[name=up], a[name=down], a[name=last]').addClass('disabled'); 
        $('.divUpDown').attr('title', '');

        if(selectedRow.index() == 0){
            $('a[name=down], a[name=last]').removeClass('disabled'); 
        }
        else if(selectedRow.index() == table_rows.length-2){
            $('a[name=first], a[name=up]').removeClass('disabled'); 
        }
        else{
            $('a[name=first], a[name=up], a[name=down], a[name=last]').removeClass('disabled'); 
        }
        // $(this).find('td:first-child').html(1023);
        // var priorityRank = $(this).find('td:first-child').html();
    }
    else{
        var trCode = $(this).attr('value');
        $("#modalReqDetails").show();
        
        $.post("./includes/requestDetails.php",
        {
            reqCode: trCode,
            user: "admin"
        },
        function(data, status)
        {
            ajaxCode           = fxExtract_Data(data, "RequestCode~", 12);       //12 is the length of "RequestCode~" Keyword
            ajaxTitle          = fxExtract_Data(data, "Title~", 6);
            ajaxGroup          = fxExtract_Data(data, "Group~", 6);
            ajaxDesc           = fxExtract_Data(data, "Description~", 12);
            ajaxReq            = fxExtract_Data(data, "InitialPath~", 12);
            ajaxKeyPerson      = fxExtract_Data(data, "KP~", 3);
            ajaxClientRep      = fxExtract_Data(data, "ClientRepresentative~", 21);
            ajaxDev            = fxExtract_Data(data, "Developer~", 10);
            ajaxDateReq        = fxExtract_Data(data, "DateRequested~", 14);
            ajaxStartDate      = fxExtract_Data(data, "StartDate~", 10);
            ajaxFinishDate     = fxExtract_Data(data, "FinishDate~", 11);
            ajaxProgress       = fxExtract_Data(data, "Progress~", 9);
            ajaxStatus         = fxExtract_Data(data, "Status~", 7);
            ajaxRemarks        = fxExtract_Data(data, "Remarks~", 8);
            ajaxKeyPersonEmail = fxExtract_Data(data, "KeyPersonEmail~", 15);
            ajaxClientRepEmail = fxExtract_Data(data, "ClientRepEmail~", 15);
            ajaxUploadedFiles  = fxExtract_Data(data, "UploadedFiles~", 14);
            ajaxTicketNumber   = fxExtract_Data(data, "TicketNumber~", 13);
            ajaxPriorityRank   = fxExtract_Data(data, "PriorityRank~", 13);
            ajaxProjectType    = fxExtract_Data(data, "ProjectType~", 12);
            ajaxFinishPath     = fxExtract_Data(data, "FinishPath~", 11);
            ajaxProjectCode    = fxExtract_Data(data, "ProjectCode~", 12);


            fxGetGroupName(ajaxGroup);
            ajaxDev = (ajaxDev == "-") ? ajaxDev : ajaxDev+", ";
            ajaxStartDate = (ajaxStartDate == "0000-00-00")? "": ajaxStartDate; //Prevents Javascript 0000-00-00 Date Warning
            ajaxFinishDate = (ajaxFinishDate == "0000-00-00")? "": ajaxFinishDate; //Prevents Javascript 0000-00-00 Date Warning


            // Assigns to Global Variable for RESET TO DEFAULT
            gReqCode = ajaxCode;
            gKeyPersonEmail = ajaxKeyPersonEmail;
            gTitle = ajaxTitle;
            gDesc = ajaxDesc;
            gKeyPerson = ajaxKeyPerson;
            gClientRep = ajaxClientRep;
            gClientRepEmail = ajaxClientRepEmail;
            gFileLocation = ajaxReq;
            gFinishPath = ajaxFinishPath;
            gStatus = ajaxStatus;
            gDev = ajaxDev;
            gRemarks = ajaxRemarks;
            gStartDate = ajaxStartDate;
            gFinishDate = ajaxFinishDate;
            gProgress = ajaxProgress;
            gTicket = ajaxTicketNumber;
            gProjectType = ajaxProjectType;
            gProjectCode = ajaxProjectCode;

            $("input[name=reqNumber]").val(ajaxTicketNumber);
            $("input[name=inputCode]").val(ajaxCode);
            $("select[name=projectType]").val((ajaxProjectType === "" || ajaxProjectType === "-")? "default": ajaxProjectType);
            $("input[name=inputDateReq]").val(ajaxDateReq);
            // $("input[name=inputKeyPerson]").val(ajaxKeyPerson);  // Commented dahil pinalitan ng Select Element
            $("input[name=inputGroup]").val(ajaxGroup);

            $("input[name=inputTitle]").val(ajaxTitle).attr('title', ajaxTitle);
            $("input[name=inputDesc]").val(ajaxDesc).attr('title', ajaxDesc);
            $("input[name=inputReq]").val(ajaxReq).attr('title', ajaxReq);
            $('input[name=fileLocation]').val(ajaxReq);
            $("input[name=inputClientRep]").val(ajaxClientRep+"~"+ajaxClientRepEmail);
            $("select[name=inputClientRep]").append("<option selected value='"+ajaxClientRep+"~"+ajaxClientRepEmail+"'>"+ajaxClientRep+"</option"); //Upon row click, Selected in Modal IKAW LANG PALA UNG BUG PAMBIHIRA
            $("select[name=inputKeyPerson]").append("<option selected value='"+ajaxKeyPerson+"~"+ajaxKeyPersonEmail+"'>"+ajaxKeyPerson+"</option"); 
            $("input[name=inputDev]").val(ajaxDev);
            // ajaxStatus = (ajaxStatus == "On Hold")? "onhold" : ajaxStatus;
            // $("select[name=inputStatus]").val(ajaxStatus.toLowerCase());
            $("select[name=inputStatus]").val( ((ajaxStatus === "On Hold")? "onhold" : ajaxStatus).toLowerCase() );
            $("textarea[name=inputRemarks]").val(ajaxRemarks);
            $("input[name=inputStartDate]").val(ajaxStartDate);
            $("input[name=inputFinishDate]").val(ajaxFinishDate);
            $("input[name=inputProgress]").val(ajaxProgress); 
            $("input[name=inputPriorityRank]").val(ajaxPriorityRank);

            fxHide_projectNumGrp();
            fxHide_existingProjGrp();
            
            existingProjGrp_show = true;
            projNumGrp_show = false;


            if(ajaxStatus != "Ongoing" && ajaxStatus != "On Hold"){
                $('select[name=inputStatus] option[value=onhold]').remove();
            }


            if(ajaxStatus == "Finished")
            {
                if(ajaxFinishPath == "")
                {
                    $("input[name=inputReq]").attr('placeholder', "The Finish Path is not set.").val("");
                    $('#modalReqDetails button[name=copyBtn]').attr('disabled', true);
                }
                else{
                    // PURPOSE: When user copied the Path, system will redirect user to the Folder Location instead of opening the File to Browser
                    ajaxFinishPath = ajaxFinishPath.replace(/\//g, "\\");   //Replaces Backslash (/) into Forward Slash (\)  

                    $("input[name=inputReq]").val(ajaxFinishPath).attr('title', ajaxFinishPath);
                    $('#modalReqDetails button[name=copyBtn]').attr('disabled', false);
                }
            }



            if(ajaxStatus == "Finished" && ajaxProjectType != null)
            {
                fxHide_existingProjGrp();
                fxShow_projectNumGrp();

                projNumGrp_show = true;
                existingProjGrp_show = false;
                
                $('button[name=chooseExisting]').hide();

                ajaxProjectCode = ajaxProjectCode.slice(-4);
                $('input[name=projectNumber]').val(ajaxProjectCode);
            }

            $("#modalReqDetails").show();

            var group = $("input[name=inputGroup]").val();
            var clientRep = $("select[name=inputClientRep]").text();
            clientRep = $.trim(clientRep); //Trims whitespace. Nirereturn kasi lahat ng index DEPRECATED
            $.post("./includes/getClientRep.php",
            {
                requestFrom: 'admin',
                postGroup: group,
                postClientRep: clientRep
            },
            function(data,status)
            {
                const clientRepArray = JSON.parse(data); //converts String to Array
                
                var nameWithoutEmail;
                $.each(clientRepArray, function(index, value)
                {
                    nameWithoutEmail = value.slice(0, value.indexOf("~")); //this will slice the Employee's Full Name from its Email. Example: ["Alvin John Aganan~aganan-kdt@corp.khi.co.jp"]
                    $("select[name=inputClientRep], select[name=inputKeyPerson]").append($('<option>',{
                        value: value,
                        text: nameWithoutEmail
                    }));
                });
            });        
        });   //end of function(data, status)
    } //end of else statement
});



var statusUpdated = false; //This variable will trigger the Status Changed Email
var reasonEnabled = false; //This will check if Textarea Reason is ON or OFF
var mStatus, mProgress, mProjectType, mProjectNumber;  // M stands for Modified
var remarksPlaceholder;

$("select[name=inputStatus]").change(function()
{
    mStatus = $(this).val();
    mProgress = $('input[name=inputProgress]').val();
    mProjectType = $('select[name=projectType]').val();

    $('select[name=existingProjects]').children().remove();     //Resets 'Existing Projects' Field <options>

    if(gStatus != mStatus)
    {
        statusUpdated = true;
    }else{
        statusUpdated = false;
    }

    mRemarks = $('textarea[name=inputRemarks]').val();
    $('label[name=remarks]').text('Remarks:');  //This is the Default
  

    if(mStatus == "cancelled" || mStatus == "denied")
    {
        remarksPlaceholder = "Your request is "+mStatus+" due to . . . (Explain your reason here)";
        $('textarea[name=inputRemarks]').val('').attr('placeholder', remarksPlaceholder);
        $('label[name=remarks]').text('Reason:');
        
        reasonEnabled = true;
    }
    else if(mStatus == "pending")
    {
        remarksPlaceholder = "Your request is on queue.";
        $('textarea[name=inputRemarks]').val(remarksPlaceholder);
    }
    else if(mStatus == "ongoing" && mProgress == 100)
    {
        fxOngoingRemarks(mProgress, mStatus);
    }
    else if(mStatus == "ongoing")
    {
        fxOngoingRemarks(mProgress, mStatus);
    }
    else if(mStatus == "onhold")
    {
        remarksPlaceholder = "Your request is ON HOLD due to prior requests.";
        $('textarea[name=inputRemarks]').val(remarksPlaceholder);
    }
    else if(mStatus == "waiting")
    {
        remarksPlaceholder = "Waiting for comments / documents.";
        $('textarea[name=inputRemarks]').val(remarksPlaceholder);
    }
    else if(mStatus == "finished")
    {
        remarksPlaceholder = "This request was already finished.";
        $('textarea[name=inputRemarks]').val(remarksPlaceholder);

        if(mProjectType != null)
        {
            // fxFadeIn_projectNumGrp();
            fxFadeIn_existingProjGrp();
            fxGetTotalFiles();
        }
    }
    else
    {
        remarksPlaceholder = "Put your comments or notes here.";
        $('textarea[name=inputRemarks]').val(gRemarks).attr('placeholder', remarksPlaceholder);
        reasonEnabled = false;
    }


    if(mStatus != "finished")
    {
        $('select[name=projectType]').removeClass('requiredField'); 
        $('input[name=inputStartDate]').removeClass('requiredField'); 
        $('input[name=inputFinishDate]').removeClass('requiredField'); 
        
        fxFadeOut_projectNumGrp(); 
        fxFadeOut_existingProjGrp();
    }
});



$("input[name=inputSearch]").keyup(function()
{
    var tbl         = "table[name=requestList]";
    var tbl_header  = "table[name=requestList] tr th";
    var searchInput = "input[name=inputSearch]";

    fxSearch_table(searchInput, tbl_header, tbl);
    fxRow_NotFound(tbl, "No Requests Found");  
});



$("input[name=searchEmployee]").keyup(function()
{
    // var searchVal = $(this).val();
    // alert('\nThis feature is under development.\n\nTIP: Try to use (CTRL + F) to search on this page.');

    var tbl         = "table[name=employeeList]";
    var tbl_header  = "table[name=employeeList] tr th";
    var searchInput = "input[name=searchEmployee]";

    fxSearch_table(searchInput, tbl_header, tbl);
    fxRow_NotFound(tbl, "No Employees Found");  
});






var arrProjectList = [];

$("select[name=projectType]")
    .on('click', function(){
        $(this).removeClass('requiredField');
    })

    .on('change', function(){
        $('select[name=existingProjects]').children().remove();
        $('.projectNumber_list').children().remove();
        arrProjectList = [];    //Resets Array List

        mProjectType = $(this).val();
        if(mStatus == "finished" || mStatus == "Finished")
        {
            if(projNumGrp_show)
            {
                fxFadeIn_projectNumGrp();
            }
            else{
                fxFadeIn_existingProjGrp();
            }
        }
        else{ 
            fxFadeOut_projectNumGrp();
            fxFadeOut_existingProjGrp();
        }

        fxGetTotalFiles();
    })

; //End of "select[name=projectType]"



$("select[name=existingProjects]").click(function(){
    $(this).removeClass('errorField');
    $('.error-projectNumber').fadeOut();
});



$("input[name=projectNumber]")
    .keydown(function(e){
        var input_value =  parseInt( $(this).val() );

        if(isNaN(input_value))  //Checks if Value is NaN
        {
            input_value = 0;
        }

        if(e.which == 38)   //Keycode 38 = Up Arrow Key
        {   
            if(input_value < 9999)
            {
                input_value += 1;
            }
            privateFunc();
        }

        if(e.which == 40)   //Keycode 40 = Down Arrow Key
        {
            if(input_value != 0000)
            {
                input_value -= 1;
                privateFunc();
            }
        }

        function privateFunc()
        {
            input_value = String(input_value);
            input_value = input_value.padStart(4, 0);   //Add Zeros if Value is 1 = 0001
            $('input[name=projectNumber]').val(input_value);
        }
    })

    .focus(function(){
        $(this).removeClass('errorField');
        $('.projectNumber_list').slideDown();
    })
;



var projNumGrp_show = false;
var existingProjGrp_show = true;


$("button[name=chooseExisting]").click(function()
{
    // $('#modalProjectsView').show();
    $('.projectNumber_list').slideUp();
    $('.error-projectNumber').hide();
    fxHide_projectNumGrp();
    fxFadeIn_existingProjGrp();
});


$("i[name=plusProject]").click(function()
{
    $('input[name=projectNumber]').val("");
    $('.error-projectNumber').hide();

    fxHide_existingProjGrp();
    fxFadeIn_projectNumGrp();

    $('select[name=existingProjects] option[value=default]').prop('selected', true);
    // console.log($('select[name=existingProjects]').html());
});



// When ESC Key is Pressed, hide Modal
$('body').keydown(function(e)
{
    if(e.which==27 && canPressESC == true)  //Key 27 is for ESC Keyboard Input
    { 
        $('#modalReqDetails').fadeOut();
    }
});



$('#xButton').click(function()
{
    $("#modalReqDetails").hide();
    $("select[name=inputClientRep]").find('option').remove(); // ".end()" is optional. Removes all <options>
});



// -- Nav Events Functions-- 

$('#navRequestList').click(function()
{
    rankingIsClicked = false;
    navControl_clicked = true;


    if(dataEmpty == 'true'){
        $('#requestList').hide();
        $("div[name=noRequestYet]").show();
    }else{
        $('#requestList').show();
    }

    if($("select[name=viewByStatus]").val() == "Ongoing"){
        // $("nav a[name=navRanking]").show();
        $("nav a[name=navRanking]").slideDown();
    }

    $('div[name=divToolsSection]').show();    
    $('.divUpDown, .rankingActions').hide();
    $('div[name=controls_subitems]').slideUp();
    $('#navControl_caret').addClass('rotate-right-caret');

    $('input[name=inputSearch], select[name=viewByStatus], select[name=viewByDev]').slideDown();
    $('span[name=clearFilter]').show();

    $('#btnExport').fadeIn();
    $('#section_title').text('Active Requests');
    $('#section_subtitle').text('Ongoing, On Hold, Waiting, and Pending Items');
    $('#navRequestList').addClass('w3-black');
    $('#navEmployeeList').removeClass('w3-black');
    $('nav a:not(#navRequestList)').removeClass('w3-black');
    $('#employeeList, #locationPath_section').hide();
    $('tr').not($(this)).css({'background-color':'', 'font-weight':''});
    $('a[name=first], a[name=up], a[name=down], a[name=last]').addClass('disabled'); 

    window.history.pushState( {}, '', '?nav=request');
});



$('#navEmployeeList').click(function()
{
    rankingIsClicked = false;
    navControl_clicked = true;

    $('div[name=controls_subitems]').slideUp();
    $('#navControl_caret').addClass('rotate-right-caret');

    $('#section_title').text('Employee List');
    $('#section_subtitle').text('KDT Current Employees');
    $('#navEmployeeList').addClass('w3-black');
    $('#navRequestList').removeClass('w3-black');
    $('nav a:not(#navEmployeeList)').removeClass('w3-black');

    $('span[name=clearFilter]').hide();

    $('#requestList').hide();
    $('#btnExport').hide();
    $('#locationPath_section').hide();
    $('.rankingActions').hide();
    $('div[name=noRequestYet]').hide();
    $('input[name=inputSearch]').hide();
    $('select[name=viewByDev]').hide();
    $('select[name=viewByStatus]').hide();
    $('div[name=divToolsSection]').hide();

    $('nav a[name=navRanking]').slideUp();
    $('#employeeList').removeClass("hide");
    $('#employeeList').show();
    window.history.pushState( {} , '', '?nav=employee' ); 
});



$('#navRanking').click(function()
{
    $('div[name=controls_subitems]').slideUp();
    $('#navControl_caret').addClass('rotate-right-caret');

    $(this).addClass('w3-black');
    $('nav a:not(#navRanking)').removeClass('w3-black');
    $('input[name=inputSearch], select[name=viewByStatus], select[name=viewByDev], #btnExport').slideUp();
    $('.divUpDown').show();
    $('span[name=clearFilter]').hide();


    rankingIsClicked = true;
    navControl_clicked = true;

    var default_list = $('table[name=requestList] tr');
    // $('table[name=requestList] tr').eq(index).find('td:first-child').html(index);

    var ctr, row_list;
    var checker = $(default_list).eq(0).find('td:nth-child(2)').html();
    
    for(ctr=0; ctr<default_list.length;ctr++){
        default_rows[ctr] = $(default_list).eq(ctr+1).find('td:nth-child(2)').html(); //eq(0) is UNDEFINED
    }

    for(ctr=0; ctr<default_list.length-1;ctr++){
        // console.log(default_rows[ctr]);
    }
    // $('.divUpDown').animate({"margin-right" : '+=200'});
});



var navControl_clicked = true;

$('#navControl').click(function()
{
    rankingIsClicked = false;
    $('#section_title').text('Location Paths');
    $('#section_subtitle').text('CONTROL');
    $('nav a:not('+this+')').removeClass('w3-black');
    $('#control_locationPaths').addClass('w3-black');
    $('#employeeList, #requestList, a[name=navRanking], input[name=inputSearch], select[name=viewByDev], select[name=viewByStatus], #btnExport, .rankingActions').hide();
    $('#locationPath_section, .location-path-section').show();
    $('span[name=clearFilter]').hide();


    if(navControl_clicked)
    {
        $('div[name=controls_subitems]').removeClass('hide');
        $('div[name=controls_subitems]').hide();
        $('div[name=controls_subitems]').slideDown();

        $('#navControl_caret').removeClass('rotate-right-caret');
        $('#navControl_caret').addClass('rotate-down-caret');

        navControl_clicked = false;
    }
    else{
        $('div[name=controls_subitems]').slideUp();

        $('#navControl_caret').removeClass('rotate-down-caret');
        $('#navControl_caret').addClass('rotate-right-caret');

        navControl_clicked = true;
    }

    $(this).addClass('w3-black');
    // $('#control_locationPaths').addClass('w3-black');

    // $('#requestList, div[name=noRequestYet], input[name=inputSearch], select[name=viewByDev], select[name=viewByStatus], nav a[name=navRanking], .rankingActions, #btnExport').hide();
    // $('#employeeList').removeClass("hide");
    // $('#employeeList').show();
    window.history.pushState( {} , '', '?nav=controls' ); 
});



$("div[name=controls_subitems] a").click(function()
{
    var sidebar_text = $(this).text();
    sidebar_text = sidebar_text.trim();

    $('div[name=controls_subitems]').children().removeClass('w3-black');
    $(this).addClass('w3-black');
    $('#section_title').text(sidebar_text);

    if(sidebar_text == "Location Paths"){
        $('section.location-path-section').show();
    }
    else{
        $('section.location-path-section').hide();

    }
});

// $("#control_emails").click(function(){
//   $('#section_title').text("Emails");
//   $('div[name=controls_subitems]').children().removeClass('w3-black');
//   $(this).addClass('w3-black');
// });


// -- End of Nav Events Functions-- 



$("form input:not(input[name=inputDev], input[name=projectNumber]), form select, form textarea").bind('click focus',function()
{
    $(".dev-parent").slideUp();
    $(".projectNumber_list").slideUp();
    $("input[name=inputDev]").removeAttr("disabled");    //Creates Bug - auto enabling of Input Dev | 
    $('textarea[name=inputRemarks]').attr('placeholder', remarksPlaceholder).removeClass('requiredField');
});



$("input[name=inputDev]").bind('click keyup',function()
{
    $("input[name=inputDev]").attr("title", "Click images below to assign developers.");
    $(this).attr("disabled", "");
    $(".dev-parent").slideDown();
    var devValue = $("input[name=inputDev]").val();
    var splitter = devValue.split(',');
    var devLabel = $(".dev-child").find("label");

    for(ctr=0;ctr<splitter.length-1;ctr++)
    {
        var iDev = splitter[ctr].trim();

        for(i=0;i<devLabel.length;i++)
        {
            var devList = $(devLabel[i]).text();

            if(iDev == devList)
            {
                iDev = "#"+devList;
                $(iDev).children("label").show();
                $(iDev).children("img").css("opacity", "1");
                $(iDev).attr("data-active-dev", "true");
            }
        }
    }
});



$(".dev-child").click(function()
{
    $('#btnSave').show();

    // $("input[name=inputDev]").trigger('keyup');
    // inputChanges = true;
    $("#btnReset").show();

    if( $("input[name=inputDev]").val() == '-'){
        $("input[name=inputDev]").val("");
    }

    var clicks = $(this).data('clicks');
    var devLabel = $(this).children("label").text();
    var inputVal = $("input[name=inputDev]").val();
    var newVal = "";
    var activeDevChecker = $(this).attr("data-active-dev");

    if(activeDevChecker == "true")
    {
        $(this).children("img").css("opacity", "0.5");
        $(this).children("label").hide();
        newVal = inputVal.replace(devLabel+", " , "");
        $("input[name=inputDev]").val(newVal);
        $(this).attr("data-active-dev", "false");
    }
    else{
        $(this).children("img").css("opacity", "1");
        $(this).children("label").show();
        $("input[name=inputDev]").val(inputVal+devLabel+", ");
        $(this).attr("data-active-dev", "true");
    }
});



// -- Move to FIRST ROW Function --
$("a[name=first]").click(function()
{
    $('.rankingActions').show();
    $('a[name=down], a[name=last]').removeClass('disabled'); 

    if(index_row == 1 || selectedRow.index() == 0){
        return false;   // this will disable <a> tag onclick event
    }

    parent = table_rows[index_row].parentNode;

    if(index_row > 1)
    {                               // New Node    Reference Node
        parent.insertBefore(table_rows[index_row], table_rows[1]); // This Inserts Selected Row to other Rows
        trList = $('table[name=requestList] tr');

        $.each(trList, function(index, value)
        {
            if(index > 0){
                $('table[name=requestList] tr').eq(index).find('td:first-child').html(index);
            }
        });

        // index_row--; // decrements every UP click
        selectedRow.find('td:first-child').html(1); // This changes the Index Value of Selected Row
    }

    $('a[name=first], a[name=up]').addClass('disabled'); 
    index_row = 1;
}); 



// -- Move 1 ROW UP Function --
$("a[name=up]").click(function()
{
    $('.rankingActions').show();
    $('a[name=down], a[name=last]').removeClass('disabled'); 

    if(index_row == 1 || selectedRow.index() == 0){
        return false;   // this will disable <a> tag onclick event
    }
    parent = table_rows[index_row].parentNode;

    if(index_row > 1)
    {
        parent.insertBefore(table_rows[index_row], table_rows[index_row - 1]); // This Inserts Selected Row to other Rows
        trList = $('table[name=requestList] tr');

        $.each(trList, function(index, value)
        {
            if(index != index_row && index > index_row){
                $('table[name=requestList] tr').eq(index).find('td:first-child').html(index);
            }

            if(index == index_row){
                $('table[name=requestList] tr').eq(index).find('td:first-child').html(index);
            }
        });

        index_row--; // decrements every UP click
        selectedRow.find('td:first-child').html(index_row); // This changes the Index Value of Selected Row
        
        if(index_row == 1){   //Checks if it reaches the First Row then it will disable the UP and Move to <a> tag
            $('a[name=first], a[name=up]').addClass('disabled'); 
        }
    }
}); 



// -- Move 1 ROW DOWN Function
$("a[name=down]").click(function()
{
    $('.rankingActions').show();
    $('a[name=first], a[name=up]').removeClass('disabled'); 

    parent = table_rows[index_row].parentNode;

    if(index_row == table_rows.length-2){
        $('a[name=down], a[name=last]').addClass('disabled'); 
    }

    if(index_row < table_rows.length-1)
    {
        parent.insertBefore(table_rows[index_row+1], table_rows[index_row]);
        index_row++;
        trList = $('table[name=requestList] tr');
        
        $.each(trList, function(index, value){
            if(index != index_row && index < index_row){
                $('table[name=requestList] tr').eq(index).find('td:first-child').html(index);
            }
            
            if(index == index_row){
                $('table[name=requestList] tr').eq(index).find('td:first-child').html(index-1);
            }
        });
        selectedRow.find('td:first-child').html(index_row); // This changes the Index Value of Selected Row
    }
});



// -- Move to LAST ROW Function --
$("a[name=last]").click(function()
{
    const tableLength = table_rows.length;

    $('.rankingActions').show();
    $('a[name=first], a[name=up]').removeClass('disabled'); 

    if(index_row == tableLength-1 || selectedRow.index() == tableLength-2){
        return false;   // this will disable <a> tag onclick event
    }

    parent = table_rows[index_row].parentNode;

    if(index_row < tableLength-1){  // New Node    Reference Node
        parent.insertBefore(table_rows[index_row], table_rows[tableLength]); // This Inserts Selected Row to other Rows
        trList = $('table[name=requestList] tr');

        $.each(trList, function(index, value)
        {
            if(index < tableLength-1){
                $('table[name=requestList] tr').eq(index).find('td:first-child').html(index);
            }
            if(index == tableLength-1){
                $('table[name=requestList] tr').eq(index).find('td:first-child').html(index-1);
            }
        });

        // index_row--; // decrements every UP click
        selectedRow.find('td:first-child').html(tableLength-1); // This changes the Index Value of Selected Row
    }

    $('a[name=down], a[name=last]').addClass('disabled'); 
    index_row = tableLength-1;
}); 



// -- Ranking Priority Actions --

$('button[name=saveRanking]').click(function()
{
    $('#modalConfirmRanking').show();
});



$('button[name=cancelRanking]').click(function()
{
    window.location.href = "admin.php?view=ongoing";
    // $('#navRequestList').trigger('click');   
});



$("button[name=yesConfirmRanking]").click(function()
{
    $('#modalConfirmRanking').hide();

    var newRanking = [], undefinedChecker;
    $.each(trList, function(index, value)
    {
        undefinedChecker = $('table[name=requestList] tr').eq(index).find('td:nth-child(3)').html();

        if(undefinedChecker !== undefined){
            newRanking[index] = $('table[name=requestList] tr').eq(index).find('td:nth-child(3)').html();
        }
    });

    $.post("./includes/update.php", 
    {
        requestChecker: "updateRanking",
        newRanking: newRanking
    },
    function(data, status){
        var dataStorage = data;
        console.log("Data: "+data);
        console.log(status);
        if(status == 'success')
        {
            window.location.href = "/WRS/admin.php?changes=ranking";
        }
    });

    $.each(default_rows, function(index, value){
        // console.log(default_rows[index]);
    });
    // window.location.href = 'admin.php?view=ongoing';
    // location.reload(); //this reloads the entire page  //uncomment mo to - April 21, 2022
});



$("button[name=noConfirmRanking]").click(function()
{
    $('#modalConfirmRanking').hide();
});



// -- EMPLOYEE LIST Functions --

$('table[name=employeeList]').click(function()
{
    $('#modalEmployeeInfo').show();
})
// -- End of EMPLOYEE LIST Functions -- 




// -- CONTROL > LOCATION PATH Functions (Start) -- 
// -----------------------------------------------

$("button.lp-change-btn").click(function()
{
    $(this).hide();
    $(this).next().hide();
    $(this).nextAll('.lp-reset-btn').fadeIn(1000);

    $(this).prevAll('.lp-path-input').removeAttr('readonly').attr('placeholder', 'Set the Location Path here');
    $(this).prevAll('.lp-path-input').focus();
});



$("input.lp-path-input").keyup(function(event)
{
    var inputName = $(this).attr('name');
    var current_value = $(this).val();
    var default_value;

    $(this).nextAll('.lp-save-btn').hide();

    if(inputName      == "initialPath"){         default_value = gInitialPath;  }
    else if(inputName == "finish_publicPath"){   default_value = gFinish_publicPath;  }
    else if(inputName == "finish_systemPath"){   default_value = gFinish_systemPath;  }
    else if(inputName == "finish_BUPath"){       default_value = gFinish_BUPath;  }
    else{ 
        console.log("ERROR: Location Path Input Name does not Exists![Input Keydown]"); 
    }


    if(current_value == default_value || current_value == ""){
        $(this).nextAll('.lp-check-btn').fadeOut();
    }else{
        $(this).nextAll('.lp-check-btn').fadeIn();
    }
});



$("button.lp-reset-btn").click(function()
{
    $(this).hide();
    $(this).nextAll().hide();
    $(this).prevAll('.lp-change-btn, .lp-copy-btn').fadeIn(1000);

    $(this).prevAll('.lp-path-input').attr('readonly', true);

    const input_name = $(this).prevAll('.lp-path-input').attr('name');
    var reset_path;

    if(input_name      == "initialPath"){         reset_path = gInitialPath;  }
    else if(input_name == "finish_publicPath"){   reset_path = gFinish_publicPath;  }
    else if(input_name == "finish_systemPath"){   reset_path = gFinish_systemPath;  }
    else if(input_name == "finish_BUPath"){       reset_path = gFinish_BUPath;  }
    else{ 
        console.log("ERROR: Location Path Input Name does not Exists!\n[Reset Button]"); 
    }

    $(this).prevAll('.lp-path-input').val(reset_path).removeClass('lp-green');
});



$("button.lp-copy-btn").click(function(e)
{
    e.preventDefault();
    $(this).prevAll('.lp-path-input').select(); //This will SELECT ALL the Text inside the Input Field 
    document.execCommand("copy"); //This will run the Copy Command to copy the Selected Text above in Clipboard

    $(this).nextAll('.lp-copy').show().fadeOut(1000);
});



$("button.lp-check-btn").click(function()
{
    var input_value = $(this).prevAll('.lp-path-input').val();
    var thiz = $(this);

    $.post("./includes/checkDirectory.php",
    {
        pathLocation: input_value  
    },
    function(data, status)
    {
        if(data == "true")
        {
            console.log('true');
            thiz.hide();

            $('span.lp-notif').addClass('w3-green').removeClass('w3-red').text("Nice one, this path exists!").fadeIn();
            thiz.prevAll('.lp-path-input').addClass('lp-green');
            thiz.nextAll('.lp-save-btn').fadeIn(1000);
            
            setTimeout(() => {
                $('span.lp-notif').fadeOut();
                thiz.prevAll('.lp-path-input').removeClass('lp-green');
            }, 3000);
        }
        else{
            console.log('false');
            $('span.lp-notif').addClass('w3-red').removeClass('w3-green').text("WARNING: This path doesn't exists!").fadeIn();
            thiz.prevAll('.lp-path-input').addClass('lp-red');

            setTimeout(() => {
                $('span.lp-notif').fadeOut();
                thiz.prevAll('.lp-path-input').removeClass('lp-red');
            }, 3000);
        }
    });
});



var update_thisPath, update_PathName;

$("button.lp-save-btn").click(function()
{
    var path_inputName = $(this).prevAll('.lp-path-input').attr('name');
    update_thisPath = $(this).prevAll('.lp-path-input').val();
    
    if(path_inputName      == "initialPath"){              update_PathName = "Initial Path";  }
    else if(path_inputName == "finish_publicPath"){   update_PathName = "Finish Public Path";  }
    else if(path_inputName == "finish_systemPath"){   update_PathName = "Finish System Path";  }
    else if(path_inputName == "finish_BUPath"){       update_PathName = "Finish BU Path";  }
    else{ 
        console.log("ERROR: Location Path Input [Name] attribute does not Exists!"); 
    }  

    $('.confirm-path').html("<b>"+update_thisPath+"</b>");
    $('#modalControlSave').show();
});



$("#modalControlSave #btnYes").click(function()
{
    $('#modalControlSave').hide();
    $('#modalControlSaveConfirm').show();
});



$("#modalControlSaveConfirm #btnYes").click(function()
{
    // update_thisPath = update_thisPath.replace(/\\/g, "/");  //Replaces Forward Slash (\) into Backslash (/)

    $.post("./includes/update.php",
    {
        requestChecker: "updateControlLocationPath",
        pathLocation: update_thisPath,
        pathName: update_PathName
    },
    function(data, status)
    {
        if(status == "success")
        {
            $('#modalControlSave').fadeOut();
            $('button.lp-reset-btn, button.lp-save-btn, button.lp-check-btn').hide();
            $('button.lp-change-btn, button.lp-copy-btn').fadeIn();

            setTimeout(() => {
                $('span.lp-notif').addClass('w3-green').removeClass('w3-red').text("Path Updated Successfully!").fadeIn();
            }, 1000);

            setTimeout(() => {
                $('span.lp-notif').fadeOut();
            }, 5000);
        }

        $('#modalControlSaveConfirm').fadeOut();
    });

});



$("#modalControlSave #btnNo").click(function(){
    $('#modalControlSave').fadeOut();
});



$("#modalControlSaveConfirm #btnNo").click(function(){
    $('#modalControlSaveConfirm').fadeOut();
});



function fxGetControl_LocationPath(){

    $.get("./includes/getControl-LocationPath.php",
    function(data,status)
    {
        // const obj = JSON.parse(data); //converts String to Array
        const obj = JSON.parse("["+data+"]"); //converts String to Array
        
        for(ctr=0; ctr<obj.length; ctr++)
        {
            var pathName = obj[ctr].PathName;
            var pathLocation = obj[ctr].LocationPath;

            // PURPOSE: When user copied the Path, system will redirect user to the Folder Location instead of opening the File to Browser       
            pathLocation = pathLocation.replace(/\//g, "\\");  //Replaces Backslash (/) into Forward Slash (\)        
            
            if(pathName == "Initial Path")
            {
                $('input[name=initialPath]').val(pathLocation);
                gInitialPath = pathLocation;
            }
            else if(pathName == "Finish Public Path")
            {
                $('input[name=finish_publicPath]').val(pathLocation);
                gFinish_publicPath = pathLocation;
            }
            else if(pathName == "Finish System Path")
            {
                $('input[name=finish_systemPath]').val(pathLocation);
                gFinish_systemPath = pathLocation;
            }
            else if(pathName == "Finish BU Path")
            {
                $('input[name=finish_BUPath]').val(pathLocation);
                gFinish_BUPath = pathLocation;
            }
            else if(pathName == "01 Application" || 
                    pathName == "02 CATIA" || 
                    pathName == "03 Microsoft Excel" ||
                    pathName == "04 AVEVA Marine" ||
                    pathName == "05 Autocad" ||
                    pathName == "06 Arduino" ||
                    pathName == "07 PDMS" ||
                    pathName == "08 Mobile Development" ||
                    pathName == "09 Web Development")
            {   
                //Do nothing -Alvin (March 29, 2022)
            }
            else{
                console.log('ERROR: Added Path Name on Database is not yet configured!');
                console.log('Variable "pathName" = '+pathName);
            }
        }
    });  
}

// -- CONTROL > LOCATION PATH Functions (End) -- 
// =============================================




// -- URL Functions -- 
// ------------------- 

let urlParams = new URLSearchParams(window.location.search);
let hasChanges = urlParams.has('changes'); // checks if it has 'changes' on URL parameters
var urlCode = urlParams.get('changes'); // gets request value in URL
var tableList = $('table[name=requestList] tr');
var tableData;

if(hasChanges)
{
    // window.location.search = ''; // removes URL Parameters but reloads the Page
    // $('div[name=notif]').show(); // for Popup Notification on Left Side
    // $('div[name=notif-top-mid]').show(); // for Popup Notification on Upload File
    // $('div[name=notif-top-mid-a]').show(); // for Popup Notification in the Middle
    
    if(urlCode == 'ranking')
    {
        $('div[name=notif-top-mid-a] p').text('Priority Requests is Updated');
        $('div[name=notif-top-mid-a]').show();
    }else{
        $('div[name=notif-top-mid-a] p').text('Updated Successfully!');
        $('div[name=notif-top-mid-a]').show();
    }

    setTimeout(function(){
        window.history.replaceState({}, document.title, "/" + "WRS/admin.php"); // removes URL Parameters WITHOUT RELOADING the Page
    },100);

    $.each(tableList, function(index, value)
    {
        if(index != 0)
        {
            tableData = tableList.eq(index).find('td:nth-child(3)').html();
            if(tableData == urlCode)
            {
                tableList.eq(index).addClass('newlyChanges');
            }
        }
    });
    
    setTimeout(function(){
        tableList.removeClass('newlyChanges');
    }, 20000);
}

// -- End of URL Functions -- 
// ==========================