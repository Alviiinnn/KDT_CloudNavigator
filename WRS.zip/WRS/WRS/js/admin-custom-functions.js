// --------------------------
// NOTE:         This Javascript Program contains all Custom Functions made by ALVIN JOHN AGANAN.
// PURPOSE:      The purpose of this is to make WRS Project "Clean Code" so that other Developers can read it clearly and easily maintain it in the future.
// Date Created: May 18, 2022
// --------------------------



function fxTooltip_disabledField(element){
    $(element).attr("title", "This field is disabled.");
}



function fxEnableButton(ID, title){
    $(ID).attr({'disabled':false, 'title':title});
}



function fxDisableButton(ID, title){
    $(ID).attr({'disabled':true, 'title':title});
}



function fxCloseModal(modalID){
    $('#'+modalID).fadeOut();
}



function fxAddClass_cEnabled(element){
    $(element).addClass('c-enabled');
}



function fxShakeModal(modalName)
{
    $('div[name='+modalName+']').addClass('shakeClass');
    setTimeout(function(){
        $('div[name='+modalName+']').removeClass('shakeClass');
    }, 500);
}



function fxExtract_Data(data, fieldName, size)
{
    first_index = data.indexOf(fieldName);
    last_index = data.lastIndexOf(fieldName);
    extracted_data = data.substring(first_index+size, last_index); 

    return extracted_data;
}



function fxFill_infoModalBody()
{
    $('div.info_modalBody').children().remove();

    var projNum = $('input[name=projectNumber]').val(); 
    var projName = $('input[name=inputTitle]').val();

 // var targetPath = gFinish_systemPath+"\\"+mProjectType+"\\"+projNum+"_"+projName; 
    var targetPath = gFinish_systemPath+"\\<br><b>"+mProjectType+"\\"+moveFiles_targetFolder+"</b>"; 

    var line1 = "<h6 style='font-size: 14px;'>Folder name <b>"+gReqCode+"</b> from the path</h6>";
    var line2 = "<h6 style='color: royalblue;'>"+gFileLocation+"</h6>";
    var line3 = "<h6 style='font-size: 14px;'>will be moved to</h6>";
    var line4 = "<h6 style='color: royalblue;margin-bottom: 20px;'>"+targetPath+"</h6>";

    $('div.info_modalBody').append(line1+line2+line3+line4);
}



function fxGetGroupName(BUCode)
{
    $.post('./includes/getGroupName.php',
    {
        groupCode: BUCode
    },
    function(data, status)
    {
        if(status == 'success'){
            $("input[name=inputGroup]").val(BUCode +" - "+data).attr('title', BUCode +" - "+data);
        }else{
            console.log('ERROR: There was an error getting the Group Name. \nGroup Code = '+BUCode);
        }
    });
}



function fxShow_projectNumGrp()
{
    $('label[name=projectNumberLabel]').show().text('Project Number:');
    $('input[name=projectNumber]').show();
    $('button[name=chooseExisting]').show();

    projNumGrp_show = true;
    existingProjGrp_show = false;
}


function fxHide_projectNumGrp()
{
    $('label[name=projectNumberLabel]').hide();
    $('input[name=projectNumber]').hide();
    $('button[name=chooseExisting]').hide();   

    projNumGrp_show = false;
    existingProjGrp_show = true;
}


function fxFadeIn_projectNumGrp()
{
    $('label[name=projectNumberLabel]').text('Project Number:').fadeIn();
    $('input[name=projectNumber]').delay(100).fadeIn();
    $('button[name=chooseExisting]').delay(200).fadeIn();

    projNumGrp_show = true;
    existingProjGrp_show = false;
}


function fxFadeOut_projectNumGrp()
{
    $('label[name=projectNumberLabel]').delay(400).fadeOut();
    $('input[name=projectNumber]').delay(200).fadeOut();
    $('button[name=chooseExisting]').fadeOut();   

    projNumGrp_show = false;
    existingProjGrp_show = true;
}


function fxShow_existingProjGrp()
{
    $('label[name=projectNumberLabel]').text('Existing Projects:').show();
    $('select[name=existingProjects]').show();
    $('i[name=plusProject]').show();

    projNumGrp_show = false;
    existingProjGrp_show = true;
}


function fxHide_existingProjGrp()
{
    $('label[name=projectNumberLabel]').hide();
    $('select[name=existingProjects]').hide();
    $('i[name=plusProject]').hide();   

    projNumGrp_show = true;
    existingProjGrp_show = false;
}


function fxFadeIn_existingProjGrp()
{
    $('label[name=projectNumberLabel]').text('Existing Projects:').fadeIn();
    $('select[name=existingProjects]').delay(100).fadeIn();
    $('i[name=plusProject]').delay(200).fadeIn();

    projNumGrp_show = false;
    existingProjGrp_show = true;
}


function fxFadeOut_existingProjGrp()
{
    $('label[name=projectNumberLabel]').delay(400).fadeOut();
    $('select[name=existingProjects]').delay(200).fadeOut();
    $('i[name=plusProject]').fadeOut();   

    projNumGrp_show = true;
    existingProjGrp_show = false;
}


function fxRemoveClass_setTimeOut(ID, className, duration)
{
    setTimeout(() => {
        $(ID).removeClass(className);
    }, duration);
}


function fxOngoingRemarks(progress, status)
{
    if(status == "ongoing")
    {
        if(progress >= 100)
        {
            remarksPlaceholder = "The progress of your request is 100%. \nPlease communicate with System Developers if you have any concerns to your request.";
            $('textarea[name=inputRemarks]').val(remarksPlaceholder);

        }else{
            remarksPlaceholder = "System group are now doing your request. \nYou can monitor here the progress.";
            $('textarea[name=inputRemarks]').val(remarksPlaceholder);
        }
    }
}


function fxSet_MinMaxDate()
{
    var date_obj = new Date();
    var current_year    = date_obj.getFullYear();
    var current_month   = date_obj.getMonth()+1;
    var current_day     = date_obj.getDate();
    current_month       = current_month.toString().padStart(2, 0);  //Adds 0 in January -> 01
    var current_date    = current_year+"-"+current_month+"-"+current_day;


    $('input[name=inputStartDate]').attr('max', current_date);
    $('input[name=inputFinishDate]').attr('min', (current_year-1)+"-01-01");    //Finish Date Minimum ay -1 lang sa Current Year as of Sir Edmon (May 30, 2022) - ALvin Aganan
}



var moveFiles_targetFolder;

function fxValidateInput(ID, modalName, activeGrp)
{
    let field_val = $(ID).val();
    const arrExists = arrProjectList.indexOf(mProjectNumber);


    if(activeGrp == 'Existing Project Grp')
    {
        moveFiles_targetFolder = $('select[name=existingProjects]').val();
    }
    else{
        moveFiles_targetFolder = $('input[name=projectNumber]').val();
        moveFiles_targetFolder += "_"+$('input[name=inputTitle]').val();      //Output: 0001_Project Name
    }


    if(field_val == "" || field_val == null)
    {
        $('.error-projectNumber').text('This field is required!').show();
        $('.projectNumber_list').hide();
        fxPrivate_fvi();
    }
    else if(field_val == 0)
    {
        $('.error-projectNumber').text('Zero is an Invalid Input!').show();
        $('.projectNumber_list').hide();
        fxPrivate_fvi();
    }
    else if(arrExists != -1)
    {
        $('.error-projectNumber').text('Project Number already Exists!').show();
        $('.projectNumber_list').hide();
        fxPrivate_fvi();
    }
    else
    {
        fxFill_infoModalBody();
        $('#target_folder').text(moveFiles_targetFolder);

        if( $('input[name=inputFinishDate]').val() )
        {
            $('#modalMoveToFinish').show();
        }
    }



    function fxPrivate_fvi()    //FVI = fxValidateInput
    {
        $(ID).addClass('errorField');  
        fxShakeModal(modalName); 
        
        setTimeout(() => {
            $(ID).removeClass('errorField');
            $('.error-projectNumber').hide();
        }, 10000);
    }
}





function fxGetTotalFiles()  
{
    var path = gFinish_systemPath+"\\";  //../WRS/PROJECTS...
    path += $('select[name=projectType]').val();  //01 Application...

    $.post("./includes/getFolderTotalFiles.php",
    {
        projectType_path: path
    },
    function(data, status)
    {
        if(status == "success")
        {
            firstgetTotFiles = data.indexOf("getTotFiles");
            lastgetTotFiles = data.lastIndexOf("getTotFiles");
            ajaxgetTotFiles = data.substring(firstgetTotFiles+11, lastgetTotFiles); //11 is the length of "getTotFiles" Keyword

            firstgetFolderNames = data.indexOf("getFolderNames");
            lastgetFolderNames = data.lastIndexOf("getFolderNames");
            ajaxgetFolderNames = data.substring(firstgetFolderNames+14, lastgetFolderNames); //14 is the length of "getFolderNames" Keyword
        }
        
        // console.log("Total Files = "+ajaxgetTotFiles);
        // console.log("Folder Names = "+ajaxgetFolderNames);
        var parsedFolderNames = JSON.parse(ajaxgetFolderNames);

        if(parsedFolderNames.length == 0){
            $('select[name=existingProjects]').append("<option disabled selected>No Projects Found</option>");
            $('.projectNumber_list').append('<p><i>No Projects Found</i></p>');
        }
        else{
            $('select[name=existingProjects]').append("<option value='' disabled selected>- choose one -</option>");
        }
    
        
        $.each(parsedFolderNames, function(index, value)
        {
            $('select[name=existingProjects]').append("<option value='"+value+"'>"+value+"</option>");
            $('.projectNumber_list').append('<p>'+value+'</p>');

            value = value.substring(0, 4);
            arrProjectList.push(value);
        });
        console.log(arrProjectList.indexOf('0005'));

        // $('input[name=projectNumber]').val(ajaxgetTotFiles);
        $('input[name=projectNumber]').attr('placeholder', ajaxgetTotFiles);
    });
}



function fxFilterStatus(obj)
{
    if(obj.length == 0){
        // const noData = "<td>-</td><td><i>No Requests Found</i></td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td class='gitna'>-</td>";
        // $("#tableRequestList").append("<tr disabled>"+noData+"</tr>");
        $("#tableRequestList").append("<tr disabled><td colspan='16' class='c-text-center'><i>No Requests Found</i></td>");
    }    

    var ctr2 = 0;

    for(var ctr=0;ctr<obj.length;ctr++){
        ctr2++;
        var tdCtr = "<td>"+ctr2+"</td>";
        var tdTicket = "<td>"+obj[ctr].TicketNumber+"</td>";
        var tdCode = "<td class='tdRequestCode' value='"+obj[ctr].RequestCode+"'>"+obj[ctr].RequestCode+"</td>";
        var tdTitle =     "<td>"+obj[ctr].Title+"</td>"; // this Title Object is from userViewBy.php AJAX POST
        var tdGroup =     "<td>"+obj[ctr].Group+"</td>";
        var tdDesc =      "<td>"+obj[ctr].Desc+"</td>";
        var tdProjectType="<td>"+obj[ctr].ProjectType+"</td>";
        var tdKeyPerson = "<td>"+obj[ctr].KeyPerson+"</td>";
        var tdClientRep = "<td>"+obj[ctr].ClientRep+"</td>";
        var tdDev =       "<td>"+obj[ctr].Dev+"</td>";
        var tdDateReq =   "<td>"+obj[ctr].DateReq+"</td>";
        // var tdTimeReq =   "<td>"+obj[ctr].TimeReq+"</td>";
        var tdStartDate =   (obj[ctr].StartDate == '0000-00-00') ? "<td>-</td>" : "<td>"+obj[ctr].StartDate+"</td>";
        var tdFinishDate =  (obj[ctr].FinishDate == '0000-00-00') ? "<td>-</td>" : "<td>"+obj[ctr].FinishDate+"</td>";
        var tdRemarks =   "<td>"+obj[ctr].Remarks+"</td>";
        var tdProgress =   (obj[ctr].Progress == 0) ? "<td>-</td>": "<td>"+obj[ctr].Progress+"%</td>";
        var tdStatus;

        if(obj[ctr].Status == "Ongoing")
        {
            tdStatus = "<td class='gitna'><span class='c-status yellow-bg'>"+obj[ctr].Status+"</span></td>";
        
            if(obj[ctr].Progress == 100){
                tdStatus = "<td class='gitna'><span class='c-status green-bg'>"+obj[ctr].Status+"</span></td>";
            }
        }
        else if(obj[ctr].Status == "On Hold"){
            tdStatus = "<td class='gitna'><span class='c-status blue-bg'>"+obj[ctr].Status+"</span></td>";
        }
        else if(obj[ctr].Status == "Finished" || obj[ctr].Status == "Waiting"){
            tdStatus = "<td class='gitna'><span class='c-status green-bg'>"+obj[ctr].Status+"</span></td>";
        }
        else if(obj[ctr].Status == "Cancelled" || obj[ctr].Status == "Denied"){
            tdStatus = "<td class='gitna'><span class='c-status red-bg'>"+obj[ctr].Status+"</span></td>";
        }
        else{
            tdStatus = "<td class='gitna'><span class='c-status'>"+obj[ctr].Status+"</span></td>";
        }

        var appendTr =  "<tr value='"+obj[ctr].RequestCode+"' class='rowClick'>"+tdCtr+tdTicket+tdCode+tdTitle+tdDesc+tdProjectType+tdGroup+tdKeyPerson+tdClientRep+tdDev+tdDateReq+tdStartDate+tdFinishDate+tdRemarks+tdProgress+tdStatus+"</tr>";
        $("table[name=requestList] tbody").delay(5000).append(appendTr);
    }
}



