// --------------------------
// NOTE:         This Javascript Program contains all Universal Custom Functions for both User and Admin UI made by ALVIN JOHN AGANAN.
// PURPOSE:      The purpose of this is to make WRS Project "Clean Code" so that other Developers can read it clearly and easily maintain it in the future.
// Date Created: June 7, 2022
// --------------------------


function fxRow_NotFound(tableName, text)
{
    if(!$(tableName+' tbody tr').is(':visible')){
        $(tableName+' tbody').append("<tr disabled class='matchNotFound'><td colspan='16' class='c-text-center'><i>"+text+"</i></td>");
    }else{
        $(tableName+' tbody tr').remove('.matchNotFound');
    }
}


function fxSearch_table(element, table_header, table_name)
{
    var filter, table, tr, td, i, txtValue, td_ctr, col_length;

    search_input = $(element).val();
    search_input = String(search_input);    //This solves the bug "TypeError: Cannot read properties of undefined (reading 'toUpperCase')"
    filter = search_input.toUpperCase();
    col_length = $(table_header).length;
    table = $(table_name);
    tr = table.find('tr');
    
    td_ctr = 0;

    for (i = 0; i < tr.length; i++) 
    {   
        td_ctr = 0;
        for(ctr=1; ctr<=col_length; ctr++)
        {
            td = tr[i].getElementsByTagName("td")[td_ctr];
            if (td) 
            {
                txtValue = td.textContent || td.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1)    //Actual Searching Function
                {
                    tr[i].style.display = "";   //Displays Row which is Similar to Search Value
                    break;
                }
                else{
                    tr[i].style.display = "none";   //Hides Row which is NOT Similar to Search Value
                }
            }   
            td_ctr++;
        }
    }
}