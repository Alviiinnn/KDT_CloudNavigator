//---------------------------------
// THIS JAVASCRIPT IS FOR INDEX.PHP
//---------------------------------



var gUserName = $('input[name=userName]').val();
var gDBUsername = $('input[name=dbUsername]').val();
var gFirstName = $('input[name=firstName]').val();
var gUploadControl = $('input[name=uploadControl]').val();
var gExportControl = $('input[name=exportControl]').val();
var userAccess = $('input[name=userAccess]').val();
var gRefreshStatus = $('input[name=refreshStatus]').val();


$(document).ready(function(){
  var emptyTableChecker = $("input[name=emptyTableChecker]").attr('data-empty-table');

  if(userAccess == "Admin" || userAccess == "Developer"){
    $('.admin-link').show();
  }else{
    $('.admin-link').hide();
  }

  // -- Dynamically Loads Developers in Filter list --
  $.get("./includes/getDev.php",
    function(data,status){
      const devArray = JSON.parse(data); //converts String to Array
      
      $.each(devArray, function(index, value){
        $("select[name=selectViewByDev]").append($('<option>',{
          value: value,
          text: value}));
      });
    }
  );

  if(emptyTableChecker == 'true'){
    $('#btnNry').show();
    $('#child1Div, p[name=projectDirectory]').hide();
    $('#header').text("Web Request System");
    $('#btnNry').click(function(){
    $('#modalRequest').show();
    });

    $('#btnNry').hover(function(){
        $('#btnNry').text('Click to Add New Request');
        // $('#btnNry').css("outline-color","blue");
      }, 
      function(){
        $('#btnNry').html("<i style='color:gray;'>There are no requests yet.</i>");
      }
    );    
  }else{
    $('#btnNry').hide();
  }

  if(gUploadControl == "OFF"){
    $('button[name=uploadReq]').hide();
    $('button[name=anyConcerns]').removeClass('w3-display-bottomleft c-modal-left-btn');
  }

  if(gRefreshStatus == "DONE"){
    $('#modalHardRefresh').hide();
  }else{
    $('#modalHardRefresh').show();
  }
  
  if(gExportControl == "OFF"){
    $('#btnExport').hide();
  }else{
    $('#btnExport').show();
  }


  $("#modalReqDetails .div-email,input[name^=uploadAdditional],button[name=submitUpload],button[name=cancelUpload], .concerns, button[name=backConcerns], #btnReset, hr[name=hrAnyConcerns]").hide();

  $('#modalHardRefresh .refresh-firstName').append(gFirstName+"!");

  // $('#modalHardRefresh').show();



});



$("input[name=inputSearch]").keyup(function()
{
    var tbl         = "#requestList";
    var tbl_header  = "#requestList tr th";
    var searchInput = "input[name=inputSearch]";

    fxSearch_table(searchInput, tbl_header, tbl);
    fxRow_NotFound(tbl, "No Requests Found");  
}); 



$("input[name=searchDirectory]").keyup(function()
{
    var tbl_header  = "table[name=projectDirectory] tr th";
    var tbl         = "table[name=projectDirectory]";
    var searchInput = "input[name=searchDirectory]";

    fxSearch_table(searchInput, tbl_header, tbl);
    fxRow_NotFound(tbl, "No Requests Found");
}); 



function closeModalFunc(modalID)
{
    $(modalID).hide();
    $(modalID).css({'background-color':'rgb(0,0,0)', 'background-color':'rgba(0,0,0,0.4)'}); // Resets Modal BG-color to Default
}



$("#plusButton").click(function(){
  // $('#modalRequest').css({'top':0, 'left':0});

  if(userAccess == "Viewer"){
    $("#modalNoAccess").show();
  }else{
    $("#modalRequest").show();
  }

});

$('#btnReset').click(function(){
  
  if(inputGroupVal == "Choose Group"){
    $("select[name=inputGroup]").prop("selectedIndex",0);          //This Resets Group Dropdown
    $('select[name=inputClientRepEmail] option').not(':first, :nth(1)').remove(); //Remove all <option> except the 1st & 2nd child
    $("select[name=inputClientRepEmail]").prop('disabled', 'true');
  }

  $("select[name=inputClientRepEmail]").prop("selectedIndex",0); //This Resets Client Rep Dropdown

  $("input[name=inputTitle]").val("");
  $("input[name=inputDesc]").val("");
  $("input[name^=inputReq]").val("");

  $("div.container-clientRep").slideUp();
  $(".addedClientRep, input[name=addClientRep]").remove();
  $("div.container-clientRep p.p-remove").remove();
  $('label[name=clientRepLabel]').text('Representative:');
  clientRepCtr = 2; // This will RESET the Client Rep Counter  

  arrClientRepEmails.length = 0; // This will RESET the Array to Empty the Added Client Reps EMAIL Array
  arrClientReps.length = 0;      // This will RESET the Array to Empty the Added Client Reps NAME Array
  $('div.container-clientRep-preview').children().remove();
  $('select[name=inputClientRepEmail] option').removeClass('highlight-addedClientRep');   //For Client Rep 1: Changes the Color and Font-weight back to Default
  $('p.warning-clientRep').remove();
  $(this).hide();

});

$("#editBtn").click(function(event){
  event.preventDefault(); //to prevent submission of Form
  $("#modalPreview").hide();
  $("#modalRequest").show();

  $('div.container-clientRep-preview').children().remove();
});

$("#submitPls").click(function(){
  // var a1 = $("input[name=inputKeyPerson]").val();
  // var a2 = $("input[name=inputGroup]").val();
  // var a3 = $("input[name=inputClientRepEmail] option").filter(":selected").val();
  // var a4 = $("input[name=inputClientRepEmail] option").filter(":selected").text();

  var regExpEmail = /\S+@\S+\.\S+/; // Regular Expression for Testing Valid Email Format
  var testEmail, validEmails = "";

  $.each(arrEmailCC, function(index, value){
    testEmail = regExpEmail.test(value);
    
    if(testEmail){
      validEmails += value+";";
    }
  });
  $('input[name=inputEmailCC]').val(validEmails);

  $(this).attr({"disabled": true, 'title': 'Please wait . . .'})
        .addClass('cursor-wait')
        .html('<i class="fa fa-paper-plane w3-large "></i> SUBMITTING . . .');
  $('#submitPls i').removeClass('fa-paper-plane');
  $('#submitPls i').addClass('fa-spinner c-loading');
  $("input[name=inputKeyPerson]").removeAttr("disabled");
  $("select[name=inputGroup]").removeAttr("disabled");
  
  $("#formNewRequest").submit(); //uncommment mo to
});

//-----AJAX------

var indexCode, indexTitle, indexGroup, indexDesc, indexReq, indexKeyPerson, indexClientRep, indexDev, indexDateReq, indexStatus, indexRemarks;
var ajaxCode, ajaxTitle, ajaxGroup, ajaxDesc, ajaxReq, ajaxKeyPerson, ajaxClientRep, ajaxDev, ajaxDateReq, ajaxStatus, ajaxRemarks;
var firstKeyPersonEmail, firstClientRepEmail;
var lastKeyPersonEmail, lastClientRepEmail;
var ajaxKeyPersonEmail, ajaxClientRepEmail;

$("tr").on({mouseover:function(){

  var hasYellowBG = $(this).find('td:last-child').hasClass('yellow-bg');
  var hasGreenBG = $(this).find('td:last-child').hasClass('green-bg');
  var hasBlueBG = $(this).find('td:last-child').hasClass('blue-bg');

  if(hasYellowBG === true || hasGreenBG === true || hasBlueBG === true){
    // $(this).find('td:last-child').css('font-weight','bold');
    // $(this).find('td:last-child').css({'background-color':'lemonchiffon', 'color':'gray'});
    // $(this).find('td:last-child').css('background-color', '#ccc');
  }
},
  mouseout: function(){
    var hasYellowBG = $(this).find('td:last-child').hasClass('yellow-bg');
    var hasGreenBG = $(this).find('td:last-child').hasClass('green-bg');
    var hasBlueBG = $(this).find('td:last-child').hasClass('blue-bg');

    // if(hasYellowBG === true){
    //   $(this).find('td:last-child').css('background-color', 'yellow'); 
    // }

    // if(hasGreenBG === true){
    //   $(this).find('td:last-child').css({'background-color':'green', 'color':'white'});
    // }  

    // if(hasBlueBG === true){
    //   $(this).find('td:last-child').css({'background-color':'dodgerblue', 'color':'white'});
    // }  
  }
});

// -- Row Click Function -- 

$("table[name=requestlist] tr:not(:first)").click(function(){
  var trRequestCode = $(this).attr('value');
  $("span[name=uploadedFiles] span").remove(); //Clears Uploaded File Lists to Append new ones
  // var userChecker = "requestor";
  ajaxShowDetails(trRequestCode);
});



function ajaxShowDetails(trRequestCode)
{
    $.post("./includes/requestDetails.php", 
    {
        reqCode: trRequestCode
    },
    function(data, status)
    {
        ajaxCode           = fxExtract_Data(data, "RequestCode~", 12);       //12 is the length of "RequestCode~" Keyword
        ajaxTitle          = fxExtract_Data(data, "Title~", 6);
        ajaxGroup          = fxExtract_Data(data, "Group~", 6);
        ajaxDesc           = fxExtract_Data(data, "Description~", 12);
        ajaxReq            = fxExtract_Data(data, "InitialPath~", 12);
        ajaxKeyPerson      = fxExtract_Data(data, "KP~", 3);
        ajaxClientRep      = fxExtract_Data(data, "ClientRepresentative~", 21);
        ajaxDev            = fxExtract_Data(data, "Developer~", 10);
        ajaxDateReq        = fxExtract_Data(data, "DateRequested~", 14);
        ajaxStatus         = fxExtract_Data(data, "Status~", 7);
        ajaxRemarks        = fxExtract_Data(data, "Remarks~", 8);
        ajaxKeyPersonEmail = fxExtract_Data(data, "KeyPersonEmail~", 15);
        ajaxClientRepEmail = fxExtract_Data(data, "ClientRepEmail~", 15);
        ajaxUploadedFiles  = fxExtract_Data(data, "UploadedFiles~", 14);
        ajaxTicket         = fxExtract_Data(data, "TicketNumber~", 13);
        ajaxFinishPath     = fxExtract_Data(data, "FinishPath~", 11);
        
        
        if(ajaxClientRepEmail == "None;"){
        ajaxClientRepEmail = "";
        }

        if(ajaxUploadedFiles != "")
        {
            $("span[name=uploadedFiles]").text("");

            var arrFiles = ajaxUploadedFiles.split(",");

            $.each(arrFiles, function(index, value){
                $("span[name=uploadedFiles]").append("<span class='w3-col span-margin-bot'>"+value+"</span>"); //Lists each Uploaded Files
            });
        }
        else{
            $("span[name=uploadedFiles]").text('-');
        }

        // $("#sReqDetailsCode").text(ajaxCode); // Commented to kase meron nang Ticket Number
        $("#sReqDetailsTicket").text(ajaxTicket);
        $("#sReqDetailsTitle").text(ajaxTitle);
        $("#sReqDetailsGroup").text(ajaxGroup);
        $("#sReqDetailsDesc").text(ajaxDesc);
        $("#sReqDetailsKeyPerson").text(ajaxKeyPerson);
        $("#sReqDetailsClientRep").text(ajaxClientRep);
        $("#sReqDetailsDev").text(ajaxDev);
        $("#sReqDetailsDateReq").text(ajaxDateReq);
        $("#sReqDetailsStatus").text(ajaxStatus);
        $("#sReqDetailsRemarks").text(ajaxRemarks);

        $("input[name=emailRequestNumber]").val(ajaxTicket);
        $("input[name=emailRequestCode]").val(ajaxCode);
        $("input[name=emailKPersonEmail]").val(ajaxKeyPersonEmail);
        $("input[name=emailCRepEmail]").val(ajaxClientRepEmail);
        $("input[name=emailDevs]").val(ajaxDev);
        
        if(ajaxStatus == "Finished")
        {
            if(ajaxFinishPath == "")
            {
                $("#sReqDetailsReqPath").val("-").attr('title', "Finish Path is Not Set");
                $('#modalReqDetails button[name=copyBtn]').hide();
            }
            else{
                $("#sReqDetailsReqPath").val(ajaxFinishPath).attr('title', ajaxFinishPath);
                $('#modalReqDetails button[name=copyBtn]').show();
            }
        }
        else{
            $("#sReqDetailsReqPath").val(ajaxReq).attr('title', ajaxReq);
        }


        if(gUserName != ajaxKeyPerson && gUserName != ajaxClientRep){
            $('footer[name=requestDetails]').hide();
        }
        else{
            $('footer[name=requestDetails]').show();
        }

        $("#modalReqDetails").show();
    });  
}


var ctrl_press = false;
var f5_press = false;

$('html').keydown(function(e)
{
    if(gRefreshStatus != "DONE")
    {
        e.preventDefault();

        if(e.which == 17){    // Key 17 = CTRL
            ctrl_press = true;
        }
    }

    if (e.which==27){     // Key 27 = ESC
        $("#modalReqDetails").fadeOut();
    }
});



$('html').keyup(function(e)
{
    if(gRefreshStatus != "DONE")
    {
        e.preventDefault();

        if(e.which == 17){    // Key 17 = CTRL
            ctrl_press = false;
        }

        if(e.which == 116)    // Key 116 = F5
        {   
            if(ctrl_press == true)
            {
                f5_press = true;

                $.post("./includes/update.php",
                {
                    requestChecker: "updateHardRefreshDone",
                    privilege: "user",
                    username: gDBUsername
                }, 
                function(data, status)
                {
                    console.log(status);
                    console.log(data);
                    console.log("Hard Refresh!");
                });
                $('#modalHardRefresh').hide();

                window.location.href = window.location.href;
            }
        }

        // console.log("==============");
        // console.log("F5: "+f5_press);
        // console.log("CTRL: "+ctrl_press);
    }
});



$("span[name=clearFilter]").click(function()
{
    location.reload();

  // $.post("./includes/userViewBy.php",
  //   {
  //     filterType: "statusFilter",
  //     viewByStatus: "All"
  //   },
  //   function(data, status){

  //   });
});



var selectedDev, selectedStatus, filterType;

$("select[name=selectViewByDev]").change(function()
{
    $('span[name=clearFilter]').show();
    $('span[name=clearFilter]').removeClass("hide");
    // $('span[name=clearFilter]').addClass('clearFilterAnimate');

    $("table[name=requestlist] tr:not(:first)").remove(); //This will remove all existing Rows to Update New Ones

    selectedDev = $("select[name=selectViewByDev]").val();
    selectedStatus = $("select[name=selectViewByStatus]").val();

    if(selectedStatus === null)
    {
        filterType = "developerFilter";
    }
    else{
        filterType = "devNstatusFilter";
    }

    $.post("./includes/userViewBy.php",
    {
        filterType: filterType,
        viewByDev: selectedDev,
        viewByStatus: selectedStatus
    }, 
    function(data, status)
    {
        const obj = JSON.parse("["+data+"]");
        fxFilterTable(obj);
    });
});



$("select[name=selectViewByStatus]").change(function()
{
    $('span[name=clearFilter]').show();
    $('span[name=clearFilter]').removeClass("hide");
    $("table[name=requestlist] tr:not(:first)").remove();

    selectedStatus = $("select[name=selectViewByStatus]").val();
    selectedDev = $("select[name=selectViewByDev]").val();

    if(selectedDev === null)
    {
        filterType = "statusFilter";
    }
    else{
        filterType = "devNstatusFilter";
    }

    $.post("./includes/userViewBy.php",
    {
        filterType: filterType,
        viewByStatus: selectedStatus,
        viewByDev: selectedDev
    },
    function(data,status)
    {
        // var jsonFile = '[{"Code":"SYS_20210901_01"},{"Code":"SYS_20210901_02"},{"Code":"SYS_20210901_03"}]'; //gumana na
        // var obj = JSON.parse(jsonFile); //gumana na

        // console.log(obj[0].Code);  //gumana na
        const obj = JSON.parse("["+data+"]");
        fxFilterTable(obj);
    });
});



function  fxFilterTable(obj){

  if(obj.length == 0){
      // $("table").append("<tr disabled><td>-</td><td><i>No Requests Found</i></td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td><td class='gitna'>-</td>");
      $("table[name=requestlist]").append("<tr disabled><td colspan='15' class='c-text-center'><i>No Requests Found</i></td>");
    }

    var ctr2 = 0;
    for(ctr=0;ctr<obj.length;ctr++){
      ctr2++;
      var tdCtr = "<td>"+ctr2+"</td>";
      var tdTicket = "<td>"+obj[ctr].TicketNumber+"</td>";
      var tdCode = "<td class='tdRequestCode' value='"+obj[ctr].RequestCode+"'>"+obj[ctr].RequestCode+"</td>";
      var tdTitle =     "<td>"+obj[ctr].Title+"</td>";
      var tdGroup =     "<td>"+obj[ctr].Group+"</td>";
      var tdDesc =      "<td>"+obj[ctr].Desc+"</td>";
      var tdKeyPerson = "<td>"+obj[ctr].KeyPerson+"</td>";
      var tdClientRep = "<td>"+obj[ctr].ClientRep+"</td>";
      var tdDev =       "<td>"+obj[ctr].Dev+"</td>";
      var tdDateReq =   "<td>"+obj[ctr].DateReq+"</td>";
      var tdStartDate =  (obj[ctr].StartDate == '0000-00-00') ? "<td>-</td>" : "<td>"+obj[ctr].StartDate+"</td>";
      var tdFinishDate =  (obj[ctr].FinishDate == '0000-00-00') ? "<td>-</td>" : "<td>"+obj[ctr].FinishDate+"</td>";
      var tdDaysLeft =  "<td>-</td>";
      var tdRemarks =   "<td>"+obj[ctr].Remarks+"</td>";
      var tdProgress =   (obj[ctr].Progress == 0) ? "<td>-</td>" : "<td>"+obj[ctr].Progress+"%</td>";
      var tdStatus;
      if(obj[ctr].Status == "Ongoing"){
        tdStatus = "<td class='gitna'><span class='yellow-bg c-status'>"+obj[ctr].Status+"</span></td>";
      
        if(obj[ctr].Progress == 100){
          tdStatus = "<td class='gitna'><span class='green-bg c-status'>"+obj[ctr].Status+"</span></td>";
        }
      
      }else if(obj[ctr].Status == "Finished" || obj[ctr].Status == "Waiting"){
        tdStatus = "<td class='gitna'><span class='green-bg c-status'>"+obj[ctr].Status+"</span></td>";
      
      }else if(obj[ctr].Status == "Denied" || obj[ctr].Status == "Cancelled"){
        tdStatus = "<td class='gitna'><span class='red-bg c-status'>"+obj[ctr].Status+"</span></td>";
      
      }else if(obj[ctr].Status == "On Hold"){
        tdStatus = "<td class='gitna'><span class='blue-bg c-status'>"+obj[ctr].Status+"</span></td>";
      
      }else{
        tdStatus = "<td class='gitna'><span class='c-status'>"+obj[ctr].Status+"</span></td>";
      }

      var appendTr =  "<tr onclick='ajaxShowDetails(\""+obj[ctr].RequestCode+"\");' value='"+obj[ctr].RequestCode+"'>"+tdCtr+tdTicket+tdTitle+tdDesc+tdGroup+tdKeyPerson+tdClientRep+tdDev+tdDateReq+tdStartDate+tdFinishDate+tdDaysLeft+tdRemarks+tdProgress+tdStatus+"</tr>";
      $("table[name=requestlist] tbody").append(appendTr).fadeIn();
      // $("table[name=requestlist] tbody").append(appendTr);
    }
} 
// --- END of fxFilterTable()


$("#modalReqDetails button[name=copyBtn]").click(function(){
  $('#sReqDetailsReqPath').select(); //This will SELECT ALL the Text inside the Input Field
  document.execCommand("copy"); //This will run the Copy Command to copy the Selected Text above in Clipboard
  $('p[name=copied]').show().fadeOut(4000);
});


var clientRepCtr = 2;   //For Adding Client Reps
const arrClientReps = [];
const arrClientRepEmails = [];
var prevClientRep1, prevClientRep1Email;
var errorClientRep1 = false;

$('select[name=inputClientRepEmail]')
  .click(function(){
    prevClientRep1Email = $(this).val();    //For getting previous selected item EMAIL (DO NOT REMOVE THIS HERE)
    prevClientRep1 = $(this).text();        //For getting previous selected item NAME (DO NOT REMOVE THIS HERE)
    
    $(this).find('option').css('color', 'gray');
  })

  .change(function(){
    var picked = $(this).val();
    let pickedName = $(this).find('option:selected').text();
    var indexShowWarning = $(this).index();
    
    $('div.container-clientRep').show();

    arrClientRepEmails.shift(prevClientRep1Email); // Removes First Element of EMAIL Array 
    arrClientReps.shift(prevClientRep1);           // Removes First Element of NAME Array

    if(arrClientRepEmails.indexOf(picked) === -1){  // -1 means the item is not on the Array. 0, 1, 2... means it is in the Array
      arrClientRepEmails.unshift(picked);  // Inserts new item at Beginning of EMAIL Array
      arrClientReps.unshift(pickedName);   // Inserts new item at Beginning of NAME Array

      $(this).removeClass('errorField');
      $('p.warning-clientRep').remove();
    }
    else{
      errorClientRep1 = true;
      $(this).addClass('errorField');
      funcShake("Representative 1", pickedName);
    }

    //  This IF will remove the Highlighted Options to another Selected ones 
    if(prevClientRep1Email !== picked && errorClientRep1 === false){
      $('.container-clientRep .addedClientRep').children('select').find('option[value="'+prevClientRep1Email+'"]').removeClass('highlight-addedClientRep');
      $("select[name=inputClientRepEmail] option[value='"+prevClientRep1Email+"']").removeClass('highlight-addedClientRep');     
    }else{
      errorClientRep1 = false;
    }
    

    
    if($(this).val() != 'None'){
      $('p[name=pClientRep]').css('margin-bottom', 0);
      $('.container-clientRep .addedClientRep').children('select').find('option[value="'+picked+'"]').addClass('highlight-addedClientRep');
      $("select[name=inputClientRepEmail] option[value='"+picked+"']").addClass('highlight-addedClientRep');    
      // $('input[name=addClientRep]').removeClass('hide');
      if(clientRepCtr == 2 || $('.addedClientRep').length == 0){ // This Condition assures ONLY Last Added Client Rep Onchange Event will add the "Add Client Rep" Button || Checks if there's no Client Rep 2
        funcAddClientRepBtn();
      }else{ 
        //Do Not Add "Add Client Rep" Button  
      }
    }else{
      $("div.container-clientRep").slideUp();
      $('input[name=addClientRep], .addedClientRep').remove();
      $('p.p-remove').remove();
      clientRepCtr = 2; //This will RESET Client Rep Counter
      arrClientRepEmails.length = 0; // This will RESET the EMAIL Array to Empty the Added Client Reps EMAIL Array
      arrClientReps.length = 0;      // This will RESET the NAME Array to Empty the Added Client Reps NAME Array
      $('select[name=inputClientRepEmail] option').removeClass('highlight-addedClientRep');   //For Client Rep 1: Changes the Color and Font-weight back to Default
      $('label[name=clientRepLabel]').text('Representative:');
    }

    // prevClientRep1Email = picked;   //For getting previous selected item (DO NOT REMOVE THIS HERE)

});

// ---------------------------------------Triggers Only the Last Child with "addedClientRep" Class
$(document).on('change', '.addedClientRep:last-child', function(){    //Listens to On-change Event of appended <select> element

  funcAddClientRepBtn();
  funcPClientRep(); 

});

var prevPicked;
var bool_warningClientRep = false;
var boolShake = false;  // Checks if dumaan sa Else na "... is already selected ..."
var clickedErrorField = false;  // Removes "errorField" Class if Select Element is Clicked
var showErrorField = false;
var lastPickError = false;

$(document)
// balik ka here

  .on('click', 'p.addedClientRep', function(){    // Purpose: To get the previous selected option / previous selection
    var selectName = $(this).find('select').attr('name'); 
    prevPicked = $('select[name='+selectName+']').val();

    if(clickedErrorField === true){
      clickedErrorField = false;
    }else{
      clickedErrorField = true;
      if(showErrorField === true){
        $(this).find('select option').css('color', 'gray').not('highlight-addedClientRep');   // Makes the Error Select Element color Gray
        showErrorField = false;
      }
    }
  })

  .on('change', 'p.addedClientRep', function(){
    
    $('.warning-clientRep').remove();

    var picked = $(this).find('select').val(); 
    var pickedName = $(this).find('select option:selected').text(); 

    // var nameSelect = $(this).find('select').attr('name');
    let arrIndex = arrClientRepEmails.indexOf(prevPicked);
    var indexShowWarning = $(this).index();


    // CHECKS if Selected is on the Array 'arrClientRepEmails' - If Else
    if(arrClientRepEmails.indexOf(picked) == -1){   // -1 means the item is not on the Array. 0, 1, 2... means it is in the Array
      $(this).find('select').removeClass('errorField');

      arrClientRepEmails.push(picked);
      arrClientReps.push(pickedName);
      // let arrIndex = arrClientRepEmails.indexOf(prevPicked);


      if(prevPicked !== null && lastPickError !== true){    // Checks if the Prev Selection is not Null. Null = if has no Previous Selection 
        
        arrClientRepEmails.splice(arrIndex, 1); // DELETES Previous Selection in EMAIL Array
        arrClientReps.splice(arrIndex, 1);      // DELETES Previous Selection in NAME Array
        $('select[name=inputClientRepEmail] option[value="'+prevPicked+'"]').removeClass('highlight-addedClientRep');   //For Client Rep 1 Option: Changes the Color and Font-weight back to Default
        $('.container-clientRep .addedClientRep').children('select').find('option[value="'+prevPicked+'"]').removeClass('highlight-addedClientRep');    //For Added Client Reps: Changed Color and Font-weight back to Default
        
      }
      
      funcAddClientRepBtn();    // DO NOT REMOVE THIS HERE PLEASEEEEE
      lastPickError = false;    // DO NOT REMOVE THIS PLEASEEEE NAPAGANA RIN KITAAAA

    }else{

      arrClientRepEmails.splice(arrIndex, 1); // DELETES Previous Selection in EMAIL Array
      arrClientReps.splice(arrIndex, 1); // DELETES Previous Selection in NAME Array
      $('select[name=inputClientRepEmail] option[value="'+prevPicked+'"]').removeClass('highlight-addedClientRep');   //For Client Rep 1 Option: Changes the Color and Font-weight back to Default
      $('.container-clientRep .addedClientRep').children('select').find('option[value="'+prevPicked+'"]').removeClass('highlight-addedClientRep');    //For Added Client Reps: Changed Color and Font-weight back to Default

      boolShake = false;
      $(this).find('select').addClass('errorField');
      showErrorField = true;
      lastPickError = true;

      let employeeName = $(this).find('select option:selected').text();
      funcShake("Added Representatives", employeeName, indexShowWarning);
      
      $('input[name=addClientRep]').parent().remove();
      bool_warningClientRep = true;
    }

    $(".container-clientRep .addedClientRep").children('select').find("option[value='"+picked+"']").addClass('highlight-addedClientRep');
    $("select[name=inputClientRepEmail] option[value='"+picked+"']").addClass('highlight-addedClientRep');

});

function funcShake(field, employeeName, indexShowWarning){
  $('div[name=modalRequest]').addClass('shakeClass').removeClass('w3-animate-top');
  setTimeout(function(){
    $('div[name=modalRequest]').removeClass('shakeClass');
  }, 500);
  
  let warningClientRep = '<p class="w3-row-padding w3-text-red w3-center warning-clientRep">';
      // warningClientRep += '<strong>You have already selected <u>'+employeeName+'</u>.</strong>';
      // warningClientRep += '<strong><u>'+employeeName+'</u> had already selected, please choose another.</strong>';
      // warningClientRep += '<strong><u>'+employeeName+'</u> is already selected.</strong>';

      warningClientRep += '<strong><u>'+employeeName+'</u> has already been selected.</strong>';
      warningClientRep += '</p>';    
  // $('div.container-clientRep').append(warningClientRep);
  if(field == "Representative 1"){
    $('p[name=pClientRep]').after(warningClientRep);
  }else{
    $('div.container-clientRep p').eq(indexShowWarning).after(warningClientRep);
  }
}

function funcAddClientRepBtn(){

  if($('input[name=addClientRep]').length === 0){
    let elementAddClientRep = "<p class='w3-center p-remove w3-row-padding' style='display:none;'>";
    elementAddClientRep += "<input class='w3-padding w3-button w3-blue w3-round w3-hover-blue w3-hover-opacity' type='button' name='addClientRep' value='Add Representative "+clientRepCtr+"' title='Add another Representative' style='width:51%;margin-left:6px;border:1px solid dimgray;' />";
    elementAddClientRep += "</p>";
    // $('#formNewRequest').append(elementAddClientRep);  // Na-comment nung nilagyan ng Div Container
    // $('div.container-clientRep').append(elementAddClientRep);
    $('div.container-clientRep').append(elementAddClientRep);
    $('p.p-remove').slideDown();
    // $('.addedClientRep').slideDown();

    $('div.container-clientRep').animate({
      scrollTop: $('html').get(0).scrollHeight
    }, 1000);

    $('input[name=addClientRep]').click(function(){
      $(this).unwrap();   // Deletes Parent Element of Add Button
      $(this).remove();   // Deletes Add Client Rep Button
      $('label[name=clientRepLabel]').text('Representative 1:');
      let elementClientRep = "<p class='w3-row-padding addedClientRep' style='display:none;'>";
      elementClientRep += "<label class='w3-col m3 l3 c-padding-8'>Representative "+clientRepCtr+":</label>";
      elementClientRep += "<select class='w3-col s11 m8 l8 c-padding-8 w3-input' name='clientRepEmail"+clientRepCtr+"' title='Representative "+clientRepCtr+"' required>";
      elementClientRep += "</select>";
      elementClientRep += "<i class='delClientRep fa fa-times w3-button w3-col s1 m1 l1 w3-text-pink w3-hover-text-white w3-hover-pink w3-large' style='padding:9px;border-radius:1px;'>";
      elementClientRep += "</i>";
      elementClientRep += "</p>";
      // $('#formNewRequest').append(elementClientRep); // Na-comment nung nilagyan ng Div Container
      $('div.container-clientRep').append(elementClientRep);
      $('p.addedClientRep').fadeIn();
      $('select[name=inputClientRepEmail] option').clone().appendTo('select[name=clientRepEmail'+clientRepCtr+']');
      $('select[name=clientRepEmail'+clientRepCtr+'] option[value=None]').remove();
      clientRepCtr++;
    });   
  } //end of If
} //end of Function

$("#formNewRequest").on("click", ".delClientRep", function(){   //---X or REMOVE Client Rep Function
  clientRepCtr--;   // Decrements Counter for "Add Client Rep" Button
  $('.warning-clientRep').slideUp(function(){
    // $('.warning-clientRep').remove();
    $(this).remove();
  });

  if($('.addedClientRep').length == 1){   //  Checks if it is the LAST Added Client Rep
    $('label[name=clientRepLabel]').text('Representative:');    //  Resets Client Rep Counter
    clientRepCtr = 2;   //  Resets Client Rep Counter
    $('input[name=addClientRep]').val('Add Representative 2');
  }else{
    $('input[name=addClientRep]').val('Add Representative '+clientRepCtr);
  }

  var remaining = $(this).parent().nextAll().find('label').length;
  var indexClicked = $(this).parent().index();   //  For Added Client Rep

  let deletedClientRep = $('select[name=clientRepEmail'+(indexClicked+2)+']').val();
  $('select[name=inputClientRepEmail] option[value="'+deletedClientRep+'"]').removeClass('highlight-addedClientRep');   //For Client Rep 1: Changes the Color and Font-weight back to Default
  $('.container-clientRep .addedClientRep').children('select').find('option[value="'+deletedClientRep+'"]').removeClass('highlight-addedClientRep');  //For Added Client Reps: Changed Color and Font-weight back to Default
  var indexDeletedCR = arrClientRepEmails.indexOf(deletedClientRep);

  arrClientRepEmails.splice(indexDeletedCR, 1);  //Remove the Selected Item from EMAIL Array List
  arrClientReps.splice(indexDeletedCR, 1);       //Remove the Selected Item from NAME Array List

// balik ka dito
  // if(!$('div.container-clientRep p').hasClass('warning-clientRep')){
  //   arrClientRepEmails.splice(indexDeletedCR, 1);  //Remove the Selected Item from EMAIL Array List
  //   arrClientReps.splice(indexDeletedCR, 1);       //Remove the Selected Item from NAME Array List
  // }

  if(indexClicked > 1){
    remaining = remaining + (indexClicked - 1);
  }


  for(var ctr=0; ctr<=remaining; ctr++){
    if(ctr >= indexClicked){
      if(indexClicked > 0){
        $(this).parent().nextAll().eq(ctr-indexClicked).find('label').text("Representative "+(ctr+2)+":");
        $(this).parent().nextAll().eq(ctr-indexClicked).find('select').attr({'name':'clientRepEmail'+(ctr+2), 'title':'Representative '+(ctr+2)});
      
      }else{
        $(this).parent().nextAll().eq(ctr).find('label').text("Representative "+(ctr+2)+":");
        $(this).parent().nextAll().eq(ctr).find('select').attr({'name':'clientRepEmail'+(ctr+2), 'title':'Representative '+(ctr+2)});
        console.log("This Value:"+$(this).parent().eq(1).find('label').text());
      }
    }
  }

  var thiz = $(this); 

  $(this).parent().slideUp(function(){
    $(this).removeClass('w3-padding-row');
    thiz.prevAll().remove();   //  Removes ALL Preceding Siblings
    thiz.unwrap();   //  Removes Parent Container
    thiz.remove();   //  Removes X Button    
  });

  funcPClientRep();

});

function funcPClientRep(){

  if($('.container-clientRep p').length >= 4){
    $('p[name=pClientRep]').css('margin-bottom', 13);
  }else{
    $('p[name=pClientRep]').css('margin-bottom', 0);
  }
}

$('#btnNext').click(function(){
  // $('div.c-modal').addClass('w3-animate-top');

  // var group = $("input[name=iGroup]").val(); //Di gumagana sa Array
  var keyPerson = $("input[name=inputKeyPerson]").val();
  var group = $('select[name=inputGroup] option').filter(':selected').val();
  var groupName = $('select[name=inputGroup] option').filter(':selected').text();
  var title = $("input[name=inputTitle]").val();
  var desc = $("input[name=inputDesc]").val();
  var req = $("input[name^=inputReq]").val();
  var clientRep = $("select[name=inputClientRepEmail] option").filter(':selected').text();
  var clientRepEmail = $("select[name=inputClientRepEmail] option").filter(':selected').val();
  clientRepEmail = clientRepEmail.slice(clientRepEmail.indexOf('~')+1, clientRepEmail.length);
  var clientRepPreview = clientRep+" ("+clientRepEmail+")";
  
  var fieldsCompleted = true;


  if((title&&desc&&req)=="" && group == "Choose Group"){
    $("#btnReset").hide();
  }

  if(group == "Choose Group"){
    fieldsCompleted = false;
    $("select[name=inputGroup]").addClass("requiredField");
    $("select[name=inputGroup]").css("color", "red");
    $("select[name=inputGroup]").focus(function(){
      $("select[name=inputGroup]").css("color", "gray");
      $("select[name=inputGroup]").removeClass("requiredField");
    });
  }

  if(title== ""){
    fieldsCompleted = false;
    $("input[name=inputTitle]").addClass("requiredField");
    $("input[name=inputTitle]").attr("placeholder", "This is a required field");
    $("input[name=inputTitle]").focus(function(){
      $("input[name=inputTitle]").removeClass("requiredField");
      $("input[name=inputTitle]").attr("placeholder", "Note: Please be specific and direct to the point");
    });
  }
  if(desc== ""){
    fieldsCompleted = false;
    $("input[name=inputDesc]").addClass("requiredField");
    $("input[name=inputDesc]").attr("placeholder", "This is a required field");
    $("input[name=inputDesc]").focus(function(){
      $("input[name=inputDesc]").removeClass("requiredField");
      $("input[name=inputDesc]").attr("placeholder", "This request will . . .");
    });
  }
  if(req== ""){
    fieldsCompleted = false; 
    $("input[name^=inputReq]").addClass("requiredField");
    $("input[name^=inputReq]").attr("placeholder", "This is a required field");
    $("input[name^=inputReq]").focus(function(){
      $("input[name^=inputReq]").removeClass("requiredField");
      $("input[name^=inputReq]").attr("placeholder", "Requirements *");
    });
  }
  if(clientRepEmail == 0 || clientRepEmail == "None"){
    clientRep = "None";
    clientRepPreview = "None";
    $("input[name=inputClientRepEmail]").val("None");
  }
  // if(clientRep == null){
  //   fieldsCompleted = false;
  //   $("select[name=inputClientRepEmail]").addClass("requiredField");
  //   $("select[name=inputClientRepEmail]").css("color", "red");
  //   $("select[name=inputClientRepEmail]").focus(function(){
  //     $("select[name=inputClientRepEmail]").css("color", "gray");
  //     $("select[name=inputClientRepEmail]").removeClass("requiredField");
  //   });
  // }
  if($('div.container-clientRep p').hasClass('warning-clientRep')){
    fieldsCompleted = false;
    $('div[name=modalRequest]').addClass('shakeClass');
    setTimeout(function(){
      $('div[name=modalRequest]').removeClass('shakeClass');
    }, 500);
    // funcShake();
  }

  if(fieldsCompleted == true){

    $('div[name=modalRequest]').removeClass('shakeClass').addClass('w3-animate-top');


    //$document.getElementById("input[name=inputDesc]").disabled = true;

    // If Else Statement for Dynamic Adding of Client Rep on Preview Modal
    var keyPersonEmail = $('input[name=inputKeyPersonEmail]').val();
    var clientRep1Name = $('select[name=inputClientRepEmail] option:selected').text();
    var clientRep1Val = $('select[name=inputClientRepEmail]').val();

    if(arrClientRepEmails.length > 1){
      var appendThiz = ""; //Available only here inside this IF Block Statement
      
      appendThiz += "<p class='w3-row-padding'>";
      appendThiz += "<label class='w3-col m3 l3'>Representative 1:</label>";
      appendThiz += "<span class='w3-col m9 l9' id='sClientRep'></span>";
      appendThiz += "</p>";

      $('#sEmailTo').text(keyPersonEmail+"; "+clientRepEmail+"; ");

      let ctr;
      for(ctr=1; ctr<=arrClientRepEmails.length-1; ctr++){
        
        var inputVal = $('select[name="clientRepEmail'+(ctr+1)+'"]').val();
        var inputText = $('select[name="clientRepEmail'+(ctr+1)+'"]').find(':selected').text();
        $('select[name="clientRepEmail'+(ctr+1)+'"]').text();
        appendThiz += "<p class='w3-row-padding'>";
        appendThiz += "<label class='w3-col m3 l3'>Representative "+(ctr+1)+":</label>";
        appendThiz += "<span class='w3-col m9 l9' id='sClientRep"+(ctr+1)+"'>"+inputText+" ("+inputVal+")</span>";
        appendThiz += "</p>";  

        
        if(ctr === 1)
        {
          $('#sEmailTo').append('<br>');
        }
        else if((ctr+1) % 2 == 0)
        {
          $('#sEmailTo').append('<br>');
        }
        else
        {
          console.log("false " + (ctr+1));
        }        

        $('#sEmailTo').append(document.createTextNode(inputVal+"; "));
        $('input[name=inputClientRepEmails]').val(function(){
          return this.value + inputVal+";";
        });
        $('input[name=inputClientReps]').val(function(){
          if(ctr == arrClientRepEmails.length-1){
            return this.value + inputText;
          }else{
            return this.value + inputText+", ";
          }
        });
      }
      
      $('input[name=inputClientReps]').val(function(){
        return clientRep1Name+", "+ this.value;
      });
      

      $('div.container-clientRep-preview').append(appendThiz);

    }else{
      var appendThiz = ""; //Available only here inside this ELSE Block Statement
      appendThiz += "<p class='w3-row-padding'>";
      appendThiz += "<label class='w3-col m3 l3'>Representative:</label>";
      appendThiz += "<span class='w3-col m9 l9' id='sClientRep'></span>";
      appendThiz += "</p>";

      $('div.container-clientRep-preview').append(appendThiz);
      ;
      (clientRep1Val === null)? $('input[name=inputClientReps]').val("None") : $('input[name=inputClientReps]').val(clientRep1Name);
      
      // $('#sEmailTo').text(keyPersonEmail+"; "+clientRepEmail);
      (clientRepEmail == "None" || clientRepEmail == 0)? $('#sEmailTo').text(keyPersonEmail) : $('#sEmailTo').text(keyPersonEmail+"; "+clientRepEmail); 

    }
    $("#sGroup").text(groupName);
    $("#sTitle").text(title);
    $("#sDesc").text(desc);
    // $("#sReq").text(req);
    $("#sClientRep").text(clientRepPreview);
    // $("input[name=inputKeyPerson]").val(keyPerson);
    // $("input[name=inputGroup]").val(group);
    // $("input[name=inputTitle]").val(title);
    // $("input[name=inputDesc]").val(desc);
    // $("input[name^=inputReq]").val(req);
    $("input[name=inputClientRepEmail]").val(clientRep);
    
    $("#modalRequest").hide();
    $("#modalPreview").show();
  }else{
    // $('div[name=modalRequest]').addClass('shakeClass');
      funcShake();
  }

});

$('#addCC').click(function(){
  $(this).hide();
  $('select[name=addCC]').removeClass('hide');
  $('select[name=inputClientRepEmail] option').clone().appendTo('select[name=addCC]');
  $('select[name=addCC] option[value=None]').remove(); //Removes the "None" Option from Clone
  $('select[name=addCC] option').css({'color':'gray', 'font-weight':'normal'}); 
});


const arrEmailCC = [];

$('select[name=addCC]')
  .focus(function(){
    $('select[name=addCC]').removeClass('errorField');
  })
  .change(function(){
    // $('#addCC').show();
    let empEmail = $('select[name=addCC]').find(':selected').val();
    let empName = $('select[name=addCC]').find(':selected').text();

    if(arrEmailCC.includes(empEmail) || arrEmailCC.includes(empName)){
      $('p[name=ccExists]').removeClass('hide');
      $('select[name=addCC]').addClass('errorField');
    }
    else{
      $('p[name=ccExists]').addClass('hide');
      $('select[name=addCC]').removeClass('errorField');

      let addItem = (empEmail) ? empEmail : empName;
      arrEmailCC.push(addItem);

      empEmail = (empEmail == false) ? "<i>- No Outlook Email</i>" : "("+empEmail+")";
      let elementAddCC = "<span class='w3-col l11 span-margin-bot'>";
      elementAddCC += "<strong>"+empName+"</strong> "+empEmail;
      elementAddCC += "</span>";
      elementAddCC += "<button class='w3-col l1 c-remove-item' name='cRemoveItem'>";
      elementAddCC += "<i class='fa fa-times w3-small'></i>";
      elementAddCC += "</button>";
      $('span[name=addCC]').append(elementAddCC);

      $('span[name=addCC]').animate({
        // scrollTop: $('html, span[addCC]').get(0).scrollHeight //Auto Scrolls Down to Bottom
        scrollTop: $('html').get(0).scrollHeight //Auto Scrolls Down to Bottom
      }, 1000); 
    }
  });
  // Allysha Ellaine Ponce - No Outlook Email
$('span[name=addCC]')
  .on('click', 'button[name=cRemoveItem]', function(){
    let thisBtn = $(this);    //This Variable provides Solution for "setTimeout" function "$(this)" problem
    thisBtn.prev().slideUp(); //Hides the Employee Name and its Email
    thisBtn.slideUp();        //Hides the X Button
    let xEmailCC = thisBtn.prev().text(); //x means Removed Email CC

    if(xEmailCC.includes('No Outlook Email')){ //Checks if No Outlook Email
      let indexNoEmail = xEmailCC.indexOf(' - No Outlook Email');
      xEmailCC = xEmailCC.substring(0, indexNoEmail); //Gets Employee Name
    }else{
      xEmailCC = xEmailCC.slice(xEmailCC.indexOf("(")+1, xEmailCC.indexOf(')')); //Extract the Email from "Alvin John Aganan (aganan-kdt@corp.khi.co.jp)" Format
    }

    xEmailCC = arrEmailCC.indexOf(xEmailCC); //Returns index of Removed Email CC in Array
    arrEmailCC.splice(xEmailCC, 1); //Removes the Clicked EmailCC from Array List

    setTimeout(function(){
      thisBtn.prev().remove(); //Removes the Employee Name and its Email
      thisBtn.remove(); //Removes the X Button
    }, 1000); //1000 Milliseconds = 1 Second
  })

  .on('mouseenter', 'button[name=cRemoveItem]', function(){
    $(this).prev().css({'font-size':'14px', 'transition':'0.2s'});
  })

  .on('mouseleave', 'button[name=cRemoveItem]', function(){
    $(this).prev().css('font-size', 'inherit');
  });

$("input[name=inputTitle],input[name=inputDesc]").keyup(function(){
  $("#btnReset").show();
});

$("input[name^=inputReq],select[name=inputClientRepEmail]").change(function(){
  $("#btnReset").show();
});

$("button[name=uploadReq]").click(function(){
  $("input[name^=uploadAdditional], hr").slideDown();
  $("button[name=cancelUpload], hr").show();
  $("button[name=anyConcerns], button[name=uploadReq], span[name=xModalReqDetails]").hide();
});

$("input[name^=uploadAdditional]").change(function(){
    $("button[name=submitUpload]").show();
});

// $("button[name=submitUpload]").click(function(){
//   $("button[name=submitUpload], button[name=cancelUpload], input[name^=uploadAdditional], hr").hide();
//   $("button[name=anyConcerns], button[name=uploadReq], span[name=xModalReqDetails]").show();
//   $("input[name^=uploadAdditional]").val(""); //This will reset input File
// });

$("button[name=submitUpload]").click(function(){
  $(this).hide();
  // $(this).text("Uploading . . .");
  $('div.loader').removeClass('hide');
  $('button[name=cancelUpload]').attr("disabled", true);
});

$("button[name=cancelUpload]").click(function(){
  $("button[name=submitUpload], button[name=cancelUpload]").hide();
  $("input[name^=uploadAdditional], hr").slideUp();
  $("button[name=anyConcerns], button[name=uploadReq], span[name=xModalReqDetails]").show();
  $("input[name^=uploadAdditional]").val(""); //This will reset input File
});

$("button[name=anyConcerns]").click(function(){
    $("hr, button[name=backConcerns]").show();
    $(".concerns").slideDown();

    if(gUploadControl == "ON"){
      $('button[name=uploadRequest]').hide();
    }
    $("button[name=anyConcerns], button[name=uploadReq], span[name=xModalReqDetails]").hide();
});

$("button[name=backConcerns]").click(function(){
    $("button[name=backConcerns]").hide();
    $(".concerns, hr").slideUp();
    if(gUploadControl == "OFF"){
      $("button[name=anyConcerns], span[name=xModalReqDetails]").show();
    }else{
      $("button[name=anyConcerns], button[name=uploadReq], span[name=xModalReqDetails]").show();
    }
});

$("button[name=uploadRequest]").click(function(){
  $("#modalSendEmail").show();
  $("#modalSendEmail h3").html("Request to Upload Files");
  $("#modalSendEmail textarea").val("Hi System Group,\n\nI am requesting permission to upload additional files. \nThank you!\n\nRegards,\n"+ajaxKeyPerson);
  $("#modalSendEmail input[name=emailCC]").val(ajaxKeyPersonEmail+"; "+ajaxClientRepEmail);
  $("#modalSendEmail input[name=emailSubject]").val("Request to Upload Additional Files - "+ajaxTicket);
});

$("button[name=cancelRequest]").click(function(){
  
  $("#modalSendEmail").show();
  $("#modalSendEmail h3").html("Cancellation Request");
  $("#modalSendEmail textarea").val("Hi System Group,\n\nI am requesting for cancellation of our Request. \nThank you!\n\nRegards,\n"+ajaxKeyPerson);
  $("#modalSendEmail input[name=emailCC]").val(ajaxKeyPersonEmail+"; "+ajaxClientRepEmail);
  $("#modalSendEmail input[name=emailSubject]").val("Cancellation of Request - "+ajaxTicket);
});

$("button[name=updateClientRepRequest]").click(function(){
  
  $("#modalSendEmail").show();
  $("#modalSendEmail h3").html("Update Representative");
  $("#modalSendEmail textarea").val("Hi System Group,\n\nI am requesting to update our Representative from Juan Dela Cruz to John Doe. \nThank you!\n\nRegards,\n"+ajaxKeyPerson);
  $("#modalSendEmail input[name=emailCC]").val(ajaxKeyPersonEmail+"; "+ajaxClientRepEmail);
  $("#modalSendEmail input[name=emailSubject]").val("Update Representative Request - "+ajaxTicket);
});

$("button[name=othersRequest]").click(function(){
  

  $("#modalSendEmail").show();
  $("#modalSendEmail h3").html("Other Requests/Concerns");
  $("#modalSendEmail textarea").val("Hi System Group,\n\nI am requesting to ________________. \n\n\n\nRegards,\n"+ajaxKeyPerson);
  $("#modalSendEmail input[name=emailCC]").val(ajaxKeyPersonEmail+"; "+ajaxClientRepEmail);
  $("#modalSendEmail input[name=emailSubject]").val("Request to ... - "+ajaxTicket);
});

$("button[name=cancelEmail]").click(function(){
  $("#modalSendEmail").hide();
  $("#modalSendEmail textarea").val(""); // Clear all Modified Entries
});


// SLIDESHOW FUNCTION
//-------------------

var slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
}
//-------------------------- 
// End of SLIDESHOW FUNCTION


var inputGroupVal = $('select[name=inputGroup] option').val();

if(inputGroupVal != "Choose Group"){
  $('select[name=inputClientRepEmail]').removeAttr('disabled');
  $('select[name=inputClientRepEmail]').prop('title', 'Representative');
}

directoryIsClicked = true;

$('p[name=projectDirectory]').click(function()
{
    if(directoryIsClicked)
    {
        $('#projectDirectory').removeClass('hide');
        $('#list').hide();
        $('#plusButton').hide();
        $('#btnExport').hide();
        $('input[name=inputSearch]').hide();
        $('span[name=clearFilter]').hide();
        $('select[name=selectViewByDev]').hide();
        $('select[name=selectViewByStatus]').hide();
        $('.ribbon-requestList').hide();

        $('p[name=projectDirectory]').html("Request List");
        $('#header').html("Project Directory");
        $('#subheader').html("List of Completed Projects");
        window.history.pushState({}, '', '?nav=directory');

        directoryIsClicked = false;
    }else{
        $('#projectDirectory').addClass('hide');
        $('#list, #plusButton, select[name=selectViewByDev], select[name=selectViewByStatus], span[name=clearFilter], #btnExport').show();
        $('p[name=projectDirectory]').html("Project Directory");
        $('#header').html("Active Requests");
        $('#subheader').html("Ongoing, On Hold, Waiting, and Pending Items");
        window.history.pushState({}, '', '/WRS/');
        // window.history.replaceState({}, document.title, "/" + "WRS/index.php");

        directoryIsClicked = true;
    }
});



$('table[name=projectDirectory]').on('click', 'tr:not(:first, .matchNotFound)', function()
{
    var trRequestCode = $(this).attr('value');

    fxGet_ProjectDetails(trRequestCode);


    $('#modalProjectDetails').show();


    let projCode = $(this).find('td:nth-child(2)').html();
    let macroName = $(this).find('td:nth-child(3)').html();
    let desc = $(this).find('td:nth-child(4)').html();
    let kp = $(this).find('td:nth-child(5)').html();
    let cr = $(this).find('td:nth-child(6)').html();
    let dev = $(this).find('td:nth-child(7)').html();
    let path = $(this).find('td:nth-child(8)').html();
    $('#sDirectoryProjCode').text(projCode);
    $('#sDirectoryMacroName').text(macroName);
    $('#sDirectoryDesc').text(desc);
    $('#sDirectoryKP').text(kp);
    $('#sDirectoryCR').text(cr);
    $('#sDirectoryDev').text(dev);
    $('#sDirectoryPath').val(path);

});



function fxGet_ProjectDetails(requestCode)
{
    $.post("./includes/requestDetails.php",
    {
        reqCode: requestCode
    }, 
    function(data, status)
    {
        ajaxProjectCode = fxExtract_Data(data, "ProjectCode~", 12);    //11 is the length of "ProjectCode~" Keyword
        ajaxTitle       = fxExtract_Data(data, "Title~", 6);    
        ajaxDesc        = fxExtract_Data(data, "Description~", 12);   
        ajaxKeyPerson   = fxExtract_Data(data, "KP~", 3);   
        ajaxClientRep   = fxExtract_Data(data, "ClientRepresentative~", 21);   
        ajaxDev         = fxExtract_Data(data, "Developer~", 10);   
        ajaxFinishPath  = fxExtract_Data(data, "FinishPath~", 11);   

        ajaxFinishPath = ajaxFinishPath.replace(/\//g, "\\");   //Replaces Backslash (/) into Forward Slash (\)  
        
        $('#sDirectoryProjCode').text(ajaxProjectCode);
        $('#sDirectoryMacroName').text(ajaxTitle).attr('title', ajaxTitle);
        $('#sDirectoryDesc').text(ajaxDesc).attr('title', ajaxDesc);
        $('#sDirectoryKP').text(ajaxKeyPerson);
        $('#sDirectoryCR').text(ajaxClientRep);
        $('#sDirectoryDev').text(ajaxDev);
        $('#sDirectoryPath').val(ajaxFinishPath).attr('title', ajaxFinishPath);
    });
}



function fxExtract_Data(data, fieldName, size)
{
    first_index = data.indexOf(fieldName);
    last_index = data.lastIndexOf(fieldName);
    extracted_data = data.substring(first_index+size, last_index); 

    return extracted_data;
}



$('button[name=copyBtn]').click(function(){

  $('input[name=inputPath]').select(); //This will SELECT ALL the Text inside the Input Field
  document.execCommand("copy"); //This will run the Copy Command to copy the Selected Text above in Clipboard
  $('p[name=copied]').show().fadeOut(1000);

});

var gKeyPerson = $('input[name=inputKeyPerson]').val();

$('select[name=inputGroup]').change(function(){
  $('#btnReset').show();
  $('select[name=inputClientRepEmail]').removeAttr('disabled');
  $('select[name=inputClientRepEmail]').prop('title', 'Representative');
  $('select[name=inputClientRepEmail] option').not(':first, :nth(1)').remove(); //Remove all <option> except the 1st & 2nd child
  var chosenGroup = $(this).val();
  
  $.post("./includes/getClientRep.php", 
  {
    requestFrom: 'user',
    groupCode: chosenGroup
  },
  function(data, status){
    
    const members = JSON.parse(data);
    $.each(members, function(index, value){
    memberName = value.slice(0, value.indexOf("~")); //this will slice Employee's Full Name from its Email. Example: ["Alvin John Aganan~aganan-kdt@corp.khi.co.jp"]
    emailLength = value.length;
    memberEmail = value.slice(value.indexOf("~")+1, emailLength); //this will slice Employee's Email from its Email. Example: ["Alvin John Aganan~aganan-kdt@corp.khi.co.jp"]
    
    if(gKeyPerson == memberName){
      return; //This will skip 1 iteration to avoid selecting itself as the Representative
    }
    
    $('select[name=inputClientRepEmail]').append($('<option>',{
      value: memberEmail,
      text: memberName}));
    });

  });
});




// --- This clones the Element from HTML to another Form ---
// $("input[name^=inputReq]").change(function(){
//   var $this = $(this), $clone = $this.clone();
//   $this.after($clone).appendTo(formNewRequest);
// });


// $(window).resize(function(){
//   var width = $(window).width();
//   var height = $(window).height();
//   $("#h").text(width);
//   $("#w").text(height);
// });

let urlParams = new URLSearchParams(window.location.search);
let hasRequest = urlParams.has('request'); // checks if it has 'request' on URL parameters
let hasUpload = urlParams.has('upload'); // checks if it has 'upload' on URL parameters
let hasEmail = urlParams.has('email'); // checks if it has 'email' on URL parameters
let hasNav = urlParams.has('nav'); // checks if it has 'nav' on URL parameters
var urlNav = urlParams.get('nav'); // gets request value in URL
var urlCode = urlParams.get('request'); // gets request value in URL
var uploadID = urlParams.get('id'); // gets upload ID in URL
var tableList = $('table tr');
var tableData, tableRowID;

if(hasRequest){
  // window.location.search = ''; // removes URL Parameters but reloads the Page
  $('div[name=notif]').show();
  setTimeout(function(){
    window.history.replaceState({}, document.title, "/" + "WRS/"); // removes URL Parameters WITHOUT RELOADING the Page
  },100);

  $.each(tableList, function(index, value){
    if(index != 0){
      tableData = tableList.eq(index).find('td:nth-child(2)').html();
      if(tableData == urlCode){
        tableList.eq(index).addClass('newlyAdded');
      }
    }
  });
  setTimeout(function(){
    tableList.removeClass('newlyAdded');
  }, 60000); // 60 Seconds = 60,000 Milliseconds

  $('html, body').delay(4000).animate({             // Delays Auto Scroll to Bottom in 7000 Milliseconds/ 7 Seconds
    scrollTop: $('html, body').get(0).scrollHeight
  }, 2000);  // 
}


if(hasUpload){
  $('div[name=notif] p').html("File Uploaded Successfully");
  $('div[name=notif]').show();
  
  $.each(tableList, function(index, value){
    if(index != 0){
      tableRowID = tableList.eq(index).attr('id');
      console.log("URL ID "+uploadID);

      if(tableRowID == uploadID){
        tableList.eq(index).addClass('newlyAdded');
      }
    }
  });

  setTimeout(function(){
    tableList.removeClass('newlyAdded');
  }, 20000); // 20 Seconds = 20,000 Milliseconds

  setTimeout(function(){
    window.history.replaceState({}, document.title, "/" + "WRS/"); //removes URL Parameters WITHOUT RELOADING the Page
  }, 100);

  setTimeout(function () {
    $('html, body').animate({
      scrollTop: $(window).scrollTop() - 160
    });
  },3000);
}


if(hasEmail){
  $('div[name=notif] p').html("Your request was sent thru email.");
  $('div[name=notif]').show();
  
  setTimeout(function(){
    window.history.replaceState({}, document.title, "/" + "WRS/"); //removes URL Parameters WITHOUT RELOADING the Page
  }, 100);
}


if(hasNav){
  if(urlNav == "directory"){
    directoryIsClicked = true;
    $('.home-link').show();
    $('.directory-link').hide();
    $('p[name=projectDirectory]').trigger('click');

    $.post("./includes/userViewBy.php",
    {
        filterType: "statusFilter",
        viewByStatus: "Finished"
    },
    function(data, status){
        
        const obj = JSON.parse("["+data+"]");
        console.table(obj);
        console.log(obj);
        fxDirectoryTable(obj);
    });    
  }
}


function fxDirectoryTable(obj){

    if(obj.length == 0){
        $("table[name=projectDirectory]").append("<tr disabled><td colspan='8' class='c-text-center'><i>No Projects Found</i></td>");
      }
  
      var ctr2 = 0;
      for(ctr=0;ctr<obj.length;ctr++){
        ctr2++;
        var tdCtr = "<td>"+ctr2+"</td>";
        // var tdTicket = "<td>-</td>";
        var tdProjectCode = "<td>"+obj[ctr].ProjectCode+"</td>";
        var tdTicket      = "<td>"+obj[ctr].TicketNumber+"</td>";
        var tdCode        = "<td class='tdRequestCode' value='"+obj[ctr].RequestCode+"'>"+obj[ctr].RequestCode+"</td>";
        var tdTitle       = "<td>"+obj[ctr].Title+"</td>";
        var tdDesc        = "<td>"+obj[ctr].Desc+"</td>";
        var tdKeyPerson   = "<td>"+obj[ctr].KeyPerson+"</td>";
        var tdClientRep   = "<td>"+obj[ctr].ClientRep+"</td>";
        var tdDev         = "<td>"+obj[ctr].Dev+"</td>";
        var tdFinishPath  = "<td>"+obj[ctr].FinishPath+"</td>";

        
        
        var appendTr =  "<tr value='"+obj[ctr].RequestCode+"'>"+tdCtr+tdProjectCode+tdTicket+tdTitle+tdDesc+tdKeyPerson+tdClientRep+tdDev+"</tr>";
        $("table[name=projectDirectory] tbody").append(appendTr);
        // $("table[name=requestlist] tbody").append(appendTr);
      }
}
// --- END of fxDirectoryTable()




$('button[name=btnGoUp]').click(function(){
  // $('html, body').scrollTop($(document).height());
  $('html,body').animate({ scrollTop: 0 }, 'slow');
    // return false; //kasama to ng Go to Top Animation

  //window.scrollTo(0,0); // X & Y Coordinates. This will scroll to Top and Leftmost
});


// Make the DIV element draggable:
dragElement(document.getElementById("modalRequest"));
// dragElement(document.getElementById("modalPreview"));

function dragElement(elmnt) {
  var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  if (document.getElementById(elmnt.id + "Header")) {
    // if present, the Header is where you move the DIV from:
    document.getElementById(elmnt.id + "Header").onmousedown = dragMouseDown;
    document.getElementById(elmnt.id + "Footer").onmousedown = dragMouseDown;
  } else {
    // otherwise, move the DIV from anywhere inside the DIV:
    elmnt.onmousedown = dragMouseDown;
  }

  function dragMouseDown(e) {
    e = e || window.event;
    e.preventDefault();
    // get the mouse cursor position at startup:
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    // call a function whenever the cursor moves:
    document.onmousemove = elementDrag;
  }

  function elementDrag(e) {
    $('#modalRequest').css('background-color','transparent');
    
    e = e || window.event;
    e.preventDefault();
    // calculate the new cursor position:
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    // set the element's new position:
    elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
    elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
  }

  function closeDragElement() {
    // stop moving when mouse button is released:
    document.onmouseup = null;
    document.onmousemove = null;
  }
}



$('#btnExport').click(function()
{
    if(gExportControl == "OFF"){
        $('#modalNoAccess').show();
    }
    else{
        $('#requestList th').attr('data-f-bold', true);

        TableToExcel.convert(document.getElementById("requestList"));
        $('#requestList th').removeAttr('data-f-bold', true);
        
        $(this).text('EXPORTING . . .');

        setTimeout(() => {
        $(this).text('EXPORT');  
        }, 2000);
    }

});



$(".directory-link").click(function(){

    $.post("./includes/userViewBy.php",
    {
        filterType: "statusFilter",
        viewByStatus: "Finished"
    },
    function(data, status){
        console.log(data);
    });
});