<?php


    if(ISSET($_GET['username'])){
        setcookie("newUser", $_GET['username'], time()+86400*30);   //86400 seconds = 1 Day
        header('Location: ./');
    }
?>

<html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<style>
    *{
        font-size: 20px;
    }
    form, div{
        margin-top: 10%;
    }
</style>

<body>
    <!-- <form id="formPassword" align="center">
        <label>Password: </label>
        <input type="password" placeholder="Input Password" name="password" />
        <input type="submit">
    </form> -->
    <form id="formUser" action="user.php" method="GET"  align="center">
        <label>Username: </label>
        <input type="text" placeholder="Input Username" value="" name="username" autofocus/>
        <input type="submit">
    </form>    
<script>

// $('#formPassword').submit(function(event){
//     event.preventDefault();
//     let a = $('input[name=password]').val();
//     if(a == "hulaanmo"){

//     }
// });


</script>
</body>
</html>