<?php 
    // include "includes/dbconnect.php";
    if(isset($_COOKIE["newUser"])){
        header("Location: //kdt-ph");
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>KDT Portal - Welcome Page</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Oswald:700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lato:400" rel="stylesheet">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

	<!-- Font Awesome Icon -->
	<link type="text/css" rel="stylesheet" href="css/font-awesome.min.css" />

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


	<style>
		.w3-section{
			display: none;
		}
		img{
			width: 90%;
		}
		input{
			border: none;
			outline: none;
			background: none;
			width: 100%;
			text-align: center;
			font-size: 17px;
			font-style: italic;
			margin-bottom: 10px;
			margin-top: 20px;
		}
		label{
			font-size: 15px;
			color: blue;
			margin-top: 20px;
			display: none;
		}
		button:hover{
			cursor: pointer;
		}

	</style>

</head>

<body>

	<div id="notfound">
		<div class="notfound-bg">
			<div></div>
			<div></div>
			<div></div>
			<div></div>
		</div>
		<div class="notfound">
			<h2 name="welcome">Welcome to</h2>

			<div class="notfound-404">
				<h1>KDT Web Portal</h1>
			</div>
			
			<!-- <p id="pTag">To get started, follow the instructions below.</p> -->
			<p name="getStarted">To get started, click the start button below.</p>
			<button name="start">Start</button>

			<div class="w3-row-padding w3-section w3-stretch">
				<div class="w3-col l4 ">
					<h3><strong>Step 1:</strong> Copy this path:</h3>
					<!-- <h4><i>\\KDTS015\WebRequest\WRS\Patch\WebRequest_Patch.exe</i></h4> -->
					<input name="hiddenText" type="text" value="\\KDTS015\WebRequest\WRS\Patch\WebRequest_Patch.exe" readonly/>
					<button name="copy">Copy</button><br>
					<label>Text Copied to Clipboard!</label>
				</div>
				<div class="w3-col l4 ">
					<h3 title="TIP: Press Windows Key + E to open the File Explorer."><strong>Step 2:</strong> Open your File Explorer (<i class="fa fa-windows"></i> + E)</h3>
					<img src="Search File Explorer.png" alt="Picture 1" />
				</div>
				<div class="w3-col l4 ">
					<h3><strong>Step 3:</strong> Paste the Path in File Explorer and press ENTER.</h3>
					<img src="Paste in File Explorer.png" alt="Picture 1" />
				</div>
			</div>
		</div>


	</div>

<script>

var btnClicked = true;

$('button[name=start]').click(function(){
	if(btnClicked){
		$('h2[name=welcome]').slideUp();
		$('.w3-section').slideDown();
		$('p[name=getStarted]').text("Please follow the instructions below. This will automate your login on your next visit.");
		$(this).text("Close");
		btnClicked = false;
	}else{
		$('h2[name=welcome]').slideDown();
		$('.w3-section').slideUp();
		$('p[name=getStarted]').text("To get started, click the start button below.");
		$(this).text("Start");
		btnClicked = true;
	}
});

$('button[name=copy]').click(function(){
	$('input[name=hiddenText]').select();
	document.execCommand("copy");
	$('label').show().fadeOut(1000);
});

</script>

</body>

<!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>
