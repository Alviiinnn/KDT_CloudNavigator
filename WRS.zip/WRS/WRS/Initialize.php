<?php
setcookie("newUser","");

$filename = "D:\Home\Webrequestlogin\userName.txt";

$readme = file_get_contents($filename);
echo $readme;

setcookie("newUser", $readme, time()+84600*30);
echo $_COOKIE["newUser"];

echo "<script>window.close();</script>";

?>