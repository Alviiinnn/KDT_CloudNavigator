<?php 
    // include "includes/dbconnect.php";
    if(isset($_COOKIE["newUser"])){
        header("Location: ./");
    }
?>


<!DOCTYPE html>
<html>
<title>User Not Found</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<body class="w3-black">
    <div class="w3-container w3-animate-top" align="center" style="padding-top: 100px;">
        <h1>ERROR: User Not Found!</h1>
        <p>Please run the WebRequest_Patch.exe File located in the path below then REFRESH this Page.</p><br>
        <p style="opacity: 0.5;">\\KDTS015\WebRequest\WRS\Patch</p>
        
    </div>

</body>
</html>