<?php
// mkdir("C:\Users\dev_common\Documents\Test Folder\Hello");    //Working

$path1 = "C:\\xampp\\htdocs\\PROJECTS\\TEST1"; //WORKING 100%
$path2 = "C:/xampp/htdocs/PROJECTS/TEST2/AAA"; //WORKING 100%
mkdir($path1, 0755, true);
mkdir($path2, 0755, true);


if(file_exists($path1))
{
    echo "<br>Exists 1";
}else{
    echo "<br>Not 1";
}


if(file_exists($path2))
{
    echo "<br>Exists 2";
}else{
    echo "<br>Not 2";
}


?>