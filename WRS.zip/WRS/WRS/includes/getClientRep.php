<?php 

include "dbconnect.php";
$requestFrom = $_POST['requestFrom'];

if($requestFrom == "user"){
    $groupCode = $_POST['groupCode'];
    // $sql = "SELECT FirstName, LastName, Email FROM employee_list  WHERE BusinessUnit LIKE '%$groupCode%' ORDER BY FirstName"; //DO NOT DELETE THIS! 
    $sql = "SELECT FirstName, LastName, Email FROM employee_list ORDER BY FirstName";
    $result = $conn->query($sql);

    $ctr = 0;
    $string = "[";

    if($result->num_rows > 0){

        while($row = $result->fetch_assoc()){
            $clientRepFullName = $row['FirstName']." ".$row['LastName']; 
            $clientRepFullName = ucwords(strtolower($clientRepFullName));    
            $clientRepFullName .= "~".$row['Email'];

            $ctr++;

            if($result->num_rows == $ctr){
                $string .= "\"$clientRepFullName\"]";  
                echo $string; //ito ang irereturn na value sa JQUERY
            }else{
                $string .= "\"$clientRepFullName\", ";  
            }
        }
    }
}

if($requestFrom == 'admin'){
    $groupCode = $_POST['postGroup'];
    $clientRep = $_POST['postClientRep'];

    // $sql = "SELECT FirstName, LastName, Email FROM employee_list  WHERE BusinessUnit LIKE '%$groupCode%' ORDER BY FirstName"; //DO NOT DELETE THIS
    $sql = "SELECT FirstName, LastName, Email FROM employee_list ORDER BY FirstName";
    $result = $conn->query($sql);

    $ctr = 0;
    // $arrayVar = array();
    $string = "[";

    if($result->num_rows > 0){
        while($row = $result->fetch_assoc()){
            $clientRepFullName = $row['FirstName']." ".$row['LastName']; 
            $clientRepFullName = ucwords(strtolower($clientRepFullName));
            // $arrayVar[$ctr] = "$clientRepFullName";
            $ctr++;
            if($clientRepFullName == $clientRep){
                continue; //this will skip Current Client Rep
            }
            $clientRepFullName .= "~".$row['Email'];

            if($result->num_rows == $ctr){
                $string .= "\"$clientRepFullName\"]";  
                echo $string; //ito ang irereturn na value sa JQUERY
            }else{
                $string .= "\"$clientRepFullName\", ";  
            }
        }
    }
}



?>