<?php
// include "dbconnect.php";

// function funcGetFullName($printMe){
// echo "Print This: ".$printMe;
// }

// $sql = "SELECT FirstName, LastName FROM employee_list WHERE UserName = 'Developer' ORDER BY UserName";


?>