<?php

include "dbconnect.php";

$filterType = $_POST['filterType']; //Variable to check if Status or Developer Filter

if($filterType == "statusFilter"){
    $selectedStatus = $_POST['viewByStatus'];

    if($selectedStatus == "All"){
        // $sql = "SELECT * FROM request_list WHERE Status <> 'Finished' ";
        $sql = 'SELECT * FROM request_list
            -- WHERE Status <> "Finished" AND Status <> "Cancelled" AND Status <> "Denied" 
            ORDER BY (CASE Status
            WHEN "Ongoing" THEN 1
            WHEN "On Hold" THEN 1
            WHEN "Waiting" THEN 1
            WHEN "Pending" THEN 2
            WHEN "Finished" THEN 3
            WHEN "Cancelled" THEN 4 
            WHEN "Denied" THEN 5
            END), DateRequested, PriorityRank';
    }else if($selectedStatus == "Ongoing"){
        $sql = "SELECT * FROM request_list WHERE Status = '$selectedStatus' OR Status = 'On Hold' OR Status = 'Waiting' ORDER BY PriorityRank";
    }
    else{
        $sql = "SELECT * FROM request_list WHERE Status = '$selectedStatus' ";
    }
}

if($filterType == "developerFilter"){
    $selectedDev = $_POST['viewByDev'];

    if($selectedDev == "All Developers"){
        $sql = "SELECT * FROM request_list WHERE Developer <> '-' 
                ORDER BY (CASE Status
                WHEN 'Ongoing' THEN 1
                WHEN 'On Hold' THEN 1
                WHEN 'Waiting' THEN 1
                WHEN 'Pending' THEN 2
                WHEN 'Finished' THEN 3
                WHEN 'Cancelled' THEN 4
                WHEN 'Denied' THEN 5
                END), PriorityRank";
    }else{
        $sql = "SELECT * FROM request_list WHERE Developer LIKE '%$selectedDev%' 
                ORDER BY (CASE Status 
                WHEN 'Ongoing' THEN 1
                WHEN 'On Hold' THEN 1
                WHEN 'Pending' THEN 2 
                WHEN 'Finished' THEN 3
                WHEN 'Cancelled' THEN 4
                WHEN 'Denied' THEN 5
                END), PriorityRank";
    }
}


if($filterType == "devNstatusFilter")
{
    $selectedStatus = $_POST['viewByStatus'];
    $selectedDev = $_POST['viewByDev'];


    if($selectedDev == "All Developers" && $selectedStatus == "All")
    {
        $sql = "SELECT * FROM request_list WHERE Developer <> '-' 
                ORDER BY (CASE Status
                WHEN 'Ongoing' THEN 1
                WHEN 'On Hold' THEN 1
                WHEN 'Waiting' THEN 1
                WHEN 'Pending' THEN 2
                WHEN 'Finished' THEN 3
                WHEN 'Cancelled' THEN 4
                WHEN 'Denied' THEN 5
                END), PriorityRank";
    }
    else if($selectedDev == "All Developers" && $selectedStatus != "All")
    {
        $sql = "SELECT * FROM request_list WHERE Developer <> '-' AND Status = '$selectedStatus'
                ORDER BY (CASE Status
                WHEN 'Ongoing' THEN 1
                WHEN 'On Hold' THEN 1
                WHEN 'Waiting' THEN 1
                WHEN 'Pending' THEN 2
                WHEN 'Finished' THEN 3
                WHEN 'Cancelled' THEN 4
                WHEN 'Denied' THEN 5
                END), PriorityRank";
    }
    else if($selectedStatus == "All")
    {
        $sql = "SELECT * FROM request_list WHERE Developer LIKE '%$selectedDev%' 
                ORDER BY (CASE Status
                WHEN 'Ongoing' THEN 1
                WHEN 'On Hold' THEN 1
                WHEN 'Waiting' THEN 1
                WHEN 'Pending' THEN 2
                WHEN 'Finished' THEN 3
                WHEN 'Cancelled' THEN 4
                WHEN 'Denied' THEN 5
                END), PriorityRank";
    }
    else{
        $sql = "SELECT * FROM request_list WHERE Status = '$selectedStatus' AND Developer LIKE '%$selectedDev%' 
                ORDER BY (CASE Status
                WHEN 'Ongoing' THEN 1
                WHEN 'On Hold' THEN 1
                WHEN 'Waiting' THEN 1
                WHEN 'Pending' THEN 2
                WHEN 'Finished' THEN 3
                WHEN 'Cancelled' THEN 4
                WHEN 'Denied' THEN 5
                END), PriorityRank";
    }
}


$result = $conn->query($sql);

// $objRequest = {
//     RequestCode: [],
//     ProjectName: [],
//     Status: []
// };
$ctr = 0;
$totalRows = $result->num_rows;
if($result->num_rows > 0){
    while($row = $result->fetch_assoc()){
        $ctr++;
        $requestObj = new stdClass();

        // $requestObj->Request = ["Code"=>$row['RequestCode'],
        //                             "ProjectName"=>$row['Title'],
        //                             "Group"=>$row['GroupBU'],
        //                             "Status"=>$row['Status']];

        $requestObj->TicketNumber = $row['TicketNumber'];
        $requestObj->RequestCode = $row['RequestCode'];
        $requestObj->PriorityRank = $row['PriorityRank'];
        $requestObj->Title = $row['Title'];
        $requestObj->Group = $row['GroupBU'];
        $requestObj->Desc = $row['Description'];
        $requestObj->ProjectType = $row['ProjectType'];
        $requestObj->ProjectCode = $row['ProjectCode'];
        $requestObj->KeyPerson = $row['KeyPerson'];
        $requestObj->ClientRep = $row['ClientRepresentative'];
        $requestObj->Dev = $row['Developer'];
        $requestObj->DateReq = $row['DateRequested'];
        $requestObj->TimeReq = $row['TimeRequested'];
        $requestObj->StartDate = $row['StartDate'];
        $requestObj->FinishDate = $row['FinishDate'];
        $requestObj->Remarks = $row['Remarks'];
        $requestObj->Progress = $row['Progress'];
        $requestObj->Status = $row['Status'];
        $requestObj->FinishPath = $row['FinishPath'];

        $requestJSON = json_encode($requestObj);

        if($ctr == $totalRows){
            echo $requestJSON;
        }else
        {
            echo $requestJSON.",";
        }
    }
}

?>