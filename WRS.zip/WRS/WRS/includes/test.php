<?php

$testingOnly = "
<hr>
<h2 style='color: gray;'><i>Please ignore this email. This is a <u>TEST ONLY</u>!</i></h2>
<hr>
<br>
";

?>