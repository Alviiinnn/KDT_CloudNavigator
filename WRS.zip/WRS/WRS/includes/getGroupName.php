<?php

include "dbconnect.php";

$groupCode = $_POST['groupCode'];

$sql = "SELECT BUName from business_units WHERE BUCode = '$groupCode' ";

$result = $conn->query($sql);

if($result->num_rows > 0){
    $row = $result->fetch_assoc();
    echo $row['BUName'];
}else{
    echo "There's an error on fetching Group Code '$groupCode'. Please check on 'getGroupName.php'";
}

$conn->close();

?>