<?php 

include "dbconnect.php";

// $sql = "SELECT FirstName, LastName FROM employee_list WHERE Access = 'Developer' ORDER BY FirstName";

// $result = $conn->query($sql);
// $string = "[";
// $ctr = 0;
// if($result->num_rows > 0){
//     while($row = $result->fetch_assoc()){
//         $firstName = strtolower($row['FirstName']);
//         $lastName = strtolower($row['LastName']);
//         $fullName = $firstName." ".$lastName;
//         $fullName = ucwords($fullName);
//         $ctr++;
//         if($result->num_rows == $ctr){
//             $string .= "\"$fullName\"]";
//             echo $string; //ito ang irereturn na value sa JQUERY
//         }else{
//             $string .= "\"$fullName\", ";
//         }
//     }
// }

$sql = "SELECT UserName, Email, FirstName, LastName FROM employee_list WHERE Access = 'Developer' ORDER BY UserName";

$result = $conn->query($sql);
$string = "[";
$devUserNames = array();
$devEmails = array();
$devFullNames = array();
$ctr = 0;

if($result->num_rows > 0){
    while($row = $result->fetch_assoc()){
        $UserName = $row['UserName'];
        $fullName = $row['FirstName']." ".$row['LastName'];
        
        array_push($devFullNames, $fullName);
        array_push($devEmails, $row['Email']);
        array_push($devUserNames, $row['UserName']);

        $ctr++;
        if($result->num_rows == $ctr){
            $string .= "\"$UserName\"]";
            echo $string; //ito ang irereturn na value sa JQUERY
        }else{
            $string .= "\"$UserName\", ";
        }
    }
}

?>