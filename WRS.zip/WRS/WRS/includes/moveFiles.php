<?php
// COPY and DELETE of this Function is WORKING on LOCAL and SERVER Files
// Created by: Alvin John Aganan - March 31, 2022


// --- VARIABLES ---
// $fileLocation         - from update.php
// $projectType          - from update.php
// $projectName          - from update.php
// $reqCode              - from update.php
// $projectNumber        - from update.php
// $existingProject      - from update.php
// $finishDate           - from update.php
// $G_FinishSystemPath   - from getControl-LocationPath.php
// $var_totalFiles       - from getFolderTotalFiles.php


require "getControl-LocationPath.php";


$src                = fxIsset($fileLocation);      // MF means MoveFiles. I created this para exclusive lang siya sa moveFiles.php
$mf_reqCode         = fxIsset($reqCode);    
$mf_projectType     = fxIsset($projectType);
$mf_projectName     = fxIsset($projectName);
$mf_existingProject = fxIsset($existingProject);
$mf_finishDate      = fxIsset($finishDate);
$mf_finishDateYear  = substr($mf_finishDate, 0, 4);     // Get Year from 2022-05-30 -> 2022

function fxIsset($isset_value)
{
    if(isset($isset_value)){
        return $isset_value;
    }
}

function fxFileExists($dir_value)
{
    if(file_exists($dir_value) == false){
        mkdir($dir_value);
    }
}


$dir_projectType = "$G_FinishSystemPath/$mf_projectType";


require "getFolderTotalFiles.php";      //WARNING: DO NOT REMOVE THIS HERE! - Alvin Aganan (April 4, 2022)


$projectCodeName     = $projectNumber."_".$projectName;          //Project Code and Name - 0001_Web Request System Project
$dir_projectCodeName = ($mf_existingProject) ? "$dir_projectType/$mf_existingProject" : "$dir_projectType/$projectCodeName";    //157.116.72.26/WebRequest/WRS/PROJECTS/01 Application/0001_WRS Project
$dir_year            = "$dir_projectCodeName/$mf_finishDateYear";       //157.116.72.26/WebRequest/WRS/PROJECTS/01 Application/0001_WRS Project/2022
$dir_requestCode     = "$dir_year/$mf_reqCode";       //157.116.72.26/WebRequest/WRS/PROJECTS/01 Application/0001_WRS Project/2022/20211231_235959_E466
$destination         = $dir_requestCode;


include "updateFinishPath.php";


fxFileExists($G_FinishSystemPath);   // Creates: //157.116.72.26/WebRequest/WRS/PROJECTS
fxFileExists($dir_projectType);      // Creates: //157.116.72.26/WebRequest/WRS/PROJECTS/01 Application...
fxFileExists($dir_projectCodeName);  // Creates: //157.116.72.26/WebRequest/WRS/PROJECTS/01 Application/0001_WRS Project
fxFileExists($dir_year);             // Creates: //157.116.72.26/WebRequest/WRS/PROJECTS/01 Application/0001_WRS Project/2022
fxFileExists($dir_requestCode);      // Creates: //157.116.72.26/WebRequest/WRS/PROJECTS/01 Application/0001_WRS Project/2022/20211231_235959_E466


echo "<br>mf_reqCode: $mf_reqCode";
echo "<br>Dir_projectType: $dir_projectType";
echo "<br>Dir_projectCodeName: $dir_projectCodeName";
echo "<br>Dir_projectCodeName: $dir_year";
echo "<br>Dir_requestCode: $dir_requestCode";


$GLOBALS['ctr'] = 1;

recurseCopy($src, $destination);

function recurseCopy(
    string $sourceDirectory,
    string $destinationDirectory,
    string $childFolder = ''
): void {
    echo "<p>Count = ".$GLOBALS['ctr']."</p>";

    $directory = opendir($sourceDirectory);

    if (is_dir($destinationDirectory) === false) {
        mkdir($destinationDirectory);
        echo "<p><b>DIRECTORY:</b> $destinationDirectory</p>";

    }

    if ($childFolder !== '') {
        if (is_dir("$destinationDirectory/$childFolder") === false) {
            mkdir("$destinationDirectory/$childFolder");
            echo "<p><b>CHILD DIRECTORY:</b> $childFolder</p>";

        }

        while (($file = readdir($directory)) !== false) {
            if ($file === '.' || $file === '..') {
                continue;
            }

            if (is_dir("$sourceDirectory/$file") === true) {
                recurseCopy("$sourceDirectory/$file", "$destinationDirectory/$childFolder/$file");
            } else {
                copy("$sourceDirectory/$file", "$destinationDirectory/$childFolder/$file");
            }
        }

        closedir($directory);

        return;
    }

    while (($file = readdir($directory)) !== false) {
        if ($file === '.' || $file === '..') {
            continue;
        }

        if (is_dir("$sourceDirectory/$file") === true) {
            recurseCopy("$sourceDirectory/$file", "$destinationDirectory/$file");
        }
        else {
            copy("$sourceDirectory/$file", "$destinationDirectory/$file");
        }
        echo "<p><b>File:</b> $file</p>";
    }

    closedir($directory);
    echo "<h3>Copied Successfully!</h3>";
    $GLOBALS['ctr']++;

}

    // $dir = 'samples' . DIRECTORY_SEPARATOR . 'sampledirtree';
    $it = new RecursiveDirectoryIterator($src, RecursiveDirectoryIterator::SKIP_DOTS);
    $files = new RecursiveIteratorIterator($it,
                RecursiveIteratorIterator::CHILD_FIRST);
    foreach($files as $file) {
        if ($file->isDir()){
            rmdir($file->getRealPath());
        } else {
            unlink($file->getRealPath());
        }
    }
    rmdir($src);

    echo "<h3>Deleted Successfully!</h3>";


?>