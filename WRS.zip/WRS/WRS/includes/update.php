<?php
include "dbconnect.php";

$updateChecker = $_POST['requestChecker'];

if($updateChecker == "updateRequestDetails")
{
    //This Counts the number of Priority Items
    $sql1 = "SELECT COUNT(*)PriorityRank FROM request_list WHERE PriorityRank <> 0";
    $result = $conn->query($sql1);
    $row1 = $result->fetch_assoc();
    $totalPriority = $row1['PriorityRank']; //This returns the current Total Number of Priority Items

    $reqCode         = $_POST['inputCode'];
    $projectType     = $_POST['projectType'];
    $projectNumber   = $_POST['projectNumber'];
    $projectCode     = "";
    $existingProject = $_POST['existingProjects'];
    $keyPerson       = $_POST['inputKeyPerson'];
    $projectName     = mysqli_real_escape_string($conn, $_POST['inputTitle']);
    $desc            = mysqli_real_escape_string($conn, $_POST['inputDesc']);
    $clientRep       = $_POST['inputClientRep'];
    $status          = $_POST['inputStatus'];
    $fileLocation    = $_POST['inputReq'];
    $dev             = $_POST['inputDev'];
    $startDate       = $_POST['inputStartDate'];
    $finishDate      = $_POST['inputFinishDate'];
    $progress        = $_POST['inputProgress'];
    $remarks         = mysqli_real_escape_string($conn, $_POST['inputRemarks']);
    $priorityRank    = $_POST['inputPriorityRank'];

    switch($status){
        case "ongoing": $status = "Ongoing"; break;
        case "onhold": $status = "On Hold"; break;
        case "waiting": $status = "Waiting"; break;
        case "finished": $status = "Finished"; break;
        case "cancelled": $status = "Cancelled"; break;
        case "denied": $status = "Denied"; break;
        default: $status = "Pending";
    }

    if(!isset($projectNumber) || $projectNumber == "")
    {
        $projectNumber = substr($existingProject, 0, 4);    // If user chose the 'Existing Projects', its Project Number will be used
    }

    $projectCode = substr($projectType, 0, 2);  //Get the '01' on "01 Application"
    $projectCode .= "-".$projectNumber;         //Concatenate '01' with '0999' = "01-0999"

    $dev = rtrim($dev, ", "); //This will remove comma and space at the last of the String: Dev_name, Dev_name2, 
    
    //This will stripped out the Email from this String: Alvin John Aganan~aganan-kdt@corp.khi.co.jp
    $clientRepEmail = substr($clientRep, strpos($clientRep, "~")+1); 
    $keyPersonEmail = substr($keyPerson, strpos($keyPerson, "~")+1); 

    //Strips out Representative Name from this String: Alvin John Aganan~aganan-kdt@corp.khi.co.jp
    $clientRep = rtrim($clientRep, $clientRepEmail); 
    $clientRep = rtrim($clientRep, "~"); //Trims tilde ~ on this String: Alvin John Aganan~
    $keyPerson = rtrim($keyPerson, $keyPersonEmail); 
    $keyPerson = rtrim($keyPerson, "~");

    if(empty($dev)){
        $dev = "-";
    }
    
    if(empty($projectType)){
        $projectType = "-";
    }

    if($status == 'Finished'){  
        require "moveFiles.php";    //This will Copy and Delete Folders (including subfolders) to desired Destination
    }


    // if($status == 'On Hold'){  $ranking = $priorityRank;  }
    // if($status == 'Ongoing'){  $ranking = $totalPriority+1;  }
    // if(!ISSET($ranking)){   $ranking = 0;  }
    
    if($status == 'On Hold' || $status == 'Waiting')
    {  
        $ranking = $priorityRank;  
    }
    
    if($status == 'Ongoing')
    {   
        if($priorityRank == 0)
        {
            $ranking = $totalPriority+1;  
        }else{
            $ranking = $priorityRank;  
        }
    }
    
    if(!ISSET($ranking)){   $ranking = 0;  }



    if($priorityRank != 0 && $status != 'On Hold'){
        $sql3 = "SELECT RequestCode, Status, PriorityRank FROM request_list WHERE PriorityRank <> 0";
        $result3 = $conn->query($sql3);
        $arrRanks = array();
        $ctr = 0;
        if($result3->num_rows > 0){
            while($row3 = $result3->fetch_assoc()){
                $arrReqCodes[$ctr] = $row3['RequestCode'];
                $arrRanks[$ctr] = $row3['PriorityRank'];
                $ctr++;
            }
        }

        for($ctr=0; $ctr<count($arrRanks); $ctr++){
            // echo "<br>Arrays: ".$arrRanks[$ctr]." ".$arrReqCodes[$ctr];
            if($arrRanks[$ctr] > $priorityRank){
                $deduct1 = $arrRanks[$ctr] - 1;
                $sql4 = "UPDATE request_list SET PriorityRank = '$deduct1' WHERE RequestCode = '$arrReqCodes[$ctr]' ";
                $conn->query($sql4);
            }else{
                continue;
            }
        }
        echo "<br>Rows: ".$result3->num_rows;
    }
    echo "<br>Priority Rank: ".$priorityRank;

    // echo "<br>".$clientRep."<br>";
    // echo $clientRepEmail."<br>";

    echo "Code: ".$reqCode."<br>".
    "Project Name: ".$projectName."<br>".
    "Desc: ".$desc."<br>".
    "Client Rep: ".$clientRep."<br>".
    "Status: ".$status."<br>".
    "Dev: ".$dev."<br>".
    "Start Date: ".$startDate."<br>".
    "Finish Date: ".$finishDate."<br>".
    "Remarks: ".$remarks."<br>".
    "Rank: ".$priorityRank."<br>".
    "Project Type: ".$projectType."<br>";

    $sql2 = "UPDATE request_list 
            SET KeyPerson = '$keyPerson',
                KeyPersonEmail = '$keyPersonEmail',
                Title = '$projectName',
                Description = '$desc',
                ProjectType = '$projectType',
                ProjectCode = '$projectCode',
                ClientRepresentative = '$clientRep',
                ClientRepEmail = '$clientRepEmail', 
                Status = '$status', 
                Developer = '$dev',
                StartDate = '$startDate',
                FinishDate = '$finishDate',
                Progress = '$progress',
                Remarks = '$remarks',
                PriorityRank = '$ranking'
            WHERE RequestCode = '$reqCode' ";

    $conn->query($sql2);
    $conn->close();

    $status = strtolower($status);
    echo "<br>Eto ang Progress: ".$progress;
    echo "<br>Project Number: ".$projectNumber;
    echo "<br>Existing Project: ".$existingProject;
    header("Location: ../admin.php?changes=$reqCode&#$reqCode");
    // header("Location: ../admin.php?view=$status&changes=$reqCode"); 
    // header("Location: ../admin.php");
}



if($updateChecker == "updateRanking")
{
    $newRanking = $_POST['newRanking'];
    // var_dump($newRanking);
    print_r($newRanking);
    
    $sql = "UPDATE request_list SET PriorityRank = 0";  // This will RESET Ranking Priority in Database
    $conn->query($sql);    


    for($ctr=0; $ctr<count($newRanking); $ctr++)
    {
        $rank = $ctr;
        $refCode = $newRanking[$ctr];
        
        // This will Update New Ranking 
        $sql = "UPDATE request_list 
        SET PriorityRank = '$rank'
        WHERE RequestCode = '$refCode' ";
    
        $conn->query($sql);
    }
    $conn->close();
    // echo serialize($newRanking);
}



if($updateChecker == "updateEmployeeInfo")
{
    $access = $_POST['inputAccess'];
    $empID = $_POST['inputEmployeeID'];
    $exportControl = $_POST['inputExportControl'];

    if(isset($_POST['inputUploadControl'])){ //by Default, Checkbox Value is 'on'
        $uploadControl = "ON";
    }else{
        $uploadControl = "OFF";
    }

    if(isset($_POST['inputExportControl'])){ //by Default, Checkbox Value is 'on'
        $exportControl = "ON";
    }else{
        $exportControl = "OFF";
    }

    // echo $access." ".$empID." ".$uploadControl;
    $sql = "UPDATE employee_list 
            SET Access = '$access', UploadControl = '$uploadControl', ExportControl = '$exportControl'
            WHERE EmployeeID = '$empID' ";
    $conn->query($sql);

    $conn->close();
    header('Location: /WRS/admin.php?nav=employee');
}



if($updateChecker == "updateControlLocationPath")
{
    $pathLocation = $_POST['pathLocation'];
    $pathName = $_POST['pathName'];

    $path_location = str_replace("\\", "/", $pathLocation);  //replaces Forward Slash "\" into Backslash "/"


    $sql = "UPDATE control_locationpath 
            SET LocationPath = '$path_location' 
            WHERE PathName = '$pathName'";

    $conn->query($sql);

    $conn->close();
    // header('Location: /WRS/admin.php?nav=controls');
    echo $pathLocation;
    echo $pathName;
}



if($updateChecker == "updateHardRefreshDone")
{
    $userName = $_POST['username'];
    $privilege = $_POST['privilege'];
    
    if($privilege == 'admin')
    {
        $sql = "UPDATE employee_list 
                SET RefreshStatusAdmin = 'DONE' 
                WHERE UserName = '$userName' ";
    }
    else{
        $sql = "UPDATE employee_list 
                SET RefreshStatus = 'DONE' 
                WHERE UserName = '$userName' ";
    }

    $conn->query($sql);
    echo $userName;
}

?>

