<?php
// session_start();

if(!isset($_COOKIE["newUser"])){
    header("Location: ./welcome");
}else{
    $pcUsername = $_COOKIE["newUser"];
    // header("Location: //");
}

?>