<?php

include "dbconnect.php";


$sql = "SELECT * FROM business_unit";

$result = $conn->query($sql);


$ctr = 0;
$totalRows = $result->num_rows;
if($result->num_rows > 0){
    while($row = $result->fetch_assoc()){
        $ctr++;
        $requestObj = new stdClass();

        $requestObj->TicketNumber = $row['TicketNumber'];
        $requestObj->RequestCode = $row['RequestCode'];
        $requestObj->PriorityRank = $row['PriorityRank'];
        $requestObj->Title = $row['Title'];
        $requestObj->Group = $row['GroupBU'];
        $requestObj->Desc = $row['Description'];
        $requestObj->ProjectType = $row['ProjectType'];
        $requestObj->ProjectCode = $row['ProjectCode'];
        $requestObj->KeyPerson = $row['KeyPerson'];
        $requestObj->ClientRep = $row['ClientRepresentative'];
        $requestObj->Dev = $row['Developer'];
        $requestObj->DateReq = $row['DateRequested'];
        $requestObj->TimeReq = $row['TimeRequested'];
        $requestObj->StartDate = $row['StartDate'];
        $requestObj->FinishDate = $row['FinishDate'];
        $requestObj->Remarks = $row['Remarks'];
        $requestObj->Progress = $row['Progress'];
        $requestObj->Status = $row['Status'];
        $requestObj->FinishPath = $row['FinishPath'];

        $requestJSON = json_encode($requestObj);

        if($ctr == $totalRows){
            echo $requestJSON;
        }else
        {
            echo $requestJSON.",";
        }
    }
}

?>