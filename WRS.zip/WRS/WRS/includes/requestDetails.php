<?php 

include "dbconnect.php";

$reqCode = $_POST['reqCode'];
// $user = $_POST['user'];

$sql = "SELECT * FROM request_list WHERE RequestCode = '$reqCode'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

// I added ~ (tilde) to make it unique and avoid errors. - Alvin Aganan (May 23, 2022)

echo
"RequestCode~".         $row['RequestCode']."RequestCode~".
"Title~".               $row['Title']."Title~".
"Group~".               $row['GroupBU']."Group~".
"Description~".         $row['Description']."Description~".
"InitialPath~".         $row['InitialPath']."InitialPath~".
"KP~".                  $row['KeyPerson']."KP~".
"ClientRepresentative~".$row['ClientRepresentative']."ClientRepresentative~".
"Developer~".           $row['Developer']."Developer~".
"DateRequested~".       $row['DateRequested']."DateRequested~".
"Status~".              $row['Status']."Status~".
"Remarks~".             $row['Remarks']."Remarks~".
"StartDate~".           $row['StartDate']."StartDate~".
"FinishDate~".          $row['FinishDate']."FinishDate~".
"Progress~".            $row['Progress']."Progress~".
"KeyPersonEmail~".      $row['KeyPersonEmail']."KeyPersonEmail~".
"ClientRepEmail~".      $row['ClientRepEmail']."ClientRepEmail~".
"UploadedFiles~".       $row['UploadedFiles']."UploadedFiles~".
"PriorityRank~".        $row['PriorityRank']."PriorityRank~".
"TicketNumber~".        $row['TicketNumber']."TicketNumber~".
"ProjectType~".         $row['ProjectType']."ProjectType~".
"ProjectCode~".         $row['ProjectCode']."ProjectCode~".
"FinishPath~".          $row['FinishPath']."FinishPath~";
?>