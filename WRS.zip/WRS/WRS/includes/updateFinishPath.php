<?php
// --- VARIABLES ---
// $destination  - from moveFiles.php
// $mf_reqCode   - from moveFiles.php


include "dbconnect.php";

$sql = "UPDATE request_list 
SET FinishPath = '$destination' 
WHERE RequestCode = '$mf_reqCode'";

$conn->query($sql);


?>