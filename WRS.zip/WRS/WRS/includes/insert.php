<?php 
date_default_timezone_set("Asia/Manila");

$servername = "localhost";
$username = "root";
$password = "";

try {
  $pdo = new PDO("mysql:host=localhost;dbname=webrequestdb", $username, $password);
  //echo "Connected successfully";
} catch(PDOException $e) {
  //echo "Connection failed: " . $e->getMessage();
}

$sql2 = "INSERT INTO request_list(RequestCode, GroupBU, Title, Description, UploadedFiles, InitialPath, KeyPerson, KeyPersonEmail, ClientRepresentative, ClientRepEmail, DateRequested, TimeRequested)  
          VALUES (:requestcode, :inputGroup, :inputTitle, :inputDesc, :inputFiles, :inputReq, :inputKeyPerson, :inputKeyPersonEmail, :inputClientReps, :inputClientRepEmail, NOW(), NOW())";

// $sqlCode = "SELECT BUCode FROM business_units WHERE BUCode = :inputGroup ";

// $sqlBilang = "SELECT COUNT(GroupBU) FROM request_list WHERE GroupBU = :inputGroup AND DateRequested = :request_date" ;

// $stmt3 = $pdo->prepare($sqlBilang);
// $stmt3->bindParam(":request_date", $request_date);
// $stmt3->bindParam(":inputGroup", $group);
// $stmt2 = $pdo->prepare($sqlCode);
// $stmt2->bindParam(":inputGroup", $group);

$stmt = $pdo->prepare($sql2);
$stmt->bindParam(":inputKeyPerson", $keyPerson);
$stmt->bindParam(":inputKeyPersonEmail", $keyPersonEmail);
$stmt->bindParam(":inputGroup", $group);
$stmt->bindParam(":inputTitle", $title);
$stmt->bindParam(":inputDesc", $desc);
$stmt->bindParam(":inputFiles", $newFileNames);
$stmt->bindParam(":inputReq", $reqPath);
$stmt->bindParam(":inputClientReps", $clientReps);
$stmt->bindParam(":inputClientRepEmail", $clientRepEmail);
$stmt->bindParam(":requestcode", $requestcode);
$request_date = date("Ymd");
$empID = $_POST['inputEmployeeID'];
$keyPerson = $_POST['inputKeyPerson'];
$keyPersonEmail = $_POST['inputKeyPersonEmail'];
$group = $_POST['inputGroup'];
$title = $_POST['inputTitle'];
$desc = $_POST['inputDesc'];
// $req = $_POST['inputReq'];
// $req = $_FILES['inputReq']['name'];
$clientReps = $_POST['inputClientReps'];

// $clientRepEmail = $_POST['inputClientRepEmail'];
// Check if inputClientRepEmail is UNDEFINED
if(!isset($_POST['inputClientRepEmail'])){
  $clientRepEmail = "None";
}else if($_POST['inputClientRepEmail'] == "None"){
  $clientRepEmail = "None";
}else{
  $clientRepEmail = $_POST['inputClientRepEmail'];
}
$clientRepEmails = $_POST['inputClientRepEmails'];
$emailCC = $_POST['inputEmailCC'];

$clientRepEmail .= ";".$clientRepEmails;

// $stmt2->execute();
// $result2 = $stmt2->fetchColumn();

// $stmt3->execute();
// $result3 = $stmt3->fetchColumn();
// $result4 = $result3 + 1;

$datengayon = date("Ymd");
$currentYear = date("Y");
$dateFormat = date("Ymd_His")."_E".$empID;
$timeFormat = date("His");

// $invID=str_pad($result4, 2, '0', STR_PAD_LEFT);

//$requestcode=$result2."_".$datengayon."_".$invID; //Lumang Request Code created by Joshua SYS_20210131_01
$requestcode = $datengayon."_".$timeFormat."_E".$empID; 


// VARIABLE: $G_InitialPath - from "getControl-LocationPath.php"

include "getControl-LocationPath.php";

$path = "//157.116.72.26/WebRequest/WRS/Database";

if(!isset($G_InitialPath)){
    $path = "//157.116.72.26/WebRequest/WRS/Database";
}else{
    $path = $G_InitialPath;
}


$reqPath = "$path/$currentYear/$dateFormat"; // Change this tuwing ililipat ang of Code sa ibang Computer
$reqPath = str_replace("/", "\\", $reqPath);  //replaces Backslash "/" into Forward Slash "\"


// echo "Result + 1: ".$result4;
// echo $requestcode;
include "uploadFile.php"; //DO NOT REMOVE THIS LINE ON THIS POSITION!!!

$newFileNames = str_replace("<br>", ",", $strFileNameSizes); //Removes <br> in String

$result = $stmt->execute(); //DO NOT REMOVE THIS LINE ON ITS POSITION!!!
$last_id = $pdo->lastInsertId(); //Gets the Unique Primary ID of the Newly Inserted Row to use in Ticket Number


// TICKET Function
// ----------------------Digits, String to Add to the Left
$addZeros = str_pad($last_id, 3, 0, STR_PAD_LEFT);  //$last_id = 25. Result: 025
$trimCurrentYear = substr($currentYear, -2);  //2021 -> 21
$ticket = "WRN-$trimCurrentYear-".$addZeros;
echo "<br>$ticket<br>";
$sqlTicket = "UPDATE request_list SET TicketNumber = '$ticket' WHERE ID = $last_id";
$stmtTicket = $pdo->prepare($sqlTicket); //Prepares Statement
$stmtTicket->execute(); //Executes Query
// ---------------


// GET GROUP NAME Function
// -----------------------
$stmtGroupName = $pdo->query("SELECT BUName FROM business_units WHERE BUCode = '$group'");
$rowsBUName = $stmtGroupName->fetchAll();

$groupName = "";

if(count($rowsBUName) !== 0){
  foreach($rowsBUName as $rowsGroupName){
    $groupName = "of ".$rowsGroupName['BUName'];
  }
}else{
  $groupName = "($group)";
}
// ---------------


$datengayon = date("l, F j, Y - h:i:s A");


//Check Representative if None
if($clientRepEmail == NULL || $clientRepEmail == "None;")
{
  $clientRepEmail = "";
  $clientRepEmails = "";
  $emailTo = $keyPersonEmail."\r\n";
}else{
  $emailTo = $keyPersonEmail.";".$clientRepEmail."\r\n";
}

//EMAIL FUNCTION
// $emailTo = $keyPersonEmail;
// $emailTo = $keyPersonEmail.";".$clientRepEmail."\r\n";


// <hr>
// <h2 style='color: gray;'><i>Please ignore this email. This is a <u>TEST ONLY</u>!</i></h2>
// <hr>
// <br>

$emailSubject = "WRS: New Request - ".$requestcode;
$emailMessage = "
<!DOCTYPE html>
<html>
<head>
<title>From Web Request System</title>
<style>
body, p, th, td{font-family: calibri; font-size: 15px; }
table{margin-left: 20px;}
th{text-align: left; vertical-align: top;}
</style>
</head>
<body>

  <p>Dear All,</p>


  <p><strong>$keyPerson </strong>$groupName submitted a new request. These are the details:</p>
  <table>

    <tr>
      <th style='width: 15%;'>Request Number:</th>
      <td style='width: 20%;'>$ticket</td>
    </tr>    
    <tr>
      <th>Key Person:</th>
      <td>$keyPerson ($group)</td>
    </tr>
    <tr>
      <th>Representative(s):</th>
      <td>$clientReps</td>
    </tr>    
    <tr>
      <th>Project Name:</th>
      <td>$title</td>
    </tr>
    <tr>
      <th>Description:</th>
      <td>$desc</td>
    </tr>
    <tr>
      <th>Uploaded File(s):</th>
      <td>$strFileNames</td>
      <td>$strFileSizes</td>
    </tr>
    <tr>
      <th>File Location:</th>
      <td>$reqPath</td>
    </tr>    
    <tr>
      <th>Request Code:</th>
      <td>$requestcode</td>
    </tr>      
    <tr>
      <th>Date Requested:</th>
      <td>$datengayon</td>
    </tr>

  </table>
  <p>To check active requests, kindly visit our <strong>Web Request System</strong> by clicking this link: http://kdt-ph/WRS/</p>
  <p>Thank you!</p>
  <p>Best regards,<br><a href='http://kdt-ph/WRS/'>Web Request System</a><br>KDT Solutions</p>
  
<hr>
<pre style='font-size: 11px; font-family: calibri;'>
<i> <b>NOTE: This email is auto-generated by <a href='http://kdt-ph/WRS'>Web Request System</a>. Please do not reply. </b></i>


If you have any concerns, you can message our Developer thru Spark or Email.

Spark Name:    alvinjohn
Lotus Email:     aganan-kdt
Outlook Email: aganan-kdt@corp.khi.co.jp
</pre>

</body>
</html>";

// Always set content-type when sending HTML email
$emailHeaders = "MIME-Version: 1.0" . "\r\n"; 
$emailHeaders .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$emailHeaders .= 'From: KDT - Web Request System <kdtdev01-kdt@corp.khi.co.jp>' . "\r\n";
// $emailHeaders .= "Cc: Felix Edwin Petate<petate123-kdt@corp.khi.co.jp>,Joshua Mari Coquia<coquia123-kdt@corp.khi.co.jp>\r\n";
// $emailHeaders .= "Cc: petate-kdt@corp.khi.co.jp;coquia-kdt@corp.khi.co.jp\r\n";
echo "<br>Email CC: ".$emailCC;

$emailHeaders .= "Cc: $emailCC\r\n";
// $emailHeaders .= "Cc: petate-kdt@corp.khi.co.jp;aganan-kdt@corp.khi.co.jp;coquia-kdt@corp.khi.co.jp\r\n";
// $emailHeaders .= "Cc: lazaro-kdt@corp.khi.co.jp;
//                       torio-kdt@corp.khi.co.jp;
//                       dejesus_j-kdt@corp.khi.co.jp;
//                       delacruz-kdt@corp.khi.co.jp;
//                       petate-kdt@corp.khi.co.jp;
//                       aganan-kdt@corp.khi.co.jp;
//                       coquia-kdt@corp.khi.co.jp;
//                       tan-g1@hg.khi.co.jp;
//                       matibag-kdt@corp.khi.co.jp;
//                       balisbis-kdt@corp.khi.co.jp\r\n";            
$emailHeaders .= "Cc: Edmon Lazaro<lazaro-kdt@corp.khi.co.jp>,
                      Jommuel De Jesus<dejesus_j-kdt@corp.khi.co.jp>,
                      EJ Dela Cruz<delacruz-kdt@corp.khi.co.jp>,
                      Felix Edwin Petate<petate-kdt@corp.khi.co.jp>,
                      Alvin John Aganan<aganan-kdt@corp.khi.co.jp>,
                      Joshua Mari Coquia<coquia-kdt@corp.khi.co.jp>,
                      Collene Keith Medrano<medrano_c-kdt@corp.khi.co.jp>,
                      Glenda Ann Gulam<gulam-kdt@corp.khi.co.jp>,
                      Erwin Tan<tan-g1@hg.khi.co.jp>,
                      Wilson Matibag<matibag-kdt@corp.khi.co.jp>,
                      Cezar Balisbis Jr.<balisbis-kdt@corp.khi.co.jp>\r\n";                                  
$emailHeaders .= "Bcc: kdtdev01-kdt@corp.khi.co.jp;aganan-kdt@corp.khi.co.jp\r\n";

mail($emailTo,$emailSubject,$emailMessage,$emailHeaders);

header('Location: /WRS?request='.$ticket);

// header('Location: //157.116.72.192/WRS?request='.$ticket);

if($result){
  echo 'Data Inserted';
}
else{
  echo 'Data not inserted';
}

$pdo=null;
?>