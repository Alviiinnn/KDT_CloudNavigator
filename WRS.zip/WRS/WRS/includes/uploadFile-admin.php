<?php
// This Program is for Admin.php when Uploading File

// --- VARIABLES ---

// $G_InitialPath - from "getControl-LocationPath.php"
// -----------------

include "getControl-LocationPath.php";


if(!isset($G_InitialPath)){
    $path = "//157.116.72.26/WebRequest/WRS/Database";
}


date_default_timezone_set("Asia/Manila");

$currentYear = date("Y");
$dateFormat = date("Y-m-d - His")." - ";
// $dateFormat = strval($dateFormat);   //Converts Interger into String. Remove this if code is working fine.

//Check if Folder and File Name Exists
$pathLocation = $_POST['fileLocation'];
$adminUser = $_POST['dbUsername'];
$requestCode = $_POST['inputCode'];
$folderName = $dateFormat.$adminUser;

$fileLocation = str_replace("/", "\\", $pathLocation);  //replaces Forward Slash "\" into Backslash "/"

if(file_exists("$path/$currentYear") == false){

    mkdir("$path/$currentYear");
    mkdir($fileLocation);

}else{

    if(file_exists($fileLocation) == false){
        mkdir($fileLocation);   // \\157.116.72.26\WebRequest\WRS\Database\2022\20220210_102422_E466
    }
}

mkdir($fileLocation."/".$folderName);


// mkdir("//157.116.72.26/WebRequest/WRS/Database/test/$folderName"); //Goods
// mkdir("//157.116.72.26/WebRequest/WRS/Database/test/$adminUser");  //Goods
// mkdir("//157.116.72.26/WebRequest/WRS/Database/test/$requestCode");



// Configure upload directory and allowed file types
// $upload_dir = "//157.116.72.26/WebRequest/WRS/Database/test".DIRECTORY_SEPARATOR;
$upload_dir = $fileLocation."/".$folderName.DIRECTORY_SEPARATOR;
// $allowed_types = array('jpg', 'png', 'jpeg', 'gif', 'txt', 'doc', 'docx', 'xlsx', 'jfif', 'pdf', 'ppt', 'pptx', 'dwg', 'xml', 'csv', 'mov', 'eml');

// Define maxsize for files i.e 2MB
$maxsize = 1000 * 1024 * 1024;

// Checks if user sent an empty form
if(!empty(array_filter($_FILES['finishFile']['name']))) {

    $arrFileNames = array(); //Array Storage for File Names
    $arrFileSizes = array(); //Array Storage for File Sizes

    // Loop through each file in files[] array
    foreach ($_FILES['finishFile']['tmp_name'] as $key => $value) {
        
        $file_tmpname = $_FILES['finishFile']['tmp_name'][$key];
        $file_name = $_FILES['finishFile']['name'][$key];
        $file_size = $_FILES['finishFile']['size'][$key];
        $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);

        $newFileSize = round($file_size / 1024, 2); // Converts Bytes to Kilobytes
		
        if($newFileSize >= 1000){
            $newFileSize = round($newFileSize / 1024, 2); // Converts Kilobytes to Megabytes
            $newFileSize .= " MB";
        }else{
            $newFileSize .= " KB";
        }

        $arrFileNameSizes[$key] = $file_name."  -  ".$newFileSize; // Stores File Name and File Size per Index
        $arrFileNames[$key] = $file_name; // Stores File Name per Index
        $arrFileSizes[$key] = $newFileSize; // Stores File Size per Index

        // Set upload file path
        $filepath = $upload_dir.$file_name;

        // Check file type is allowed or not
        // if(in_array(strtolower($file_ext), $allowed_types)) {

            // Verify file size - 2MB max
            if ($file_size > $maxsize)		
                echo "Error: File size is larger than the allowed limit.";

            // If file with name already exist then append time in
            // front of name of the file to avoid overwriting of file
            if(file_exists($filepath)) {
                $filepath = $upload_dir.time().$file_name;
                
                if( move_uploaded_file($file_tmpname, $filepath)) {
                    echo "{$file_name} successfully uploaded <br />";
                }
                else {					
                    echo "Error uploading {$file_name} <br />";
                }
            }
            else {
            
                if( move_uploaded_file($file_tmpname, $filepath)) {
                    echo "{$file_name} successfully uploaded <br />";
                }
                else {					
                    echo "Error uploading {$file_name} <br />";
                }
            }
        // }
        // else {
            
        //     // If file extension not valid
        //     echo "Error uploading {$file_name} ";
        //     echo "({$file_ext} file type is not allowed)<br / >";
        // }
    }
    $strFileNames = ""; // String to Store the File Names
    $strFileSizes = ""; // String to Store the File Sizes
    $strFileNameSizes = ""; // String to Store the File Name with Sizes
    foreach($arrFileNames as $eachFileNames){
        $strFileNames .= "$eachFileNames<br>";
    }
    foreach($arrFileSizes as $eachFileSizes){
        $strFileSizes .= "$eachFileSizes<br>";
    }
    foreach($arrFileNameSizes as $eachFileNameSizes){
        $strFileNameSizes .= "$eachFileNameSizes<br>";
    }
    $strFileNameSizes = rtrim($strFileNameSizes, ",");
}
else {
    // If no files selected
    echo "No files selected.";
}


?>
