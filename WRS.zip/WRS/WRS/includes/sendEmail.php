<?php
  // include "test.php"; // UNCOMMENT THIS IF YOU ARE TESTING THIS CODE
  include "emailFooter.php";

$emailType = $_POST['emailType'];

if($emailType == "OtherRequests"){
  $emailTo = "aganan-kdt@corp.khi.co.jp;";
  $emailCC = $_POST['emailCC'];
  $emailSubject = "WRS: ".$_POST['emailSubject'];
  $emailContent = $_POST['emailContent'];

  $emailMessage = "
  <!DOCTYPE html><html>
  <head><title>From Web Request System</title>
  <style>
  pre{font-family: Calibri; font-size: 15px;}
  th{text-align: left;}
  </style>
  </head>
  <body>
    <pre>$emailContent</pre>
  <br>
  $emailFooterContent
  </body>
  </html>";

  // Always set content-type when sending HTML email
  $emailHeaders = "MIME-Version: 1.0" . "\r\n";
  $emailHeaders .= "Content-type:text/html;charset=UTF-8" . "\r\n";

  // More headers
  $emailHeaders .= 'From: <kdtdev01-kdt@corp.khi.co.jp>' . "\r\n";
  $emailHeaders .= 'Cc: '.$emailCC."\r\n";
  $emailHeaders .= 'Bcc: kdtdev01-kdt@corp.khi.co.jp;aganan-kdt@corp.khi.co.jp';

  mail($emailTo,$emailSubject,$emailMessage,$emailHeaders);

  header("Location: /WRS?email=success");
}

//---------------------------------------

if($emailType == "UploadAdditional"){
  include "dbconnect.php";

  $reqNumber = $_POST['emailRequestNumber'];
  $reqCode = $_POST['emailRequestCode'];
  $userName = $_POST['emailUserName'];
  $kPersonEmail = $_POST['emailKPersonEmail'];
  $cRepEmail = $_POST['emailCRepEmail'];
  $devEmail = $_POST['emailDevs'];
  echo "<br>Dev Emails: ".$devEmail;
  $devEmail = explode(",", $devEmail);
  $devQuery = "";

  for($ctr=0; $ctr<count($devEmail); $ctr++){
    if(count($devEmail)==1){
      $devQuery .= "UserName = '".str_replace(" ", "", $devEmail[$ctr])."'";
    }else{
      if($ctr == count($devEmail)-1 ){
        $devQuery .= "UserName = '".str_replace(" ", "", $devEmail[$ctr])."'";
      }else{
        $devQuery .= "UserName = '".str_replace(" ", "", $devEmail[$ctr])."' OR ";
      }
    }
  }
  echo "<br>Query: $devQuery";

  echo "<br>Count: ".count($devEmail);

  $sql = "SELECT Email FROM employee_list WHERE $devQuery ";
  $result = $conn->query($sql);

  $concatEmails = "";
  $ctr = 0;
  if($result->num_rows > 0){
    while($row = $result->fetch_assoc()){
      echo "<br>Row = ".$row['Email'];
      $ctr++;

      if($result->num_rows == $ctr){
        $concatEmails .= $row['Email'];
      }else{
        $concatEmails .= $row['Email'].";";
      }
    }
  }
  echo "<br>Concat emails: $concatEmails";

  if($concatEmails != ""){
    $emailTo = $concatEmails;
  }else{
    $emailTo = "Edmon Lazaro<lazaro-kdt@corp.khi.co.jp>,
                Jommuel De Jesus<dejesus_j-kdt@corp.khi.co.jp>,
                EJ Dela Cruz<delacruz-kdt@corp.khi.co.jp>,
                Felix Edwin Petate<petate-kdt@corp.khi.co.jp>,
                Joshua Mari Coquia<coquia-kdt@corp.khi.co.jp>,
                Alvin John Aganan<aganan-kdt@corp.khi.co.jp>,
                Collene Keith Medrano<medrano_c-kdt@corp.khi.co.jp>,
                Glenda Ann Gulam<gulam-kdt@corp.khi.co.jp>";
  }
  
  // $emailTo = "petate-kdt@corp.khi.co.jp; aganan-kdt@corp.khi.co.jp; coquia-kdt@corp.khi.co.jp";
  // $emailCC = $_POST['emailCC'];
  $emailCC = "$kPersonEmail; $cRepEmail";
  $emailSubject = "WRS: Upload Additional Files - $reqNumber";

  $emailMessage = "
  <!DOCTYPE html><html>
  <head><title>From Web Request System</title>
  <style>
  pre, td, p{font-family: Calibri; font-size: 15px;}
  th{text-align: left;}
  table{
    margin-left: 5px;
  }
  </style>
  </head>
  <body>

<pre>Hi System Group,

I uploaded additional files for our <b>request</b> with file name(s):
</pre>

<table>
<tr>
  <td><strong>$strFileNames </strong></td>
  <td> $strFileSizes</td>
</tr>
</table>

<p><strong>File Location: </strong> $uploaded_fileLocation</p>

<pre>
Thank you!

Regards,
<b>$userName</b>
</pre>
<br>
$emailFooterContent

  </body>
  </html>";

  // Always set content-type when sending HTML email
  $emailHeaders = "MIME-Version: 1.0" . "\r\n";
  $emailHeaders .= "Content-type:text/html;charset=UTF-8" . "\r\n";

  // More headers
  $emailHeaders .= 'From: KDT - Web Request System <kdtdev01-kdt@corp.khi.co.jp>' . "\r\n";
  $emailHeaders .= 'Cc: '.$emailCC."\r\n";
  $emailHeaders .= 'Bcc: kdtdev01-kdt@corp.khi.co.jp;aganan-kdt@corp.khi.co.jp';

  mail($emailTo,$emailSubject,$emailMessage,$emailHeaders);

  header("Location: /WRS?upload=success&id=$reqCode#$reqCode");
}

//---------------------------------------

if($emailType == "StatusChanged"){

  include "getDev.php";
  
  $ticketNumber = $_POST['emailTicket'];
  $reqCode = $_POST['emailRequestCode'];
  $projectName = $_POST['emailTitle'];
  $description = $_POST['emailDesc'];
  $keyPerson = $_POST['emailKeyPerson'];
  $clientRep = $_POST['emailClientRep'];
  $kPersonEmail = $_POST['emailKPersonEmail'];  //DO NOT CHANGE this VARIABLE NAME - Connected to "getGender.php" 
  $cRepEmail = $_POST['emailCRepEmail'];
  $devs = $_POST['emailDevs'];    //Dev Usernames
  $status = $_POST['emailStatus'];
  $remarks = $_POST['emailRemarks'];
  $admin = $_POST['emailAdmin'];
  $reason = "";
  $mainContent = "";

  require "getGender.php";
  // VARIABLE: $gender - from "getGender.php"

  $salutation = "";
  
  if($gender == "Male"){
    $salutation = "Mr. $keyPerson";

  }else if($gender == "Female"){
    $salutation = "Ms. $keyPerson";
  
  }else{
    $salutation = $keyPerson."-san";
  }
  
  
  // VARIABLES devUserNames, $devEmails, $devFullNames - From getDev.php
  if($devs == "-"){

    for($ctr = 0; $ctr<count($devEmails); $ctr++){
      // INCLUDE IN EMAIL CC - ALL DEVS
      $printEmails .= ucwords(strtolower($devFullNames[$ctr])); // CAPITAL kasi ung output kaya may STRTOLOWER tsaka UCWORDS
      $printEmails .= "<".$devEmails[$ctr].">,";
    }  
    $allDevs = $printEmails;  // For Finished Status
  
  }else if($devs == ""){
    $devs = "-";
    
  }else{
    $arrDevNames = array();

    $devEmails_count  = count($devEmails);  //Dev Email ang ni-count ko kase para sure na masendan ng Email - Alvin (April 19, 2022)

    for($ctr = 0; $ctr<$devEmails_count; $ctr++){
      
      //Ni-comment dahil di Compatible sa PHP 7 below - if( str_contains($devs, $devUserNames[$ctr]) ){ // str_contains(haystack, needle) -- str_contains(PHP 8), Workaround - strpos() | UPDATE: strpos() has a Bug that it omits 1 item on array list. Stop using strpos(), use str_contains() instead. 

      //--- This IF Statement Checks if Input Devs exists on Developer List in Database
      
      //---------NOTE! DO NOT REMOVE WHITESPACE because it is the Workaround that it doesn't include the First Character on FIND Parameter
      if( strpos(" ".$devs, $devUserNames[$ctr]) ){   //strpos(string, find, start) - Start: Default 0, if Negative, starts at the end. 
        
        // INCLUDE IN EMAIL CC - ASSIGN DEVS ONLY
        $assignDevs = ucwords(strtolower($devFullNames[$ctr])); // CAPITAL kasi ung output kaya may STRTOLOWER tsaka UCWORDS
        $printEmails .= $assignDevs; 
        $printEmails .= "<".$devEmails[$ctr].">,";
        array_push($arrDevNames, $assignDevs);
      }
    
    }

    $arrDevNames_count = count($arrDevNames);
    $devs = "";  //This will reset Dev's Username para yung Full Name yung ma-save dito.
    $ctr = 1;

    foreach($arrDevNames as $eachDevName){

      if($ctr < $arrDevNames_count){
        $devs .= $eachDevName . ", ";
      }else{
        $devs .= $eachDevName;
      }
      $ctr++;
    }

  }   // END of If Else Statement

  $emailCC = $printEmails;

  $cRepEmail = ($cRepEmail == "None;" || $cRepEmail == "None")? "" : $cRepEmail;

  $wrsLinks = "To check active requests, kindly visit our <a href='http://kdt-ph/WRS'><b>Web Request System</b></a> by clicking this link: http://kdt-ph/WRS/";

  if($status == 'ongoing')
  {
    $mainContent = "Good day!<br><br>Please be advised that the status of your <b>request</b> is now <strong><u>ONGOING</u></strong>. Kindly check the details below:";

    $status = "<td style='background-color: yellow;'><b>ONGOING</b></td>";
  }
  else if($status == 'finished')
  {
    $mainContent = "Good News!<br><br>System Group had already finished working your <b>request</b>. Kindly check the details below:";
  
    $emailCC .= "Edmon Lazaro<lazaro-kdt@corp.khi.co.jp>,
                Jommuel De Jesus<dejesus_j-kdt@corp.khi.co.jp>,
                EJ Dela Cruz<delacruz-kdt@corp.khi.co.jp>,
                Felix Edwin Petate<petate-kdt@corp.khi.co.jp>,
                Alvin John Aganan<aganan-kdt@corp.khi.co.jp>,
                Joshua Mari Coquia<coquia-kdt@corp.khi.co.jp>,
                Collene Keith Medrano<medrano_c-kdt@corp.khi.co.jp>,
                Glenda Ann Gulam<gulam-kdt@corp.khi.co.jp>,                
                Erwin Tan<tan-g1@hg.khi.co.jp>, 
                Wilson Matibag<matibag-kdt@corp.khi.co.jp>, 
                Cezar Balisbis Jr.<balisbis-kdt@corp.khi.co.jp>";    

    // $emailCC .= "Edmon Lazaro1<lazaroTEST-kdt@corp.khi.co.jp>,
    //             Raffy Torio1<torioTEST-kdt@corp.khi.co.jp>,
    //             Jommuel De Jesus1<dejesusTEST_j-kdt@corp.khi.co.jp>,
    //             EJ Dela Cruz1<delacruzTEST-kdt@corp.khi.co.jp>,
    //             Felix Edwin Petate1<petateTEST-kdt@corp.khi.co.jp>,
    //             Alvin John Aganan1<aganan-kdt@corp.khi.co.jp>,
    //             Joshua Mari Coquia1<coquiaTEST-kdt@corp.khi.co.jp>,
    //             Erwin Tan1<tanTEST-g1@hg.khi.co.jp>, 
    //             Wilson Matibag1<matibagTEST-kdt@corp.khi.co.jp>, 
    //             Cezar Balisbis Jr.1<balisbisTEST-kdt@corp.khi.co.jp>";      
    
    $status = "<td style='background-color: green; color: white;'>FINISHED</td>";
    $wrsLinks = "Completed requests were moved automatically to <a href='http://kdt-ph/WRS?nav=directory'><b>Project Directory</b></a>. Click this link to visit it: http://kdt-ph/WRS?nav=directory";
  }
  else if($status == 'onhold')
  {
    $mainContent = "Good day.<br><br>Please be advised that the status of your <b>request</b> is <strong><u>ON HOLD</u></strong>. Please read the reason(s) and details below:";
    $reason = "<br>- <i>".$remarks."</i>";
    $reason = "<tr> 
                <th>Reason:</th>
                <td></td>
              </tr>";
    
    $status = "<td style='background-color: gray; color: white;'>ON HOLD</td>";
  }
  else if($status == 'cancelled' || $status == 'denied')
  {
    $status = strtoupper($status);
    $mainContent = "We regret to inform you that your <b>request</b> is <strong><u>$status</u></strong>. Please read the reason and details below:";    
    $status = strtoupper($status);
    $status = "<td style='background-color: red; color: white;'>$status</td>";
    $reason = "<tr>
                <th>Reason:</th>
                <td style='color: darkred;'><i>$remarks</i></td>
              </tr>";
  }
  else{
    $status = strtoupper($status);
    $mainContent = "Good day.<br><br>Please be advised that the status of your <b>request</b> is <strong><u>$status</u></strong>. Kindly check the details below:";
  }


  $emailTo = "$kPersonEmail; $cRepEmail";

  $emailSubject = "WRS: Status Update - $ticketNumber";

  $emailMessage = "
  <!DOCTYPE html><html>
  <head><title>From Web Request System</title>
  <style>
  body, pre, td{font-family: Calibri; font-size: 15px;}
  table{margin-left: 20px;}
  th{text-align: left; vertical-align:top; padding-right: 10px;}
  </style>
  </head>
  <body>

<p>Dear $salutation,</p>
<p><br>$mainContent</p>

<table>
  <tr>
    <th style='width: 20%;'>Request Number:</th>
    <td>$ticketNumber</td>
  </tr>
  <tr>
    <th>Project Name:</th>
    <td>$projectName</td>
  </tr>
  <tr>
    <th>Description:</th>
    <td>$description</td>
  </tr>
  <tr>
    <th>Key Person:</th>
    <td>$keyPerson</td>
  </tr>
  <tr>
    <th>Representative(s):</th>
    <td>$clientRep</td>
  </tr>
  <tr>
    <th>Developer(s):</th>
    <td>$devs</td>
  </tr> 
  <tr>
    <th>Request Code:</th>
    <td>$reqCode</td>
  </tr>
  <tr>
    <th>Status:</th>
    $status
  </tr>  
  $reason  
</table>
<pre>

$wrsLinks

Thank you!
</pre><br>

<p>Best regards,<br><b>KDT System Group</b></p>

$emailFooterContent
<p style='color: #DCDCDC; font-size: 10px; text-align: right;'><b>Email Sender:</b> $admin</p>
  </body>
  </html>";

  // Always set content-type when sending HTML email
  $emailHeaders = "MIME-Version: 1.0" . "\r\n";
  $emailHeaders .= "Content-type:text/html;charset=UTF-8" . "\r\n";

  // More headers
  $emailHeaders .= 'From: KDT - Web Request System <kdtdev01-kdt@corp.khi.co.jp>' . "\r\n";
  $emailHeaders .= 'Cc: '.$emailCC."\r\n";
  $emailHeaders .= 'Bcc: kdtdev01-kdt@corp.khi.co.jp;aganan-kdt@corp.khi.co.jp';

  mail($emailTo,$emailSubject,$emailMessage,$emailHeaders);

  header("Location: /WRS?upload=success"); 
}

?>
