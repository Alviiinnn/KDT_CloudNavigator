<?php
// --- VARIABLES ---
// $dir_projectType - from moveFiles.php


echo "<br><hr>";

// $dir = "//157.116.72.26/WebRequest/WRS/Database/2022";   //For Testing, do not delete.

if(isset($_POST['projectType_path'])){
    $dir_projectType = $_POST['projectType_path'];
}

$dir = $dir_projectType;
echo "<h3>Read Folders inside Directory</h3>";
echo "<p><b>Directory:</b> $dir</p>";
$ctr = 0;
$folders = array();

if (is_dir($dir)) {
    if ($dh = opendir($dir)) {
        while (($file = readdir($dh)) !== false) {

            if($file == "." || $file == ".."){
                continue;   //Skips the Dot and Double Dot File
            }else{
                $ctr++;
                echo "<b>Folder $ctr - </b> ".$file."<br />";
                array_push($folders, $file);
            }
        }
        closedir($dh);
        echo "<br>Total Folders = $ctr";
    }
    else{
        echo "<br>WARNING: Cannot Open Directory";
    }
}else{
    echo "<br>WARNING: <b>$dir</b> is not a Directory. Or maybe it doesn't Exists.";
}

$var_totalFiles = str_pad($ctr+1, 4, 0, STR_PAD_LEFT);    //$ctr = 25. Result: 0025
echo "<br>getTotFiles".$var_totalFiles."getTotFiles";

$folders = json_encode($folders);
echo "<br>getFolderNames".$folders."getFolderNames";


?>