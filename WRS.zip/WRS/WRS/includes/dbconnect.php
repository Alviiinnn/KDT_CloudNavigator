<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "webrequestdb";

require "readTextFile.php"; //galing dito ung $pcUsername

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM employee_list WHERE UserName = '$pcUsername' ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

  // output data of each row
  while($row = $result->fetch_assoc()) {

    $keyPersonEmail = $row['Email'];
    $rawFullName = $row["FullName"];
    $underscorePos = strpos($rawFullName, "_");
    $rawFirstName = substr($rawFullName, $underscorePos);
    $userFirstName = substr($rawFullName, $underscorePos+1);
    $userLastName = substr($rawFullName,0,$underscorePos);
    $userFullName = $userFirstName." ".$userLastName;
    $userFullName = ucwords(strtolower($userFullName));
    $fullName = $userFullName;
    $gender = $row['Gender'];
    $employeeID = $row['EmployeeID'];
    $userAccess = $row['Access'];
    $userBU = $row["BusinessUnit"];
    $uploadControl = $row["UploadControl"];
    $exportControl = $row["ExportControl"];
    $dbUsername = $row['UserName'];
    $refreshStatus = $row['RefreshStatus'];
    $refreshStatusAdmin = $row['RefreshStatusAdmin'];

    $firstName = ucwords(strtolower($userFirstName));
  }
} else {
  $lala = $_COOKIE["newUser"];
  header("Location: /welcome?usernotfound".$lala);
}

$sql2 = "SELECT BUName FROM business_units WHERE BUCode = '$userBU' ";
$result2 = $conn->query($sql2);

if($result2->num_rows > 0){
  while($row2 = $result2->fetch_assoc()){
    $BUName = $row2['BUName'];
    $manyBU = false; //this returns 0
  }
}else{
  $manyBU = true; //this returns 1
  $BUs = explode("/",$userBU);
}

// $conn->close(); //closes database connection

// -- OUTPUT --
//$userFullName 
//$userBU 
//$pcUsername
//$BUName

?>