<?php
include "dbconnect.php";

$sql = "SELECT * FROM control_locationPath";
$result = $conn->query($sql);

$path = array();

$ctr = 0;
$totalRows = $result->num_rows;

if($result->num_rows > 0){

    while($row = $result->fetch_assoc()){
        $ctr++;
        $pathObj = new stdClass();  

        $pathObj->PathName = $row['PathName'];
        $pathObj->LocationPath = $row['LocationPath'];
        
        $pathJSON = json_encode($pathObj);

        if($ctr == $totalRows){
            echo $pathJSON;
        }else
        {
            echo $pathJSON.",";
        }

        // This is to Store Values to Variables

        if($row['PathName'] == "Initial Path"){
            $G_InitialPath = $row['LocationPath'];
        }

        if($row['PathName'] == "Finish System Path"){
            $G_FinishSystemPath = $row['LocationPath'];
        }
    }
}

// COMMENT THIS BECAUSE IT CAUSES AN ERROR TO ADMIN.PHP 
// echo "<br><br><b>Finish System Path</b> = $g_FinishSystemPath";
// echo "<br><br><b>Initial Path</b> = $G_InitialPath";


?>