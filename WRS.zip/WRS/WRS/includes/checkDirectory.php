<?php

$path = $_POST['pathLocation'];

if(file_exists($path)){
    echo "true";
}else{
    echo "false";
}
?>