<?php

// VARIABLE: kPersonEmail - from "sendEmail.php"

include "dbconnect.php";

if(isset($kPersonEmail)){
    
    $sql = "SELECT Gender FROM employee_list WHERE Email = '$kPersonEmail' ";

    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    $gender = $row['Gender'];

}

?>