<?php
// --- VARIABLES ---
// $G_InitialPath - from "getControl-LocationPath.php"

date_default_timezone_set("Asia/Manila");


include "getControl-LocationPath.php";

if(!isset($G_InitialPath)){
    $path = "//157.116.72.26/WebRequest/WRS/Database";
}else{
    $path = $G_InitialPath;
}


// $reqCode_year = date("Y");
$reqCode_year = "2021";
$empID = $_POST['inputEmployeeID'];
$dateFormat = date("Ymd_His")."_E".$empID;

$reqCode = $_POST['emailRequestCode'];
$reqCode_year = substr($reqCode, 0, 4);
echo "<br>".$reqCode;
echo "<br>Path: ".$path."<br>";
var_dump($path);

//Check if Folder and File Name Exists
if(file_exists("$path/$reqCode_year/$reqCode") == false){
    mkdir("$path/$reqCode_year/$reqCode");
    mkdir("$path/$reqCode_year/$reqCode/$dateFormat");
}else{
    mkdir("$path/$reqCode_year/$reqCode/$dateFormat");
}

// Configure upload directory and allowed file types
$upload_dir = "$path/$reqCode_year/$reqCode/$dateFormat".DIRECTORY_SEPARATOR;   //This program will save the Uploaded Files to ONE UP LEVEL FOLDER if DIRECTORY_SEPARATOR is removed.
$uploaded_fileLocation = "\\\\157.116.72.26\WebRequest\WRS\Database\\$reqCode_year\\$reqCode\\$dateFormat";

echo "Upload Dir: $upload_dir";
$allowed_types = array('jpg', 'png', 'jpeg', 'gif', 'txt', 'doc', 'docx', 'xlsx', 'jfif', 'pdf', 'ppt', 'pptx', 'dwg', 'xml', 'csv', 'wmv', 'mov');

// Define maxsize for files i.e 2MB
$maxsize = 1000 * 1024 * 1024;

// Checks if user sent an empty form
if(!empty(array_filter($_FILES['uploadAdditional']['name']))) {

    $arrFileNames = array(); //Array Storage for File Names
    $arrFileSizes = array(); //Array Storage for File Sizes

    // Loop through each file in files[] array
    foreach ($_FILES['uploadAdditional']['tmp_name'] as $key => $value) {
        
        $file_tmpname = $_FILES['uploadAdditional']['tmp_name'][$key];
        $file_name = $_FILES['uploadAdditional']['name'][$key];
        $file_size = $_FILES['uploadAdditional']['size'][$key];
        $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);

        $newFileSize = round($file_size / 1024, 2); // Converts Bytes to Kilobytes
		
        if($newFileSize >= 1000){
            $newFileSize = round($newFileSize / 1024, 2); // Converts Kilobytes to Megabytes
            $newFileSize .= " MB";
        }else{
            $newFileSize .= " KB";
        }        

        //$arrFileNames[$key] = $file_name."  -  ".$newFileSize; // Stores File Name and File Size per Index
        $arrFileNameSizes[$key] = $file_name."  -  ".$newFileSize; // Stores File Name and File Size per Index        
        $arrFileNames[$key] = $file_name; // Stores File Name per Index
        $arrFileSizes[$key] = $newFileSize; // Stores File Size per Index

        // Set upload file path
        $filepath = $upload_dir.$file_name;

        // Check file type is allowed or not
        // if(in_array(strtolower($file_ext), $allowed_types)) {

            // Verify file size - 2MB max
            if ($file_size > $maxsize)		
                echo "Error: File size is larger than the allowed limit.";

            // If file with name already exist then append time in
            // front of name of the file to avoid overwriting of file
            if(file_exists($filepath)) {
                $filepath = $upload_dir.time().$file_name;
                
                if( move_uploaded_file($file_tmpname, $filepath)) {
                    echo "{$file_name} successfully uploaded <br />";
                }
                else {					
                    echo "Error uploading {$file_name} <br />";
                }
            }
            else {
            
                if( move_uploaded_file($file_tmpname, $filepath)) {
                    echo "{$file_name} successfully uploaded <br />";
                }
                else {					
                    echo "Error uploading {$file_name} <br />";
                }
            }
        // }
        // else {
            
        //     // If file extension not valid
        //     echo "Error uploading {$file_name} ";
        //     echo "({$file_ext} file type is not allowed)<br / >";
        // }
    }
    $strFileNames = ""; // String to Store the File Names
    $strFileSizes = ""; // String to Store the File Sizes
    $strFileNameSizes = ""; // String to Store the File Name with Sizes

    foreach($arrFileNames as $eachFileNames){
        $strFileNames .= "$eachFileNames<br>";
    }
    foreach($arrFileSizes as $eachFileSizes){
        $strFileSizes .= "- $eachFileSizes<br>";
    }
    foreach($arrFileNameSizes as $eachFileNameSizes){
        $strFileNameSizes .= "$eachFileNameSizes,";
    }    
    $strFileNameSizes = rtrim($strFileNameSizes, ",");

    require "dbconnect.php";
    $sql = "UPDATE request_list
            SET UploadedFiles = '$strFileNameSizes'
            WHERE RequestCode = '$reqCode' ";
    $conn->query($sql);
    $conn->close();
}
else {
    // If no files selected
    echo "No files selected.";
}

// header("Location: /WRS?upload=success");
require "sendEmail.php"; //Ibalik mo to ngayon April 25, 2022

?>