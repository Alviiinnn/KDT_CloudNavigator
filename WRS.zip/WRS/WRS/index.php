<?php 
  include "includes/dbconnect.php";
  
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Web Request System</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="icon" type="image/x-icon" href="logo.jfif">
<link rel="stylesheet" href="css/w3.css">

<link rel="stylesheet" href="css/font-awesome.css">
<link rel="stylesheet" href="css/font-montserrat.css">

<link rel="stylesheet" href="css/material-icons.css">
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="css/universal.css">

<link rel="stylesheet" href="css/w3-colors-win8.css">
<link rel="stylesheet" href="css/w3-colors-2021.css">

<script src="libraries/jquery-uncompressed (Development).js"></script>
<script src="libraries/export_plugin.js"></script>


<style>
*{
  scroll-behavior: smooth;
}
/* body{
  overflow: auto; This affects the Sticky Header CSS
}  */

input:disabled:hover, select:disabled:hover{
  cursor: not-allowed;
}
select:disabled {--webkit-appearance: none;}

/* input,select{
  border: none;
} */
/* label[name='inputReq']{ //for Attach File Label
  color: gray;
  font-weight: normal;
  border: 2px dashed lightgray;
  border-radius: 10px;
  text-align: center;
} */
.c-modal-details{
  width: 770px;
}

.c-modal-refresh{
  width: 440px;
}

.c-modal-warning{
  width: 430px;
}

a{
  text-decoration: none;
  display: none;
}

td{
  vertical-align: middle!important;
}
div.notif {
  color: darkslategray;
  background-color: lightyellow;
  position: fixed;
  box-shadow: 3px 3px 6px 0px #000000;
  top: -100px;
  left: 40px;
  font-weight: bold;
  width: 20em;
  z-index: 4;
  text-align: center;
  border-radius: 5px;
  animation-name: notif;
  animation-duration: 5s;
  animation-delay: 0.5s;
  animation-timing-function: ease;
  animation-direction: alternate;
}

@keyframes notif {
  0%   {left: 40px;}
  10%  {top: 75px;}
  25%  {top: 75px;}
  50%  {left: 40px;}
  75%  {top: 75px;}
  80% {left: -500px;}
  100% {left: -500px;}
}

.hide{
  display: none;
}


textarea{
  resize: vertical;
  color: dimgray;
  padding: 20px!important;
  border: 1px solid darkgray; 
}
#modalSendEmail input{
  border: 1px solid darkgray;
  color: dimgray;
}
#modalSendEmail input:focus{
  outline: 1px solid darkslategray;
  border: 1px solid transparent;
  color: black;
  background-color: floralwhite;
}
textarea:focus{
  outline: 1px solid darkslategray;
  border: 1px solid transparent;
  color: black;
  background-color: floralwhite;
}
/* .concerns{
  margin: -10px 0px -35px 0px;
} */
.concerns button{
  width: 50%!important;
}
#modalSendEmail input{
  padding: 5px 10px!important;
}
.gitna{
  text-align: center!important;
}


.c-modal-left-event:hover{
  box-shadow: none;
  color: black!important;
}
p[name=projectDirectory]:hover{
  cursor: pointer;
}
span[name=clearFilter]{
  padding: 6px 6px 6px 9px;
  /* margin-right: -100px; */
}
 
/* .clearFilterAnimate{
  animation-name: clearFilter;
  animation-duration: 1s;
  animation-timing-function: ease;
  animation-direction: normal;
}
@keyframes clearFilter{
  0% {margin-right: -50px;}
  25% {margin-right: -10px;}
  50% {margin-right: 0px;}
  100% {margin-right: 0px;}
} */
span[name=clearFilter]:hover{
  cursor: pointer;
  color: darkgray;
}

span.file-container{
  min-height: 0px;
  max-height: 190px;
  overflow: auto;
  /* border: 1px solid lightgray; */
}

div.container-clientRep{
  min-height: 0px;
  max-height: 200px;
  overflow: auto;
  /* box-shadow: -6px 0px 4px 0px gray inset; */
}



.span-margin-bot{
  margin-bottom: 5px;
}
a{
  color: white!important;
}

input[name=inputPath]{
  border: none;
  outline: none;
  color: #757575;
}

.c-copied{
  display: none;
  position: absolute;
  margin: -65px auto auto auto;
  /* left: 0; */
  right: 30px;
}
.c-remove-item{
  background-color: transparent;
  /* border: 1px solid indianred; */
  border: none;
  color: indianred;
  border-radius: 3px;
  transition: 0.2s;
}
.c-remove-item:hover{
  color: white;
  background-color: indianred;  
}

.c-padding-8{
  padding: 8px!important;
}
input.c-padding-8, select.c-padding-8{
  border: 1px solid lightgray;
  border-radius: 1px;
}

#formNewRequest input:focus, #formNewRequest select:focus{
  background-color: floralwhite;
  outline: none;
  border: 1px solid gray;
}
.highlight-addedClientRep{
  color: black;
  font-weight: bold;
}
.shakeClass {
  animation: shake 0.1s;
  animation-iteration-count: 4;
}

@keyframes shake {
  0% { transform: translate(1px, 1px) rotate(0deg); }
  10% { transform: translate(-1px, -2px) rotate(-1deg); }
  20% { transform: translate(-3px, 0px) rotate(1deg); }
  30% { transform: translate(3px, 2px) rotate(1deg); }
  40% { transform: translate(1px, -1px) rotate(1deg); }
  50% { transform: translate(-1px, 2px) rotate(-1deg); }
  60% { transform: translate(-3px, 1px) rotate(0deg); }
  70% { transform: translate(3px, 1px) rotate(-1deg); }
  80% { transform: translate(-1px, -1px) rotate(1deg); }
  90% { transform: translate(1px, 2px) rotate(0deg); }
  100% { transform: translate(1px, -2px) rotate(-1deg); }
}

.shakeWarning {
  animation: shakeWarning 0.1s;
  animation-iteration-count: 4;
}

@keyframes shakeWarning {
  0% { transform: translate(1px, 1px) rotate(0deg); }
  10% { transform: translate(-1px, -2px) rotate(-3deg); }
  20% { transform: translate(-3px, 0px) rotate(3deg); }
  30% { transform: translate(3px, 2px) rotate(3deg); }
  40% { transform: translate(1px, -1px) rotate(3deg); }
  30% { transform: translate(-1px, 2px) rotate(-3deg); }
  60% { transform: translate(-3px, 1px) rotate(0deg); }
  70% { transform: translate(3px, 1px) rotate(-3deg); }
  80% { transform: translate(-1px, -1px) rotate(3deg); }
  90% { transform: translate(1px, 2px) rotate(0deg); }
  100% { transform: translate(1px, -2px) rotate(-3deg); }
}








</style>
</head>
<body class="w3-black">

<header>
    <div class="header">
        <img class="logo" src="logo.jfif">
        <h1 class="w3-large c-web-title">WEB REQUEST SYSTEM</h1>

        <div class="username">
            <ul class="w3-text-black nav-links" style="padding: 0;">
                <li class="admin-link" style="display: none;"> <a href="/WRS/admin.php">Admin</a> </li>
                <li class="home-link" style="display: none;"> <a href="/WRS">Home</a> </li>
                <li class="directory-link"> <a href="/WRS/?nav=directory">Directory</a> </li>

                <li> <a href="//kdt-ph" target="_blank">KDT Portal</a> </li>
                <li> <a href="//kdt-ph/QMS" target="_blank">QMS</a> </li>
                <li> <a href="//kdt-ph/Forms" target="_blank">KDT Forms</a> </li>
                <li> <a href="http://kdtvs12/sites/kdt/_layouts/15/start.aspx#/" target="_blank">Intranet</a> </li>

                <li>
                    <span name='username' class="header-username"><?php echo $fullName; ?></span>
                </li>
            </ul>
        </div>
    </div>
</header>



<input type="hidden" name="firstName" value="<?php echo $firstName; ?>" />
<input type="hidden" name="userAccess" value="<?php echo $userAccess; ?>" />
<input type="hidden" name="userName" value="<?php echo $fullName; ?>" />
<input type="hidden" name="dbUsername" value="<?php echo $dbUsername; ?>" />
<input type="hidden" name="uploadControl" value="<?php echo $uploadControl; ?>" />
<input type="hidden" name="exportControl" value="<?php echo $exportControl; ?>" />
<input type="hidden" name="refreshStatus" value="<?php echo $refreshStatus; ?>" />

<div class="notif w3-display-topleft" name="notif" style="display:none;">
    <p>Submitted Successfully</p>
</div>

<!-- Page Content -->
<div class="w3-padding-large" id="parentDiv">
  <!-- Header/Home -->
  <header class="w3-container w3-padding-32 w3-center w3-black w3-animate-opacity" style="margin-top: 47px;">
    <p class='w3-display-topleft' name="projectDirectory" style="margin: 25px 40px 25px;">Project Directory</p>
    <!-- <h4>
      <marquee direction="down" behavior="alternate" style="width: 440px; index: 100;">
        <marquee scrollamount="20" behavior="alternate">Testing Environment</marquee>
      </marquee>
    </h4>     -->
    <h2 id="header"><span class="w3-hide-small">Active Requests</h2>
    <p id="subheader">Ongoing, On Hold, Waiting, and Pending Items</p>

  </header>


  <div class='w3-container' align='center' >
    <button id='btnNry' class='w3-button w3-xlarge' 
    style='width: 500px!important;margin-top:150px; display: none;'><i style="color:gray;">There are no requests yet.</i></button>
  </div>

<div id="child1Div">
  <!-- Ribbon Tool -->
  <div class="w3-container c-sticky w3-black ribbon-requestList">

      <input name="inputSearch" class="c-search w3-animate-opacity w3-round-small w3-col s3 m3 l2" type="text" placeholder="Search Requests" title="Type anything to search on this table"/>
      <button id="btnExport" class="w3-right w3-button w3-round-small w3-animate-opacity" style="margin-left:4px;padding:4.5px;">EXPORT</button>
      <select name="selectViewByStatus" 
              class="c-select w3-animate-opacity w3-round-small w3-right w3-col s3 m3 l2" 
              style="z-index: 2;" 
              title="View by Status">
        <option selected disabled>- Filter by Status - </option>
        <option value="All">View All</option>
        <option value="Pending">Pending</option>
        <option value="Ongoing">Ongoing</option>
        <option value="On Hold">On Hold</option>
        <option value="Waiting">Waiting</option>
        <option value="Finished">Finished</option>
        <option value="Cancelled">Cancelled</option>
        <option value="Denied">Denied</option>
      </select>
      <select name="selectViewByDev" 
              class="c-select w3-animate-opacity w3-round-small w3-right w3-col s3 m3 l2" 
              style="z-index: 2;" 
              title="View by Developer">
        <option selected disabled>- Filter by Developers - </option>
        <option value="All Developers">All Developers</option>
      </select>
      <span class="w3-right w3-animate-right hide" name="clearFilter">Clear Filters</span>
      <div class="w3-tooltip w3-right" name="plusButton">
        <p id="plusButtonP" class="w3-text w3-animate-right" style="margin: 0px 8px 0px 0px; ">Add Request</p>
        <a class="w3-btn c-padding-0">
          <i id="plusButton" class="fa fa-plus-circle w3-xxlarge c-rotateAnimation w3-animate-opacity"></i>
        </a>
      </div>

  </div>
  <!-- End of Ribbon Tool -->

  <!-- List Section -->

  <div id="list" class="w3-container w3-text-grey w3-animate-opacity" >

  <table id="requestList" class="w3-table-all w3-hoverable c-overflow" name="requestlist">
    <thead class="c-sticky-header c-outline-gray w3-text-light-gray" >
      <tr class="c-bgcolor">
        <th title="Priority Rank Number">#</th>
        <th title="Web Request Number" style="width: 115px;">Request No.</th>
        <th>Project Name</th>
        <th style="width: 20%;">Description</th>
        <th>Group</th>
        <th>Key Person</th>
        <th>Representative</th>
        <th>Developer</th>
        <th>Date Requested</th>
        <th style="width: 5%;">Start Date</th>
        <th style="width: 5%;">Finish Date</th>
        <th>Days Left</th>
        <th>Remarks</th>
        <th>Progress</th>
        <th class="gitna" style="width: 6%;">Status</th>
      </tr>
    </thead>
    <tbody>
<?php
// $sql = "SELECT * FROM request_list";

// $sql = 'SELECT * FROM request_list
//         ORDER BY (CASE Status
//         WHEN "Ongoing" THEN 1
//         WHEN "Pending" THEN 2
//         WHEN "Finished" THEN 3
//         WHEN "Cancelled" THEN 4
//         END), DateRequested';

$sql = 'SELECT * FROM request_list
        WHERE Status <> "Finished" AND Status <> "Cancelled" AND Status <> "Denied" 
        ORDER BY (CASE Status
        WHEN "Ongoing" THEN 1
        WHEN "On Hold" THEN 1
        WHEN "Waiting" THEN 1
        WHEN "Pending" THEN 2
        END), PriorityRank, DateRequested';

$result = $conn->query($sql);
$ctr = 0;
if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    // $dateReq = $row['DateRequested'];
    // $dateTrim = substr($dateReq, 0, 10);
    $ctr++;

    if($row['Status'] == "Ongoing"){
      $status = "<td class='gitna'><span class='yellow-bg c-status'>".$row['Status']."</span></td>";
      
      if($row['Progress'] == 100){
        $status = "<td class='gitna'><span class='green-bg c-status'>".$row['Status']."</td>";
      }
    }else if($row['Status'] == "Finished" || $row['Status'] == "Waiting"){
      $status = "<td class='gitna'><span class='green-bg c-status'>".$row['Status']."</td>";
    
    }else if($row['Status'] == "On Hold"){
      $status = "<td class='gitna'><span class='blue-bg c-status'>".$row['Status']."</td>";
    
    }else{
      $status = "<td class='gitna'><span class='c-status'>".$row['Status']."</td>";
    }

    echo "<tr id='".$row['RequestCode']."' value='".$row['RequestCode']."'>";

    // ----THIS IF Block Statement is Commented to USE Counter Variable instead of Showing Priority Rank ----
    // if($row['Status'] == "Ongoing"){
    //   echo "<td>".$row['PriorityRank']."</td>";
    // }else if($row['Status'] == "On Hold"){
    //   echo "<td>".$row['PriorityRank']."</td>";
    // }else if($row['PriorityRank'] != 0){
    //   echo "<td>".$row['PriorityRank']."</td>";
    // }else{
    //   echo "<td></td>";
    // }

    echo "
      <td>".$ctr."</td>
      <td class='tdRequestCode' value='".$row['RequestCode']."'>".$row['TicketNumber']."</td>
      <td>".$row['Title']."</td>
      <td>".$row['Description']."</td>
      <td>".$row['GroupBU']."</td>
      <td>".$row['KeyPerson']."</td>      
      <td>".$row['ClientRepresentative']."</td>      
      <td>".$row['Developer']."</td>      
      <td>".$row['DateRequested']."</td>";
    $rowStartDate = ($row['StartDate'] == "0000-00-00")? "<td>-</td>": "<td>".$row['StartDate']."</td>";
    $rowFinishDate = ($row['FinishDate'] == "0000-00-00")? "<td>-</td>": "<td>".$row['FinishDate']."</td>";
    $rowProgress = ($row['Progress'] == 0)? "<td>-</td>": "<td>".$row['Progress']."%</td>";
    $remarks = "<td>".$row['Remarks']."</td>";
    echo $rowStartDate.$rowFinishDate."<td>-</td>".$remarks.$rowProgress.$status."</tr>";

  }
} else {
  echo "<br>Else Statement
    <input type='hidden' data-empty-table='true' name='emptyTableChecker'/>
  ";
}  
?>
  </tbody>
  </table>
  <!-- <button name="btnGoUp" class="w3-button w3-right">
    <i class="fa fa-arrow-up w3-xxlarge"></i><br>Go Up</button> -->

  </div>
</div>

<div align="center" class="w3-container">
</div>
  <!-- End List Section -->


    <!-- Project Directory Section -->
    <div id="projectDirectory" class="w3-container w3-text-grey w3-animate-opacity hide">

        <!-- Ribbon Tool -->
        <div class="w3-container c-sticky w3-black c-ribbon-parent" style="padding: 7px 0px 6px!important;">
            <input name="searchDirectory" 
                class="c-search w3-round-small w3-col s3 m3 l2" 
                type="text" placeholder="Search Here"  title="Type anything to search in the table"/>
        </div>  <!-- End of Ribbon Tool -->
        

        <table name="projectDirectory" class="w3-table-all w3-hoverable c-overflow">
            <thead class="c-sticky-header c-outline-gray w3-text-light-gray" style="top: 102px!important;">
                <tr class="c-bgcolor">
                    <th>#</th>
                    <th style="width: 115px;">Project Code</th>
                    <th style="width: 115px;">Request No.</th>
                    <th>Project Name</th>
                    <th>Description</th>
                    <th>Key Person</th>
                    <th>Representative</th>
                    <th>Developer</th>
                </tr>
            </thead>
            <tbody>
            <!-- <tr>
                <td>1</td>
                <td>04-0079</td>
                <td>kdtCableWayBranchSplit</td>
                <td>20211006-0858 SHI CHR - edmon</td>
                <td>Edmon Lazaro</td>
                <td>None</td>
                <td>edmon</td>
                <td>W:\WRS\MacroList\04_AVEVAMarine\0079_kdtCableWayBranchSplit\WRS-04-0079</td>
            </tr> -->
            </tbody>
        </table>
    </div>  <!-- End Project Directory Section -->
      

  <!-- Modal Request Form -->
  <div id="modalRequest" class="w3-modal">
    <div class="w3-modal-content w3-animate-top w3-card-4 c-modal" name="modalRequest">
      <header id="modalRequestHeader" class="w3-container w3-dark-gray">
        <span onclick="closeModalFunc('#modalRequest')" 
        class="w3-button w3-display-topright w3-large" style="padding: 14.5px 20px;">&times;</span>
        <h3 class="w3-center">Request Form</h3>
      </header>
      <div class="w3-container w3-margin">
        <form id='formNewRequest' action="includes/insert.php" target="_self" method="POST" enctype="multipart/form-data"> 
          <input type="hidden" name="inputKeyPersonEmail" value="<?php echo $keyPersonEmail; ?>" />
          <input type='hidden' name='inputClientReps'/>
          <input type='hidden' name='inputClientRepEmails'/>
          <input type="hidden" name="inputEmployeeID" value="<?php echo $employeeID; ?>" />
          <!-- <input type="hidden" name="inputEmailTo"/> -->
          <input type="hidden" name="inputEmailCC"/>


          <!-- <input type="hidden" name="inputClientRepEmail"/> -->

          <p class="w3-row-padding">
          <?php 
            if($manyBU == true){
              echo "
                <label class='w3-col m3 l3 c-padding-8'>Group:</label>
                <select class='w3-col m9 l9 c-padding-8 w3-input' type='text' name='inputGroup' title='Business Unit'>
                <option selected disabled value='Choose Group'>- Choose Group -</option>";
              foreach($BUs as $BUCode){
                $sqlBUs = "SELECT BUName FROM business_units WHERE BUCode = '$BUCode' ";
                $resultBUs = $conn->query($sqlBUs);
                $rowBUs = $resultBUs->fetch_assoc();
                $BUName = $rowBUs['BUName'];
                $fullBUName = $BUCode." - ".$BUName;
                echo "<option value='".$BUCode."'>".$fullBUName."</option>";
              }
              echo "
              </select>
              </p>";

            }else{
              echo "
                <label class='w3-col m3 l3 c-padding-8'>Group:</label>
                <select class='w3-col m9 l9 c-padding-8 w3-input' type='text' name='inputGroup' title='You cannot edit this field.' disabled>
                <option value='".$userBU."' selected>".$BUName."</option>
              </select>
              ";
            }
          ?> 
          </p>        
          <p class="w3-row-padding">
            <label class="w3-col m3 l3 c-padding-8">Key Person / PIC :</label>
            <input class="w3-col m9 l9 c-padding-8 w3-input" type="text" placeholder="Requestor's Name" name='inputKeyPerson' value="<?php echo $userFullName;?>" title='You cannot edit this field.' disabled>          
          </p>        
          <p class="w3-row-padding">
            <label class="w3-col m3 l3 c-padding-8">Project Name:</label>
            <input class="w3-col m9 l9 c-padding-8 w3-input" type="text" placeholder="Note: Please be specific and direct to the point" name="inputTitle" required>
          </p>  
               
          <p class="w3-row-padding">
            <label class="w3-col m3 l3 c-padding-8">Description:</label>
            <input class="w3-col m9 l9 c-padding-8 w3-input" type="text" placeholder="This request will . . ." name="inputDesc" required>
          </p>
          <p class="w3-row-padding">
            <label class="w3-col m3 l3 c-padding-8">Upload Files:</label>
            <input class="w3-col m9 l9 c-padding-8 w3-input" type="file" name="inputReq[]" placeholder="Upload Files Here"  multiple/>
            <!-- <label class="w3-col l8 w3-row-padding" for="iAttach" name="">Attach File Here</label> -->
          </p>
          <p class="w3-row-padding" name="pClientRep">
            <label class="w3-col m3 l3 c-padding-8" name="clientRepLabel">Representative:</label>
            <select class="w3-col s11 m8 l9 c-padding-8 w3-input" name="inputClientRepEmail" title="Choose a group first" required disabled> 
              <option selected disabled value="0">- Choose Employee -</option>
              <option value="None">None</option>
            <?php 
            // $sqlClientRep = "SELECT * FROM employee_list WHERE BusinessUnit LIKE '%$userBU%' ORDER BY FirstName";
            $sqlClientRep = "SELECT * FROM employee_list ORDER BY FirstName";
            $resultClientRep = $conn->query($sqlClientRep);
            if($resultClientRep->num_rows > 0){
              while($rowClientRep = $resultClientRep->fetch_assoc()){
                if($rowClientRep['FullName'] != $rawFullName){
                  $clientRepFirstName = $rowClientRep["FirstName"];
                  $clientRepLastName = $rowClientRep["LastName"];
                  $clientRepFullName = $clientRepFirstName." ".$clientRepLastName;
                  $clientRepFullName = ucwords(strtolower($clientRepFullName));
                  echo "<option value='".$rowClientRep['Email']."'>".$clientRepFullName."</option>";
                  // echo "<option value='".$rowClientRep['Email']."'>".$rowClientRep['Email']."</option>";
                }
                echo "";
              }
            }
            ?>
            </select> 
              <!-- <i class="fa fa-times w3-button w3-col s1 m1 l1 w3-text-pink w3-hover-text-white w3-hover-pink w3-large delClientRep"
                style="padding:9px;border-radius:1px;">
              </i> -->
          </p>   


          <div class="container-clientRep"></div>       


      </div>
      </form>     
      <!-- <p class="w3-row-padding w3-text-red w3-center"> -->
          <!-- <strong>Please Fill-Up All the Required Fields<strong> -->
          <!-- <strong>WARNING: Duplicate Representatives Found!<strong> -->
      <!-- </p>  -->

      <footer id="modalRequestFooter" class="w3-container w3-dark-gray ">
        <p class="w3-center">
          <input id='btnReset' type="reset" class="w3-button w3-left" style="padding: 8px 0px 8px 0px;" />
          <button id='btnNext' class="w3-button w3-green  w3-right w3-ripple w3-round-small" type='button' style="margin: 0px 0px 12px;">NEXT</button>
          <!-- <button id='btnNext' class="w3-button w3-light-grey w3-right" type='button' style="margin: 0px 0px 12px;">NEXT</button> -->
        </p>
      </footer>

    </div>
  </div>  
  <!-- End of Modal Request Form -->
  
  <!-- Modal Preview Request -->
  <div id="modalPreview" class="w3-modal">
    <div class="w3-modal-content w3-animate-opacity w3-card-4 c-modal">
      <header id="modalPreviewHeader" class="w3-container c-cadetblue">
        <h3 class="w3-center">Request Preview</h3>
      </header>
      <div class="w3-container w3-margin">
        <p class="w3-row-padding">
          <label class="w3-col m3 l3">Group:</label>
          <span class="w3-col m9 l9" id="sGroup"></span>
        </p>
        <p class="w3-row-padding">
          <label class="w3-col m3 l3">Key Person:</label>
          <span class="w3-col m9 l9"><?php echo $fullName." (".$keyPersonEmail.")"; ?></span>
        </p>
        <p class="w3-row-padding">
          <label class="w3-col m3 l3">Project Name:</label>
          <span class="w3-col m9 l9" id="sTitle"></span>
        </p>
        <p class="w3-row-padding">
          <label class="w3-col m3 l3">Description:</label>
          <span class="w3-col m9 l9" id="sDesc"></span>
        </p>
        <!-- <p class="w3-row-padding">
          <label class="w3-col m3 l3">Requirements:</label>
          <span class="w3-col m9 l9" id="sReq"></span>
        </p> -->

        <div class="container-clientRep-preview">
        <!-- <p class="w3-row-padding">
          <label class="w3-col m3 l3">Representative 1:</label>
          <span class="w3-col m9 l9" id="sClientRep"></span>
        </p> -->          
        </div>                                
        <hr/>
        <p class="w3-row-padding">
          <label class="w3-col m3 l3">Email To:</label>
          <!-- <span class="w3-col m9 l9" id="">aganan-kdt@corp.khi.co.jp; aganan-kdt@corp.khi.co.jp; aganan-kdt@corp.khi.co.jp; aganan-kdt@corp.khi.co.jp</span> -->
          <span class="w3-col m9 l9" id="sEmailTo"></span>
        </p>    
        <p class="w3-row-padding" style="padding-right: 0px;">
          <label class="w3-col m3 l3">Email Cc: 
            <i id="addCC" class="fa fa-plus w3-button" title="Add Email CC" 
              style="border-radius: 10px;position:absolute;margin: -4px 0px 0px 5px;"></i>
          </label>
          <span name="addCC" class="w3-col s12 m9 l9 file-container" 
                style="box-shadow: -6px 0px 4px 0px gray inset; padding:5px 8px 5px 7px;">
            <span class="w3-col l11 span-margin-bot"><strong>Edmon Lazaro</strong> (lazaro-kdt@corp.khi.co.jp)</span>
            <span class="w3-col l11 span-margin-bot"><strong>Jommuel De Jesus</strong> (dejesus_j-kdt@corp.khi.co.jp)</span>
            <span class="w3-col l11 span-margin-bot"><strong>Earvin James Dela Cruz</strong> (delacruz-kdt@corp.khi.co.jp)</span>
            <span class="w3-col l11 span-margin-bot"><strong>Felix Edwin Petate</strong> (petate-kdt@corp.khi.co.jp)</span>
            <span class="w3-col l11 span-margin-bot"><strong>Alvin John Aganan</strong> (aganan-kdt@corp.khi.co.jp)</span>
            <span class="w3-col l11 span-margin-bot"><strong>Joshua Mari Coquia</strong> (coquia-kdt@corp.khi.co.jp)</span>
            <span class="w3-col l11 span-margin-bot"><strong>Collene Keith Medrano</strong> (medrano_c-kdt@corp.khi.co.jp)</span>
            <span class="w3-col l11 span-margin-bot"><strong>Glenda Ann Gulam</strong> (gulam-kdt@corp.khi.co.jp)</span>
            <span class="w3-col l11 span-margin-bot"><strong>Erwin Tan</strong> (tan-g1-kdt@corp.khi.co.jp)</span>
            <span class="w3-col l11 span-margin-bot"><strong>Wilson Matibag</strong> (matibag-kdt@corp.khi.co.jp)</span>
            <span class="w3-col l11 span-margin-bot"><strong>Cezar Balisbis Jr.</strong> (balisbis-kdt@corp.khi.co.jp)</span>
          </span>
          <!-- <span class="w3-col m9 l9" id="">Alvin John Aganan (aganan-kdt@corp.khi.co.jp)</span> -->
        </p>
        <p class="w3-row-padding">
          <!-- <button name="addCC" class="w3-col l3">Add Email CC</button>   -->
          <p name="ccExists" class="w3-col l3 w3-text-red hide" style="margin: -1px;"><strong>You already add this!</strong></p>                
          <select name="addCC" 
                  class="w3-col m9 l9 w3-row-padding w3-right hide"  
                  title="Choose Employee to Add in Email CC" 
                  style="border: 1px solid darkgray; padding:8px 9px 8px; border-radius:3px;margin-top:-10px;">
          </select>        
        </p>   
      </div>
      <footer class="w3-container c-cadetblue">
        <div class="w3-center w3-padding">
          <button id="editBtn" class="w3-btn w3-display-bottomleft w3-text-white c-modal-left-btn" style="padding: 20px 18px 20px 16px;">EDIT</button>
          <button id='submitPls' class="w3-button w3-light-grey w3-padding-large w3-round-small">
            <i class="fa fa-paper-plane w3-large "></i> SUBMIT
          </button>
          </div>
      </footer>

    </div>
  </div>  
  <!-- End of Modal Preview Request -->

  <!-- Modal Request Details -->
  <div id="modalReqDetails" class="w3-modal">
    <div class="w3-modal-content  w3-card-4 c-modal-details w3-animate-opacity">
      <header class="w3-container c-dimgray">
        <span name="xModalReqDetails" onclick="closeModalFunc('#modalReqDetails')" class="w3-button w3-display-topright w3-large" style="padding: 14.5px 20px;">&times;</span>
        <h3 class="w3-center">Request Details</h3>
      </header>
      <div class="w3-container w3-margin w3-text-gray div-details" style="padding-bottom: 10px;">
        <p class="w3-row-padding">
          <!-- <label class="w3-col m3 l3">Request Code:</label>
          <span class="w3-col l4" id="sReqDetailsCode"></span> -->
          <label class="w3-col m3 l3">Request Number:</label>
          <span class="w3-col l4" id="sReqDetailsTicket"></span>          
          <label class="w3-col m3 l3">Date Requested:</label>
          <span class="w3-col l2" id="sReqDetailsDateReq"></span>
        </p>
        <p class="w3-row-padding">
          <label class="w3-col m3 l3">Key Person:</label>
          <span class="w3-col l4" id="sReqDetailsKeyPerson"></span>
          <label class="w3-col m3 l3">Group:</label>
          <span class="w3-col l2" id="sReqDetailsGroup"></span>
        </p>
        <p class="w3-row-padding">
          <label class="w3-col m3 l3">Project Name:</label>
          <span class="w3-col m9 l9" id="sReqDetailsTitle"></span>
        </p>
        <p class="w3-row-padding">
          <label class="w3-col m3 l3">Description:</label>
          <span class="w3-col m9 l9" id="sReqDetailsDesc"></span>
        </p>
        <p class="w3-row-padding">
          <label class="w3-col m3 l3">File Location:</label>
          <input id="sReqDetailsReqPath" class="w3-col m9 l8" title="" placeholder="File Location"  style="border: none; color: gray;" readonly/>
          <button name="copyBtn" class="w3-col s1 m1 l1 w3-button w3-blue w3-hover-blue w3-hover-opacity w3-round-small" style="padding: 2px; margin-top: -2px;">COPY</button>
          <p class="w3-center w3-text-blue c-copied" name="copied" >Text Copied!</p>

        </p>
        <p class="w3-row-padding">
          <label class="w3-col m3 l3">Uploaded File(s):</label>
          <span name="uploadedFiles" class="w3-col s12 m9 l9 file-container"></span>
        </p>          
        <p class="w3-row-padding">
          <label class="w3-col m3 l3">Representative(s):</label>
          <span class="w3-col m9 l9" id="sReqDetailsClientRep"></span>
        </p>      
        <p class="w3-row-padding">
          <label class="w3-col m3 l3">Developer:</label>
          <span class="w3-col m9 l9" id="sReqDetailsDev"></span>
        </p>
        <p class="w3-row-padding">
          <label class="w3-col m3 l3">Status:</label>
          <span class="w3-col m9 l9" id="sReqDetailsStatus"></span>
        </p>
        <p class="w3-row-padding">
          <label class="w3-col m3 l3">Remarks:</label>
          <span class="w3-col m9 l9" id="sReqDetailsRemarks"></span>
        </p>
        
        <hr name='hrAnyConcerns'>

        <div class="concerns" align="center">
          <button class="w3-button" name="uploadRequest">Upload Additional Files</button>
          <button class="w3-button" name="cancelRequest">Cancellation Request</button>
          <button class="w3-button" name="updateClientRepRequest">Update Representative</button>
          <button class="w3-button" name="othersRequest">Other Requests/Concerns</button>
        </div>
          <form id='formAdditionalUpload' action="includes/uploadAdditional.php" target="_self" method="POST" enctype="multipart/form-data"> 
          <input type="hidden" name="inputEmployeeID" value="<?php echo $employeeID; ?>"/>
          <input type="hidden" name="emailUserName" value="<?php echo $fullName; ?>" />
          <input type="hidden" name="emailType" value="UploadAdditional"/>
          <input type="hidden" name="emailRequestCode"/>
          <input type="hidden" name="emailKPersonEmail"/>
          <input type="hidden" name="emailCRepEmail"/>
          <input type="hidden" name="emailDevs"/>
          <input type="hidden" name="emailRequestNumber"/>
          <div class="loader hide"></div>
          <input class="w3-col l11" type="file" name="uploadAdditional[]" accept="*" multiple style="margin: 0px 8px;" /> 
          <!-- <input class="w3-col l11" type="file" name="uploadAdditional[]" accept="image/png, image/jpeg, image/gif" multiple style="margin: -8px 0px 8px;" />  -->
          <!-- ATTRIBUTE that Solves Slow opening of Open File Dialog: accept="image/png, image/jpeg, image/gif" -->
          <!-- The Browser runs Safe Browsing Feature that is why it loads too slow -->

      </div>

      <footer class="w3-container w3-dark-gray" name='requestDetails'>
        <p class="w3-center" style="margin: 10px 0px;">
          <button class="w3-button w3-green w3-padding-large w3-round-small" type='submit' name="submitUpload">Upload</button>
          </form>
          <button class="w3-btn w3-display-bottomleft c-modal-left-btn c-modal-left-event w3-text-white" name="anyConcerns">Any Requests?</button>
          <button class="w3-button w3-light-grey w3-padding-large w3-round-small" type='button' name="uploadReq">Upload Requirements</button>
          <button class="w3-button w3-light-grey w3-padding-large w3-round-small" type='button' name="backConcerns">Back</button>
          <button class="w3-button w3-light-grey w3-padding-large w3-round-small" type='button' name="cancelUpload">Cancel</button>
        </p>
    </footer>
    </div>
  </div>  
  <!-- End of Modal Request Details -->   

  <!-- Modal Send Email -->
  <div id="modalSendEmail" class="w3-modal">
    <div class="w3-modal-content  w3-card-4 c-modal-details">
      <header class="w3-container c-dimgray">
        <span name="xModalReqDetails" onclick="closeModalFunc('#modalSendEmail')" class="w3-button w3-display-topright w3-xlarge" style="padding: 14.5px 20px;">&times;</span>
        <h3 class="w3-center">Cancellation Request</h3>
      </header>
      <div class="w3-container w3-margin w3-text-gray div-email">
        <form id="formSendEmail" action="includes/sendEmail.php" method="POST" target="_self">
        <input type="hidden" name="emailType" value="OtherRequests"/>
        
        <p class="w3-row-padding">
          <label class="w3-col l2">To:</label>
          <input class="w3-col l10" type="text" name="emailTo" placeholder="<email>" value="All System Group Members" disabled/>
        </p>
        <p class="w3-row-padding">
          <label class="w3-col l2">Cc:</label>
          <input class="w3-col l10" type="text" name="emailCC" placeholder="<Key Person's Email><Representative's Email>"/>
        </p>   
        <p class="w3-row-padding">
          <label class="w3-col l2">Subject:</label>
          <input class="w3-col l10" type="text" name="emailSubject" placeholder="Request's Subject"/>
        </p>               
        <p class="w3-row-padding">
          <textarea class="w3-col l12" rows="10" placeholder="<Email Content>" name="emailContent"><pre></pre></textarea>
        </p>
      </div>

      <footer class="w3-container w3-dark-gray">
        <p class="w3-center">
          <button class="w3-button w3-light-grey w3-padding-large w3-round-small" type='submit' name="sendEmail"><i class="fa fa-paper-plane"></i> Send Email</button>
          </form>
          <button class="w3-button w3-light-grey w3-padding-large w3-round-small" type='button' name="cancelEmail">Cancel</button>
        </p>
    </footer>
    </div>
  </div>  
  <!-- End of Modal Send Email -->   

<!-- Balik ka dito -->
  <!-- Modal No Requestor Access -->
  <div id="modalNoAccess" class="w3-modal">
    <div class="w3-modal-content  w3-card-4 c-modal-warning shakeWarning">
      <header class="w3-container w3-red">
        <span name="xModalReqDetails" onclick="closeModalFunc('#modalNoAccess')" class="w3-button w3-display-topright w3-large" style="padding: 14.5px 20px;">&times;</span>
        <h3 class="w3-center">WARNING</h3>
      </header>
      <div class="w3-container w3-margin w3-text-gray">
        <!-- <h5 align="center" class="w3-padding-16 w3-text-red"><b>Your Request Access is Disabled</b></h5> -->
        <div align="center" style="margin-top:15px;">
          <i class="fa fa-frown-o w3-xxxlarge w3-text-red"></i>
        </div>
        <!-- <h5 align="center" class="w3-padding-16 w3-text-red"><b>Your access on this feature is Disabled</b></h5> -->
        <!-- <h5 align="center" class="w3-padding-16 w3-text-red"><b>Sorry, you don't have access on this feature.</b></h5> -->
        <h5 align="center" class="w3-padding-16 w3-text-red"><b>Sorry, you don't have permission to access this feature.</b></h5>
        <p style="padding: 8px;" >Please contact <strong>IT GROUP</strong> to enable your access.</p>  
        <!-- <p class="w3-padding">Please contact System Group's Web Request Team to enable your access.</p>  
        <div class="w3-row-padding" style="padding-bottom: 15px;">
          <div class="w3-col s3 m3 l3">
              <label>Spark</label>
              <p style="margin: 8px 0px 2px 0px;">edmon</p>
              <p style="margin: 0px 0px 13px 0px;">alvinjohn</p>
          </div>
          <div class="w3-col s3 m3 l3">
            <label>Lotus</label>
            <p style="margin: 8px 0px 2px 0px;">lazaro-kdt</p>
            <p style="margin: 0px 0px 13px 0px;">aganan-kdt</p>
          </div>    
          <div class="w3-col s6 m6 l6">
            <label>Outlook</label>
            <p style="margin: 8px 0px 2px 0px;">lazaro-kdt@corp.khi.co.jp</p>
            <p style="margin: 0px 0px 13px 0px;">aganan-kdt@corp.khi.co.jp</p>
          </div>    
        </div>         -->
      </div>

      <!-- <div class="w3-container w3-margin w3-text-gray">
        <i class="fa fa-window-close-o"></i>
        <h5 align="center" class="w3-padding-16"><b>Your Request Access is Disabled</b></h5>
        <p>Please contact System Group's Web Request Team to enable your access.</p>
        <p class="w3-row" style="margin: 1px 0px;">
          <label class="w3-col l2">Spark:</label>
          <label class="w3-col l10" style="font-weight: normal">edmon / alvinjohn</label> 
        </p>
        <p class="w3-row" style="margin: 5px 0px;">
          <label class="w3-col l2">Lotus:</label>
          <label class="w3-col l10" style="font-weight: normal">lazaro-kdt / aganan-kdt</label> 
        </p>   
        <p class="w3-row" style="margin: 5px 0px 25px;">
          <label class="w3-col l2">Outlook:</label>
          <label class="w3-col l10" style="font-weight: normal">lazaro-kdt@corp.khi.co.jp / aganan-kdt@corp.khi.co.jp</label> 
        </p>               
      </div> -->

    </div>
  </div>  
  <!-- End of Modal No Requestor Access -->     

  
  <!-- Modal Directory -->
  <div id="modalProjectDetails" class="w3-modal">
    <div class="w3-modal-content  w3-card-4 c-modal-details">
      <header class="w3-container c-dimgray">
        <span name="xModalReqDetails" onclick="closeModalFunc('#modalProjectDetails')" class="w3-button w3-display-topright w3-large" style="padding: 14.5px 20px;">&times;</span>
        <h3 class="w3-center">Project Details</h3>
      </header>
      <div class="w3-container w3-margin w3-text-gray div-details">
        <p class="w3-row-padding">
          <label class="w3-col l3">Project Code:</label>
          <span id="sDirectoryProjCode" class="w3-col l9"></span>          
        </p>
        <!-- <p class="w3-row-padding">
          <label class="w3-col l3">Request Number:</label>
          <span id="sDirectoryProjCode" class="w3-col l9"></span>          
        </p>         -->
        <p class="w3-row-padding">
          <label class="w3-col l3">Project Name:</label>
          <span id="sDirectoryMacroName" class="w3-col l9"></span>          
        </p>
        <p class="w3-row-padding">
          <label class="w3-col l3">Description:</label>
          <span id="sDirectoryDesc" class="w3-col l9"></span>          
        </p>
        <p class="w3-row-padding">
          <label class="w3-col l3">Key Person:</label>
          <span id="sDirectoryKP" class="w3-col l9"></span>          
        </p>
        <p class="w3-row-padding">
          <label class="w3-col l3">Representative(s):</label>
          <span id="sDirectoryCR" class="w3-col l9"></span>          
        </p>
        <p class="w3-row-padding">
          <label class="w3-col l3">Developer:</label>
          <span id="sDirectoryDev" class="w3-col l9"></span>          
        </p>
        <p class="w3-row-padding">
          <label class="w3-col l3">Finish Path:</label>
          <input class="w3-col l8" id="sDirectoryPath" name="inputPath" type="text" value="" readonly/>
          <button name="copyBtn" 
                  class="w3-col l1 w3-button w3-blue w3-hover-blue w3-hover-opacity w3-round-small"
                  style="padding: 2px;margin-top:-2px;">COPY</button>
          <p class="w3-center w3-text-blue c-copied" name="copied" >Text Copied!</p>
        </p>     

        <!-- Slideshow Container -->
        <div class="slideshow-container" style="width: 300px;">

          <!-- Full-width images with number and caption text -->
          <div class="mySlides fade">
            <!-- <div class="numbertext">1 / 3</div> -->
            <img src="pictures/1.PNG" style="width:100%">
            <!-- <div class="text">Caption Text</div> -->
          </div>

          <div class="mySlides fade">
            <!-- <div class="numbertext">2 / 3</div> -->
            <img src="pictures\2.PNG" style="width:100%">
            <!-- <div class="text">Caption Two</div> -->
          </div>

          <div class="mySlides fade">
            <img src="pictures\3.png" style="width:100%">
          </div>

          <!-- Next and previous buttons -->
          <a class="prev" onclick="plusSlides(-1)">&#10094;sdflksjdf</a>
          <a class="next" onclick="plusSlides(1)">&#10095;</a>
        </div>
        <br>

        <!-- The dots/circles -->
        <div style="text-align:center">
          <span class="dot" onclick="currentSlide(1)"></span>
          <span class="dot" onclick="currentSlide(2)"></span>
          <span class="dot" onclick="currentSlide(3)"></span>
        </div>        
        <!-- End of Slideshow Container -->

    
      </div>
    </div>
  </div>  
  <!-- End of Modal Directory -->   


  <!-- Modal Hard Refresh Page -->
  <div id="modalHardRefresh" class="w3-modal" style="display: none; z-index:2000">
    <div class="w3-modal-content  w3-card-4 c-modal-refresh w3-animate-top">
      <header class="w3-container w3-blue">
        <h4 class="w3-center refresh-firstName">Hello </h4>
      </header>
      <div class="w3-container w3-margin w3-text-gray">
        <!-- <h5 align="center" class="w3-padding-16 w3-text-red"><b>Your Request Access is Disabled</b></h5> -->
        <div align="center" style="margin-top:15px;">
          <i class="fa fa-smile-o w3-xxxlarge w3-text-blue"></i>
        </div>
        <!-- <h5 align="center" class="w3-padding-16 w3-text-red"><b>Your access on this feature is Disabled</b></h5> -->
        <!-- <h5 align="center" class="w3-padding-16 w3-text-red"><b>Sorry, you don't have access on this feature.</b></h5> -->
        <h5 align="center" class="w3-padding-16 w3-text-blue">Welcome to <b>KDT Web Request System</b></h5>
        <p class="w3-padding">We have an update! Please press <b>CTRL + F5</b> on your keyboard to load the external resources of this page.</p>  
        <p class="w3-padding" style="font-size: 9px;color: orangered;">NOTE: Sometimes you need to do this 2 times.</p>
      </div>

    </div>
  </div>  
  <!-- End of Modal Hard Refresh Page -->     



  <!-- Footer -->
    <!-- <footer class="w3-container w3-text-grey" align="center">
      <p>Project of System Group</p>
      <p>If you have any concerns, message us at Spark (alvinjohn). Thank you!</p>
    </footer>   -->
  <!-- End footer -->

</div> <!-- End of Child1 Div -->    

<!-- END of PAGE CONTENT -->

</div> <!-- END OF PARENT DIV -->


<script src="js/main.js"></script>
<script src="js/universal.js"></script>


</body>
</html>