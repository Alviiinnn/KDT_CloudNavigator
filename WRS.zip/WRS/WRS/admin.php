<?php 
  include "includes/dbconnect.php";
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin - Web Request System</title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="icon" type="image/x-icon" href="logo.jfif">
<link rel="stylesheet" href="css/w3.css">
<!-- <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> -->


<link rel="stylesheet" href="css/font-awesome.css">
<link rel="stylesheet" href="css/font-montserrat.css">

<link rel="stylesheet" href="css/material-icons.css">
<link rel="stylesheet" href="css/admin.css">
<link rel="stylesheet" href="css/universal.css">

<link rel="stylesheet" href="css/w3-colors-win8.css">
<link rel="stylesheet" href="css/w3-colors-2021.css">

<script src="libraries/jquery-uncompressed (Development).js"></script>
<script src="libraries/export_plugin.js"></script>



<style>
  *{
    scroll-behavior: smooth;
  }
  section{
    transition: 1s;
  }
  html{
    overflow: auto;
  }
  header{
    z-index: 99999;
  }
  th{
    vertical-align: middle!important;
  }
  table{
    z-index: 1!important;
  }
  td{
    vertical-align: middle!important;
  }
  img[name=employeePic]{
    top: 95px;
    left: 43px;
  }
  .modalEmployeeInfo input{
    color: darkgray;
    border: 1px solid lightgray;
    padding: 3px 11px !important;
  }
  form#formUpdateRequest select{
  padding: 4px 3px;
  }
  select[name=inputAccess]{
    border: 1px solid darkgray;
    padding: 3px 6px!important;
    color: slategray;
    outline: none;
  }
  select[name=inputAccess]:disabled{
    color: dimgray;
  }
  select[name=inputAccess]:focus{
    border: 1px solid darkslategray;
  }
  .gitna{ text-align: center!important; }
  .kanan{ text-align: right!important; }


  .newlyChanges{
    /* background-color: lemonchiffon!important; */
    /* background-color: springgreen!important; */
    background-color: yellow!important;
  }
  .newlyChanges:hover{
    /* font-weight: bold; */
    background-color: lemonchiffon!important;
  }

  div.notif {
    color: darkslategray;
    background-color: lightyellow;
    box-shadow: 3px 3px 6px 0px #000000;
    position: fixed;
    display: none;
    top: -100px;
    left: 40px;
    font-weight: bold;
    width: 20em;
    z-index: 100;
    text-align: center;
    border-radius: 5px;
    animation-name: notif;
    animation-duration: 10s;
    animation-delay: 0.5s;
    /* animation-timing-function: ease-in-ease-out; */
    animation-timing-function: ease;
    animation-direction: alternate;
  }

  @keyframes notif {
    /* 0%   {left: 160px;} */
    0%   {left: 184px;}
    10%  {top: 68px;}
    25%  {top: 68px;}
    50%  {left: 184px;}
    75%  {top: 68px;}
    80% {left: -500px;}
    100% {left: -500px;}
  }

  div.notif-top-mid {
    color: darkslategray;
    background-color: lightyellow;
    display: none;
    /* position: absolute; */
    position: fixed;
    margin: auto;
    top: -50px;
    left: 0;
    right: 0;
    font-weight: bold;
    width: 20em;
    z-index: 1000;
    text-align: center;
    border-radius: 5px;
    animation-name: notif-top-mid;
    animation-duration: 5s;
    /* animation-timing-function: ease; */
    /* animation-direction: alternate; */
  }  

  @keyframes notif-top-mid {
    0% {top: -50px;}
    10% {top: 70px;}
    90% {top: 70px;}
    100% {top: -50px;}
  }
  
  th {
    font-weight: normal;
    /* vertical-align: bottom!important; */
  }

  label.upload-finish {
    border: 1px dashed darkgray;
    border-radius: 8px;
    text-align: center;
    font-weight: normal;
    padding: 10px!important;
  }
  label.upload-finish:hover {
    cursor: pointer;
    border: 2px dashed gray;
    font-weight: bold;
    padding: 9px!important;
  }  

  .c-copied{
    display: none;
    position: absolute;
    margin: -65px auto auto auto;
    /* left: 0; */
    right: 30px;
  }

  .readonly-input:focus{
    background-color: transparent!important;
    outline: none;
  }

  .c-sidebar-container{
    top: 60px; 
    display: flex;
    flex-direction: column;
  }
  .c-sidebar-item{
    display: flex;
    align-items: center;
  }
  .c-sidebar-item p{
    margin: 18px;
  }
  .c-sidebar-item i{
    width: 15%;
  }
  .c-sidebar-subitem{
    text-align: left;
  }
  .c-sidebar-subitem p{
    /* margin-left: 38px; */
  }
  .c-controls-subitem-container{
    display: flex;
    flex-direction: column;
    margin-left: 38px;
  }

  /* CONTROL - LOCATION PATH */
  /* ----------------------- */

  .location-path-section{
    display: flex; 
    justify-content: center;
  }



  .location-path-section input{
    border: none;
    /* outline: 1px solid lightgray; */
    padding: 5px 8px!important;
    color: dimgray;
  }

  .location-path-section button{
    padding: 5px!important;
  }

  .location-path-section label{
    padding: 5px!important;
    font-weight: normal;
  }

  .lp-copy{
    display: none;
    position: absolute;
    margin: -20px -76px 0;
    font-size: 10px;
    font-weight: bold;
  }

  .lp-change-btn:hover, .lp-reset-btn:hover{
    font-weight: bold;
  }

  .lp-notif{
    /* display: none;
    position: absolute;
    left: 49%;
    margin: -25px auto; */
    display: none;
    position: absolute;
    left: 12em;
    right: 0;
    margin: -25px auto;
    width: 20.5em;
    text-align: center;
 
    /* display: none;
    position: absolute;
    left: 50%;
    margin: -25px auto auto 6.4em;
    -webkit-transform: translateX(-50%);
    transform: translateX(-50%);  */
  }

  .lp-green{
    outline: 2px solid green;
    /* background-color: lightgreen; */
  }

  .lp-red{
    outline: 2px solid red;
    /* background-color: lightpink; */
  }

  /* CONTROL - LOCATION PATH end */
  /* =========================== */

  .newlyAdded{
    background-color: lemonchiffon!important;
  }
  .newlyAdded:hover{
    font-weight: bold;
  }

  .t1s{ /* Transition 1s */
    transition: 1s;
  }

  input[name=projectNumber]::-webkit-outer-spin-button,
  input[name=projectNumber]::-webkit-inner-spin-button {    /* This will Hide and Disable Number Input Up and Down Arrows */
      -webkit-appearance: none;
      /* margin: 0; */
  }


  .info_modalBody h6{
      font-size: 13px;
  }

  /* select[name=existingProjects] option{
      font-family: system-ui!important;
  } */

  .c-modal-refresh{
    width: 440px;
  }

</style>
</head>

<body class="w3-black">

<header>

  <div class="header">
    <img class="logo" src="logo.jfif">
    <h1 class="w3-large c-web-title">WEB REQUEST SYSTEM</h1>

    <div class="username">
      <ul class="w3-text-black nav-links" style="padding: 0;">
        <li> <a href="/WRS">Home</a> </li>
        <li> <a href="/WRS/?nav=directory">Directory</a> </li>
        <li> <a href="//kdt-ph" target="_blank">KDT Portal</a> </li>
        <li> <a href="//kdt-ph/QMS" target="_blank">QMS</a> </li>
        <li> <a href="//kdt-ph/Forms" target="_blank">KDT Forms</a> </li>
        <li> <a href="http://kdtvs12/sites/kdt/_layouts/15/start.aspx#/" target="_blank">Intranet</a> </li>
        <li>
          <span name='username' class="w3-text-black"><b><?php echo $fullName; ?></b></span>
        </li>
      </ul>
      <!-- <a href="/WRS" target="_self" class="hide">Go to Requestor</a> -->
    </div>

  </div>

</header>

<input type="hidden" name="firstName" value="<?php echo $firstName; ?>" />
<input name="dbUsername" type="hidden" value="<?php echo $dbUsername; ?>" />
<input type="hidden" name="refreshStatus" value="<?php echo $refreshStatusAdmin; ?>" />


<div name="notif" class="notif">
  <p>Updated Successfully!</p>
</div>

<div name="notif-top-mid" class="notif-top-mid">
  <p>Upload Success!</p>
</div>

<div name="notif-top-mid-a"  class="notif-top-mid-a">
  <p>Updated Successfully!</p>
</div>

<!-- Icon Bar (Sidebar - hidden on small screens) -->
<nav class="w3-sidebar w3-small w3-hide-small c-sidebar-container">
  <!-- Avatar image in top left corner -->

  <p class="w3-center" style="color: lightgray; margin: 15px 0;">ADMINISTRATOR</p>
  <hr style="margin: 0; border-color: gray;">
  <a id="navRequestList" class="w3-button c-sidebar-item">
    <i class="fa fa-list w3-xlarge"></i>
    <p>REQUESTS</p>
  </a>
  <a id="navEmployeeList" class="w3-button c-sidebar-item">
    <i class="fa fa-users w3-xlarge"></i>
    <p>EMPLOYEES</p>
  </a>  
  <a id="navControl" class="w3-button c-sidebar-item">
    <i class="fa fa-sliders w3-xlarge"></i>
    <p>CONTROLS</p>
    <i id="navControl_caret" class="fa fa-caret-right w3-large"></i>
  </a>

<!-- DO NOT CHANGE THE PLACEMENT OF THE FOLLOWING ELEMENTS -->
  <div name="controls_subitems" class="c-controls-subitem-container hide">
    <a id="control_emails" class="w3-button c-sidebar-subitem">
      <p>Emails</p>
    </a>
    <a id="control_projectTypes" class="w3-button c-sidebar-subitem">
      <p>Project Types</p>
    </a>
    <a id="control_locationPaths" class="w3-button c-sidebar-subitem">
      <p>Location Paths</p>
    </a>
    <a id="control_groups" class="w3-button c-sidebar-subitem">
      <p>Groups</p>
    </a>    
    <a id="control_devs" class="w3-button c-sidebar-subitem">
      <p>Developers</p>
    </a>
  </div>
<!-- DO NOT CHANGE THE PLACEMENT OF THE ABOVE ELEMENTS -->


  <a name='navRanking' id="navRanking" class="w3-button c-sidebar-item hide">
    <i class="fa fa-sort-numeric-asc w3-xlarge"></i>
    <p>RANKING</p>
  </a>

</nav>

<!-- Navbar on small screens (Hidden on medium and large screens) -->
<!-- <div class="w3-top w3-hide-large w3-hide-medium" id="myNavbar">
  <div class="w3-bar w3-black w3-opacity w3-hover-opacity-off w3-center w3-small">
    <a href="#" class="w3-bar-item w3-button" style="width:25% !important">HOME</a>
    <a href="#about" class="w3-bar-item w3-button" style="width:25% !important">ABOUT</a>
    <a href="#photos" class="w3-bar-item w3-button" style="width:25% !important">PHOTOS</a>
    <a href="#contact" class="w3-bar-item w3-button" style="width:25% !important">CONTACT</a>
  </div>
</div> -->




<!-- Page Content -->
<div class="w3-padding-large" id="main">
  <!-- Header/Home -->

  <div class="w3-padding-32 w3-center" style="margin-top: 47px;">
    <h2 id="section_title" class="w3-center"><span class="w3-hide-small">Active Requests</h2>
    <p id="section_subtitle">Ongoing, On Hold, Waiting, and Pending Items</p>
  </div>


  <div> <!-- Request List SECTION -->
    
    <!-- Tools Section -->
    <div name="divToolsSection" class="w3-black c-sticky" style="height: 43px;">   
      <p class="w3-row" style="margin: 6px 0;">
        <input name="inputSearch" class="w3-col m4 l2 w3-animate-opacity c-search w3-round-small" type="text" placeholder="Search Requests"/>
        <button id="btnExport" class="w3-right w3-button w3-animate-opacity w3-round-small" style="margin-left:4px;padding:4.5px;">EXPORT</button>
        <select name="viewByStatus" class="w3-col s4 m3 l2 w3-right w3-animate-opacity w3-round-small"  title="View By Status">
          <option selected disabled>- Filter by Status -</option>
          <option value="All">View All</option>
          <option value="Pending">Pending</option>
          <option value="Ongoing">Ongoing</option>
          <option value="On Hold">On Hold</option>
          <option value="Waiting">Waiting</option>
          <option value="Finished">Finished</option>
          <option value="Cancelled">Cancelled</option>
          <option value="Denied">Denied</option>
        </select>
        <select name="viewByDev" class="w3-col s4 m3 l2 w3-right w3-animate-opacity w3-round-small" title="View By Developer">
          <option selected disabled>- Filter by Developers -</option>
          <option value="All Developers">All Developers</option>
        </select>
        <span class="w3-right w3-animate-right hide" name="clearFilter">Clear Filters</span>

        <!-- <a class="w3-col m2 l1 w3-right w3-button">
          <i class="fa fa-sort-numeric-asc w3-xlarge"></i>
          <p>RANKING</p>
        </a>  -->
      </p>
    </div>
    <!-- End Tools Section -->    
    

    <!-- Request List Section -->
    <div id="requestList" class="w3-text-grey w3-animate-opacity" style="display:flex; flex-direction: row; justify-content: center; align-items: center">

      <table name='requestList' id='tableRequestList' class="w3-table-all w3-hoverable w3-left">
        <thead class="c-outline-gray w3-text-light-gray">
          <tr class="c-bgcolor c-sticky-header">
            <th>#</th>
            <th style="width: 7%;">Request No.</th>
            <th>Request Code</th>
            <th>Project Name</th>
            <th>Description</th>
            <th>Project Type</th>
            <th>Group</th>
            <th>Key Person</th>
            <th>Representative</th>
            <th>Developer</th>
            <th>Date Requested</th>
            <th style="width: 6%;">Start Date</th>
            <th style="width: 6%;">Finish Date</th>
            <th>Remarks</th>
            <th>Progress</th>
            <th class="gitna" style="width: 6%;">Status</th>
          </tr>
        </thead>

        <tbody>
        <?php
          $sql = 'SELECT * FROM request_list
                  WHERE Status <> "Finished" AND Status <> "Cancelled" AND Status <> "Denied" 
                  ORDER BY (CASE Status
                  WHEN "Ongoing" THEN 1
                  WHEN "On Hold" THEN 1
                  WHEN "Waiting" THEN 1
                  WHEN "Pending" THEN 2
                  END), PriorityRank, DateRequested';

          $result = $conn->query($sql);
          $ctr = 0;
          if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {

              $ctr += 1;
              
              echo "<tr id='".$row['RequestCode']."' value='".$row['RequestCode']."' class='rowClick'>";

              if($row['Status'] == "Ongoing"){
                $status = "<td class='gitna'><span class='c-status yellow-bg'>".$row['Status']."</span></td>";

                if($row['Progress'] == 100){
                  $status = "<td class='gitna'><span class='c-status green-bg'>".$row['Status']."</span></td>";
                }

              }else if($row['Status'] == "Waiting"){
                $status = "<td class='gitna'><span class='c-status green-bg'>".$row['Status']."</span></td>";

              }else if($row['Status'] == "On Hold"){
                $status = "<td class='gitna'><span class='c-status blue-bg'>".$row['Status']."</span></td>";

              }else{
                $status = "<td class='gitna'><span class='c-status'>".$row['Status']."</span></td>";
              }

              echo "
                <td>".$ctr."</td>
                <td>".$row['TicketNumber']."</td>
                <td>".$row['RequestCode']."</td>
                <td>".$row['Title']."</td>
                <td>".$row['Description']."</td>
                <td>".$row['ProjectType']."</td>
                <td>".$row['GroupBU']."</td>
                <td>".$row['KeyPerson']."</td>      
                <td value='".$row['ClientRepEmail']."'>".$row['ClientRepresentative']."</td>      
                <td>".$row['Developer']."</td>      
                <td>".$row['DateRequested']."</td>";      
                
                $rowStartDate = ($row['StartDate'] == "0000-00-00")? "<td>-</td>": "<td>".$row['StartDate']."</td>";
                $rowFinishDate = ($row['FinishDate'] == "0000-00-00")? "<td>-</td>": "<td>".$row['FinishDate']."</td>";
                $rowRemarks = "<td>".$row['Remarks']."</td>";
                $rowProgress = ($row['Progress'] == 0)? "<td>-</td>": "<td>".$row['Progress']."%</td>";
                echo $rowStartDate.$rowFinishDate.$rowRemarks.$rowProgress.$status."</tr>";
            }
          }else {
            echo "<tr>
              <td>-</td>
              <td><i>No Data Available</i></td>
              <td>-</td>
              <td>-</td>
              <td>-</td>
              <td>-</td>
              <td>-</td>
              <td>-</td>
              <td>-</td>
              <td>-</td>
              <td>-</td>
            </tr> 
            <input name='dataChecker' data-empty='true'/>
            ";
          }  
        ?>   
        </tbody> 	
      </table>

      <div class="divUpDown w3-animate-right" align="center" title="Click a Row to Move">
        <a name='first' id="moveFirst" class="w3-bar-item w3-button w3-padding-large disabled">
          <!-- <p>First</p> -->
          <i class="fa fa-angle-double-up w3-xxlarge" title="Move to First Row"></i>
        </a>   
        <a name='up' class="w3-bar-item w3-button w3-padding-large disabled">
          <i class="fa fa-chevron-up w3-xxlarge" title="Move Up"></i>
          <!-- <p>UP</p> -->
        </a>  
        <a name='down' class="w3-bar-item w3-button w3-padding-large disabled">
          <!-- <p>Down</p> -->
          <i class="fa fa-chevron-down w3-xxlarge" title="Move Down"></i>
        </a>      
        <a name='last' class="w3-bar-item w3-button w3-padding-large disabled">
          <i class="fa fa-angle-double-down w3-xxlarge" title="Move to Last Row"></i>
          <!-- <p>Last</p> -->
        </a>    
      </div>

    </div>  <!-- End of Request List Section -->

  </div>



    <!-- ACTIONS for Ranking Priority Changes -->
    <div align="center" style="text-align: center;">
    <div class="rankingActions" align="center" style="display:none;">
        <button class="w3-button w3-padding-large w3-hover-green" name="saveRanking">Save Changes</button>
        <button class="w3-button w3-padding-large " name="cancelRanking">Cancel</button>
    </div>
    </div>
    
    <div align="center" name="noRequestYet" style="display:none;">
        <h3><i>There are no request yet. <br>Go to <a href="./">Requestor's Interface</a> to add requests.</i></h3>
    </div>



    <!-- Employee List Section -->
    <!-- --------------------- -->

    <div class="w3-container w3-text-grey w3-animate-opacity hide" id="employeeList" >
            
        <!-- Ribbon Tool -->
        <div class="w3-container c-sticky w3-black c-ribbon-parent" style="padding: 7px 0px 6px!important;">
            <input name="searchEmployee" 
                class="c-search w3-round-small w3-col s3 m3 l2" 
                type="text" placeholder="Search Employees"  title="Type anything to search in the table"/>
            <select name="filterGroup" class="w3-col s4 m3 l2 w3-right w3-round-small" title="Choose Group"
                style="padding: 5px 8px 6px;">
                <option selected disabled>- Filter by Group -</option>
                <option value="">ACT - Accounting Group</option>
                <option value="">ADM - Admin Group</option>
                <option value="">ANA - Analysis Group</option>
            </select>
                
        </div>  <!-- End of Ribbon Tool -->

        <table name="employeeList" class="w3-table-all w3-hoverable c-bgcolor">
            <thead class="c-outline-gray w3-text-light-gray">
                <tr class="c-bgcolor c-sticky-employee" value="header">
                    <th>#</th>
                    <th>Employee ID</th>
                    <th>Full Name</th>
                    <th>User Name</th>
                    <th>PC</th>
                    <th>Email</th>
                    <th>Group</th>
                    <th>Designation</th>
                    <th>Access</th>
                    <th>Upload</th>
                    <th>Export</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $sql = "SELECT * FROM employee_list";
            $result = $conn->query($sql);
            $ctr = 0;
            if ($result->num_rows > 0) {
                // output data of each row
                while($row = $result->fetch_assoc()) {

                $ctr += 1;
                echo "
                <tr value='".$row['EmployeeID']."'>
                    <td>".$ctr."</td>
                    <td>".$row['EmployeeID']."</td>
                    <td>".$row['FullName']."</td>
                    <td>".$row['UserName']."</td>
                    <td>".$row['PC']."</td>
                    <td>".$row['Email']."</td>      
                    <td>".$row['BusinessUnit']."</td>      
                    <td>".$row['Designation']."</td>      
                    <td>".$row['Access']."</td>      
                    <td>".$row['UploadControl']."</td>      
                    <td>".$row['ExportControl']."</td>      
                </tr>";    
                }
            } else {
                echo "<tr><td colspan='11' class='c-text-center'><i>No Employees Found</i></td></tr> ";
            }
            ?>
            </tbody>
        </table>
    </div>  
    
    <!-- End of Employee List Section -->  
    <!-- ============================ -->
  
  


    <!-- Location Path Control Section -->
    <!-- ----------------------------- -->

    <!-- WARNING! DO NOT CHANGE THE ROW ARRANGEMENT OF THE FOLLOWING ELEMENTS of this Section -->
    <!-- Because, it will DESTROY its JQUERY Functionality -->

    <section class="location-path-section">

        <div id="locationPath_section" class="w3-container w3-light-gray w3-animate-opacity w3-padding-32 w3-round" style="width: 80em;">

            <div class="w3-padding">
                <span class="w3-green w3-padding w3-round lp-notif"></span>

                <h5 class="w3-row">New Request / Additional Upload</h5>  

                <p class="w3-padding-16 w3-margin c-pad-top-0">
                <label class="w3-col s2 m2 l2 t1s lp-path-label ">Initial Path:</label>
                <input name="initialPath" class="w3-col s6 m6 l8 t1s lp-path-input " type="text" placeholder="Click the 'Change' button to update this path" value="\\157.116.72.26\WebRequest\WRS\Database\2022" readonly/>
                <button class="w3-col s2 m2 l1 t1s w3-button w3-round w3-hover-none lp-change-btn ">Change</button>             
                <button class="w3-col s2 m2 l1 t1s w3-button w3-blue w3-hover-blue w3-hover-opacity w3-round lp-copy-btn ">Copy</button>
                <button class="w3-col s2 m2 l1 t1s w3-button w3-round w3-hover-none lp-reset-btn " style="display: none;">Reset</button>
                <button class="w3-col s2 m2 l1 t1s w3-button w3-teal w3-hover-teal w3-hover-opacity w3-round lp-check-btn " style="display: none;">Check</button>
                <button class="w3-col s2 m2 l1 t1s w3-button w3-green w3-hover-green w3-hover-opacity w3-round lp-save-btn " style="display: none;">Save</button>          
                <label class="w3-text-blue lp-copy">Text Copied!</label>
                </p>
            </div>

            <div class="w3-padding">
                <h5 class="w3-row">Finish Requests</h5>  

                <div class="w3-margin">
                    <p class="w3-padding-16 c-pad-top-0">
                        <label class="w3-col s2 m2 l2 t1s lp-path-label">Public Path:</label>
                        <input name="finish_publicPath" class="w3-col s6 m6 l8 t1s lp-path-input" type="text" placeholder="Click the 'Change' button to update this path" value="\\157.116.72.26\WebRequest\WRS\Database\2022" readonly/>
                        <button class="w3-col s2 m2 l1 t1s w3-button w3-round w3-hover-none lp-change-btn">Change</button>
                        <button class="w3-col s2 m2 l1 t1s w3-button w3-blue w3-hover-blue w3-hover-opacity w3-round lp-copy-btn">Copy</button>
                        <button class="w3-col s2 m2 l1 t1s w3-button w3-round w3-hover-none lp-reset-btn" style="display: none;">Reset</button>
                        <button class="w3-col s2 m2 l1 t1s w3-button w3-teal w3-hover-teal w3-hover-opacity w3-round lp-check-btn" style="display: none;">Check</button>
                        <button class="w3-col s2 m2 l1 t1s w3-button w3-green w3-hover-green w3-hover-opacity w3-round lp-save-btn" style="display: none;">Save</button>            
                        <label class="w3-text-blue lp-copy">Text Copied!</label>

                    </p>

                    <p class="w3-padding-16">
                        <label class="w3-col s2 m2 l2 t1s lp-path-label">System Path:</label>
                        <input name="finish_systemPath" class="w3-col s6 m6 l8 t1s lp-path-input" type="text" placeholder="Click the 'Change' button to update this path" value="\\157.116.72.26\WebRequest\WRS\Database\2022" readonly/>
                        <button class="w3-col s2 m2 l1 t1s w3-button w3-round w3-hover-none lp-change-btn">Change</button>
                        <button class="w3-col s2 m2 l1 t1s w3-button w3-blue w3-hover-blue w3-hover-opacity w3-round lp-copy-btn">Copy</button>
                        <button class="w3-col s2 m2 l1 t1s w3-button w3-round w3-hover-none lp-reset-btn" style="display: none;">Reset</button>
                        <button class="w3-col s2 m2 l1 t1s w3-button w3-teal w3-hover-teal w3-hover-opacity w3-round lp-check-btn" style="display: none;">Check</button>
                        <button class="w3-col s2 m2 l1 t1s w3-button w3-green w3-hover-green w3-hover-opacity w3-round lp-save-btn" style="display: none;">Save</button>                    
                        <label class="w3-text-blue lp-copy">Text Copied!</label>
                    </p>

                    <p class="w3-padding-16">
                        <label class="w3-col s2 m2 l2 t1s lp-path-label">Business Unit Path:</label>
                        <input name="finish_BUPath" class="w3-col s6 m6 l8 t1s lp-path-input" type="text" placeholder="Click the 'Change' button to update this path" value="\\157.116.72.26\WebRequest\WRS\Database\2022" readonly/>
                        <button class="w3-col s2 m2 l1 t1s w3-button w3-round w3-hover-none lp-change-btn">Change</button>
                        <button class="w3-col s2 m2 l1 t1s w3-button w3-blue w3-hover-blue w3-hover-opacity w3-round lp-copy-btn">Copy</button>
                        <button class="w3-col s2 m2 l1 t1s w3-button w3-round w3-hover-none lp-reset-btn" style="display: none;">Reset</button>
                        <button class="w3-col s2 m2 l1 t1s w3-button w3-teal w3-hover-teal w3-hover-opacity w3-round lp-check-btn" style="display: none;">Check</button>
                        <button class="w3-col s2 m2 l1 t1s w3-button w3-green w3-hover-green w3-hover-opacity w3-round lp-save-btn" style="display: none;">Save</button>                        
                        <label class="w3-text-blue lp-copy">Text Copied!</label>
                    </p>
                </div>
            </div>

        </div>
        
    </section>


</div> <!-- End of id="Main" -->
  



    <!-- Modal Request Details -->
    <div id="modalReqDetails" class="w3-modal modalReqDetails">
        <div name="modalReqDetails" class="w3-modal-content w3-card-4 c-modal">
            <header class="w3-container c-dimgray">
                <span id="xButton" class="w3-button w3-display-topright w3-large" 
                      style="padding: 14.5px 20px;"
                      title="Press ESC to close this Modal.">&times;</span>
                <h3 class="w3-center">Request Details</h3>
            </header>

            <div class="w3-container w3-margin w3-text-gray">
                <form id="formUpdateRequest" action="includes/update.php" method="POST" target="_self">
                    <input type="hidden" name="requestChecker" value="updateRequestDetails"/>
                    <input type="hidden" name="inputPriorityRank"/>
                    <p class="w3-row-padding">
                        <label class="w3-col s3 m3 l3">Request Number:</label>
                        <input class="w3-col s4 m4 l4 disabledField" type="text" name="reqNumber" placeholder="Web Request Number" disabled/>
                        <label class="w3-col s3 m3 l3">Date Requested:</label>
                        <input class="w3-col s2 m2 l2 disabledField" style="text-align: right;" type="text" name="inputDateReq" placeholder="Date Requested" disabled/>
                    </p>
                    <p class="w3-row-padding">
                        <label class="w3-col s3 m3 l3">Request Code:</label> 
                        <input class="w3-col s4 m4 l4 disabledField" type="text" name="inputCode" placeholder="Request Code" disabled/>
                        <label class="w3-col s1 m1 l1">Group:</label>
                        <input class="w3-col s4 m4 l4 disabledField" type="text" name="inputGroup" style="text-align: right;" placeholder="Group" disabled/>
                    </p>

                    <p class="w3-row-padding">
                        <label class="w3-col s3 m3 l3">Project Name:</label> 
                        <input class="w3-col s9 m9 l9" type="text" name="inputTitle" placeholder="e.g. Sytems Group Automation Project" disabled/>
                    </p>

                    <p class="w3-row-padding">
                        <label class="w3-col s3 m3 l3">Description:</label> 
                        <input class="w3-col s9 m9 l9" type="text" name="inputDesc" placeholder="This request will . . ." disabled/>
                    </p>

                    <p class="w3-row-padding">
                        <label class="w3-col s3 m3 l3">Key Person:</label> 
                        <!-- <input class="w3-col l4 disabledField" type="text" name="inputKeyPerson" placeholder="Key Person" disabled/> -->
                        <select class="w3-col s3 m3 l3" name="inputKeyPerson" disabled></select>
                        <label class="w3-col s1 m1 l1"></label>
                    </p>
                    <p class="w3-row-padding fClientRep">
                        <label class="w3-col s3 m3 l3">Representative:</label>
                        <!-- <input class="w3-col l9" type="text" name="inputClientRep" placeholder="Representative" disabled/> -->
                        <select name="inputClientRep" disabled title="Representative">
                        </select>
                    </p>          

                    <p class="w3-row-padding">
                        <label class="w3-col s3 m3 l3">File Location:</label> 
                        <label class="error-fileLocation">File Location does not Exists!</label>
                        <input name="inputReq" class="w3-col s8 m8 l8 disabledField readonly-input" type="text" placeholder="File Location" style="padding: 2px 7px !important;"  readonly/>
                        <button name="copyBtn" class="w3-col s1 m1 l1 w3-button w3-blue w3-hover-blue w3-hover-opacity w3-round-small" style="padding: 4px;margin-top:-2px;">COPY</button>
                        <p class="w3-center w3-text-blue c-copied" name="copied" >Text Copied!</p>
                    </p>

                    <p class="w3-row-padding">
                        <label class="w3-col s3 m3 l3">Developer:</label>
                        <input class="w3-col s9 m9 l9" type="text" name="inputDev" placeholder="Add Developers" disabled/>
                    </p>  

                    <div class="dev-parent">
                        <div id="edmon" class="dev-child" data-active-dev="false" >
                            <img src="pictures/Devs/212 Edmon Lazaro.jpg" 
                                 alt="Edmon Lazaro" 
                                 onerror="this.src='http://kdtvs12/sites/kdt/Shared%20Documents/1x1/212%20Edmon%20Lazaro.JPG'">
                            <label>edmon</label>   
                        </div> 

                        <!-- <div id="raffy" class="dev-child" data-active-dev="false">
                            <img src="http://kdtvs12/sites/kdt/Shared%20Documents/1x1/353%20Raffy%20Torio.jpg" 
                                 alt="Raffy Torio" onerror="this.src='pictures/Devs/353 Raffy Torio.jpg'">
                            <label>raffy</label>   
                        </div>    -->

                        <div id="jommuel" class="dev-child" data-active-dev="false">
                            <img src="pictures/Devs/355 Jommuel De Jesus.jpg" 
                                 alt="Jommuel De Jesus" 
                                 onerror="this.src='http://kdtvs12/sites/kdt/Shared%20Documents/1x1/355%20Jommel%20De%20Jesus.JPG'">
                            <label>jommuel</label>
                        </div> 

                        <div id="earvinjames" class="dev-child" data-active-dev="false">
                            <img src="pictures/Devs/409 Earvin James Dela Cruz.jpg" 
                                 alt="Earvin James Dela Cruz" 
                                 onerror="this.src='http://kdtvs12/sites/kdt/Shared%20Documents/1x1/409%20Earvin%20James%20Dela%20Cruz.jpg'">
                            <label>earvinjames</label>
                        </div> 

                        <div id="felix" class="dev-child" data-active-dev="false">
                            <img src="pictures/Devs/465 Felix Edwin Petate.jpg" 
                                 alt="Felix Edwin Petate" 
                                 onerror="this.src='http://kdtvs12/sites/kdt/Shared%20Documents/1x1/465%20Felix%20Edwin%20Petate.jpg'">
                            <label>felix</label>
                        </div> 

                        <div id="josh" class="dev-child" data-active-dev="false">
                            <img src="pictures/Devs/464 Joshua Mari Coquia.jpg" 
                                 alt="Joshua Mari Coquia" 
                                 onerror="this.src='http://kdtvs12/sites/kdt/Shared%20Documents/1x1/464%20Joshua%20Mari%20Coquia.jpg'">
                            <label>josh</label>
                        </div> 

                        <div id="alvinjohn" class="dev-child" data-active-dev="false">
                            <img src="pictures/Devs/466 Alvin John Aganan.jpg" 
                                 alt="Alvin Aganan" 
                                 onerror="this.src='http://kdtvs12/sites/kdt/Shared Documents/1x1/466 Alvin John Aganan.jpg'">
                            <label>alvinjohn</label>
                        </div>   
                        
                        <div id="collene" class="dev-child" data-active-dev="false">
                            <img src="pictures/Devs/487 Collene Keith Medrano.jpg" 
                                 alt="Keith Medrano" 
                                 onerror="this.src='http://kdtvs12/sites/kdt/Shared Documents/1x1/487 Collene Keith Medrano.jpg'">
                            <label>collene</label>
                        </div>

                        <div id="glenda" class="dev-child" data-active-dev="false">
                            <img src="pictures/Devs/488 Glenda Ann Gulam.jpg" 
                                 alt="Glenda Gulam" onerror="this.src='http://kdtvs12/sites/kdt/Shared Documents/1x1/488 Glenda Ann Gulam.jpg'">
                            <label>glenda</label>
                        </div>
                    </div>   

                    <p class="w3-row-padding">
                        <label class="w3-col s3 m3 l3">Start Date:</label>
                        <input name="inputStartDate" class="w3-col s3 m3 l3" type="date" disabled/>
                        <label class="w3-col s1 m1 l1"></label>
                        <label class="w3-col s2 m2 l2">Finish Date:</label>
                        <input name="inputFinishDate" class="w3-col s3 m3 l3" type="date" disabled/>
                    </p>    

                    <p class="w3-row-padding">
                        <label class="w3-col s3 m3 l3">Project Type:</label>
                        <select name="projectType" class="w3-col s3 m3 l3" title="Choose type" disabled>
                            <option value="default" selected disabled>- choose type -</option>
                            <option value="01 Application">01 Application</option>
                            <option value="02 CATIA">02 CATIA</option>
                            <option value="03 Microsoft Excel">03 Microsoft Excel</option>
                            <option value="04 AVEVA Marine">04 AVEVA Marine</option>
                            <option value="05 Autocad">05 Autocad</option>
                            <option value="06 Arduino">06 Arduino</option>
                            <option value="07 PDMS">07 PDMS</option>
                            <option value="08 Mobile Development">08 Mobile Development</option>
                            <option value="09 Web Development">09 Web Development</option>
                        </select>
                        <label class="w3-col s1 m1 l1"></label>
                        <label class="error-projectNumber"><i></i></label>

                        <label name="projectNumberLabel" class="w3-col s2 m2 l2" >Existing Projects:</label>
                        <select name="existingProjects" class="w3-col s2 m2 l2" title="Choose type" >
                            <option value="default" selected disabled>- choose one -</option>
                        </select>
                        
                        <i name="plusProject" 
                            class="fa fa-plus w3-col s1 m1 l1 w3-button w3-padding w3-round-small w3-hover-none c-rotateAnimation"
                            title="Add New Project Folder"
                            style="margin-top: 0px;padding: 6.5px 16px!important;">
                        </i>
                        <input name="projectNumber" class="w3-col s1 m1 l1" type="text" placeholder="0000"  maxlength="4" 
                            onkeypress="return ( event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" 
                            style="padding: 3px 7px!important;" disabled/>

                        <!-- <input name="projectNumber" class="w3-col s1 m1 l1" type="number" placeholder="0000" pattern="[0-9]{4}" maxlength="4" value="1111" /> -->
                        <button 
                            name="chooseExisting"
                            title="Choose Existing Projects"
                            type="button"
                            class="w3-col s2 m2 l2 w3-button w3-padding-small w3-round-small w3-hover-none" 
                            style="padding: 3.5px 0px!important; margin-top: -1px!important;">Choose Existing
                        </button>
                        <div class="projectNumber_list">
                            <!-- <p>0001_Web Request System</p>
                            <p>0002_Web Request System</p>
                            <p>0003_Web Request System</p>
                            <p>0004_Web Request System</p>
                            <p>0005_Web Request System</p>
                            <p>0006_Web Request System</p>
                            <p>0007_Simplier Weekly Report and Monitoring for KDT Civil</p>
                            <p>0008_Web Request System</p>
                            <p>0009_Web Request System</p>
                            <p>0010_Web Request System</p> -->
                        </div>                        
                    </p>

                    <p class="w3-row-padding">
                        <label class="w3-col s3 m3 l3">Status:</label>
                        <select class="w3-col s3 m3 l3" name="inputStatus" disabled title="Change Status">
                            <option value="pending">Pending</option>
                            <option value="ongoing">Ongoing</option>
                            <option value="onhold">On Hold</option>
                            <option value="waiting">Waiting</option>
                            <option value="finished">Finished</option>
                            <option value="cancelled">Cancelled</option>
                            <option value="denied">Denied</option>
                        </select>   
                        <label class="w3-col s1 m1 l1"></label>
                        <label class="w3-col s2 m2 l2">Progress %</label>
                        <input class="w3-col s3 m3 l3" type="number" name="inputProgress" min="0" max="100" placeholder="0% - 100%" disabled/> 
                    </p>

                    <p class="w3-row-padding">
                        <label name='remarks' class="w3-col s3 m3 l3" >Remarks:</label>
                        <textarea name="inputRemarks" class="w3-col s9 m9 l9" style="padding: 7px;" rows="3" placeholder='Put your comments/notes here.' disabled>Remarks</textarea>
                    </p>
                    
            </div>

            <footer class="w3-container w3-dark-gray">
                <div class="w3-center w3-padding">
                    <input id='btnReset' type="button" class="w3-btn w3-display-bottomleft c-modal-left-btn" value="Reset to Default" name="btnReset"/>
                    <button id='btnSave' class="w3-button w3-padding-large w3-teal w3-hover-green w3-round-small">SAVE</button>
                    <button id='btnCancel' class="w3-button w3-light-grey w3-padding-large w3-round-small">CANCEL</button>
                </form>
                    <button id='btnEdit' class="w3-button w3-light-grey w3-padding-large w3-round-small"><i class="fa fa-pencil"></i> EDIT</button>
                    <button id='btnUpload' 
                            class="w3-button w3-display-bottomleft w3-padding-large w3-hover-dark-gray w3-hover-text-black"
                            style="margin: 8px 0px;"><i class="fa fa-upload"></i> Upload Files</button>
                </div>
            </footer>        
        </div>
    </div>  
    <!-- End of Modal Request Details -->    

    
    
    <!-- Modal Employee Info -->
    <div id="modalEmployeeInfo" class="w3-modal modalEmployeeInfo">
        <div class="w3-modal-content w3-card-4" style="width: 500px;">
            <header class="w3-container c-dimgray">
                <span class="w3-button w3-display-topright w3-large" style="padding: 14.5px 20px;" onclick="$('#modalEmployeeInfo').hide();">&times;</span>
                <h3 class="w3-center">Employee Information</h3>
            </header>

            <div class="w3-container w3-margin w3-text-gray">
                <form id="formEmployeeInfo" action="includes/update.php" method="POST" target="_self">
                    <input type="hidden" name="requestChecker" value="updateEmployeeInfo"/> 
                    <p class="w3-row-padding">
                        <label class="w3-col l4">Name:</label> 
                        <input class="w3-col l8 " type="text" name="inputName" placeholder="" disabled/>
                    </p>
                    <p class="w3-row-padding">
                        <label class="w3-col l4">Employee ID:</label> 
                        <input class="w3-col l8 " type="text" name="inputEmployeeID" placeholder="" disabled/>
                    </p>
                    <p class="w3-row-padding">
                        <label class="w3-col l4">Username:</label> 
                        <input class="w3-col l8 " type="text" name="inputUsername" placeholder="" disabled/>
                    </p>
                    <p class="w3-row-padding">
                        <label class="w3-col l4">Email:</label> 
                        <input class="w3-col l8 " type="text" name="inputEmail" placeholder="" disabled/>
                    </p>
                    <p class="w3-row-padding">
                        <label class="w3-col l4">Business Unit:</label> 
                        <input class="w3-col l8 " type="text" name="inputBU" placeholder="" disabled/>
                    </p>
                    <p class="w3-row-padding">
                        <label class="w3-col l4">Designation:</label> 
                        <input class="w3-col l8 " type="text" name="inputDesignation" placeholder="" disabled/>
                    </p>
                    <p class="w3-row-padding">
                        <label class="w3-col l4">PC:</label> 
                        <input class="w3-col l8 " type="text" name="inputPC" placeholder="" disabled/>
                    </p>
                    <p class="w3-row-padding">
                        <label class="w3-col l4">Access Type:</label> 
                        <select  disabled name="inputAccess">
                            <option value="Admin">Admin</option>
                            <option value="Developer">Developer</option>
                            <option value="IT">IT</option>        
                            <option value="Requestor">Requestor</option>
                            <option value="Viewer">Viewer</option>
                        </select>   
                    </p>
                    <p class="w3-row-padding">
                        <label class="w3-col l4">Upload Control:</label> 
                        <label class="switch">
                            <input type="checkbox" name="inputUploadControl" disabled>
                            <span class="slider round" ></span>
                        </label>  
                        <span name="uploadControl"></span>
                    </p>
                    <p class="w3-row-padding">
                        <label class="w3-col l4">Export Control:</label> 
                        <label class="switch">
                            <input type="checkbox" name="inputExportControl" disabled>
                            <span class="slider round" ></span>
                        </label>  
                        <span name="exportControl"></span>
                    </p>        
            </div>

            <footer class="w3-container w3-dark-gray">
                <div class="w3-center w3-padding">
                    <!-- <input id='btnReset' type="button" class="w3-btn w3-display-bottomleft c-modal-left-btn" value="Reset to Default" name="btnReset"/> -->
                    <button name="saveEmpInfo" type="submit" class="w3-button w3-padding-large w3-round-small w3-teal w3-hover-green">SAVE</button>
                </form>
                    <button name="updateEmpInfo" class="w3-button w3-light-grey w3-padding-large w3-round-small" >Edit Access</button>
                    <button name="cancelEmpInfo" class="w3-button w3-light-grey w3-padding-large w3-round-small" >CANCEL</button>
                </div>
            </footer>
        </div>
    </div>      <!-- End of Modal Employee Info -->
    

    <!-- Modal Upload -->
    <div id="modalUpload" class="w3-modal">    
        <div class="w3-modal-content w3-card-4 w3-animate-top c-modal-upload">
            <header class="w3-container c-dimgray c-header-radius">
                <span class="w3-button w3-display-topright w3-large" 
                        style="padding: 14.5px 20px;border-radius:0 5px 0 0;"
                        onclick="fxCloseModal('modalUpload')">&times;</span>
                <h4 class="w3-left pad-3" style="margin-left: 20px;">Upload Files</h4>
            </header>

            <div class="w3-container w3-margin w3-text-gray">
                <p class="w3-row-padding w3-margin-bottom">
                    <label class="w3-col l12 upload-finish" for="finishFile">CHOOSE FILES</label>
                    <form id="formUploadFiles" action="" method="POST" enctype="multipart/form-data">
                        <input name="finishFile[]" type="file" id="finishFile" class="hide" multiple/>    
                        <input type="hidden" name="fileLocation" value="sampleValue"/>
                        <input type="hidden" name="inputText" value="This is Input Text Value"/>
                    </form>
                </p>
                <p name="fileList_header" class="w3-row-padding">
                    <label class="w3-col s1 m1 l1">#</label>
                    <label class="w3-col s8 m8 l8">File Name</label>
                    <label class="w3-col s3 m3 l3 kanan">Size</label>
                </p>
                <div name="fileList_Jar">
                    <!-- <div class="w3-row-padding">
                    <label class="w3-col s1 m1 l1">1</label>
                    <label class="w3-col s9 m9 l9">FileNasdfsdfsdfsdfsdfsdfsdfsdkfgl.png</label>
                    <label class="w3-col s2 m2 l2">20 KB</label>
                    </div>
                    <div class="w3-row-padding">
                    <label class="w3-col s1 m1 l1">1</label>
                    <label class="w3-col s9 m9 l9">FileNasdkfgl.png</label>
                    <label class="w3-col s2 m2 l2">20 KB</label>
                    </div>
                    <div class="w3-row-padding">
                    <label class="w3-col s1 m1 l1">1</label>
                    <label class="w3-col s9 m9 l9">FileNasdkfgl.png</label>
                    <label class="w3-col s2 m2 l2">20 KB</label>
                    </div> -->
                </div>      <!-- end of DIV - fileList_Jar -->
            </div>      <!-- end of DIV Modal Body Content -->      

            <footer class="w3-container w3-dark-gray c-footer-radius">
                <div class="w3-center w3-padding">
                    <button id='btn_uploadToServer' type="submit" class="w3-button w3-light-grey w3-padding w3-round-small">Upload to Server</button>
                </div>
            </footer>
        </div>    
    </div>      <!-- End of Modal Confirm -->
      

    <!-- Modal Move to Finish Folder -->
    <div id="modalMoveToFinish" class="w3-modal">    
        <div class="w3-modal-content w3-card-4 w3-animate-top c-modal-confirm">
            <header class="w3-container c-dimgray c-header-radius">
                <h4 class="w3-center pad-3">Move Files</h4>
            </header>

            <div class="w3-container w3-margin w3-text-gray" align="center">
                <p class="w3-row-padding">
                    <h6>Uploaded files for this request will be <strong>moved to finish folder</strong>. 
                        <a id='btn_seeDetails' class="w3-hover-text-black cursor-pointer" style="font-size: 12px;">(See Details)</a> <br><br><b style="font-size:14px;font-weight:normal;">Folder to be Created:</b><br>
                        <b id='target_folder' style='color: slateblue; font-size: 14px;'></b>
                    </h6> 
                </p>
            </div>

            <footer class="w3-container w3-dark-gray c-footer-radius">
                <div class="w3-center w3-padding">
                    <button id='btnGoBack' class="w3-button w3-light-grey w3-padding w3-round-small">Go Back</button>
                    <button id='btnProceed' class="w3-button w3-padding w3-teal w3-hover-green w3-round-small">Proceed</button>
                </div>
            </footer>
        </div>    
    </div>      <!-- End of Move to Finish Folder -->
    

    <!-- Modal Confirm -->
    <div id="modalConfirm" class="w3-modal">    
        <div class="w3-modal-content w3-card-4 w3-animate-top c-modal-confirm">
            <header class="w3-container c-dimgray c-header-radius">
                <h4 class="w3-center pad-3">Update Information</h4>
            </header>

            <div class="w3-container w3-margin w3-text-gray" align="center">
                <p class="w3-row-padding">
                    <h6>Do you want to save the changes you've made?</h6> 
                </p>
            </div>

            <footer class="w3-container w3-dark-gray c-footer-radius">
                <div class="w3-center w3-padding">
                    <button id='btnNo' class="w3-button w3-light-grey w3-padding w3-round-small">NO</button>
                    <button id='btnYes' class="w3-button w3-padding w3-teal w3-hover-green w3-round-small">YES</button>
                </div>
            </footer>
        </div>    
    </div>      <!-- End of Modal Confirm -->
    

    <!-- Modal Send Request Status -->
    <div id="modalSendReqStat" class="w3-modal">    
        <div class="w3-modal-content w3-card-4 w3-animate-top c-modal-confirm">
            <header class="w3-container c-dimgray c-header-radius">
                <h4 class="w3-center pad-3">Send Status</h4>
            </header>

            <div class="w3-container w3-margin w3-text-gray" align="center">
                <p class="w3-row-padding">
                    <h6>Do you want to email Requestor/Representative about the <strong>Status of their Request?</strong></h6>
                </p>
            </div>

            <footer class="w3-container w3-dark-gray c-footer-radius">
                <div class="w3-center w3-padding">
                    <button name="yes" class="w3-button w3-teal w3-hover-green w3-round-small">YES</button>
                    <button name="no" class="w3-button w3-light-grey w3-round-small">NO</button>
                </div>
            </footer>
        </div>    
    </div>      <!-- End of Send Request Status --> 
     

    <!-- Modal Ranking -->
    <div id="modalConfirmRanking" class="w3-modal">    
        <div class="w3-modal-content w3-card-4 c-modal-confirm w3-animate-top">
            <header class="w3-container c-dimgray c-header-radius">
                <h4 class="w3-center pad-3">Update Ranking Priority</h4>
            </header>
            
            <div class="w3-container w3-margin w3-text-gray" align="center">
                <p class="w3-row-padding">
                    <h6>Do you want to save the changes you've made?</h6> 
                </p>
            </div>

            <footer class="w3-container w3-dark-gray c-footer-radius">
                <div class="w3-center w3-padding">
                    <button name="yesConfirmRanking" class="w3-button w3-padding w3-teal w3-hover-green w3-round-small">YES</button>
                    <button name="noConfirmRanking" class="w3-button w3-padding w3-light-grey w3-round-small">NO</button>
                </div>
            </footer>
        </div>    
    </div>   <!-- End of Modal Ranking -->
  

    <!-- Modal Confirm -->
    <div id="modalControlSave" class="w3-modal">    
        <div class="w3-modal-content w3-card-4 w3-animate-top c-modal-control">
            <header class="w3-container c-dimgray c-header-radius">
                <h4 class="w3-center pad-3 c-modal-header">Update Path</h4>
            </header>
            
            <div class="w3-container w3-margin w3-text-gray" align="center">
                <p class="w3-row-padding">
                    <h6 class="c-modal-content">Do you want to save this path?</h6> 
                    <p class="w3-medium c-wrap-content confirm-path"><b>//157.116.72.26/WebRequest/WRS/files</b></p>
                </p>
            </div>

            <footer class="w3-container w3-dark-gray c-footer-radius">
                <div class="w3-center w3-padding">
                    <button id='btnYes' class="w3-button w3-padding w3-teal w3-hover-green w3-round-small">YES</button>
                    <button id='btnNo' class="w3-button w3-light-grey w3-padding w3-round-small">NO</button>
                </div>
            </footer>
        </div>    
    </div>      <!-- End of Modal Confirm -->  
    

    <!-- Modal Confirm -->
    <div id="modalControlSaveConfirm" class="w3-modal">    
        <div class="w3-modal-content w3-card-4 w3-animate-top c-modal-control">
            <header class="w3-container w3-red c-header-radius">
                <h4 class="w3-center pad-3 c-modal-header">WARNING</h4>
            </header>

            <div class="w3-container w3-margin w3-text-gray" align="center">
                <p class="w3-row-padding">
                    <h6 class="c-modal-content">This path update <b>will affect the whole system</b>. Do you want to proceed?</h6> 
                </p>
            </div>

            <footer class="w3-container w3-red c-footer-radius">
                <div class="w3-center w3-padding">
                    <button id='btnNo' class="w3-button w3-light-grey w3-padding w3-round-small">NO</button>
                    <button id='btnYes' class="w3-button w3-padding w3-hover-none w3-round-small">YES</button>
                </div>
            </footer>
        </div>    
    </div>      <!-- End of Modal Confirm -->    
    

    <!-- Modal Moving Files Info -->
    <div id="modal_movingFilesInfo" class="w3-modal">    
        <div class="w3-modal-content w3-card-4 w3-animate-top c-modal-info">
            <header class="w3-container w3-blue c-header-radius">
                <span class="w3-button w3-display-topright w3-large" 
                    style="padding: 14.5px 20px;border-radius:0 5px 0 0;"
                    onclick="fxCloseModal('modal_movingFilesInfo')">&times;</span>
                <h4 class="pad-3"><i class="fa fa-info-circle w3-xlarge" style="margin-right: 10px;"></i>Moving Files Info</h4>
            </header>

            <div class="w3-container w3-margin w3-text-gray info_modalBody" align="center">
                <!-- <h6 style="font-size: 14px;">Folder named <b>20220311_145622_E212</b> from</h6>
                <h6 style="color: royalblue;">\\157.116.72.26\WebRequest\WRS\Database\2022\20220311_145622_E212</h6>
                <h6 style="font-size: 14px;">will be moved to</h6>
                <h6 style="color: royalblue;">\\157.116.72.26\WebRequest\WRS\PROJECTS\09 Web Development\0022_Web Request System (WRS)\20211206_092833_E212</h6> -->
            </div>

            <!-- <footer class="w3-container w3-blue c-footer-radius">
                <div class="w3-center w3-padding">
                    <button id="btn_ok" class="w3-button w3-light-grey w3-padding w3-round-small">OK</button>
                </div>
            </footer> -->
        </div>    
    </div>      <!-- End of Modal Moving Files Info -->

    <!-- Modal Projects View -->
    <div id="modalProjectsView" class="w3-modal">    
        <div class="w3-modal-content w3-card-4 w3-animate-top c-modal-project-view">
            <header class="w3-container c-dimgray c-header-radius">
                <span class="w3-button w3-display-topright w3-large" 
                        style="padding: 14.5px 20px;border-radius:0 5px 0 0;"
                        onclick="fxCloseModal('modalProjectsView')">&times;</span>
                <h4 class="w3-left pad-3" style="margin-left: 20px;">Projects</h4>
            </header>

            <div class="w3-container w3-margin w3-text-gray">
                <p class="w3-row-padding w3-margin-bottom">
                    <label class="w3-col l12">WRS > PROJECTS > 01 Application</label>
                </p>

                <div class="projectFolders_Jar w3-row-padding">
                    <!-- <div class="w3-row-padding">
                        <label class="w3-col s1 m1 l1">1</label>
                        <label class="w3-col s9 m9 l9">0001_Web Request System</label>
                    </div>
                    <div class="w3-row-padding">
                        <label class="w3-col s1 m1 l1">2</label>
                        <label class="w3-col s9 m9 l9">0002_EE Photo Database</label>
                    </div>
                    <div class="w3-row-padding">
                        <label class="w3-col s1 m1 l1">3</label>
                        <label class="w3-col s9 m9 l9">0003_KDT Portal</label>
                    </div> -->
                    <table class="w3-hoverable" style="width: 100%; margin-bottom: 20px;">
                        <thead>
                            <th style="width: 30px!important; text-align: left; font-weight: bold;">#</th>
                            <th style="text-align: left; font-weight: bold;">File Names</th>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>0001_Web Request System</td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>0002_EE Photo Database</td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>0003_KDT Portal</td>
                            </tr>
                        </tbody>
                    </table>

                </div>      <!-- end of DIV - projectFolders_Jar -->
            </div>      <!-- end of DIV Modal Body Content -->      

        </div>    
    </div>      <!-- End of Modal Projects View -->    
    
  


<!-- END PAGE CONTENT -->
</div>

    <!-- Modal Hard Refresh Page -->
    <div id="modalHardRefresh" class="w3-modal" style="display: none; z-index:2000">
        <div class="w3-modal-content  w3-card-4 c-modal-refresh w3-animate-top">
            <header class="w3-container w3-blue">
                <h4 class="w3-center refresh-firstName">Hello </h4>
            </header>
            <div class="w3-container w3-margin w3-text-gray">
                <!-- <h5 align="center" class="w3-padding-16 w3-text-red"><b>Your Request Access is Disabled</b></h5> -->
                <div align="center" style="margin-top:15px;">
                    <i class="fa fa-smile-o w3-xxxlarge w3-text-blue"></i>
                </div>
                <!-- <h5 align="center" class="w3-padding-16 w3-text-red"><b>Your access on this feature is Disabled</b></h5> -->
                <!-- <h5 align="center" class="w3-padding-16 w3-text-red"><b>Sorry, you don't have access on this feature.</b></h5> -->
                <h5 align="center" class="w3-padding-16 w3-text-blue">Welcome to <b>KDT Web Request System</b></h5>
                <p class="w3-padding">We have an update! Please press <b>CTRL + F5</b> on your keyboard to load the external resources of this page.</p>  
                <p class="w3-padding" style="font-size: 9px;color: orangered;">NOTE: Sometimes you need to do this 2 times.</p>
            </div>
        </div>
    </div>  
    <!-- End of Modal Hard Refresh Page -->  




<script src="js/admin.js"></script>
<script src="js/admin-custom-functions.js"></script>
<script src="js/universal.js"></script>

</body>
</html>
