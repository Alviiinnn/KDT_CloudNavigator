<!doctype html>
<html lang="en">
  <head>
    <title>Agritayo</title>
    <?php include "header.php"; ?>

  </head>

<body>
  <!-- <div class="container">
    <section>
      <video autoplay controls="false"  width="100%">
        <source src="Media/Intro Animation - Web.mp4" type="video/mp4">
      </video>
    </section>
  </div> -->

  <!-- LOGIN SECTION -->

  <section class="page-login">
    <div class="">
      <div class="d-flex justify-content-center">
        <form class="col-10">
          <h1 class="p-5 text-center">Welcome to AgriTayo!</h1>
            <!-- Email input -->
          <div class="form-outline mb-3">
            <label class="form-label" for="form2Example1">Username</label>
            <input type="email" id="form2Example1" class="form-control" />
          </div>
          
          <!-- Password input -->
          <div class="form-outline mb-2">
            <label class="form-label" for="form2Example2">Password</label>
            <input type="password" id="form2Example2" class="form-control" />
          </div>

          <div class="text-end">
            <!-- Simple link -->
            <a id="btn_forgotPass" href="#!" class="">Forgot password?</a>
          </div>
          
          
          <!-- Submit button -->
          <div class="d-grid mx-auto">
            <button id="login" type="button" class="btn btn-success btn-block mt-5 mb-2">Login</button>
          </div>
          
          <!-- Register buttons -->
          <div class="text-center">
            <p >Don't have an account? <a id="registerNow" target="_self" href="#"  >Register Now!</a></p>
          </div>
        </form>
      </div>
    </div>
  </section>


  <!-- REGISTER SECTION -->

  <section class="page-register d-none">
    <div class="d-flex justify-content-center">
      <form id="register" class="col-10" action="profile.php" method="POST">
        <h1 class="pt-5 pb-4 text-center">Registration</h1>
        
        <div class="row mb-3">
          <label class="form-label">Name *</label>
          <input name="firstname" type="text" class="col form-control mx-2" placeholder="First Name"  required/>
          <input name="lastname" type="text" class="col form-control mx-2" placeholder="Last Name"  required/>
        </div>
        
        <div class="row mb-3">
          <label class="form-label" for="">Username *</label>
          <input name="username" type="text" class="col form-control mx-2" placeholder="Create a unique one!"  required/>
        </div>

        <div class="row mb-3">
          <label class="form-label" for="">Phone Number</label>
          <input name="phonenum" type="text" class="col form-control mx-2" placeholder="0912-3456-7890" />
        </div>

        <div class="row mb-3">
          <label class="form-label" for="">Email *</label>
          <input name="email" type="email" class="col form-control mx-2" placeholder="sample@email.com" required/>
        </div>
        
        <div class="row mb-5">
          <label class="form-label" for="">Password *</label>
          <input name="psw1" type="password" class="col form-control mx-2" placeholder="Initial Password" required/>
          <input name="psw2" type="password" class="col form-control mx-2" placeholder="Confirm Password" required/>
        </div>
        
        <div class="d-grid mx-auto">
          <!-- <button id="btn_register" class="btn btn-success " data-bs-toggle="modal" data-bs-target="#myModal">Register</button> -->
          <button id="btn_register" class="btn btn-success" >Register</button>
          <p id="btn_loginInstead" class="mx-auto btn">Login Instead</p>
        </div>
      
      </form>
    </div>
  </section>


  <!-- <div class="home container">

    HOME PAGE
    <div class="row header">
      
      <div class="col-1">
        <img class="col-1" src="Media/Logo.png" />
        <h1>AgriTayo</h1>
      </div>
      
      <div class="col-1">
        <input type="text" class="form-control">
      </div>

      <div class="col-1">
        <p>Aira</p>
        <img />
      </div>

    </div>

    <section class="page-home">
    </section>

  </div> -->




<!-- <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal">
  Open modal
</button> -->


<!-- The Modal -->
<div class="modal fade" id="myModal">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <div class="modal-header">
        <h4 class="modal-title">Saving Confirmation</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">
        Do you want to save your inputs?
      </div>

      <div class="modal-footer justify-content-center">
        <button type="button" class="btn btn-primary px-4">Yes</button>
        <button type="button" class="btn btn-danger px-4" data-bs-dismiss="modal">No</button>
      </div>

    </div>
  </div>
</div>




<script>

  //----- LOGIN PAGE

  $('#registerNow').click(function(){
    $('section.page-login').hide();
    $('section.page-register').removeClass('d-none').hide();
    $('section.page-register').fadeIn();
  });


  $('#login').click(function(){
    var url = "home.html";
    location.href = url;
  });


  $('#btn_forgotPass').click(function(){
    
  });



  //----- REGISTRATION PAGE

  $('#btn_loginInstead').click(function(){
    $('section.page-register').hide();
    $('section.page-login').fadeIn();
  });


  $('#btn_register').click(function(e)
  {
    // e.preventDefault();    

    var boolReady = false;
    var firstname = $('input[name=firstname]').val();
    var lastname = $('input[name=lastname]').val();
    var username = $('input[name=username]').val();
    var num = $('input[name=phonenum]').val();
    var email = $('input[name=email]').val();
    var psw1 = $('input[name=psw1]').val();
    var psw2 = $('input[name=psw2]').val();

    if(psw1 != "" && psw2 != "")
    {
      fnPasswordMatch(psw1, psw2, e);
    }
    
  });


  function fnPasswordMatch(pass1, pass2, e)
  {

    if(pass1 != pass2)
    {
      alert("Password not Match!");
      e.preventDefault();    
    }
    else{
      $('#myModal').show();
      console.log("Password Matched");
    }
  }


</script>

</body>
</html>