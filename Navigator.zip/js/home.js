

$(document).ready(function(){

    fnGet_Uploads();

    function fnGet_Uploads() 
    {
        $.post("./includes/get_data.php",
        {
            table_name: 'tbl_uploads'
        },
        function (data, status) 
        {
            if(status == "success")
            {
                data = JSON.parse(data);
                fnLoad_Home(data);
                console.log(data);
            }
            else{
                console.log("Upload Page: Error on fetching Data from Database");
            }
        });
    }

    function fnLoad_Home(data)
    {


        $.each(data, function(index, value)
        {
            var addItem = "<div class='m-2 w-11'>";
            addItem += "<div class='card'>";
            addItem += "<img src='./Storage/Uploads/"+value.FileNameDB+"' class='card-img-top' alt='...'>";
            addItem += "</div>";
            addItem += "<p class='text-center mb-0'>"+value.FileName+"</p>";
            addItem += "</div>";
            $('.addMoDito').append(addItem);
        });
    }


}); //Document
