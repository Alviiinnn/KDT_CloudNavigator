-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2023 at 09:58 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `navigatordb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_categories`
--

CREATE TABLE `tbl_categories` (
  `ID` int(11) NOT NULL,
  `CategoryName` varchar(255) DEFAULT NULL,
  `CategoryType` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_categories`
--

INSERT INTO `tbl_categories` (`ID`, `CategoryName`, `CategoryType`) VALUES
(1, 'Cement Plant', 'Plant'),
(2, 'Chemical Plant', 'Plant'),
(3, 'FGD Plant', 'Plant'),
(4, 'Oil and Gas', 'Plant'),
(5, 'Power Plant', 'Plant'),
(6, 'ANSHUN POWER PLANT', 'Project'),
(7, 'ANTAM LINE 4', 'Project'),
(8, 'ANTAM Fe-Ni Smelting Project', 'Project'),
(9, 'Butson Cement Plant', 'Project'),
(10, 'CAM PH', 'Project'),
(11, 'Dingzhou Power Plant FGD', 'Project'),
(12, 'Fatima (MFC)', 'Project'),
(13, 'FATIMA 327B62T1', 'Project'),
(14, 'Fe-Ni Smelting Plant', 'Project'),
(15, 'FGD-NEDO ORIGINAL', 'Project'),
(16, 'HALMAHERA', 'Project'),
(17, 'HPA-AN Coal Conversion', 'Project'),
(18, 'Ichthys LNG', 'Project'),
(19, 'KOBE 11', 'Project'),
(20, 'KOMATSU', 'Project'),
(21, 'MCFPP Mindanao Project', 'Project'),
(22, 'MeOH Feed', 'Project'),
(23, 'NIttetsu-Sumikin Cement', 'Project'),
(24, 'NZ UREA', 'Project'),
(25, 'P-11 CEMENT PLANT', 'Project'),
(26, 'SAUDI FGD PLANT(MHI)', 'Project'),
(27, 'SNNC II', 'Project'),
(28, 'SNNC Fe-Ni Smelting Plant (2007)', 'Project'),
(29, 'SNNC Smelting Plant (2006)', 'Project'),
(30, 'Souryu Cement', 'Project'),
(31, 'Sukagawa Project', 'Project'),
(32, 'Taiheiyo', 'Project'),
(33, 'TETOUAN Extension Plant', 'Project'),
(34, 'Thai Binh FGD', 'Project'),
(35, 'Turkmenistan GTG', 'Project'),
(36, 'Turkmenistan in Mary', 'Project'),
(37, 'TURKMENISTAN CEMENT PLANT', 'Project'),
(38, 'Uong Bi FGD Plant', 'Project');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_groups`
--

CREATE TABLE `tbl_groups` (
  `ID` int(11) NOT NULL,
  `GroupCode` varchar(15) NOT NULL,
  `GroupName` varchar(100) NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_groups`
--

INSERT INTO `tbl_groups` (`ID`, `GroupCode`, `GroupName`, `Status`) VALUES
(1, 'ACT', 'Accounting Group', 'Active'),
(2, 'ADM', 'Admin', 'Active'),
(3, 'ANA', 'Analysis Group', 'Active'),
(4, 'ASH', 'Ash Handling Group', 'Active'),
(5, 'CHE', 'Chemical Group', 'Active'),
(6, 'CIV', 'Civil Group', 'Active'),
(7, 'CM', 'Cement Group', 'Active'),
(8, 'CRY', 'Cryogenic Group', 'Active'),
(9, 'ECS', 'Electrical Control System', 'Active'),
(10, 'EE1', 'Electrical Engineering 1 ', 'Active'),
(11, 'EE2', 'Electrical Engineering 2', 'Active'),
(12, 'ENE', 'Energy Group', 'Active'),
(13, 'ENV', 'Environmental Group', 'Active'),
(14, 'ETCL', 'EarthTechnica Co., Ltd. Group', 'Active'),
(15, 'IT', 'IT Group', 'Active'),
(16, 'MCH', 'Machinery Group', 'Active'),
(17, 'MH', 'Material Handling Group', 'Active'),
(18, 'MIL', 'Mill Group', 'Active'),
(19, 'MNG', 'Managerial Group', 'Active'),
(20, 'PIP', 'Piping Group', 'Active'),
(21, 'SYS', 'Systems Group', 'Active'),
(22, 'TEG', 'Tunneling Equipment Group', 'Active'),
(23, 'SHI', 'Ship Group', 'Active'),
(24, 'EE', 'Electrical Engineering Group', 'Active'),
(25, 'INT', 'Inventor Team', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tags`
--

CREATE TABLE `tbl_tags` (
  `ID` int(11) NOT NULL,
  `TagName` varchar(255) DEFAULT NULL,
  `TagType` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_tags`
--

INSERT INTO `tbl_tags` (`ID`, `TagName`, `TagType`) VALUES
(1, 'Coriolis Flowmeter', NULL),
(2, 'Diff. Press.Transmitter  (Capilary tube)', NULL),
(3, 'Differential Pressure Transmitter', NULL),
(4, 'Displacer Type Level Instrument (Servo Type)', NULL),
(5, 'Flow Nozzle', NULL),
(6, 'Gas Analyzer', NULL),
(7, 'Gas Analyzer Density Meter', NULL),
(8, 'Gas Analyzer Infrared and TCD', NULL),
(9, 'Gas Analyzer Paramagnetic Oxygen', NULL),
(10, 'Gas Chromatograph', NULL),
(11, 'Gas Detector (Diffusion Type)', NULL),
(12, 'Hydrastep Level Meter', NULL),
(13, 'Infrared Analyzer', NULL),
(14, 'Interface Level Meter Gauge', NULL),
(15, 'Interface Level Meter Transmitter', NULL),
(16, 'K Thermocouple & Transmitter (Head Mounted)', NULL),
(17, 'K Thermocouple & Transmitter (Multi Point)', NULL),
(18, 'K Thermocouple & Transmitter (Remote)', NULL),
(19, 'Level Gauge', NULL),
(20, 'Liquid Analyzer Conductivity meter', NULL),
(21, 'Liquid Analyzer pH meter', NULL),
(22, 'Local Elect Receiver Indicator', NULL),
(23, 'N Thermocouple & Transmitter (Head Mounted)', NULL),
(24, 'N Thermocouple & Transmitter (Remote)', NULL),
(25, 'Orifice', NULL),
(26, 'Pressure Gauge', NULL),
(27, 'Pressure Switch', NULL),
(28, 'Pressure Transmitter', NULL),
(29, 'Pressure Transmitter (Capilary tube)', NULL),
(30, 'Radar Type Level Instrument', NULL),
(31, 'Temperature Gauge', NULL),
(32, 'Temperature Sensor (Infrared Television System)', NULL),
(33, 'Ultrasonic Flowmeter (Gas)', NULL),
(34, 'Ultrasonic Flowmeter (Liquid)', NULL),
(35, 'Variable Area Flowmeter', NULL),
(36, 'Venturi Tube', NULL),
(37, 'Vortex Flowmeter', NULL),
(38, 'Zirconia Oxygen', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_uploads`
--

CREATE TABLE `tbl_uploads` (
  `ID` int(11) NOT NULL,
  `FileName` varchar(100) DEFAULT NULL,
  `FileNameDB` varchar(50) DEFAULT NULL,
  `DateUploaded` date DEFAULT NULL,
  `Uploader` varchar(20) DEFAULT NULL,
  `FileType` varchar(10) DEFAULT NULL,
  `FileSize` int(11) DEFAULT NULL,
  `Status` varchar(30) DEFAULT NULL,
  `Tags` varchar(1000) DEFAULT NULL,
  `Categories` varchar(500) DEFAULT NULL,
  `PlantType` varchar(50) DEFAULT NULL,
  `ProjectName` varchar(200) DEFAULT NULL,
  `BusinessUnit` varchar(10) DEFAULT NULL,
  `Notes` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_uploads`
--

INSERT INTO `tbl_uploads` (`ID`, `FileName`, `FileNameDB`, `DateUploaded`, `Uploader`, `FileType`, `FileSize`, `Status`, `Tags`, `Categories`, `PlantType`, `ProjectName`, `BusinessUnit`, `Notes`) VALUES
(2, 'Pressure Gauge.png', '20230419_170222_1103_E466.png', '2023-04-19', 'alvinjohn', 'png', 57792, 'For Checking', '[\"Flow Nozzle\"]', '[\"Power Plant\"]', NULL, NULL, 'CIV', ''),
(3, 'sdf.jfif', '20230419_171707_8003_E466.jfif', '2023-04-19', 'alvinjohn', 'jfif', 10175, 'For Checking', '[\"Coriolis Flowmeter\"]', 'Categories', 'Oil and Gas', 'ANTAM LINE 4', 'ADM', ''),
(4, '8.png', '20230419_171707_4078_E466.png', '2023-04-19', 'alvinjohn', 'png', 57792, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(5, '9.png', '20230419_171707_8673_E466.png', '2023-04-19', 'alvinjohn', 'png', 293386, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(6, 'sql.txt', '20230420_075053_3611_E466.txt', '2023-04-20', 'alvinjohn', 'txt', 2079, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(7, 'sdf.png', '20230420_075830_1918_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'For Checking', '[\"Gas Analyzer\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ANA', ''),
(8, 'sdf.png', '20230420_075830_8269_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'For Checking', '[\"Gas Analyzer\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ANA', ''),
(9, '8.png', '20230420_131455_5432_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(10, '9.png', '20230420_131455_4541_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(11, '7.jfif', '20230420_133446_8374_E466.jfif', '2023-04-20', 'alvinjohn', 'jfif', 10175, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(12, '8.png', '20230420_133446_5351_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(13, '9.png', '20230420_133446_6771_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(14, 'fdg.png', '20230420_134012_2424_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'For Checking', '[\"Coriolis Flowmeter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'CIV', ''),
(15, '11.jfif', '20230420_134012_4358_E466.jfif', '2023-04-20', 'alvinjohn', 'jfif', 17144, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(16, 'sdf.jfif', '20230420_134456_4129_E466.jfif', '2023-04-20', 'alvinjohn', 'jfif', 10175, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(17, 'sdf.png', '20230420_134456_1566_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(18, 'sfd.png', '20230420_134531_1399_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(19, '9.png', '20230420_134531_9449_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(20, '10.png', '20230420_134531_8537_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(21, '654.jfif', '20230420_135253_1992_E466.jfif', '2023-04-20', 'alvinjohn', 'jfif', 10175, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ADM', ''),
(22, '8.png', '20230420_135253_0141_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(23, '9.png', '20230420_135253_5801_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(24, 'sdf.png', '20230420_135322_6278_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'For Checking', '[\"Displacer Type Level Instrument (Servo Type)\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(25, '9.png', '20230420_135322_3584_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(26, '10.png', '20230420_135322_5267_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(27, '654.png', '20230420_135421_7007_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(28, '9.png', '20230420_135421_6284_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(29, '10.png', '20230420_135421_0947_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(30, '654.png', '20230420_135505_3327_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(31, '9.png', '20230420_135505_8179_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(32, '10.png', '20230420_135505_0440_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(33, '11.jfif', '20230420_135505_0059_E466.jfif', '2023-04-20', 'alvinjohn', 'jfif', 17144, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(34, '654.png', '20230420_135531_6359_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'For Checking', '[\"Flow Nozzle\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(35, '10.png', '20230420_135531_0300_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(36, 'sdf.png', '20230420_135613_5644_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(37, '10.png', '20230420_135613_4180_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(38, '11.jfif', '20230420_135613_1171_E466.jfif', '2023-04-20', 'alvinjohn', 'jfif', 17144, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(39, '12.jfif', '20230420_135613_2937_E466.jfif', '2023-04-20', 'alvinjohn', 'jfif', 13552, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(40, 'df.png', '20230420_135655_3946_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(41, 'df.png', '20230420_135655_7076_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(42, '10.png', '20230420_135655_7134_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(43, 'sdf.png', '20230420_135720_1671_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(44, '10.png', '20230420_135720_3757_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(45, '11.jfif', '20230420_135720_5970_E466.jfif', '2023-04-20', 'alvinjohn', 'jfif', 17144, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(46, 'igh.png', '20230420_142944_1518_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'For Checking', '[\"Coriolis Flowmeter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(47, 'igh.png', '20230420_142944_2919_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'For Checking', '[\"Coriolis Flowmeter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(48, 'igh.png', '20230420_142944_5647_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'For Checking', '[\"Coriolis Flowmeter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(49, '8.png', '20230420_143130_5348_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(50, '9.png', '20230420_143130_0969_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(51, '10.png', '20230420_143130_7036_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(52, 'sdf.png', '20230420_144034_2420_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'For Checking', '[\"Gas Analyzer Paramagnetic Oxygen\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'CHE', ''),
(53, '9.png', '20230420_144034_9569_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(54, '10.png', '20230420_144034_5274_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(55, '11.jfif', '20230420_144034_2777_E466.jfif', '2023-04-20', 'alvinjohn', 'jfif', 17144, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(56, 'klh.png', '20230420_144114_3643_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(57, 'klh.png', '20230420_144114_3384_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(58, 'klh.png', '20230420_144114_2045_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(59, '8.png', '20230420_144157_1500_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(60, '9.png', '20230420_144157_3534_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(61, '10.png', '20230420_144157_2010_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(62, '654.png', '20230420_144345_7218_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(63, '654.png', '20230420_144345_1636_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(64, '10.png', '20230420_144345_7396_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(65, '654.jfif', '20230420_144345_4524_E466.jfif', '2023-04-20', 'alvinjohn', 'jfif', 17144, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(66, '654.png', '20230420_144412_5933_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'For Checking', '[\"Displacer Type Level Instrument (Servo Type)\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(67, '654.png', '20230420_144412_9427_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'For Checking', '[\"Displacer Type Level Instrument (Servo Type)\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(68, '654.png', '20230420_144412_4566_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'For Checking', '[\"Displacer Type Level Instrument (Servo Type)\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(69, '654.jfif', '20230420_144412_2983_E466.jfif', '2023-04-20', 'alvinjohn', 'jfif', 17144, 'For Checking', '[\"Displacer Type Level Instrument (Servo Type)\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(70, '8.png', '20230420_144438_9059_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(71, '9.png', '20230420_144438_7644_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(72, 'sdf.png', '20230420_144438_8179_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(73, '7.jfif', '20230420_144538_8133_E466.jfif', '2023-04-20', 'alvinjohn', 'jfif', 10175, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(74, '654.png', '20230420_144538_2111_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(75, '654.png', '20230420_144538_3250_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(76, '654.png', '20230420_144538_0506_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Cement Plant', 'ANSHUN POWER PLANT', 'ACT', ''),
(77, '7.jfif', '20230420_144805_6306_E466.jfif', '2023-04-20', 'alvinjohn', 'jfif', 10175, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(78, '8.png', '20230420_144935_3740_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(79, '9.png', '20230420_144935_2348_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(80, '10.png', '20230420_144935_1443_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(81, '11.jfif', '20230420_144935_6908_E466.jfif', '2023-04-20', 'alvinjohn', 'jfif', 17144, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(82, '8.png', '20230420_144940_6534_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(83, '9.png', '20230420_144940_9297_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(84, '10.png', '20230420_144940_0638_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(85, '8.png', '20230420_145009_5297_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(86, 'sample Value.png', '20230420_145009_7453_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Plant Type na naselect', 'Project Name na naselect', 'SYS', ''),
(87, '9.png', '20230420_145123_5284_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(88, 'sample Value.png', '20230420_145123_7104_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'For Checking', '[\"Gas Analyzer\"]', 'Categories', 'Plant Type na naselect', 'Project Name na naselect', 'SYS', ''),
(89, 'sample Value.png', '20230420_145850_4013_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'For Checking', '[\"Flow Nozzle\"]', 'Categories', 'Plant Type na naselect', 'Project Name na naselect', 'SYS', ''),
(90, '9.png', '20230420_145850_3663_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(91, 'sample Value.png', '20230420_145850_7345_E466.png', '2023-04-20', 'alvinjohn', 'png', 37875, 'For Checking', '[\"Flow Nozzle\"]', 'Categories', 'Plant Type na naselect', 'Project Name na naselect', 'SYS', ''),
(92, 'sample Value.png', '20230420_150230_0498_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'For Checking', '[\"Diff. Press.Transmitter  (Capilary tube)\"]', 'Categories', 'Plant Type na naselect', 'Project Name na naselect', 'SYS', ''),
(93, '7.jfif', '20230420_151326_5164_E466.jfif', '2023-04-20', 'alvinjohn', 'jfif', 10175, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(94, '8.png', '20230420_151326_6420_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(95, 'sample Value.png', '20230420_151326_9093_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'For Checking', '[\"Flow Nozzle\"]', 'Categories', 'Plant Type na naselect', 'Project Name na naselect', 'SYS', ''),
(96, 'sample Value.png', '20230420_151500_8809_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'For Checking', '[\"Gas Analyzer Density Meter\"]', 'Categories', 'Plant Type na naselect', 'Project Name na naselect', 'SYS', ''),
(97, 'sample Value.png', '20230420_151500_8979_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'For Checking', '[\"Gas Analyzer Density Meter\"]', 'Categories', 'Plant Type na naselect', 'Project Name na naselect', 'SYS', ''),
(98, '8.png', '20230420_153048_9330_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(99, '9.png', '20230420_153048_0354_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(100, '8.png', '20230420_154359_6788_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(101, 'sample Value.png', '20230420_154359_3786_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'For Checking', '[\"Gas Analyzer Density Meter\"]', 'Categories', 'Plant Type na naselect', 'Project Name na naselect', 'SYS', ''),
(102, 'sample Value.jfif', '20230420_155007_8667_E466.jfif', '2023-04-20', 'alvinjohn', 'jfif', 10175, 'For Checking', '[\"Flow Nozzle\"]', 'Categories', 'Plant Type na naselect', 'Project Name na naselect', 'SYS', ''),
(103, 'sample Value.png', '20230420_155007_5314_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'For Checking', '[\"Flow Nozzle\"]', 'Categories', 'Plant Type na naselect', 'Project Name na naselect', 'SYS', ''),
(104, '8.png', '20230420_155306_1534_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(105, 'sample Value.png', '20230420_155306_7289_E466.png', '2023-04-20', 'alvinjohn', 'png', 293386, 'For Checking', '[\"Diff. Press.Transmitter  (Capilary tube)\"]', 'Categories', 'Plant Type na naselect', 'Project Name na naselect', 'SYS', ''),
(106, '7.jfif', '20230420_155628_4278_E466.jfif', '2023-04-20', 'alvinjohn', 'jfif', 10175, 'Waiting to Tag', 'Tags', 'Categories', NULL, NULL, 'Group', NULL),
(107, 'sample Value.png', '20230420_155628_9650_E466.png', '2023-04-20', 'alvinjohn', 'png', 57792, 'For Checking', '[\"Differential Pressure Transmitter\"]', 'Categories', 'Plant Type na naselect', 'Project Name na naselect', 'SYS', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_categories`
--
ALTER TABLE `tbl_categories`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_groups`
--
ALTER TABLE `tbl_groups`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_tags`
--
ALTER TABLE `tbl_tags`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_uploads`
--
ALTER TABLE `tbl_uploads`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_categories`
--
ALTER TABLE `tbl_categories`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tbl_groups`
--
ALTER TABLE `tbl_groups`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tbl_tags`
--
ALTER TABLE `tbl_tags`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tbl_uploads`
--
ALTER TABLE `tbl_uploads`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
