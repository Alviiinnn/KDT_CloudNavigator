<?php

require "connect.php";

$table = $_POST['table_name'];
$arrResult = array();

$sql = "SELECT * FROM $table";
$result = $conn->query($sql);



if ($result->num_rows > 0) {
    // output data of each row
    while ($row = $result->fetch_assoc()) 
    {
        array_push($arrResult, $row);
    }
} 
else {
    echo "0 results";
}

echo json_encode($arrResult);
$conn->close();


?>