<?php

// --- VARIABLES ---
// $arrFileDB   - from "uploadFiles.php"
// -----------------

$cookie_name = "uploadedFiles";
$cookie_value = json_encode($arrFileDB);
setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day

?>