<?php
    date_default_timezone_set("Asia/Manila");

    require "connect.php";
    require "uploadFiles.php";



    $sql = "INSERT INTO tbl_uploads (FileName, FileNameDB, DateUploaded, Uploader, FileType, FileSize, Status, Tags, Categories, BusinessUnit) VALUES ";
    $datengayon = date("Y/m/d");

    for($ctr = 0; $ctr < count($arrFileNames); $ctr++)
    {
        $fileExt = pathinfo($arrFileNames[$ctr], PATHINFO_EXTENSION);
        
        if($ctr == count($arrFileNames)-1){
            $sql .= "('$arrFileNames[$ctr]', '$arrFileDB[$ctr]', '$datengayon', 'alvinjohn', '$fileExt', '$arrFileSizes[$ctr]', 'Waiting to Tag', 'Tags', 'Categories', 'Group')";
        }else{
            $sql .= "('$arrFileNames[$ctr]', '$arrFileDB[$ctr]', '$datengayon', 'alvinjohn', '$fileExt', '$arrFileSizes[$ctr]', 'Waiting to Tag', 'Tags', 'Categories', 'Group'), ";
        }
    }

    echo "<br><br>".$sql;


    if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
?>




