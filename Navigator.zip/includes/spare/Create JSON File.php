<?php

require "connect.php";

$arrResult = array();

$sql = "SELECT * FROM tbl_tags";
$result = $conn->query($sql);
$posts = $result->fetch_all(MYSQLI_ASSOC);

file_put_contents('../data/newlyUploaded.json', json_encode($arrFileDB));

$conn->close();


// $sql="select * from Posts limit 20"; 
// $result = $db->query($sql);
// $posts = $result->fetch_all(MYSQLI_ASSOC);


// echo json_encode($posts);
// // or
// $response = json_encode([
//     'posts' => $posts,
// ]);


// file_put_contents('myfile.json', json_encode($posts));



?>