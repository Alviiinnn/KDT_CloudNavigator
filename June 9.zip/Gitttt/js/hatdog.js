// NOTE: Always hard refresh the page when updates were made





var arrAddedTags = new Array();
var arrAddedCategories = new Array();
var arrAddedPhotoTags = new Array();
var arrWaitingToTag = new Array();
var arrWaitingToTag_Photos = new Array();
var arrQueue_Tagging = new Array();
var arrNew_Pictures = new Array();  //For Photo Tagging - Newly Uploaded (Pictures Only)
var arrQueue_PhotoTagging = new Array();
var arrUploadedNames = new Array();
var arrGeneratedNames = new Array();
var data_AllUploads = new Array();
var data_Groups = new Array();
var data_Tags = new Array();
var data_Categories = new Array();
var id_selected = "";
var photoTagging_isActive = false;
var picture_types = ['jpg', 'jpeg', 'png', 'jfif', 'gif'];
var current_tag;
var current_photoTag;




$(document).ready(function () {

    let saving_row = false;
    let saving_uploaded = false;

    $('.vin-main').fadeIn();

    $(document).on('click', 'button[data-btn-tag]', function () {
        id_selected = $(this).data('id');   //LOCKED! Don't move this in other line
        saving_row = true;

        let name = $(this).data('filename');
        let status = fnGet_Data_AllUploads(id_selected, "Status");

        fnReset_FileTaggingModal();

        $('[data-modal-filename], #photoTag_rawName').text(name);
        $('#ctr_fileTagging, #ctr_photoTagging').hide();
        $('#nextTag, #next_photoTag').hide();
        $('#prevTag, #prev_photoTag').hide();
        // $('#imgTag').attr('src', 'Storage/Uploads/' + id_selected);  // 1
        $('[data-modal-fileExtension], #photoTag_fileExtension').text("." + fnGet_FileExtension(name));
        $('[data-select-planttype], [data-select-projectname]').val('default');

        fnCheck_FileType(id_selected);

        if (status == "For Checking") {
            fnLoad_ForChecking(id_selected);
        }
        else {
            $('#btn_saveFileTag').text("Save to Review");
        }
    }); //Document File Tagging: btn-tag



    $(document).on('click', 'button[data-btn-delete]', function () {

        if (confirm("Are you sure to delete?")) {
            let id = $(this).parent().find('button').data('id');

            $.post("includes/delete.php",
                {
                    request: "Delete_Uploaded",
                    clientID: id
                },
                function (data, status) {
                    console.log(status);
                    console.log(data);

                    if (data.includes('Success')) {
                        location.reload();
                        // window.location.href = "";
                        // $('#tbl_uploads').DataTable().ajax.reload();
                    }
                });
        } else {
            console.log("Cancelled");
        }
    }); //Document File Tagging: btn-delete



    $(document).on('click', '[data-remove-cat]', function () {
        $(this).parent().fadeOut('slow', function () {
            this.remove();
        });

        var cat = $(this).parent().text();
        arrAddedCategories.splice(arrAddedCategories.indexOf(cat), 1);  //removes item from Array
    }); //Document remove-cat



    $(document).on('click', '[data-remove-tag]', function () {
        $(this).parent().fadeOut('slow', function () {
            this.remove();
        });

        var tag = $(this).parent().text();
        arrAddedTags.splice(arrAddedTags.indexOf(tag), 1);  //removes item from Array
    }); //Document remove-tag



    $(document).on('click', '[data-remove-phototag]', function () {
        $(this).parent().fadeOut('slow', function () {
            this.remove();
        });

        var phototag = $(this).parent().text();
        arrAddedPhotoTags.splice(arrAddedPhotoTags.indexOf(phototag), 1);  //removes item from Array
    }); //Document remove-phototag








    // --- EVENTS ---

    const _tbl_UploadsID = "#tbl_uploads";

    $(_tbl_UploadsID).DataTable({
        paging: false,
        info: true,
        searching: true,
        ordering: true,
        columnDefs: [
            {
                orderable: false,
                targets: -1
            }
        ]
    });


    fnLoadDefaults();
    fnGet_Uploads();
    fnRead_URL();

    $('#btn_upload').click(function () {
        $('input[type=file]').trigger('click');
    });


    $('input[name^=files]').change(function () {

        const uploaded_files = this.files;

        // fnAddRows(_tbl_UploadsID, uploaded_files);
        // console.log(uploaded_files[0]);

        $('#formUploads').submit();
    });


    $('.kamay').hover(function () {
        $(this).not('.active').addClass('fw-semibold');
        $(this).not('.active').removeClass('text-secondary');
    }, function () {
        $(this).not('.active').removeClass('fw-semibold');
        $(this).not('.active').addClass('text-secondary');
    });


    $('.nav-profile').click(function () {
        window.location.href = "./Profile";
    });


    $('.nav-upload').click(function () {
        window.location.href = "./Uploads";
    });


    $('#nextTag').click(function () {
        fnLoad_NextTag();
    });


    $('#prevTag').click(function () {
        fnLoad_PrevTag();
    });


    $('#btn_waiting2tag').click(function () {
        fnLoad_WaitingToTag();
        fnLoad_PhotoTagging();
    });


    $('#btn_saveFileTag').click(function () {
        
        fnSave_FileTagging();
    });


    $('#btn_savePhotoTag').click(function () {
        fnSave_PhotoTagging();
    });


    $('input[name=list_categories]').on('change', function (e) {
        var val = this.value;
        if (val) {
            fnAddCategories(val);
        }
        else {
            console.log("empty");
        }
    });


    $('input[name=list_tags]').on('change', function (e) {
        var val = this.value;
        if (val) {
            fnAddTags(val);
        }
        else {
            console.log("empty");
        }
    });


    $('input[name=list_photoTags]').change(function () {
        var val = this.value;
        if (val) {
            fnAdd_PhotoTags(val);
        } else {
            console.log("empty");
        }
    });


    $('input, select').focus(function () {
        $(this).removeClass('border-danger');
    });


    $('#next_photoTag').click(function () {
        fnLoad_NextPhotoTag();
    });


    $('#prev_photoTag').click(function () {
        fnLoad_PrevPhotoTag();
    });


    $('[data-bs-closemodal]').click(function(){
        $('#prevTag, #prev_photoTag').hide();
        arrAddedTags = [];  //resets array
        saving_row = false;
        saving_uploaded = false;
    });









    // --- CUSTOM FUNCTIONS ---

    function fnLoadDefaults() {
        $('.dataTables_filter').addClass('mb-3');
        fnGet_Groups();
        fnGet_Categories();
        fnGet_Tags();
    }


    function fnAddRows(tableID, data) {
        var tbl = $(tableID).DataTable();
        var checker = $(tableID + ' td').html();
        var ctr = (checker == "No data available in table") ? 1 : $(tableID + ' tr').length;

        var d = new Date();
        var day = d.getFullYear() + "/" + (d.getMonth() + 1) + "/" + d.getDate();
        var formatted_date = fnDateFormat(day);


        $.each(data, function (index, value) {
            index += ctr;

            var rowNode = tbl
                .row.add(
                    [
                        index,
                        value.name,
                        formatted_date,
                        'Waiting to Tag',
                        '<button class="btn">Tag</button><button class="btn" data-btn-delete>Delete</button>'
                    ]
                )
                .draw()
                .node();

            // $(rowNode)
            //     .css('color', 'red')
            //     .animate({ color: 'black' });
        });

    } //fnAddRows()


    function fnDateFormat(data) {
        try {
            data = data.split("-");
            var month = parseInt(data[1]);

            switch (month) {
                case 1: month = "Jan."; break;
                case 2: month = "Feb."; break;
                case 3: month = "Mar."; break;
                case 4: month = "Apr."; break;
                case 5: month = "May."; break;
                case 6: month = "June."; break;
                case 7: month = "July."; break;
                case 8: month = "Aug."; break;
                case 9: month = "Sept."; break;
                case 10: month = "Oct."; break;
                case 11: month = "Nov."; break;
                case 12: month = "Dec."; break;
                default: month = "Month";
            }

            var date = month + " " + data[2] + ", " + data[0];

        } catch (error) {
            alert(error + "\nfnDateFormat");
        }

        return date;
    }



    function fnGet_Uploads() {
        $.post("./includes/get_data.php",
            {
                table_name: 'tbl_uploads'
            },
            function (data, status) {
                if (status == "success") {
                    data = (data == "0 results") ? "" : JSON.parse(data);
                    data_AllUploads = data;
                    fnLoad_UploadsTbl(data);
                }
                else {
                    console.log("Upload Page: Error on fetching Data from Database");
                }
            });
    }


    function fnLoad_UploadsTbl(data) {
        const tableID = _tbl_UploadsID;
        
        var tbl = $(tableID).DataTable();
        var checker = $(tableID + ' td').html();
        var ctr = (checker == "No data available in table") ? 1 : $(tableID + ' tr').length;
        var waiting2tag_ctr = 0;

        $.each(data, function (index, value) {
            index += ctr;
            let date_value = fnDateFormat(value.DateUploaded);
            let action = "";
            let modal = "modal_fileTagging";
            if (value.Status == "For Checking") 
            {
                action = "Retag";
                let isPhotoDB = parseInt(value.forPhotoDB);

                if(isPhotoDB){
                    modal = "modal_photoTagging";
                }
            } else {
                action = "Tag";
            }

            var rowNode = tbl
                .row.add(
                    [
                        index,
                        value.FileName,
                        date_value,
                        value.Status,
                        `<button class="btn" data-btn-tag data-id="${value.FileNameDB}" data-filename="${value.FileName}" data-bs-target="#${modal}" data-bs-toggle="modal">${action}</button><button class="btn" data-btn-delete>Delete</button>`
                    ]
                )
                .draw()
                .node();

            // $(rowNode)
            //     .css('color', 'red')
            //     .animate({ color: 'black' });

            if (value.Status == "Waiting to Tag") {
                waiting2tag_ctr++;
                arrWaitingToTag.push([value.FileNameDB, value.FileName]);

                var photoTypes = picture_types;

                if (~photoTypes.indexOf(fnGet_FileExtension(value.FileNameDB))) {   //~ represents skip -1 occurence
                    arrWaitingToTag_Photos.push([value.FileNameDB, value.FileName]);    //stores data for Photo Tagging
                }
            }

        });


        if (waiting2tag_ctr) {
            $('#btn_waiting2tag').show();
            $('[data-waiting2tag]').text(waiting2tag_ctr);
        }
        else {
            $('[data-waiting2tag]').parent().parent().hide();
            $('#btn_waiting2tag').hide();
        }
    }


    function fnAddCategories(value) {
        const index = arrAddedCategories.indexOf(value);
        if (index > -1) {
            alert("Item already added");
        }
        else {
            arrAddedCategories.push(value);
            $('#category_container').append('<div class="d-flex align-items-center rounded-pill border bg-white m-1 py-1 ps-3 pe-1 fs-7 added-tag" style="display:none;"><p class="mb-0"></p>' + value + '<i class="bi bi-x-lg fs-7 kamay px-1" data-remove-cat></i></div>');
            // $('#category_container div.added-tag').slideDown('slow');
            $('#category_container div.added-tag').fadeIn('slow');
            $('#category_container div.added-tag').removeClass('added-tag');

            $('input[name=list_categories]').val("");
        }
    }


    function fnAddTags(value) {
        const index = arrAddedTags.indexOf(value);
        if (index > -1) {
            alert("Item already added");
        }
        else {
            arrAddedTags.push(value);
            $('#tags_container').append('<div class="d-flex align-items-center rounded-pill border bg-white m-1 py-1 ps-3 pe-1 fs-7 added-tag" style="display:none;"><p class="mb-0"></p>' + value + '<i class="bi bi-x-lg fs-7 kamay px-1" data-remove-tag></i></div>');
            $('#tags_container div.added-tag').fadeIn('slow');
            $('#tags_container div.added-tag').removeClass('added-tag');
            $('input[name=list_tags]').val("");
        }
    }


    function fnAdd_PhotoTags(value) {
        const index = arrAddedPhotoTags.indexOf(value);
        if (index > -1) {
            alert("Item already added");
        } else {
            arrAddedPhotoTags.push(value);
            $('#photoTags_container').append('<div class="d-flex align-items-center rounded-pill border bg-white m-1 py-1 ps-3 pe-1 fs-7 added-tag" style="display:none;"><p class="mb-0"></p>' + value + '<i class="bi bi-x-lg fs-7 kamay px-1" data-remove-phototag></i></div>');
            $('#photoTags_container div.added-tag').fadeIn('slow');
            $('#photoTags_container div.added-tag').removeClass('added-tag');
            $('input[name=list_photoTags]').val("");
        }
    }


    function fnGet_Groups() {
        $.post("./includes/get_data.php",
            {
                table_name: 'tbl_groups'
            },
            function (data, status) {
                if (status == "success") {
                    data = JSON.parse(data);
                    data_Groups = data;
                    fnLoad_Groups(data);
                }
                else {
                    console.log("Upload Page: Error on fetching Data from Database");
                }
            });
    }




    function fnLoad_Groups(data) {
        const arrGroups = [];

        $.each(data, function (index, value) {
            arrGroups.push([value.GroupCode, value.GroupCode + " - " + value.GroupName]);
        });

        arrGroups.sort();

        $.each(arrGroups, function (index, value) {
            $('#file_group').append($('<option>', {
                value: value[0],
                text: value[1]
            }));
        });

        $.each(arrGroups, function (index, value) {
            $('select[data-dropdown-groups-photoTag]').append($('<option>', {
                value: value[0],
                text: value[1]
            }));
        });
    }


    function fnGet_Categories() {
        $.post("./includes/get_data.php",
            {
                table_name: 'tbl_categories'
            },
            function (data, status) {
                if (status == "success") {
                    data = JSON.parse(data);
                    data_Categories = data;
                    fnLoad_Categories(data);
                }
                else {
                    console.log("Upload Page: Error on fetching Data from Database");
                }
            });
    }


    function fnLoad_Categories(data) {
        $.each(data, function (index, value) {
            if (value.CategoryType == "Plant") {
                $('select[data-select-plantType]').append($('<option>', {
                    value: value.CategoryName,
                    text: value.CategoryName
                }));
            }
            else {
                $('select[data-select-projectName]').append($('<option>', {
                    value: value.CategoryName,
                    text: value.CategoryName
                }));
            }

            $('datalist[data-list-categories]').append($('<option>', {
                value: value.CategoryName
            }));
        });
    }



    function fnGet_Tags() {
        $.post("./includes/get_data.php",
            {
                table_name: 'tbl_tags'
            },
            function (data, status) {
                if (status == "success") {
                    data = JSON.parse(data);
                    data_Tags = data;
                    fnLoad_Tags(data);
                }
                else {
                    console.log("Upload Page: Error on fetching Data from Database");
                }
            });
    }


    function fnLoad_Tags(data) {
        $.each(data, function (index, value) {
            $('datalist[data-list-tags]').append($('<option>', {
                value: value.TagName,
            }));
        });
    }


    function fnRead_Cookies() {
        $.get("includes/cookie.php",
            function (data, status) {
                if (status == "success") {
                    data = JSON.parse(data);

                    arrGeneratedNames = [];
                    $.each(data, function (index, value) {
                        arrGeneratedNames.push(value);
                    });

                    fnLoad_TaggingQueue();
                    fnLoad_PhotoTagging_NewUpload();


                } else {
                    console.log("\nfnRead_Cookies() Failed");
                }
            });
    }



    function fnGet_FileExtension(data) {
        var regex = /(?:\.([^.]+))?$/;
        var ext = regex.exec(data)[1];

        return ext;
    }




    function fnLoad_TaggingQueue() {
        current_tag = 0;
        arrUploadedNames = [];
        saving_uploaded = true;

        const len = arrGeneratedNames.length;
        id_selected = arrGeneratedNames[current_tag];
        
        if (len == 1) {
            $('#nextTag').hide();
            $('#prevTag').hide();
        }

        $.each(arrGeneratedNames, function (index, value) {
            let a = value;
            $.each(arrWaitingToTag, function (index, value) {
                if (a == value[0]) {
                    arrUploadedNames.push(value[1]);
                    return false; //breaks loop
                }
            });
        });

        arrQueue_Tagging = arrUploadedNames;

        // $('#btn_fileTag_switcher').hide();  //DO NOT REMOVE THIS! COZ IT MAY CAUSE A BUG!
        $('#ctr_fileTagging').text("1/" + len);
        $('[data-modal-filename').text(arrUploadedNames[current_tag]);
        $('[data-modal-fileExtension]').text("." + fnGet_FileExtension(arrGeneratedNames[current_tag]));

        fnCheck_FileType(arrGeneratedNames[current_tag]);
    }


    function fnLoad_NextTag() {
        const len = arrGeneratedNames.length;

        $('#prevTag').show();

        if (current_tag + 1 == len - 1) {
            $('#nextTag').hide();
        }
        else {
            $('#nextTag').show();
        }

        current_tag++;  //LOCKED!
        id_selected = arrGeneratedNames[current_tag];
        $('[data-modal-filename').text(arrUploadedNames[current_tag]);
        $('#ctr_fileTagging').text((current_tag + 1) + "/" + len);
        $('#imgTag').attr('src', 'Storage/Uploads/' + arrGeneratedNames[current_tag]);
        $('[data-modal-fileExtension]').text("." + fnGet_FileExtension(arrUploadedNames[current_tag]));

        // Hide/Show in Next/Prev Event
        // $('#btn_fileTag_switcher').hide();
        $('.alvin_maximize').hide();
        $('#filetag_video').hide();
        $('#imgTag').show();

        fnCheck_FileType(arrGeneratedNames[current_tag]);
    }


    function fnLoad_PrevTag() {
        const len = arrGeneratedNames.length;


        $('#nextTag').show();

        if (current_tag - 1 == 0) {
            $('#prevTag').hide();
        }
        else {
            $('#prevTag').show();
        }
        current_tag--;
        id_selected = arrGeneratedNames[current_tag];

        $('[data-modal-filename').text(arrUploadedNames[current_tag]);
        $('#ctr_fileTagging').text((current_tag + 1) + "/" + len);
        $('#imgTag').prop('src', 'Storage/Uploads/' + arrGeneratedNames[current_tag]);
        $('[data-modal-fileExtension]').text("." + fnGet_FileExtension(arrUploadedNames[current_tag]));

        // Hide/Show in Next/Prev Event
        // $('#btn_fileTag_switcher').hide();
        $('.alvin_maximize').hide();
        $('#filetag_video').hide();
        $('#imgTag').show();

        fnCheck_FileType(arrGeneratedNames[current_tag]);
    }




    function fnCheck_FileType(data) {
        let fileExtension = fnGet_FileExtension(data);
        let match = "";

        var photos = picture_types;
        var documents = ['pdf', 'xlsx', 'ppt', 'pptx', 'doc', 'docx', 'txt'];
        var videos = ['mp4', 'avi', 'wmv'];

        fn(photos, 'photos');
        fn(documents, 'documents');
        fn(videos, 'videos');

        function fn(type, name)    // function inside
        {
            $.each(type, function (index, value) {

                if (fileExtension == value) {
                    match = name;
                    return false;
                }
            });
        }

        switch (match) {
            case "photos": fnLoad_FileTagging_Photos(); break;
            case "documents": fnLoad_FileTagging_Documents(fileExtension); break;
            case "videos": fnLoad_FileTagging_Videos(); break;
            default: fnLoad_FileTagging_Others();
        }
    }


    function fnLoad_WaitingToTag() {
        fnReset_FileTaggingModal();
        arrQueue_Tagging = arrWaitingToTag;

        arrUploadedNames = [];
        arrGeneratedNames = [];
        current_tag = 0;
        id_selected = arrWaitingToTag[0][0];

        $.each(arrWaitingToTag, function (index, value) {
            arrUploadedNames.push(value[1]);
            arrGeneratedNames.push(value[0]);
        });

        if (arrWaitingToTag.length == 1) {
            $('#nextTag').hide();
            $('#prevTag').hide();
        } else {
            $('#nextTag').show();
        }

        $('.alvin_maximize').hide();
        // $('#btn_fileTag_switcher').hide();
        $('#ctr_fileTagging').show();
        $('[data-modal-filename').text(arrWaitingToTag[0][1]);
        $('#imgTag').attr('src', 'Storage/Uploads/' + arrWaitingToTag[0][0]);
        $('#ctr_fileTagging').text("1/" + arrWaitingToTag.length);
        $('[data-modal-fileExtension]').text("." + fnGet_FileExtension(arrWaitingToTag[0][1]));

        fnCheck_FileType(arrWaitingToTag[0][0]);
    }



    function fnLoad_PhotoTagging() {
        
        current_photoTag = 0;
        arrQueue_PhotoTagging = arrWaitingToTag_Photos;

        if(arrQueue_PhotoTagging){
            
            $('#photoTag_rawName').text(arrQueue_PhotoTagging[0][1]);
            $('#ctr_photoTagging').text("1/" + arrQueue_PhotoTagging.length);
            $('#imgPhotoTag').attr('src', 'Storage/Uploads/' + arrQueue_PhotoTagging[0][0]);
            $('#photoTag_fileExtension').text("." + fnGet_FileExtension(arrQueue_PhotoTagging[0][0]));
        }
    }


    function fnLoad_PhotoTagging_NewUpload() {
        var a = picture_types;
        current_photoTag = 0;

        $.each(arrGeneratedNames, function (index, value) {
            if (~a.indexOf(fnGet_FileExtension(value))) {
                let id = value;
                let rawName = fnGet_Data_AllUploads(value, "FileName");
                arrNew_Pictures.push([id, rawName]);
            }
        });

        if (arrNew_Pictures.length == 1) {
            $('#next_photoTag').hide();
        }

        if(!arrNew_Pictures)
        {
            $('#photoTag_rawName').text(arrNew_Pictures[0][1]);
            $('#photoTag_fileExtension').text("." + fnGet_FileExtension(arrNew_Pictures[0][0]));
            $('#ctr_photoTagging').text('1/' + arrNew_Pictures.length);
            $('#imgPhotoTag').attr('src', 'Storage/Uploads/' + arrNew_Pictures[0][0]);
        }



        arrQueue_PhotoTagging = arrNew_Pictures;
    }


    function fnLoad_NextPhotoTag() {
        current_photoTag++;

        var alvin_id = arrQueue_PhotoTagging[current_photoTag][0];
        var alvin_raw = arrQueue_PhotoTagging[current_photoTag][1];
        var alvin_len = arrQueue_PhotoTagging.length;

        $('#prev_photoTag').show();
        $('#photoTag_rawName').text(alvin_raw);
        $('#imgPhotoTag').attr('src', 'Storage/Uploads/' + alvin_id);
        $('#photoTag_fileExtension').text("." + fnGet_FileExtension(alvin_id));
        $('#ctr_photoTagging').text((current_photoTag + 1) + "/" + alvin_len);

        if (current_photoTag == alvin_len - 1) {
            $('#next_photoTag').hide();
        }
    }


    function fnLoad_PrevPhotoTag() {
        current_photoTag--;

        var alvin_id = arrQueue_PhotoTagging[current_photoTag][0];
        var alvin_raw = arrQueue_PhotoTagging[current_photoTag][1];
        var alvin_len = arrQueue_PhotoTagging.length;

        $('#next_photoTag').show();
        $('#photoTag_rawName').text(alvin_raw);
        $('#imgPhotoTag').attr('src', 'Storage/Uploads/' + alvin_id);
        $('#ctr_photoTagging').text((current_photoTag + 1) + "/" + alvin_len);
        $('#photoTag_fileExtension').text("." + fnGet_FileExtension(alvin_raw));

        if (current_photoTag == 0) {
            $('#prev_photoTag').hide();
        }
    }




    function fnLoad_FileTagging_Photos() {
        
        // $('#btn_fileTag_switcher').show();
        $('.alvin_maximize').show();
        $('#imgTag').attr('src', 'Storage/Uploads/' + id_selected);
        $('#imgPhotoTag').attr('src', 'Storage/Uploads/' + id_selected);
    }

    function fnLoad_FileTagging_Documents(docuType) {
        var docu;

        switch (docuType) {
            case "docx": docu = "Docx.jpg"; break;
            case "doc": docu = "Docx.jpg"; break;
            case "pptx": docu = "PPT.png"; break;
            case "ppt": docu = "PPT.png"; break;
            case "xlsx": docu = "Excel.png"; break;
            case "pdf": docu = "PDF.png"; break;
            case "txt": docu = "Txt.png"; break;
            default: docu = "Unknown.png";
        }

        $('#imgTag').attr('src', "img/docs/" + docu);
    }

    function fnLoad_FileTagging_Videos() {
        $('#imgTag').hide();
        $('#filetag_video').show();
        // $('#filetag_video video source').attr('src', 'vids');
        $('#filetag_video video').attr('src', 'Storage/Uploads/'+id_selected);
    }

    function fnLoad_FileTagging_Others() {
        $('#imgTag').attr('src', "img/docs/Unknown.png");
    }




    var readyToSave = false;

    function fnValidate_Inputs(input) {
        var value = input.val();

        if (value == null || value == "" || value == "null" || value == "default") {
            input.addClass("border-danger");
            // input.next().append("<div class='text-danger'>Required Field</div>");
            readyToSave = false;
        }
        else {
            // readyToSave = true;  //Nagkabug kasi sa Validation
        }
    }


    function fnValidate_Tags(tags, element) {

        if (tags == "") {
            element.addClass("border-danger");
            readyToSave = false;
        }
        else {
            // readyToSave = true;  //Nagkabug kasi sa Validation
        }
    }



    function fnSave_FileTagging() {
        // const i_categories = $('input[name=list_categories]');   //refer to C0001
        const i_newFileName = $('#input_newFileName');
        const i_group = $('#file_group');
        const i_plantType = $('select[name=file_plantType]');
        const i_projectName = $('select[name=file_projectName]');
        const i_tags = $('input[name=list_tags]');
        const i_notes = $('#input_notes');
        let fnID = "";

        // readyToSave = false; //Variable sharing with Photo Tagging
        readyToSave = true; //Variable sharing with Photo Tagging
        console.log(i_group.val());
        console.log(i_plantType.val());
        console.log(i_projectName.val());

        // fnValidate_Inputs(i_newFileName);    //refer to C0002
        // fnValidate_Tags(arrAddedCategories, i_categories);   //refer to C0001
        fnValidate_Inputs(i_group);
        fnValidate_Inputs(i_plantType);
        fnValidate_Inputs(i_projectName);
        fnValidate_Tags(arrAddedTags, i_tags);

        if (arrGeneratedNames[current_tag] == undefined) {
            fnID = id_selected;
        } else {
            fnID = arrGeneratedNames[current_tag];
        }

        if (readyToSave) {
            
            // let str_categories = JSON.stringify(arrAddedCategories);    //refer to C0001
            let str_tags = JSON.stringify(arrAddedTags);
            let str_name = i_newFileName.val();
            if(str_name == ""){
                str_name = $('[data-modal-filename]').text();
            }
            let arr = new Array();
            console.log(str_name);
            
            $.post("includes/update.php",
                {
                    request: "update_fileTagging",
                    id: fnID,
                    newName: str_name,
                    kdtGroup: i_group.val(),
                    plant: i_plantType.val(),
                    project: i_projectName.val(),
                    tags: str_tags,
                    notes: i_notes.val()
                },
                function (data, status) {
                    console.log(data);
                    console.log(status);

                    if (status == "success" && data.toLowerCase().indexOf('error') == -1) 
                    {
                        if(saving_row){
                            location.reload();
                        }
                        else if(saving_uploaded)
                        {
                            let len = arrGeneratedNames.length-1;
                            let index = arrGeneratedNames.indexOf(data);
                            arrGeneratedNames.splice(index, 1);

                            if(len == 0){
                                $('#modal_fileTagging').modal('hide');
                                location.reload();
                            }

                            if(len == 1){
                                $('#nextTag, #prevTag').hide();
                            }

                            if(current_tag == len-1){
                                $('#nextTag').hide();
                            }

                            if(current_tag == len){
                                current_tag--;
                            }

                            let rawName = fnGet_Data_AllUploads(arrGeneratedNames[current_tag], "FileName");

                            $('#imgTag').attr('src', 'Storage/Uploads/' + arrGeneratedNames[current_tag]);
                            $('#fileTag_rawName').text(rawName);
                            $('#fileTag_fileExtension').text("."+fnGet_FileExtension(rawName));
                            $('#ctr_fileTagging').text((current_tag + 1) + "/" + (len));
                        }
                        else{
                            let len = arrWaitingToTag.length-1;
                            console.log("Lenghthk "+len);
                            console.log("current "+len);
                            console.log(data);
                            console.table(arrWaitingToTag);
                            for (let i = 0; i < arrWaitingToTag.length; i++) 
                            {
                                if (data == arrWaitingToTag[i][0]) 
                                {
                                    arrWaitingToTag.splice(i, 1);   //Deletes Added Item from array, minus 1 to "len"
                                }
                            }

                            if(len == 0){
                                $('#modal_fileTagging').modal('hide');
                                location.reload();
                            }

                            if(len == 1){
                                $('#nextTag, #prevTag').hide();
                            }

                            if(current_tag == len-1){
                                $('#nextTag').hide();
                            }

                            if(current_tag == len){
                                current_tag--;
                            }

                            $('#imgTag').attr('src', 'Storage/Uploads/' + arrWaitingToTag[current_tag][0]);
                            $('#fileTag_rawName').text(arrWaitingToTag[current_tag][1]);
                            $('#fileTag_fileExtension').text("."+fnGet_FileExtension(arrWaitingToTag[current_tag][0]));
                            $('#ctr_fileTagging').text((current_tag + 1) + "/" + (len));
                        }

                    }
                    else {
                        console.log(data);
                        alert("ERROR 409! \nPlease contact Alvin from SYS Group to resolve this issue.");
                    }

                });
        }
        else{
            $('#modal_fileTagging').addClass('shakeClass');
            setTimeout(()=>{
                $('#modal_fileTagging').removeClass('shakeClass');
            }, 500);
        }

    }


    function fnSave_PhotoTagging() {
        const i_newFileName = $('input[name=photo_newName]');
        const i_group = $('select[name=photo_group]');
        const i_plantType = $('select[name=photo_plantType]');
        const i_projectName = $('select[name=photo_projectName]');
        const i_notes = $('textarea[name=photo_notes]');
        const i_tags = $('input[name=list_photoTags]');
        let alvin_id = "";

        readyToSave = false; //Variable sharing with File Tagging

        fnValidate_Inputs(i_newFileName);
        fnValidate_Inputs(i_group);
        fnValidate_Inputs(i_plantType);
        fnValidate_Inputs(i_projectName);
        fnValidate_Tags(arrAddedPhotoTags, i_tags);

        if (arrGeneratedNames[current_tag] == undefined) {
            alvin_id = id_selected;
        } else {
            alvin_id = arrQueue_PhotoTagging[current_photoTag][0];
        }


        if (readyToSave) {
            let str_name = i_newFileName.val();
            let str_tags = JSON.stringify(arrAddedPhotoTags);

            $.post("includes/update.php",
                {
                    request: "update_photoTagging",
                    id: alvin_id,
                    newName: str_name,
                    kdtGroup: i_group.val(),
                    plantType: i_plantType.val(),
                    projectName: i_projectName.val(),
                    tags: str_tags,
                    notes: i_notes.val()
                },
                function (data, status) {

                    if (status == "success" && data != "") {
                        let len = arrQueue_PhotoTagging.length;

                        for (let i = 0; i < arrQueue_PhotoTagging.length; i++) {
                            if (data == arrQueue_PhotoTagging[i][0]) {
                                arrQueue_PhotoTagging.splice(i, 1);   //Deletes Added Item from array, minus 1 to "len"
                            }
                        }

                        if (len == 1 || len == 0) {
                            $('#modal_photoTagging').modal('hide');
                        }
                        else {
                            console.log(`Current: ${current_photoTag}`);

                            if (current_photoTag == len || current_photoTag == (len-1)) {
                                current_photoTag--;
                            }
                            console.log(`Current: ${current_photoTag}`);
                            console.log(`Length: ${len}`);

                            $('#imgPhotoTag').attr('src', 'Storage/Uploads/' + arrQueue_PhotoTagging[current_photoTag][0]);
                            $('#photoTag_rawName').text(arrQueue_PhotoTagging[current_photoTag][1]);
                            $('#photoTag_fileExtension').text("."+fnGet_FileExtension(arrQueue_PhotoTagging[current_photoTag][0]));
                            $('#ctr_photoTagging').text((current_photoTag + 1) + "/" + (len - 1));
                        }

                    }
                    else {
                        console.log(data);
                        alert("ERROR 409! \nPlease contact Alvin from SYS Group to resolve this issue.");
                    }



                });
        }
        else{
            $('#modal_photoTagging').addClass('shakeClass');
            setTimeout(()=>{
                $('#modal_photoTagging').removeClass('shakeClass');
            }, 500);
        }
    }






    function fnGet_Data_AllUploads(id, request) {
        let found;

        $.each(data_AllUploads, function (index, value) {
            if (value.FileNameDB == id) {
                switch (request) {
                    case "Status": found = value.Status; break;
                    case "FileName": found = value.FileName; break;
                    case "PlantType": found = value.PlantType; break;
                    case "ProjectName": found = value.ProjectName; break;
                    case "Group": found = value.BusinessUnit; break;
                    case "Categories": found = value.Categories; break;
                    case "Tags": found = value.Tags; break;
                    case "Notes": found = value.Notes; break;
                    case "forPhotoDB": found = value.forPhotoDB; break;

                    default: found = value.FileNameDB;
                }
            }
        });

        return found;
    }



    function fnLoad_ForChecking(id) {
        let fileName = fnGet_Data_AllUploads(id, "FileName");
        let group = fnGet_Data_AllUploads(id, "Group");
        let plant = fnGet_Data_AllUploads(id, "PlantType");
        let project = fnGet_Data_AllUploads(id, "ProjectName");
        // let categories = fnGet_Data_AllUploads(id, "Categories");    // Alvin: C001
        let tags = fnGet_Data_AllUploads(id, "Tags");
        let notes = fnGet_Data_AllUploads(id, "Notes");
        let status = fnGet_Data_AllUploads(id, "Status");
        let forPhotoDB = fnGet_Data_AllUploads(id, "forPhotoDB");

        tags = JSON.parse(tags);
        forPhotoDB = parseInt(forPhotoDB);
        
        // Alvin: C001
        // if(forPhotoDB)
        // {
        //     $('select[name=photo_plantType]').val(plant);
        //     $('select[name=photo_projectName]').val(project);
        // }else{
        //     categories = JSON.parse(categories);
    
        //     $.each(categories, function (index, value) {
        //         $('#category_container').append('<div class="d-flex align-items-center rounded-pill border bg-white m-1 py-1 ps-3 pe-1 fs-7 added-tag" style="display:none;"><p class="mb-0"></p>' + value + '<i class="bi bi-x-lg fs-7 kamay px-1" data-remove-tag></i></div>');
        //     });
        // }

        $.each(tags, function (index, value) {
            $('#tags_container, #photoTags_container').append('<div class="d-flex align-items-center rounded-pill border bg-white m-1 py-1 ps-3 pe-1 fs-7 added-tag" style="display:none;"><p class="mb-0"></p>' + value + '<i class="bi bi-x-lg fs-7 kamay px-1" data-remove-tag></i></div>');
            arrAddedTags.push(value);
        });

        $('#input_newFileName, input[name=photo_newName]').val(fileName.split('.')[0]);
        $('#file_group, select[name=photo_group]').val(group);
        $('[data-select-planttype]').val(plant);
        $('[data-select-projectname]').val(project);
        $('#input_notes, textarea[name=photo_notes]').val(notes);
        $('#btn_saveFileTag, #btn_savePhotoTag').text("Save Changes");

        // $('input[name=list_categories]').val("");    //Alvin: C001
        $('input[name=list_tags]').val("");

    } //Load_Checking


    function fnReset_FileTaggingModal() {
        $('#input_notes').val("");
        $('#input_newFileName').val("");
        $('[data-modal-filename]').text("File Name.extension");
        $('#file_group').val($('#file_group option:first').val());
        $('#category_container').children().remove();
        $('#tags_container').children().remove();
    }









    function fnRead_URL() {
        let urlParams = new URLSearchParams(window.location.search);
        let uploadSuccess = urlParams.has('UploadSuccess'); // checks if it has 'changes' on URL parameters

        if (uploadSuccess) {
            window.history.pushState({}, '', '?');
            fnRead_Cookies();

            // $('#prevTag').hide();

            //for Uploading
            var myModal = new bootstrap.Modal(document.getElementById('modal_fileTagging'), {
                keyboard: false
            });
            myModal.toggle();
        }
    }







}); //Document Ready 1














// ----------------------------------------------------------------------------
//                                 TRASH BIN
// ----------------------------------------------------------------------------
// var ctr = $('#example tr:last-child td:first-child').text();    //ALTERNATIVE
// ctr = (ctr == "No data available in table")? 0 : parseInt(ctr);




// CHALLENGE!!! - Live Input

// $('input[name=list_tags]').on('keypress', function(e){
//     var val = this.value;
//     console.log(val);
//     val = val.substring(val.length, val.length-1);

//     // if(val)
//     // {
//     //     fnAddTags(val);
//     // }
//     // else{
//     //     console.log("empty");
//     // }

//     var current = $('#tags_container').children(':last').text();
//     current += val;
//     $('#tags_container').children(':last').text(current);
//     current = "";

//     if(e.which == 8)    //keycode 8 = Backspace
//     {
//         console.log("Backspace!");
//     }
// });