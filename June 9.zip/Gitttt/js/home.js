
let boboKa = "";

$(document).ready(function () {
    let data_uploads;
    let data_groups;
    let data_bu_hasValue = new Array();
    let data_plant_hasValue = new Array();
    let data_project_hasValue = new Array();

    fnRead_URL();

    $(document).on('click', '[data-item]', function () {
        let item = $(this).data('item');
        let maitem = item.split('.');

        window.location.href = "./Details?Item=" + maitem[0];
    });


    $('input[name=search]')
        .on('change', function (e) {
            var val = this.value;
            $('#search_result').html("Showing all results");
            if (val) {
                fnLoad_Results(val);
            } else {
                fnLoad_Home(data_uploads);
            }
        })

        .on('search', function (e) {
            var val = this.value;
            console.log("SEARCHHH");
            // $('#search_result').html("Showing 2");
            // fnLoad_Results(val);
        });



    $('#check_filetype_all').click(function () {

        let any = $('[data-chk-filetype]');
        // console.log(any[0].id);
        if (any.prop('checked') && $(this).prop('checked')) {
            any.prop('checked', false);
        }
        if (any.prop('checked', false)) {
            $(this).prop('checked', true);
        }
        $('[data-sec-documents], [data-sec-photos], [data-sec-videos], [data-sec-others]').show();
    });



    $('[data-chk-filetype]').click(() => {
        $('#check_filetype_all').prop('checked', false);
    });



    $('#check_filetype_docu').click(() => {
        let is_checked = $('#check_filetype_docu').is(':checked');
        if (is_checked) {
            let any = $('[data-chk-filetype]:checked').length;
            if (any == 1) {
                $('[data-sec-photos], [data-sec-videos], [data-sec-others]').hide();
            }
            $('[data-sec-documents]').show();
        }
        else {
            $('[data-sec-documents]').hide();
        }
    });



    $('#check_filetype_photos').click(() => {
        let is_checked = $('#check_filetype_photos').is(':checked');

        if (is_checked) {
            let any = $('[data-chk-filetype]:checked').length;

            if (any == 1) {
                $('[data-sec-documents], [data-sec-videos], [data-sec-others]').hide();
            }
            $('[data-sec-photos]').show();
        }
        else {
            $('[data-sec-photos]').hide();
        }
    });



    $('#check_filetype_videos').click(() => {
        let is_checked = $('#check_filetype_videos').is(':checked');

        if (is_checked) {
            let any = $('[data-chk-filetype]:checked').length;

            if (any == 1) {
                $('[data-sec-documents], [data-sec-photos], [data-sec-others]').hide();
            }
            $('[data-sec-videos]').show();
        }
        else {
            $('[data-sec-videos]').hide();
        }
    });



    $('#check_filetype_others').click(() => {
        let is_checked = $('#check_filetype_others').is(':checked');

        if (is_checked) {
            let any = $('[data-chk-filetype]:checked').length;

            if (any == 1) {
                $('[data-sec-documents], [data-sec-photos], [data-sec-videos]').hide();
            }
            $('[data-sec-others]').show();
        }
        else {
            $('[data-sec-others]').hide();
        }
    });



    $(document).on("click", "input[type=checkbox]", function(){
        console.log("helloo");
        console.log(this);
        console.log(this.id);
    });







    // CUSTOM FUNCTIONS


    function fnLoad_Defaults() {

        fnGet_Uploads();

        boboKa = BoboBasaPa('newUser');

        // if (boboKa) {
        //     fnGet_Uploads();
        // }
        // else {
        //     window.location.href = "./Login.html";
        // }
    }


    function fnGet_Uploads() {

        console.time("Groups");
        $.post("./includes/get_data.php",
            {
                table_name: 'tbl_groups'
            },
            function (data, status) {
                if (status == "success") {
                    data = JSON.parse(data);
                    data_groups = data;
                }
                else {
                    console.log("Home Page: Error on fetching Data from Database");
                }
            }
        );
        console.timeEnd("Groups");

        console.time("Uploads");
        $.post("./includes/get_data.php",
            {
                table_name: 'tbl_uploads'
            },
            function (data, status) {
                if (status == "success") {
                    if (data != "0 results") {
                        data = JSON.parse(data);
                        data_uploads = data;
                        fnLoad_Home(data);
                        fnLoad_Search(data);
                        fnLoad_Filter_FileType(data);
                        fnLoad_Filter_BU();
                    }
                    else {
                        $('[data-jar-documents]').append('<p class="text-center w-100">No results found.</p>');
                        $('[data-jar-photos]').append('<p class="text-center w-100">No results found.</p>');
                        $('[data-jar-videos]').append('<p class="text-center w-100">No results found.</p>');
                        $('[data-jar-others]').append('<p class="text-center w-100">No results found.</p>');
                    }
                }
                else {
                    console.log("Home Page: Error on fetching Data from Database");
                }
            }
        );
        console.timeEnd("Uploads");

        console.time("Category");
        $.post("./includes/get_data.php",
            {
                table_name: 'tbl_categories'
            },
            function (data, status) {
                if (status == "success") {
                    data = JSON.parse(data);
                    fnLoad_Filter_Categories(data);
                }
                else {
                    console.log("Home Page: Error on fetching Data from Database");
                }
            }
        );
        console.timeEnd("Category");

    }//end fnGet_Uploads()


    function fnLoad_Home(data) {

        $('[data-jar-documents]').children().remove();
        $('[data-jar-photos]').children().remove();
        $('[data-jar-videos]').children().remove();
        $('[data-jar-others]').children().remove();

        $('[data-jar-documents]').append('<p class="text-center w-100" data-noresults>No results found.</p>');
        $('[data-jar-photos]').append('<p class="text-center w-100" data-noresults>No results found.</p>');
        $('[data-jar-videos]').append('<p class="text-center w-100" data-noresults>No results found.</p>');
        $('[data-jar-others]').append('<p class="text-center w-100" data-noresults>No results found.</p>');


        $.each(data, function (index, value) {

            if (value.Status == "Approved") {
                if (value.FileType == "picture") {
                    let addItem = "<div class='m-2 w-11'>";
                    addItem += `<div class='card kamay' data-item='${value.FileNameDB}'>`;
                    addItem += `<img src='./Storage/Uploads/${value.FileNameDB}' class='card-img-top' alt='Picture'>`;
                    addItem += "</div>";
                    addItem += `<p class='text-center mb-0'>${value.FileName}</p>`;
                    addItem += "</div>";

                    $('[data-jar-photos] p[data-noresults]').remove();
                    $('[data-jar-photos]').append(addItem);

                }
                else if (value.FileType == "document") {
                    let icon;

                    var regex = /(?:\.([^.]+))?$/;
                    var ext = regex.exec(value.FileNameDB)[1];


                    switch (ext) {
                        case "pdf": icon = "PDF.png"; break;
                        case "xlsx": icon = "Excel.png"; break;
                        case "ppt": icon = "PPT.png"; break;
                        case "pptx": icon = "PPT.png"; break;
                        case "doc": icon = "Docx.jpg"; break;
                        case "docx": icon = "Docx.jpg"; break;
                        case "txt": icon = "txt.png"; break;
                        default: icon = "Unknown.png"; break;
                    }

                    let addItem = "<div class='m-2 w-11'>";
                    addItem += `<div class='card kamay p-4' data-item='${value.FileNameDB}'>`;
                    addItem += `<img src='img/docs/${icon}' class='card-img-top' alt='Picture'>`;
                    addItem += "</div>";
                    addItem += `<p class='text-center mb-0'>${value.FileName}</p>`;
                    addItem += "</div>";

                    $('[data-jar-documents] p[data-noresults]').remove();
                    $('[data-jar-documents]').append(addItem);

                }
                else if (value.FileType == "video") {
                    let addItem = "<div class='m-2 w-18'>";
                    addItem += `<div class='card kamay p-2' data-item='${value.FileNameDB}'>`;
                    addItem += "<video controls>";
                    addItem += "<source src='./Storage/Uploads/" + value.FileNameDB + "'>";
                    addItem += "Your browser does not support the video tag.";
                    addItem += "</video>";
                    addItem += "</div>";
                    addItem += `<p class='text-center mb-0'>${value.FileName}</p>`;
                    addItem += "</div>";

                    $('[data-jar-videos] p[data-noresults]').remove();
                    $('[data-jar-videos]').append(addItem);
                }
                else {
                    let addItem = "<div class='m-2 w-11'>";
                    addItem += `    <div class='card kamay p-2' data-item='${value.FileNameDB}'>`;
                    addItem += "        <img src='img/docs/Unknown.png' class='card-img-top' alt='Unknown'>";
                    addItem += "    </div>";
                    addItem += `    <p class='text-center mb-0'>${value.FileName}</p>`;
                    addItem += "</div>";

                    $('[data-jar-others] p[data-noresults]').remove();
                    $('[data-jar-others]').append(addItem);
                }
            }

        });
    } //fnLoad_Home()


    function BoboBasaPa(c_name) {
        if (document.cookie.length > 0) {
            c_start = document.cookie.indexOf(c_name + "=");
            if (c_start != -1) {
                c_start = c_start + c_name.length + 1;
                c_end = document.cookie.indexOf(";", c_start);
                if (c_end == -1) {
                    c_end = document.cookie.length;
                }
                return unescape(document.cookie.substring(c_start, c_end));
            }
        }
        return "";
    }


    function fnLoad_Search(data) {
        let arr_search = new Array();

        $.each(data, function (index, value) {

            if (value.Status == "Approved") {
                let tags = JSON.parse(value.Tags);
                $.each(tags, function (index, value) {
                    arr_search.push(value);
                });

                arr_search.push(value.FileName);
            }

            // UNCOMMENT KAPAG LAHATAN NA
            // arr_search.push(value.PlantType);
            // arr_search.push(value.ProjectName);

            // let tags = JSON.parse(value.Tags); 
            // if(tags != null){
            //     for(i=0; i<tags.length; i++){
            //         arr_search.push(tags[i]);
            //     }
            // }
        });

        // arr_search.sort();  //Not working properly
        arr_search.sort((a, b) => a.localeCompare(b));  //Working fine
        let unique_ito = [...new Set(arr_search)];  //Remove Duplicates

        $.each(unique_ito, function (index, value) {
            let str = `<option>${value}</option>`;
            $('#home_search').append(str);
        });
    }


    function fnLoad_Results(item) {
        let data = data_uploads;
        let arr_result = new Array();
        console.table(data);
        $('#search_result').html(`Search result for <b>${item}</b>`);

        $.each(data, function (index, value) {
            if (value.FileName == item || value.Tags.includes(item) || value.FileName.includes(item)) {
                arr_result.push(data[index]);
            }
        });
        fnLoad_Home(arr_result);
    }


    function fnLoad_Filter_FileType(data) {
        let ctr_all = 0;
        let ctr_docu = 0;
        let ctr_photos = 0;
        let ctr_videos = 0;
        let ctr_others = 0;

        $.each(data, function (index, value) {
            if (value.Status == "Approved") {
                switch (value.FileType) {
                    case "document": ctr_docu++; break;
                    case "picture": ctr_photos++; break;
                    case "video": ctr_videos++; break;
                    default: ctr_others++; break;
                }
                ctr_all++;
                data_bu_hasValue.push(value.BusinessUnit);
                data_plant_hasValue.push(value.PlantType);
                data_project_hasValue.push(value.ProjectName);
            }
        });

        $('label[for=check_filetype_all]').text(`All (${ctr_all})`);
        $('label[for=check_filetype_docu]').text(`Documents (${ctr_docu})`);
        $('label[for=check_filetype_photos]').text(`Photos (${ctr_photos})`);
        $('label[for=check_filetype_videos]').text(`Videos (${ctr_videos})`);
        $('label[for=check_filetype_others]').text(`Others (${ctr_others})`);
    }



    function fnLoad_Filter_BU() {
        const data = data_bu_hasValue;
        const dataGrp = data_groups;
        let uniq = [...new Set(data)]; //ES6 native object 'Set'
        const counts = {};
        
        uniq.sort((a, b) => a.localeCompare(b));    //ES6 sort
        data.forEach(function(x) { counts[x] = (counts[x] || 0) + 1; });
        
        $.each(uniq, (index, value)=>{
            let bilang = 0;
            let temp = dataGrp.filter(grp => grp.GroupCode == value);   
            let groupname = temp[0].GroupName;
            bilang = counts[value];

            let addItem = `<div class="form-check">`;
            addItem += `    <input id="filter_bu_${value}" class="form-check-input rarara" type="checkbox" />`;
            addItem += `    <label for="filter_bu_${value}" class="form-check-label" title="${groupname}">${value} (${bilang})</label>`;
            addItem += `   </div>`;

            $('.checkbox-jar-group').append(addItem);
        });
    }



    function fnLoad_Filter_Categories(data) {
        const counts_plant = {};
        const counts_project = {};
        data_plant_hasValue.forEach(function (x) { counts_plant[x] = (counts_plant[x] || 0) + 1; });
        data_project_hasValue.forEach(function (x) { counts_project[x] = (counts_project[x] || 0) + 1; });

        $.each(data, (index, value) => {
            let name = value.CategoryName;

            if (value.CategoryType == "Plant") {
                let bilangPlant = 0;
                if(~data_plant_hasValue.indexOf(name)){
                    bilangPlant = counts_plant[name];
                    let addItem = `<div class="form-check">
                                    <input id="filter_plant_cat${value.ID}" class="form-check-input" type="checkbox" />
                                    <label for="filter_plant_cat${value.ID}" class="form-check-label">${name} (${bilangPlant})</label>
                                </div>`;
                    $('#filter_plant').after(addItem);
                }
            }

            if (value.CategoryType == "Project") {
                let bilangProject = 0;
                if(~data_project_hasValue.indexOf(name)){
                    bilangProject = counts_project[name];
                    let addItem = `<div class="form-check">
                                    <input id="filter_project_proj${value.ID}" class="form-check-input" type="checkbox" />
                                    <label for="filter_project_proj${value.ID}" class="form-check-label">${name} (${bilangProject})</label>
                                </div>`;
                    $('#filter_project').after(addItem);
                }
            }
        });
    }



    function fnRead_URL() {
        let urlParams = new URLSearchParams(window.location.search);
        let hanap = urlParams.has('search');
        let hanapmo = urlParams.get('search');

        if (hanap) {
            fnLoad_Results(hanapmo);
        } else {
            fnLoad_Defaults();
        }
    }


}); //Document




// REFERENCES
// ----------

// let val = data_groups.filter(grp => grp.GroupCode == "ANA");    //Filter Get whole Row Value





// DUMP CODES
// ----------


// const counts = {};

// for(const num of data){
//     counts[num] = counts[num] ? counts[num] + 1 : 1;
// }

// console.log(counts);
// console.table(counts['FileType'][1]);