-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 01, 2023 at 07:24 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `navigatordb`
--

-- --------------------------------------------------------

--
-- Table structure for table `emp_prof`
--

CREATE TABLE `emp_prof` (
  `fldID` int(20) NOT NULL,
  `fldEmployeeNum` int(50) NOT NULL,
  `fldName` varchar(100) NOT NULL,
  `fldSurname` varchar(100) NOT NULL,
  `fldFirstname` varchar(100) NOT NULL,
  `fldNick` varchar(50) NOT NULL,
  `fldUser` varchar(20) NOT NULL,
  `fldGroup` varchar(50) NOT NULL,
  `fldGroups` varchar(100) NOT NULL,
  `fldDesig` varchar(50) NOT NULL,
  `fldBirthDate` date DEFAULT NULL,
  `fldGender` varchar(1) NOT NULL DEFAULT 'M',
  `fldStatus` varchar(20) NOT NULL,
  `fldDateHired` date DEFAULT NULL,
  `fldLotus` varchar(50) NOT NULL,
  `fldPic` varchar(100) NOT NULL,
  `fldOthers` double(10,1) NOT NULL DEFAULT 0.0,
  `fldStartTime` varchar(100) NOT NULL,
  `fldMOT` varchar(100) NOT NULL,
  `fldRemarks` varchar(100) NOT NULL,
  `fldUnit` varchar(100) NOT NULL,
  `fldHouse` varchar(100) NOT NULL,
  `fldStreet` varchar(100) NOT NULL,
  `fldSub` varchar(100) NOT NULL,
  `fldBrgy` varchar(100) NOT NULL,
  `fldCity` varchar(100) NOT NULL,
  `fldProv` varchar(100) NOT NULL,
  `fldZip` int(4) DEFAULT NULL,
  `fldDesigStamp` varchar(100) NOT NULL,
  `fldGroupStamp` varchar(100) NOT NULL,
  `fldActiveStamp` varchar(100) NOT NULL,
  `fldStampDate` date DEFAULT NULL,
  `fldChecker` varchar(100) NOT NULL,
  `fldActive` int(1) NOT NULL DEFAULT 1,
  `fldResignDate` date DEFAULT NULL,
  `fldUpload` int(1) NOT NULL DEFAULT 0,
  `fldAccess` int(1) NOT NULL,
  `fldAccessCommute` int(1) NOT NULL,
  `fldMRRSReserve` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `emp_prof`
--

INSERT INTO `emp_prof` (`fldID`, `fldEmployeeNum`, `fldName`, `fldSurname`, `fldFirstname`, `fldNick`, `fldUser`, `fldGroup`, `fldGroups`, `fldDesig`, `fldBirthDate`, `fldGender`, `fldStatus`, `fldDateHired`, `fldLotus`, `fldPic`, `fldOthers`, `fldStartTime`, `fldMOT`, `fldRemarks`, `fldUnit`, `fldHouse`, `fldStreet`, `fldSub`, `fldBrgy`, `fldCity`, `fldProv`, `fldZip`, `fldDesigStamp`, `fldGroupStamp`, `fldActiveStamp`, `fldStampDate`, `fldChecker`, `fldActive`, `fldResignDate`, `fldUpload`, `fldAccess`, `fldAccessCommute`, `fldMRRSReserve`) VALUES
(1, 7, 'LAUREANO_Antonio', 'Laureano', 'Antonio', 'Toni', 'toni1', 'ADM', '', 'CSAD', '1956-07-05', 'M', 'Married', '1989-05-11', 'laureano-kdt/P/KHI', 'pic_7.jpg', 0.0, '07:00', 'Rick', '06:00/16:00', '-', '13 ', 'P. GABRIEL', '-', 'San Jose (Pob.)', 'City of Navotas', 'NCR, Third District', 1409, 'CSAD', 'ADM', '0', '2022-04-19', 'Ernesto Veloso', 0, '2021-07-01', 1, 4, 1, 0),
(2, 8, 'PANADO_Evangeline', 'Panado', 'Evangeline', 'Van', 'van', 'ADM', 'ADM', 'DM', '1960-07-03', 'F', 'Married', '1990-06-11', 'panado-g1/P/KHI', 'pic_8.jpg', 0.0, '06:00', 'carpool', 'Evangeline Panado', '', '8248-B', 'Camachile Street', 'San Antonio', 'San Antonio', 'City of Makati', 'NCR, Fourth District', 1203, 'DM', 'ADM', '1', '2022-03-31', '', 1, NULL, 1, 4, 1, 0),
(3, 10, 'TAN_Erwin', 'Tan', 'Erwin', 'TAN', 'khi', 'MNG', 'ANA/ADM/CIV/EE/PIP/IT/SYS/MNG/ETCL', 'SM', '1965-12-20', 'M', 'Married', '1989-05-11', 'tan-g1/P/KHI', 'pic_10.jpg', 0.9, '07:00', 'ownCar', '', '104-A Rockford Bldg.', 'Lakeview Manors Cond.', 'Bagong Calzada', '', 'Ususan', 'City of Taguig', 'NCR, Fourth District', 1632, 'SM', 'ANA', '1', '2022-03-31', '', 1, NULL, 1, 4, 1, 0),
(4, 18, 'MATIBAG_Erwilson', 'Matibag', 'Erwilson', 'Wilson', 'wilson', 'MNG', 'ANA/IT/SYS/MNG', 'DM', '1972-10-16', 'M', 'Married', '1995-06-01', 'matibag-kdt/P/KHI', 'pic_18.jpg', 0.0, '06:00', 'carpool', 'Francis Martee Gulapa', '', 'Lot 14 Block 1', 'Mendiola', 'Vista Verde Executive Village', 'San Isidro', 'Cainta', 'Rizal', 1900, 'DM', 'ANA', '1', '2022-03-31', '', 1, NULL, 1, 3, 0, 0),
(5, 21, 'SANTOS_Roberto', 'Santos', 'Roberto', 'Bert', 'kuyabert', 'ADM', '', 'MJ', '1962-10-14', 'M', 'Married', '1996-09-01', '', 'pic_21.jpg', 0.0, '06:00', 'bicycle', '', '', '', 'Leon Guinto', '', 'Barangay 726', 'Malate, City of Manila', 'NCR, First District', 1004, 'MJ', 'ADM', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(6, 25, 'DERIGAY_Oliver', 'Derigay', 'Oliver', 'Oliver', 'OLIVER', 'CHE', 'CHE/CRY/CEM/MIL/ETCL/MPM/MNG', 'DM', '1971-10-21', 'M', 'Married', '1997-01-06', 'derigay-g1/P/KHI', 'pic_25.jpg', 3.5, '07:00', 'ownCar', '', '', '', '', '', 'Bayanan', 'City of Bacoor', 'Cavite', 4102, 'DM', 'CHE', '1', '2022-03-31', '', 1, NULL, 1, 3, 0, 0),
(7, 30, 'ABUAN_Christopher', 'Abuan', 'Christopher', 'Fher', 'fher', 'MHAH', 'MHAH/MNG', 'DM', '1975-12-06', 'M', 'Married', '1997-01-09', 'abuan-kdt/P/KHI', 'pic_30.jpg', 0.0, '07:00', 'carpool', 'Christopher Abuan', '158-C', 'Magtanggol St.', '158-C Magtanggol St. Bgy. 29 Maypajo, Caloocan City', 'Maypajo', 'Barangay 29', 'City of Caloocan', 'NCR, Third District', 1410, 'DM', 'MHAH', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 1, 3, 0, 0),
(8, 34, 'CORPUZ_Antonio', 'Corpuz', 'Antonio', 'Tony', 'bosstony', 'ADM', '', 'DR2', '1965-12-14', 'M', 'Married', '1997-02-01', '', 'pic_34.jpg', 0.0, '06:00', 'ownCar', '', '', '8248', 'Camachile', '', 'San Antonio', 'City of Makati', 'NCR, Fourth District', 1203, 'DR2', 'ADM', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(9, 37, 'LLANES_Ferdinand', 'Llanes', 'Ferdinand', 'Ferdie', 'llanes', 'BOI', 'BOI/INT/MNG', 'DM', '1969-10-31', 'M', 'Married', '1997-08-15', 'llanes-kdt/P/KHI', 'pic_37.jpg', 2.0, '06:00', 'carpool', 'Al Shariff Gallardo', '', 'Blk 8 lot 27', '', 'Veracruz', 'Malitlit', 'City of Santa Rosa', 'Laguna', 2406, 'DM', 'BOI', '1', '2022-03-31', '', 1, NULL, 1, 3, 0, 0),
(10, 40, 'CABELLO_Aristeo', 'Cabello', 'Aristeo', 'Aris', 'aris', 'ENV', 'ENV/MNG', 'DM', '1976-01-24', 'M', 'Married', '1997-10-16', 'cabello-kdt/P/KHI', 'pic_40.jpg', 1.0, '06:00', 'ownCar', '', '', 'Lot 34', '18 Ohio Street', 'Camella Homes', 'Salinas IV', 'City of Bacoor', 'Cavite', 4102, 'AM', 'ENV', '1', '2022-03-31', '', 1, NULL, 1, 3, 0, 0),
(11, 43, 'AMPIG_Rommel', 'Ampig', 'Rommel', 'Rommel', 'rommel1', 'MIL', 'MIL/CEM/MPM/ETCL', 'DM', '1972-01-15', 'M', 'Married', '1998-01-15', 'ampig-kdt/P/KHI', 'pic_43.jpg', 0.0, '', '', '', '', '', '', '', '', '', '', 0, 'DM', 'MIL', '0', '2022-04-19', 'Ernesto Veloso', 0, '2022-04-01', 1, 3, 0, 0),
(12, 55, 'PEREZ_April', 'Perez', 'April', 'April', 'april', 'ACT', '', 'SA', '1976-04-09', 'F', 'Single', '1998-03-23', 'perez-kdt/P/KHI', 'pic_55.jpg', 0.0, '06:00', 'carpool', 'Lorenzo Diaz', 'Missouri ', '418', 'Dr Sixto Avenue', 'Riverfront Residences', 'Caniogan', 'City of Pasig', 'NCR, Second District', 1606, 'SA', 'ACT', '1', '2022-03-31', '', 1, NULL, 1, 0, 0, 0),
(13, 61, 'BALISBIS JR._Cezar', 'Balisbis Jr.', 'Cezar', 'Czar', 'czar', 'ANA', 'ANA/SYS/IT', 'AM', '1974-09-18', 'M', 'Married', '1998-04-16', 'balisbis-kdt/P/KHI', 'pic_61.jpg', 0.0, '06:30', 'publicTransportation', '', 'Unit 4A', '#4', 'Haig Street', '_', 'Daang Bakal', 'City of Mandaluyong', 'NCR, Second District', 0, 'AM', 'ANA', '1', '2022-03-31', '', 1, NULL, 1, 3, 0, 0),
(14, 101, 'SORIANO_Sharon Ann', 'Soriano', 'Sharon Ann', 'Ann', 'soriano-kdt', 'ADM', '', 'ASS', '1976-12-12', 'F', 'Married', '2007-03-03', 'soriano-kdt/P/KHI', 'pic_101.jpg', 0.0, '06:00', 'Arnold', '05:10/15:08', '', 'B2 L11', 'Kiwi St.,', 'Greenlane Villas ', 'Bayanan', 'City of Bacoor', 'Cavite', 4102, 'ASS', 'ADM', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(15, 104, 'VELOSO_Ernesto', 'Veloso', 'Ernesto', 'Lou', 'LOU', 'MNG', 'MNG/ENV/BOI', 'SM', '1967-03-24', 'M', 'Married', '2000-07-03', 'veloso-kdt/P/KHI', 'pic_104.jpg', 9.0, '06:30', 'ownCar', '', '', '#15', 'Road 10-B', 'UPS V', 'San Isidro', 'City of Parañaque', 'NCR, Fourth District', 1713, 'SM', 'MNG', '1', '2022-03-31', '', 1, NULL, 1, 4, 1, 0),
(16, 107, 'DIAZ_Lorenzo', 'Diaz', 'Lorenzo', 'Lorenz', 'etuc', 'CEM', 'CEM/ETCL/MPM/MIL', 'AM', '1974-11-06', 'M', 'Married', '2000-10-16', 'diaz-kdt/P/KHI', 'pic_107.jpg', 2.0, '06:00', 'carpool', 'Lorenzo Diaz', '214 Riverfront Res.', '', 'Dr. Sixto Avenue', '', 'Caniogan', 'City of Pasig', 'NCR, Second District', 1606, 'AM', 'CEM', '1', '2022-03-31', '', 1, NULL, 1, 3, 0, 0),
(17, 117, 'VITALICIO_Mae Anne', 'Vitalicio', 'Mae Anne', 'Mae', 'vitalicio-kdt', 'ENV', 'ENV', 'AM', '1976-11-28', 'F', 'Single', '2002-07-01', 'vitalicio-kdt/P/KHI', 'pic_117.jpg', 2.5, '06:00', 'carpool', 'Lorenzo Diaz', '', '47B', '', 'Countryside', 'Barangka Ibaba', 'City of Mandaluyong', 'NCR, Second District', 1550, 'AM', 'ENV', '1', '2022-03-31', '', 1, NULL, 1, 3, 0, 0),
(18, 121, 'DERIGAY_Arlene', 'Derigay', 'Arlene', 'Arlene', 'arlene', 'ADM', '', 'AAR', '1977-11-20', 'F', 'Married', '2002-01-02', 'magno-kdt/P/KHI', 'pic_121.jpg', 0.0, '07:00', 'ownCar', '', '', '', '', '', 'Bayanan', 'City of Bacoor', 'Cavite', 4102, 'AAR', 'ADM', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(19, 122, 'FABIA_Roderick', 'Fabia', 'Roderick', 'Rick', 'kuyarick', 'ADM', '', 'DR', '1970-03-08', 'M', 'Married', '2004-08-18', '', 'pic_122.jpg', 0.0, '06:00', 'bicycle', '', '', 'Blk 9, Lot 1', '', 'GPL3', 'Anabu II-B', 'City of Imus', 'Cavite', 4103, 'DR', 'ADM', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(20, 134, 'BECINA_Artemio Roel', 'Becina', 'Artemio Roel', 'Brix', 'brix', 'PIP', 'EE/CIV/PIP/DXT/MNG', 'DM', '1978-04-10', 'M', 'Married', '2002-09-02', 'becina-kdt/P/KHI', 'pic_134.jpg', 1.5, '06:30', 'ownCar', '', '', '385', 'tatang exequiel compound', '', 'talon uno', 'City of Las Piñas', 'NCR, Fourth District', 1707, 'AM', 'EE', '1', '2022-03-31', '', 1, NULL, 1, 4, 1, 0),
(21, 145, 'BARADAS_Ryan', 'Baradas', 'Ryan', 'Ryan', 'ryan', 'CRY', '', 'SSV', '1981-03-25', 'M', 'Married', '2005-04-18', 'baradas-kdt/P/KHI', 'pic_145.jpg', 1.5, '07:00', 'ownCar', '', 'E.T. Homes 1', 'A-13', 'Naga Road', '', 'Pulang Lupa Dos', 'City of Las Piñas', 'NCR, Fourth District', 1740, 'SSV', 'CRY', '1', '2022-03-31', '', 1, NULL, 1, 0, 0, 0),
(22, 158, 'VALDEZ_Ramir', 'Valdez', 'Ramir', 'Ramir', 'ramir', 'EE', 'EE/MNG', 'DM', '1965-11-25', 'M', 'Married', '2006-04-03', 'valdez-kdt/P/KHI', 'pic_158.jpg', 14.1, '06:00', 'ownCar', '', '', 'Block 1 Lot 12', '', 'Amaia Scapes General Trias', 'Santiago', 'City of General Trias', 'Cavite', 4107, 'DM', 'EE', '1', '2022-03-31', '', 1, NULL, 1, 3, 0, 0),
(23, 172, 'VIRAY_Jermaine', 'Viray', 'Jermaine', 'Maine', 'maine', 'MHAH', '', 'SSV', '1982-09-20', 'F', 'Married', '2006-05-15', 'marasigan-kdt/P/KHI', 'pic_172.jpg', 0.5, '06:00', 'carpool', 'Aristeo Cabello', 'N/A', 'Blk 19 Lot 4', 'Iligan Street', 'Southern City ', 'Tanzang Luma IV', 'City of Imus', 'Cavite', 4103, 'SSV', 'MHAH', '1', '2022-03-31', '', 0, '2022-12-31', 0, 0, 0, 0),
(24, 173, 'AGUILAR_John Isaac', 'Aguilar', 'John Isaac', 'Ice', 'ice', 'EE', '', 'SSV', '1983-12-24', 'M', 'Married', '2006-05-22', 'aguilar-kdt/P/KHI', 'pic_173.jpg', 0.3, '06:00', 'ownCar', '', '', 'L5, B4', 'Essen St.', 'Mercedes Exec. Vill.', 'San Miguel', 'City of Pasig', 'NCR, Second District', 1600, 'SSV', 'EE', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(25, 174, 'APOSTOL_Roel Boy', 'Apostol', 'Roel Boy', 'Putol', 'roel', 'EE', '', 'SSV', '1983-06-20', 'M', 'Married', '2006-08-22', 'apostol-kdt/P/KHI', 'pic_174.jpg', 0.0, '06:10', 'carpool', 'Roel Boy Apostol', '', '', '', '', 'San Joaquin', 'City of Pasig', 'NCR, Second District', 1601, 'SSV', 'EE', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(26, 185, 'DE JESUS_Ryan', 'De Jesus', 'Ryan', 'Ryan', 'ryanm', 'PIP', '', 'SSV', '1982-08-25', 'M', 'Married', '2006-11-16', 'dejesus-kdt/P/KHI', 'pic_185.jpg', 0.0, '06:00', 'carpool', 'Evangeline Panado', '', '8259', 'Camachile Street', 'San Antonio Village', 'San Antonio', 'City of Makati', 'NCR, Fourth District', 1203, 'SSV', 'PIP', '1', '2022-03-31', '', 1, NULL, 1, 0, 0, 0),
(27, 194, 'CASTUERA_Maxwell', 'Castuera', 'Maxwell', 'Max', 'max', 'MHAH', '', 'SSV', '1980-03-07', 'M', 'Single', '2007-01-02', 'castuera-kdt/P/KHI', 'pic_194.jpg', 0.0, '07:00', 'ownCar', '', '', '4002', 'Gen. Malvar', '', 'Bangkal', 'City of Makati', 'NCR, Fourth District', 1233, 'SSV', 'MHAH', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(28, 209, 'LEAL JR._Ernesto', 'Leal Jr.', 'Ernesto', 'Leal', 'ernesto', 'CEM', 'CEM/ETCL/MPM', 'SSV', '1982-09-28', 'M', 'Married', '2007-03-01', 'leal-kdt/P/KHI', 'pic_209.jpg', 0.5, '07:30', 'motorCycle', '', '', 'Lot5 Blk.1', '', 'Westwood 4', 'Pasong Camachile II', 'City of General Trias', 'Cavite', 4107, 'SSV', 'CEM', '1', '2022-03-31', '', 1, NULL, 1, 0, 0, 0),
(29, 212, 'LAZARO_Edmon', 'Lazaro', 'Edmon', 'Mon', 'edmon', 'SYS', 'SYS', 'SSS', '1984-10-20', 'M', 'Married', '2007-03-21', 'lazaro-kdt/P/KHI', 'pic_212.jpg', 0.0, '06:15', 'motorCycle', '', '50', '50', 'Virginia Street', ',Manotoc Subdivision', 'Santo Niño', 'City of Marikina', 'NCR, Second District', 1800, 'SSS', 'SYS', '1', '2022-03-31', '', 1, NULL, 1, 4, 1, 1),
(30, 215, 'PALMONES_Michael', 'Palmones', 'Michael', 'Mike', 'michaelp', 'CEM', '', 'SSV', '1979-12-12', 'M', 'Single', '2007-03-21', 'palmones-kdt/P/KHI', 'pic_215.jpg', 4.0, '07:00', 'carpool', 'Joseph Michael Macalalad', '', 'B12 L10', 'Lontoc', 'PVHAI', 'Calzada', 'City of Taguig', 'NCR, Fourth District', 1635, 'SSV', 'CEM', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(31, 221, 'CAMATO JR._Gerardo', 'Camato Jr.', 'Gerardo', 'Gerald', 'gerard', 'ENV', '', 'SSV', '1984-10-14', 'M', 'Married', '2007-05-16', 'camato-kdt/P/KHI', 'pic_221.jpg', 0.0, '08:00', 'publicTransportation', '', '', '15Th', 'Cristo rey', 'SAV3', 'San Antonio', 'City of Parañaque', 'NCR, Fourth District', 1715, 'SSV', 'ENV', '1', '2022-03-31', '', 1, NULL, 1, 0, 0, 0),
(32, 222, 'BELTRAN_Jeffrey', 'Beltran', 'Jeffrey', 'Jeff', 'jeffrey', 'MIL', '', 'SSV', '1983-12-30', 'M', 'Single', '2007-05-16', 'beltran-kdt/P/KHI', 'pic_222.jpg', 0.0, '07:00', 'ownCar', '', '', '1', 'Palo Maria', '', 'Western Bicutan', 'City of Taguig', 'NCR, Fourth District', 1630, 'SSV', 'MIL', '1', '2022-03-31', '', 1, NULL, 1, 0, 0, 0),
(33, 223, 'PAHEL_Jobert', 'Pahel', 'Jobert', 'Jobs', 'jobert', 'MIL', '', 'SSV', '1982-08-21', 'M', 'Married', '2007-05-16', 'pahel-kdt/P/KHI', 'pic_223.jpg', 0.0, '07:00', 'publicTransportation', '', '', '142 BLK2', 'LANDSCAPE AREA', 'UPS4', 'Marcelo Green Village', 'City of Parañaque', 'NCR, Fourth District', 1700, 'SSV', 'MIL', '1', '2022-03-31', '', 1, NULL, 1, 0, 0, 0),
(34, 224, 'DESOLOC_Blessel', 'Desoloc', 'Blessel', 'Bles', 'bles', 'ENV', '', 'SSV', '1985-03-29', 'F', 'Single', '2007-05-16', 'desoloc-kdt/P/KHI', 'pic_224.jpg', 0.0, '08:00', 'publicTransportation', '', '-', 'Block 22 Lot 24', '', 'Green Estate 2', 'Malagasang 1-F', 'City of Cavite', 'Cavite', 4103, 'SSV', 'ENV', '1', '2022-03-31', '', 1, NULL, 1, 0, 0, 0),
(35, 226, 'GULAPA_Francis Martee', 'Gulapa', 'Francis Martee', 'Martee', 'martee', 'EE', '', 'SSV', '1985-01-23', 'M', 'Married', '2007-05-16', 'gulapa-kdt/P/KHI', 'pic_226.jpg', 0.0, '06:00', 'carpool', 'Francis Martee Gulapa', '', '17A', 'Peugeot Street', 'Village East Executive Homes ', 'Santo Domingo', 'Cainta', 'Rizal', 1900, 'SSV', 'EE', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(36, 230, 'OLIVEROS_Mark Anthony', 'Oliveros', 'Mark Anthony', 'Mark', 'mark', 'MHAH', '', 'SV', '1983-04-16', 'M', 'Married', '2007-06-25', 'oliveros-kdt/P/KHI', 'pic_230.jpg', 0.5, '07:00', 'ownCar', '', '', 'Blk 4, Lot 8', 'Peach', 'Park Infina', 'Alapan II-A', 'City of Imus', 'Cavite', 4103, 'SV', 'MHAH', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(37, 238, 'SESE_Joseph Ferdinand', 'Sese', 'Joseph Ferdinand', 'Joseph', 'sese', 'ENV', '', 'SV', '1973-09-11', 'M', 'Married', '2007-08-16', 'sese-kdt/P/KHI', 'pic_238.jpg', 8.0, '08:00', 'motorCycle', '', '', '', '', '', 'Cupang', 'Arayat', 'Pampanga', 2012, 'SV', 'ENV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(38, 240, 'MIRANDA_Christian Jay', 'Miranda', 'Christian Jay', 'Chris', 'christian', 'CEM', '', 'SV', '1983-08-25', 'M', 'Married', '2007-08-16', 'miranda-kdt/P/KHI', 'pic_240.jpg', 0.0, '07:00', 'motorCycle', '', 'LANCASTER NEW CITY', 'BLOCK 9 LOT 10', 'KIPLING ST.', 'BRIGHTON 6', 'Santa Clara', 'City of General Trias', 'Cavite', 4107, 'SV', 'CEM', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(39, 243, 'RAMOS_Sheena', 'Ramos', 'Sheena', 'Shin', 'sheena', 'ACT', '', 'SAA', '1985-09-03', 'F', 'Married', '2007-12-03', 'serdina-kdt/P/KHI', 'pic_243.jpg', 0.0, '06:00', 'Arnold', '04:20/15:00', '', 'Blk 1A Lot 11', 'Lessandra', 'Camella', 'Bagtas', 'Tanza', 'Cavite', 4108, 'SAA', 'ACT', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(40, 252, 'ARANETA_Rex', 'Araneta', 'Rex', 'Rex', 'araneta-kdt', 'CIV', '', 'SSV', '1983-05-16', 'M', 'Married', '2008-05-19', 'araneta-kdt/P/KHI', 'pic_252.jpg', 0.5, '06:30', 'carpool', 'Al Shariff Gallardo', '', 'Blk 14 Lot 22', 'Chico', 'South Fairway Homes', 'Landayan', 'City of San Pedro', 'Laguna', 4023, 'SSV', 'CIV', '1', '2022-03-31', '', 1, NULL, 1, 3, 0, 0),
(41, 256, 'SAHAGUN_Michelle', 'Sahagun', 'Michelle', 'Cheng', 'cheng', 'CEM', 'INT/CEM', 'SV', '1982-05-20', 'F', 'Married', '2010-03-01', 'canalda-kdt/P/KHI', 'pic_256.jpg', 2.0, '06:00', 'carpool', 'Roel Boy Apostol', '', '34-C', 'BANAAG ST', '', 'Pineda', 'City of Pasig', 'NCR, Second District', 1603, 'SV', 'CEM', '1', '2022-03-31', '', 0, '2022-12-31', 0, 0, 0, 0),
(42, 257, 'ONOD_Abeel', 'Onod', 'Abeel', 'Abel', 'abel', 'MIL', '', 'SV', '1986-07-07', 'M', 'Married', '2010-03-01', 'onod-kdt/P/KHI', 'pic_257.jpg', 0.0, '06:00', 'ownCar', '', '', '107-D', '7th Avenue', '', 'East Rembo', 'City of Makati', 'NCR, Fourth District', 1216, 'SV', 'MIL', '1', '2022-03-31', '', 0, '2023-03-15', 0, 0, 0, 0),
(43, 259, 'LUCENA_Rey', 'Lucena', 'Rey', 'Rey', 'rey', 'CEM', '', 'SV', '1987-05-04', 'M', 'Married', '2010-03-01', 'lucena-kdt/P/KHI', 'pic_259.jpg', 0.0, '07:00', 'ownCar', '', '', '478B', 'Miguelin St', '', 'Barangay 455', 'Sampaloc, City of Manila', 'NCR, First District', 1008, 'SV', 'CEM', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(44, 260, 'VERANO_Ronald', 'Verano', 'Ronald', 'RV', 'rv', 'ETCL', '', 'SV', '1984-07-11', 'M', 'Married', '2010-03-01', 'verano-kdt/P/KHI', 'pic_260.jpg', 1.5, '07:00', 'bicycle', '', '310-A', '', 'eusebio', '', 'Barangay 42', 'Pasay City', 'NCR, Fourth District', 1306, 'SV', 'ETCL', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(45, 261, 'VILLAMOR_Amor', 'Villamor', 'Amor', 'Amor', 'amor', 'CHE', '', 'SV', '1984-09-15', 'M', 'Married', '2010-03-01', 'villamor-kdt/P/KHI', 'pic_261.jpg', 0.1, '06:00', 'publicTransportation', '', 'C3-1H', 'California Garden Square', 'Libertad Street', '', 'Highway Hills', 'City of Mandaluyong', 'NCR, Second District', 1550, 'SV', 'CHE', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(46, 262, 'CANTARA_Mark Joel', 'Cantara', 'Mark Joel', 'Joel', 'cantara', 'MHAH', '', 'SV', '1984-01-20', 'M', 'Single', '2010-03-01', 'cantara-kdt/P/KHI', 'pic_262.jpg', 0.0, '06:00', 'publicTransportation', '', '', '65', 'Premium', 'GSIS Village, Project 8', 'Sangandaan', 'Quezon City', 'NCR, Second District', 1106, 'SV', 'MHAH', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(47, 263, 'PASCUA_Henry', 'Pascua', 'Henry', 'Henry', 'henry', 'MHAH', '', 'SV', '1984-06-19', 'M', 'Married', '2010-03-01', 'pascua-kdt/P/KHI', 'pic_263.jpg', 0.5, '07:00', 'motorCycle', '', '', 'B8 L6', 'Williamburg', 'Chesapeake Village', 'Buhay na Tubig', 'City of Imus', 'Cavite', 4103, 'SV', 'MHAH', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(48, 264, 'CULAR_Giulian Louis', 'Cular', 'Giulian Louis', 'Louis', 'louis', 'CRY', '', 'SDE', '1986-06-21', 'M', 'Single', '2010-03-01', 'cular-kdt/P/KHI', 'pic_264.jpg', 2.2, '06:30', 'carpool', 'Al Shariff Gallardo', '', 'B-41 L-5', 'Bentley Avenue', 'South Spring', 'Canlalay', 'City of Biñan', 'Laguna', 4024, 'SDE', 'CRY', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(49, 265, 'ONOD_Amalia', 'Onod', 'Amalia', 'Amie', 'amie', 'ENV', '', 'SDE', '1989-07-05', 'F', 'Married', '2010-03-01', 'nodalo-kdt/P/KHI', 'pic_265.jpg', 0.0, '06:00', 'ownCar', '', '', '107-D', '7th Avenue', '', 'East Rembo', 'City of Makati', 'NCR, Fourth District', 1216, 'SDE', 'ENV', '1', '2022-03-31', '', 0, '2023-03-15', 0, 0, 0, 0),
(50, 268, 'SANDOVAL_Dan Christian', 'Sandoval', 'Dan Christian', 'Dan', 'sandoval', 'PIP', 'PIP/DXT', 'SV', '1985-10-06', 'M', 'Single', '2010-06-01', 'sandoval-kdt/P/KHI', 'pic_268.jpg', 0.0, '06:00', 'publicTransportation', '', '', 'SM LIGHT RESIDENCES', 'MADISON', '', 'Barangka Ilaya', 'City of Mandaluyong', 'NCR, Second District', 1550, 'SV', 'PIP', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(51, 270, 'CARINGAL_Gian Carlo', 'Caringal', 'Gian Carlo', 'Carlo', 'carlo', 'PIP', '', 'SV', '1985-12-15', 'M', 'Married', '2010-06-01', 'caringal-kdt/P/KHI', 'pic_270.jpg', 2.3, '06:00', 'ownCar', '', '', '21', 'Castello Street', 'Casa Milan Neopolitan', 'Greater Lagro', 'Quezon City', 'NCR, Second District', 1100, 'SV', 'PIP', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(52, 272, 'CAVEIRO_Vincent', 'Caveiro', 'Vincent', 'Vince', 'vince_resigned', 'PIP', '', 'SV', '1986-01-02', 'M', 'Married', '2010-06-01', 'caveiro-resigned/P/KHI', 'pic_272.jpg', 0.0, '08:00', 'publicTransportation', '', 'D&D Place', '38', 'Clemente Jose', 'Malibay', 'Barangay 159', 'Pasay City', 'NCR, Fourth District', 1300, 'SV', 'PIP', '1', '2022-03-31', '', 0, '2023-03-31', 0, 0, 0, 0),
(53, 279, 'PANOPIO_Luisito', 'Panopio', 'Luisito', 'Louie', 'lpanopio', 'MHAH', '', 'SV', '1984-02-27', 'M', 'Single', '2010-06-16', 'panopio-kdt/P/KHI', 'pic_279.jpg', 2.5, '06:00', 'publicTransportation', '', '', '5', 'Baluarte Street', 'Camella Homes 4', 'Poblacion', 'City of Muntinlupa', 'NCR, Fourth District', 1776, 'SV', 'MHAH', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(54, 281, 'CURA_Leonard Ryan', 'Cura', 'Leonard Ryan', 'Ryan', 'cura', 'CHE', '', 'SV', '1986-12-08', 'M', 'Married', '2010-06-16', 'cura-kdt/P/KHI', 'pic_281.jpg', 0.2, '06:30', 'publicTransportation', '', '', 'BLK 2 Lot 14', 'Sampaguita St.', 'The Grove', 'Gatbuca', 'Calumpit', 'Bulacan', 3003, 'SV', 'CHE', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(55, 283, 'CENIZAL_Ma. Evangeline', 'Cenizal', 'Ma. Evangeline', 'Vangie', 'adami', 'EE', '', 'SV', '1986-10-22', 'F', 'Married', '2010-06-16', 'adami-kdt/P/KHI', 'pic_283.jpg', 0.0, '06:00', 'Arnold', '04:45/15:00', '', 'BLK 6 - LOT 12', 'ROGER FEDERER', 'SOUTH DASMA GARDEN VILLAS', 'Salawag', 'City of Dasmariñas', 'Cavite', 4114, 'SV', 'EE', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(56, 284, 'CIDRO_James Eric', 'Cidro', 'James Eric', 'Jim', 'james', 'EE', 'EE/DXT', 'SV', '1987-10-18', 'M', 'Married', '2010-06-16', 'cidro-kdt/P/KHI', 'pic_284.jpg', 0.0, '06:00', 'publicTransportation', '', '9E', '-', '5th Avenue', '-', 'Socorro', 'Quezon City', 'NCR, Second District', 1109, 'SV', 'EE', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(57, 288, 'GODOY_JHON RAY', 'Godoy', 'Jhon Ray', 'Jhon', 'jhon', 'EE', '', 'SV', '1989-01-10', 'M', 'Married', '2011-01-03', 'godoy-kdt/P/KHI', 'pic_288.jpg', 0.0, '07:00', 'publicTransportation', '', '', '#30', 'Calle Cabasaan', '', 'South Signal Village', 'City of Taguig', 'NCR, Fourth District', 1632, 'SV', 'EE', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(58, 290, 'ARIAP_JOMANIL', 'Ariap', 'Jomanil', 'Joma', 'joma', 'CRY', '', 'SDE', '1988-06-27', 'M', 'Single', '2011-01-03', 'ariap-kdt/P/KHI', 'pic_290.jpg', 0.0, '07:00', 'bicycle', '', '', 'Unit 310-A', 'Eusebio St.', 'Tramo', 'Barangay 42', 'Pasay City', 'NCR, Fourth District', 1300, 'SDE', 'CRY', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(59, 291, 'LLOSALA_ROWEL', 'Llosala', 'Rowel', 'Wel', 'rowel', 'CHE', '', 'SV', '1988-02-26', 'M', 'Married', '2011-01-03', 'llosala-kdt/P/KHI', 'pic_291.jpg', 0.0, '06:00', 'carpool', 'Henry Pascua', 'Legian 2 Phase B', 'Block 3 Lot 26', '4th street', 'Legian 2', 'Carsadang Bago I', 'City of Imus', 'Cavite', 4103, 'SV', 'CHE', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(60, 293, 'DIMAAPI_JASPER', 'Dimaapi', 'Jasper', 'Jasper', 'jasper', 'ETCL', '', 'SV', '1989-05-16', 'M', 'Single', '2011-01-03', 'dimaapi-kdt/P/KHI', 'pic_293.jpg', 0.0, '06:00', 'carpool', 'Jasper Dimaapi', '520L Charleston Bldg.', '', 'C. Raymundo St', 'Hampton Gardens', 'Maybunga', 'City of Pasig', 'NCR, Second District', 1607, 'SV', 'ETCL', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(61, 295, 'MORENO_Rex', 'Moreno', 'Rex', 'Rex', 'moreno', 'MHAH', 'MHAH', 'AM', '1981-03-27', 'M', 'Single', '2011-05-02', 'moreno-kdt/P/KHI', 'pic_295.jpg', 7.0, '07:30', 'publicTransportation', '', 'N/A', '2697', 'General Cailles', 'N/A', 'Bangkal', 'City of Makati', 'NCR, Fourth District', 1233, 'AM', 'MHAH', '1', '2022-03-31', '', 1, NULL, 1, 3, 0, 0),
(62, 296, 'MACALALAD_Joseph Michael', 'Macalalad', 'Joseph Michael', 'Joseph', 'macalalad', 'ENV', 'ENV', 'AM', '1981-02-16', 'M', 'Married', '2011-05-02', 'macalalad-kdt/P/KHI', 'pic_296.jpg', 7.4, '07:15', 'carpool', 'Joseph Michael Macalalad', '304 Spruce bldg. Maple Place', '', 'Molave lane', 'Acacia Estates', 'Ususan', 'City of Taguig', 'NCR, Fourth District', 1632, 'AM', 'ENV', '1', '2022-03-31', '', 1, NULL, 1, 3, 0, 0),
(63, 299, 'CANO_Bryan Jay', 'Cano', 'Bryan Jay', 'Bryan', 'cano-kdt', 'BOI', 'BOI/INT', 'SV', '1988-08-12', 'M', 'Single', '2011-08-01', 'cano-kdt/P/KHI', 'pic_299.jpg', 0.7, '06:00', 'motorCycle', '', 'Tower 3 14E', 'San Lorenzo Place Condominium', 'EDSA cor Don Chino Roces Ave', '', 'Bangkal', 'City of Makati', 'NCR, Fourth District', 1233, 'SV', 'BOI', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(64, 301, 'LINA_Dominador Joshua', 'Lina', 'Dominador Joshua', 'Josh', 'lina-kdt', 'BOI', 'BOI/INT', 'SDE', '1989-07-03', 'M', 'Single', '2011-08-01', 'lina-kdt/P/KHI', 'pic_301.jpg', 0.5, '08:30', 'ownCar', '', '', '105', 'Alligator St Commando Rd', '', 'Rizal', 'City of Makati', 'NCR, Fourth District', 1208, 'SDE', 'BOI', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(65, 302, 'SAMPAGA_LOUIE', 'Sampaga', 'Louie', 'Louie', 'sampaga', 'EE', 'EE/DXT', 'SDE', '1987-12-02', 'M', 'Married', '2012-01-16', 'sampaga-kdt/P/KHI', 'pic_302.jpg', 0.0, '07:00', 'publicTransportation', '', '', 'Block 6 Lot 25A', 'Amethys', 'Jewel Homes', 'Buenavista III', 'City of General Trias', 'Cavite', 4107, 'SDE', 'EE', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(66, 304, 'MUNDO_DAISY', 'Mundo', 'Daisy', 'Daisy', 'daisy', 'ENV', 'ENV/CHE', 'DE3', '1979-01-18', 'F', 'Single', '2012-01-16', 'mundo-kdt/P/KHI', 'pic_304.jpg', 0.0, '', '', '', '', '', '', '', '', '', '', 0, 'DE3', 'ENV', '0', '2022-03-31', '', 0, '2021-11-01', 0, 0, 0, 0),
(67, 305, 'ESCUETA_RODERICK', 'Escueta', 'Roderick', 'Eric', 'roderick', 'PIP', '', 'SDE', '1981-02-09', 'M', 'Married', '2012-01-16', 'escueta-kdt/P/KHI', 'pic_305.jpg', 0.0, '06:15', 'carpool', 'Jomari Sanao', '', 'Blk 5 lot 61', '', 'Vista Rosa', 'Soro-soro', 'City of Biñan', 'Laguna', 4024, 'SDE', 'PIP', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(68, 306, 'BELEN_KERVIN', 'Belen', 'Kervin', 'Kervin', 'kervin', 'PIP', 'PIP/DXT', 'SDE', '1988-07-23', 'M', 'Married', '2012-01-16', 'belen-kdt/P/KHI', 'pic_306.jpg', 0.0, '06:20', 'motorCycle', '', '', '5 / Blk 41', 'chrysanthenum', '', 'Addition Hills', 'City of Mandaluyong', 'NCR, Second District', 1550, 'SDE', 'PIP', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(69, 307, 'BALLON_Veronica', 'Ballon', 'Veronica', 'Vec', 'mendoza-kdt', 'IT', '', 'IT-SV', '1989-12-10', 'F', 'Married', '2012-05-07', 'mendoza-kdt/P/KHI', 'pic_307.jpg', 0.0, '06:30', 'ownCar', '', '', 'B10, L117', 'Sandpiper St.', 'Westwood 1, Lancaster', 'Pasong Camachile II', 'City of General Trias', 'Cavite', 4107, 'IT-SV', 'IT', '1', '2022-03-31', '', 1, NULL, 1, 4, 1, 1),
(70, 310, 'TUMAOB_FERDINAND', 'Tumaob', 'Ferdinand', 'Tommy', 'tommy', 'MIL', '', 'SDE', '1984-12-18', 'M', 'Married', '2012-05-16', 'tumaob-kdt/P/KHI', 'pic_310.jpg', 4.0, '06:30', 'motorCycle', '', '', '', '', 'Gumamela 2 Phase 4', 'Cupang', 'City of Antipolo', 'Rizal', 1870, 'SDE', 'MIL', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(71, 311, 'PENETRANTE JR._JORGE', 'Penetrante Jr.', 'Jorge', 'JR', 'jorge', 'BOI', '', 'SV', '1986-10-28', 'M', 'Single', '2012-05-16', 'penetrante-kdt/P/KHI', 'pic_311.jpg', 2.0, '08:00', 'publicTransportation', '', '28Q Pioneer Woodlands Tower 5', '', 'Pioneer St., cor. EDSA', '', 'Barangka Ilaya', 'City of Mandaluyong', 'NCR, Second District', 1550, 'SV', 'BOI', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(72, 312, 'LUCAS_ADELBERT', 'Lucas', 'Adelbert', 'Adel', 'adel', 'BOI', '', 'SDE', '1988-08-18', 'M', 'Single', '2012-05-16', 'lucas-kdt/P/KHI', 'pic_312.jpg', 0.0, '08:00', 'publicTransportation', '', '', '934', 'Remedios', '', 'Barangay 691', 'Malate, City of Manila', 'NCR, First District', 1004, 'SDE', 'BOI', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(73, 313, 'AGUSTINES_ALBERT', 'Agustines', 'Albert', 'Albert', 'albert', 'EE', 'EE/DXT', 'SDE', '1987-07-24', 'M', 'Single', '2012-05-16', 'agustines-kdt/P/KHI', 'pic_313.jpg', 0.0, '07:00', 'publicTransportation', '', '', '7', 'erlnda drv.', 'vermont  royale', 'Mayamot', 'City of Antipolo', 'Rizal', 1870, 'SDE', 'EE', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(74, 314, 'SANGALANG_DICKENSON', 'Sangalang', 'Dickenson', 'Dick', 'dickenson', 'EE', '', 'SDE', '1983-11-17', 'M', 'Married', '2012-05-16', 'sangalang_d-kdt/P/KHI', 'pic_314.jpg', 6.7, '06:20', 'ownCar', '', '', 'PH4 B4 L13', 'SANGGIL', 'SPRINGVILLE HEIGHTS', 'Molino VII', 'City of Bacoor', 'Cavite', 4102, 'SDE', 'EE', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(75, 316, 'BAUTISTA JR._CELSO', 'Bautista Jr.', 'Celso', 'Ceejay', 'cj', 'CEM', '', 'SDE', '1991-05-23', 'M', 'Single', '2013-02-16', 'bautista-kdt/P/KHI', 'pic_316.jpg', 0.0, '06:00', 'motorCycle', '', 'N/A', '1565E', 'Valentina', 'N/A', 'Barangay 814', 'Paco, City of Manila', 'NCR, First District', 1007, 'DE3', 'CEM', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(76, 320, 'ESCUETA JR._JUANITO', 'Escueta Jr.', 'Juanito', 'Jeck', 'jeckzay', 'EE', '', 'DE3', '1984-03-23', 'M', 'Married', '2013-02-16', 'escueta_j-kdt/P/KHI', 'pic_320.jpg', 1.6, '06:00', 'carpool', 'Al Shariff Gallardo', '', '1376', 'Macopa St.', 'Garcia Subdivision San Antonio', 'Biñan', 'City of Biñan', 'Laguna', 4024, 'DE3', 'EE', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(77, 321, 'BIGTAS_KEITH CHARM', 'Bigtas', 'Keith Charm', 'Charm', 'charm', 'EE', '', 'DE3', '1985-03-26', 'F', 'Single', '2013-02-16', 'bigtas-kdt/P/KHI', 'pic_321.jpg', 2.2, '07:00', 'carpool', 'Marie Eleonor Bio', '', '48', 'MRT Avenue', '', 'New Lower Bicutan', 'City of Taguig', 'NCR, Fourth District', 1630, 'DE3', 'EE', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(78, 322, 'DELA ROSA_ESTER', 'Dela Rosa', 'Ester', 'Tets', 'ester', 'EE', '', 'SDE', '1987-02-28', 'F', 'Single', '2013-02-16', 'delarosa-kdt/P/KHI', 'pic_322.jpg', 0.0, '07:00', 'publicTransportation', '', '', '61C', 'C. JOSE ST.,', '', 'Barangay 160', 'Pasay City', 'NCR, Fourth District', 1300, 'SDE', 'EE', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(79, 323, 'BORLAGON_ALVIN JAN', 'Borlagon', 'Alvin Jan', 'Vin', 'vhin', 'BOI', '', 'SDE', '1990-01-29', 'M', 'Married', '2013-02-16', 'borlagon-kdt/P/KHI', 'pic_323.jpg', 0.0, '06:10', 'publicTransportation', '', '', 'L-10, BLk 53', '10-29th St.', 'Villamor', 'Barangay 183', 'Pasay City', 'NCR, Fourth District', 1309, 'SDE', 'BOI', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(80, 328, 'CALLEJA_NOMER', 'Calleja', 'Nomer', 'PIPOY', 'nomer', 'BOI', '', 'SDE', '1989-04-11', 'M', 'Married', '2013-05-02', 'calleja-kdt/P/KHI', 'pic_328.jpg', 1.4, '06:00', 'publicTransportation', '', 'N/A', 'Blk 62 Lot.18', 'N/A', 'Birmingham Subd.Phase 3', 'Pulo', 'City of Cabuyao', 'Laguna', 4025, 'SDE', 'BOI', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(81, 329, 'MARQUESES_JEFF EDWARD', 'Marqueses', 'Jeff Edward', 'JEFF', 'je', 'BOI', '', 'SDE', '1988-11-01', 'M', 'Married', '2013-05-02', 'marqueses_j-kdt/P/KHI', 'pic_329.jpg', 2.2, '08:00', 'publicTransportation', '', '', '1710', 'Sandejas', '', 'Barangay 103', 'Pasay City', 'NCR, Fourth District', 1300, 'SDE', 'BOI', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(82, 330, 'OMIZ_GILBERT JASON', 'Omiz', 'Gilbert Jason', 'GILBERT', 'bert', 'PIP', '', 'SDE', '1991-04-03', 'M', 'Single', '2013-08-01', 'omiz-kdt/P/KHI', 'pic_330.jpg', 0.4, '07:00', 'publicTransportation', '', '', '15264', 'St. Francis St.', '', 'Moonwalk', 'City of Parañaque', 'NCR, Fourth District', 1709, 'SDE', 'PIP', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(83, 332, 'DE GUZMAN_CHRISTOPHER', 'De Guzman', 'Christopher', 'CHRIS', 'chrisdegz', 'ENV', '', 'SDE', '1990-09-22', 'M', 'Single', '2013-08-01', 'deguzman-kdt/P/KHI', 'pic_332.jpg', 0.0, '', '', '', '', '', '', '', '', '', '', 0, 'SDE', 'ENV', '0', '2022-03-31', '', 0, '2021-11-01', 0, 0, 0, 0),
(84, 333, 'MATAUM_MICHAEL', 'Mataum', 'Michael', 'KEL', 'kel', 'PIP', 'PIP/DXT', 'SDE', '1989-06-30', 'M', 'Single', '2013-08-01', 'mataum-kdt/P/KHI', 'pic_333.jpg', 0.7, '08:00', 'publicTransportation', '', '4A', '2971', 'Apolinario St', '', 'Bangkal', 'City of Makati', 'NCR, Fourth District', 1233, 'SDE', 'PIP', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(85, 334, 'MIRANDA_Julemir', 'Miranda', 'Julemir', 'JUN JUN', 'miranda_j-kdt', 'ENV', '', 'SDE', '1987-08-26', 'M', 'Single', '2013-08-01', 'miranda_j-kdt/P/KHI', 'pic_334.jpg', 2.1, '07:00', 'publicTransportation', '', '043', '043', 'Santol', 'santo nino', 'Santo Niño', 'Quezon City', 'NCR, Second District', 1008, 'SDE', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(86, 335, 'BALLON_AL JOHN', 'Ballon', 'Al John', 'AL JOHN', 'aljohn', 'MHAH', '', 'SDE', '1989-07-09', 'M', 'Married', '2013-08-01', 'ballon-kdt/P/KHI', 'pic_335.jpg', 0.0, '06:30', 'ownCar', '', '', 'B10, L117', 'Sandpiper Street', 'Westwood 1, Lancaster Estates', 'Pasong Camachile II', 'City of General Trias', 'Cavite', 4107, 'SDE', 'MHAH', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(87, 338, 'BULAN JR._ROSBELT', 'Bulan Jr.', 'Rosbelt', 'ROS', 'ross', 'ENV', 'ENV/DXT', 'SDE', '1990-03-14', 'M', 'Single', '2013-10-01', 'bulan-kdt/P/KHI', 'pic_338.jpg', 0.0, '07:00', 'motorCycle', '', '', '32', 'Galaxy Road', 'Cielito Homes II', 'San Isidro', 'Taytay', 'Rizal', 1920, 'SDE', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(88, 344, 'PATRON_EDILAINE MAROSE', 'Patron', 'Edilaine Marose', 'EM', 'em', 'CHE', '', 'DE3', '1992-01-24', 'F', 'Single', '2014-01-02', 'patron-kdt/P/KHI', 'pic_344.jpg', 0.0, '06:30', 'carpool', 'Juanito Escueta Jr.', '', 'B18 L7', '', 'St Joseph Village 2', 'Santo Tomas', 'City of Biñan', 'Laguna', 4024, 'DE3', 'CHE', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(89, 345, 'CAUNGA_RUSTUM OLIVER', 'Caunga', 'Rustum Oliver', 'RUSTUM', 'rocaunga', 'CRY', '', 'DE3', '1990-06-29', 'M', 'Single', '2014-01-02', 'caunga-kdt/P/KHI', 'pic_345.jpg', 0.9, '06:00', 'carpool', 'Rustum Oliver Caunga', '', '17', 'Abu Bakr St.', 'Kingsville Executive Village', 'Mayamot', 'City of Antipolo', 'Rizal', 1870, 'DE3', 'CRY', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(90, 346, 'BIO_MARIE ELEONOR', 'Bio', 'Marie Eleonor', 'MARIE', 'yhelle', 'EE', '', 'DE3', '1991-04-15', 'F', 'Married', '2014-01-02', 'mirabel-kdt/P/KHI', 'pic_346.jpg', 1.2, '07:00', 'publicTransportation', '', '', '4', 'Maestrang Pinang', '', 'Ligid-Tipas', 'City of Taguig', 'NCR, Fourth District', 1638, 'DE3', 'EE', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(91, 348, 'TOBIAS_JEOFFER', 'Tobias', 'Jeoffer', 'JEOFF', 'jltobias', 'ENV', '', 'DE3', '1990-07-24', 'M', 'Single', '2014-04-01', 'tobias-kdt/P/KHI', 'pic_348.jpg', 0.0, '07:00', 'motorCycle', '', '', 'Blk 77 Lot 7', '12-23rd', 'Villamor', 'Barangay 183', 'Pasay City', 'NCR, Fourth District', 1300, 'DE3', 'ENV', '1', '2022-03-31', '', 0, '2023-02-13', 0, 0, 0, 0),
(92, 350, 'CAJES_JOSEPH', 'Cajes', 'Joseph', 'DODONG', 'josephcc', 'CRY', '', 'DE3', '1990-03-22', 'M', 'Married', '2014-04-01', 'cajes-kdt/P/KHI', 'pic_350.jpg', 1.0, '06:00', 'bicycle', '', '', '310A', 'Eusebio', '', 'Barangay 42', 'Pasay City', 'NCR, Fourth District', 1300, 'DE3', 'CRY', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(93, 352, 'DUCAY_JOHN DAVID', 'Ducay', 'John David', 'DAVID', 'johndavid', 'ENV', '', 'DE3', '1989-08-28', 'M', 'Married', '2014-04-01', 'ducay-kdt/P/KHI', 'pic_352.jpg', 0.9, '07:00', 'carpool', 'John David Ducay', 'Crestly Bldg', '2L10', 'Perla Street', '', 'Barangay 8', 'Pasay City', 'NCR, Fourth District', 1300, 'DE3', 'ENV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(94, 353, 'TORIO_RAFFY', 'Torio', 'Raffy', 'RAFFY', 'raffy', 'SYS', 'SYS/SHI', 'SSE', '1989-02-02', 'M', 'Single', '2014-04-01', 'torio-kdt/P/KHI', 'pic_353.jpg', 1.2, '09:00', 'ownCar', '', '', '1952', 'RADIAL ROAD 10', '', 'Barangay 110', 'Tondo I/II, City of Manila', 'NCR, First District', 1012, 'SSE', 'SYS', '0', '2022-07-27', 'Erwin Tan', 0, '2022-07-18', 0, 4, 1, 1),
(95, 355, 'DE JESUS_JOMMUEL', 'De Jesus', 'Jommuel', 'JOM', 'jommuel', 'SYS', 'SYS', 'SE3', '1992-01-29', 'M', 'Single', '2014-04-01', 'dejesus_j-kdt/P/KHI', 'pic_355.jpg', 0.0, '07:00', 'motorCycle', '', '', '3064', 'Don Simeon St.', '', 'Mapulang Lupa', 'City of Valenzuela', 'NCR, Third District', 1448, 'SE3', 'SYS', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 4, 0, 1),
(96, 356, 'SUMAYOP_LIAN MARIE', 'Sumayop', 'Lian Marie', 'LIAN', 'lian', 'EE', '', 'DE3', '1991-02-07', 'F', 'Married', '2014-04-01', 'cabradilla-kdt/P/KHI', 'pic_356.jpg', 0.7, '07:00', 'publicTransportation', '', '', 'Blk 3 Lot 4', 'Sampaguita St.', 'Salanap Compound, Sitio Mendez', 'Baesa', 'Quezon City', 'NCR, Second District', 1106, 'DE3', 'EE', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(97, 357, 'SANAO_JOMARI', 'Sanao', 'Jomari', 'JOM', 'jomari', 'PIP', '', 'DE3', '1992-11-19', 'M', 'Married', '2014-06-02', 'sanao-kdt/P/KHI', 'pic_357.jpg', 0.9, '06:15', 'carpool', 'Jomari Sanao', '', 'B15 L16 P8', 'GS Taad', 'Garden Villas 3', 'Malusak (Pob.)', 'City of Santa Rosa', 'Laguna', 4026, 'DE3', 'PIP', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(98, 358, 'SANAO_ROXANNE MAY', 'Sanao', 'Roxanne May', 'XANXAN', 'xanxane', 'PIP', '', 'DE3', '1991-03-11', 'F', 'Married', '2014-06-02', 'velez-kdt/P/KHI', 'pic_358.jpg', 0.0, '06:15', 'carpool', 'Jomari Sanao', '', 'blk15 lot 16', 'GS Taad Street', 'Garden Villas 3', 'Malusak (Pob.)', 'City of Santa Rosa', 'Laguna', 4026, 'DE3', 'PIP', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(99, 364, 'BITANG_KIM BRIAN', 'Bitang', 'Kim Brian', 'Kim', 'Kimbrian', 'ENV', '', 'DE3', '1992-02-15', 'F', 'Single', '2014-09-01', 'bitang-kdt/P/KHI', 'pic_364.jpg', 0.0, '', '', '', '', '', '', '', '', '', '', 0, 'DE3', 'ENV', '0', '2022-03-31', '', 0, '2021-11-01', 0, 0, 0, 0),
(100, 365, 'MAGNAYE_LARA JOY', 'Magnaye', 'Lara Joy', 'LARA', 'lara', 'ENV', '', 'DE3', '1991-09-17', 'F', 'Married', '2014-09-01', 'dimaculangan-kdt/P/KHI', 'pic_365.jpg', 0.0, '', '', '', '', '', '', '', '', '', '', 0, 'DE3', 'ENV', '0', '2022-03-31', '', 0, '2021-11-01', 0, 0, 0, 0),
(101, 367, 'MENDOZA_MARCIAL', 'Mendoza', 'Marcial', 'MARCY', 'marci', 'ENV', '', 'DE3', '1990-05-24', 'M', 'Married', '2014-09-01', 'mendoza_m-kdt/P/KHI', 'pic_367.jpg', 0.4, '07:30', 'publicTransportation', '', '173F', '', 'M. Santos', '', 'Barangay 25', 'Pasay City', 'NCR, Fourth District', 1300, 'DE3', 'ENV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(102, 370, 'NOPRA_CHARIS CANDY', 'Nopra', 'Charis Candy', 'CANDY', 'candy', 'IT', '', 'IT-SE', '1992-04-14', 'F', 'Single', '2014-09-01', 'nopra-kdt/P/KHI', 'pic_370.jpg', 0.0, '06:00', 'Arnold', '04:45/15:00', '', 'B18 L17 ', '', 'Camachile Subd.', 'Pasong Camachile I', 'City of General Trias', 'Cavite', 4107, 'IT-E3', 'IT', '1', '2022-03-31', '', 1, NULL, 0, 4, 0, 1),
(103, 371, 'CORDOVA_YSABEL', 'Cordova', 'Ysabel', 'Ysay', 'ysay', 'MHAH', '', 'DE3', '1991-01-19', 'F', 'Single', '2015-02-02', 'cordova-kdt/P/KHI', 'pic_371.jpg', 0.0, '07:30', 'publicTransportation', '', '2607 Tower 1, Avida Prime Taft ', '', 'Taft Avenue', '', 'Barangay 36', 'Pasay City', 'NCR, Fourth District', 1709, 'DE3', 'MHAH', '1', '2022-04-19', 'Ernesto Veloso', 1, NULL, 0, 0, 0, 0),
(104, 372, 'FRANE_GERALD CHRISTOPHER', 'Frane', 'Gerald Christopher', 'Gerald', 'gerald', 'EE', '', 'DE3', '1991-12-01', 'M', 'Single', '2015-02-02', 'frane-kdt/P/KHI', 'pic_372.jpg', 0.0, '07:00', 'publicTransportation', '', '', '001', 'Bravo Street', '', 'Central Signal Village', 'City of Taguig', 'NCR, Fourth District', 1630, 'DE3', 'EE', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(105, 373, 'SABARILLO_NELMAR BONG', 'Sabarillo', 'Nelmar Bong', 'Bong', 'bong', 'CRY', '', 'DE3', '1993-04-22', 'M', 'Single', '2015-02-02', 'sabarillo-kdt/P/KHI', 'pic_373.jpg', 0.0, '07:00', 'motorCycle', '', '', '97-8', 'Manuel L. Quezon', '', 'Cupang', 'City of Muntinlupa', 'NCR, Fourth District', 1771, 'DE3', 'CRY', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(106, 374, 'Fortus_Domini', 'Fortus', 'Domini', 'Domini', 'domini_resign', 'TEG', '', 'DE3', '1993-07-12', 'M', 'Single', '2015-02-02', 'fortus-kdt/P/KHI', 'pic_374.jpg', 0.0, '', '', '', '', '', '', '', '', '', '', 0, 'DE3', 'TEG', '0', '2022-03-31', '', 0, '2022-03-15', 0, 0, 0, 0),
(107, 376, 'MANAOG_KAREN LORRAINE', 'Manaog', 'Karen Lorraine', 'Karen', 'karenv', 'EE', '', 'DE3', '1990-10-19', 'F', 'Married', '2015-02-02', 'vallestero-kdt/P/KHI', 'pic_376.jpg', 1.5, '06:00', 'carpool', 'Francis Martee Gulapa', '', '70', 'Naval St.', '', 'Dolores (Pob.)', 'Taytay', 'Rizal', 1920, 'DE3', 'EE', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(108, 377, 'GUICO_ALDRIN', 'Guico', 'Aldrin', 'Gibo', 'gibo', 'MHAH', '', 'DE3', '1991-08-11', 'M', 'Single', '2015-02-02', 'guico-kdt/P/KHI', 'pic_377.jpg', 0.6, '06:15', 'publicTransportation', '', 'Crestly Building', '', 'Perla Street', '', 'Barangay 8', 'Pasay City', 'NCR, Fourth District', 1305, 'DE3', 'MHAH', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(109, 378, 'MONTALBO_JENNELYN', 'Montalbo', 'Jennelyn', 'Jen', 'jhen', 'MHAH', '', 'DE3', '1989-12-04', 'F', 'Married', '2015-02-02', 'reyes_j-kdt/P/KHI', 'pic_378.jpg', 0.0, '', '', '', '', '', '', '', '', '', '', 0, 'DE3', 'MHAH', '0', '2022-03-31', '', 0, '2021-11-01', 0, 0, 0, 0),
(110, 381, 'FLORES_ANGELO', 'Flores', 'Angelo', 'Angelo', 'gelo', 'MHAH', '', 'DE3', '1990-06-19', 'M', 'Single', '2015-02-02', 'flores_a-kdt/P/KHI', 'pic_381.jpg', 0.0, '07:00', 'publicTransportation', '', '', '06C', 'Robin St', 'Francisville', 'Mambugan', 'City of Antipolo', 'Rizal', 1870, 'DE3', 'MHAH', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(111, 382, 'MARQUEZ_ARVIN DAVID', 'Marquez', 'Arvin David', 'Arvin', 'arvin', 'CIV', '', 'DE3', '1991-11-19', 'M', 'Married', '2015-05-11', 'marquez-kdt/P/KHI', 'pic_382.jpg', 0.0, '06:05', 'ownCar', '', '', '242', 'Natividad', '', 'San Pedro (Pob.)', 'Morong', 'Rizal', 1960, 'DE3', 'CIV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(112, 383, 'BELLEN_ABEGAIL', 'Bellen', 'Abegail', 'Abby', 'bellenabi', 'CIV', '', 'DE3', '1990-05-16', 'F', 'Single', '2015-05-11', 'bellen-kdt/P/KHI', 'pic_383.jpg', 0.0, '08:30', 'publicTransportation', '', '117 Purok 5,', 'n/a', 'Road 6', 'n/a', 'Bagong Silangan', 'Quezon City', 'NCR, Second District', 1119, 'DE3', 'CIV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(113, 384, 'GALLARDO_AL SHARIFF', 'Gallardo', 'Al Shariff', 'Al', 'al', 'ANA', '', 'DE3', '1993-06-14', 'M', 'Single', '2015-05-11', 'gallardo-kdt/P/KHI', 'pic_384.jpg', 0.0, '06:00', 'carpool', 'Al Shariff Gallardo', 'No 2B', 'No2B', 'Bonus Street', 'Chrysanthemum', 'Chrysanthemum', 'City of San Pedro', 'Laguna', 4023, 'DE3', 'ANA', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(114, 385, 'PEREZ_JEREMIA', 'Perez', 'Jeremia', 'Mia', 'mia', 'CIV', '', 'DE3', '1990-09-18', 'F', 'Single', '2015-05-11', 'perez_j-kdt/P/KHI', 'pic_385.jpg', 0.0, '09:00', 'publicTransportation', '', '', '1386-K', 'Burgos', '', 'Barangay 826', 'Paco, City of Manila', 'NCR, First District', 1007, 'DE3', 'CIV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(115, 386, 'TAN_DENNIS', 'Tan', 'Dennis', 'Dennis', 'dennistan', 'MPM', '', 'DE3', '1990-07-26', 'M', 'Single', '2015-06-01', 'tan_d-kdt/P/KHI', 'pic_386.jpg', 2.0, '06:00', 'carpool', 'Dennis Tan', '', 'Block 7, Lot 31', '', 'Villa Arcadia', 'Carsadang Bago I', 'City of Imus', 'Cavite', 4103, 'DE3', 'MPM', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(116, 387, 'BALGOMA_RAMIL', 'Balgoma', 'Ramil', 'Ram', 'rbalgoma', 'MHAH', '', 'DE3', '1992-11-17', 'M', 'Single', '2015-06-01', 'balgoma-kdt/P/KHI', 'pic_387.jpg', 0.0, '06:15', 'publicTransportation', '', 'Sophia\'s Place', '98 B', 'Vizcarra St', '', 'Malibay', 'Pasay City', 'NCR, Fourth District', 1300, 'DE3', 'MHAH', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(117, 388, 'GUPIT_BERNICO', 'Gupit', 'Bernico', 'Bernie', 'bernico', 'MHAH', '', 'DE3', '1992-03-16', 'M', 'Single', '2015-06-01', 'gupit-kdt/P/KHI', 'pic_388.jpg', 0.4, '07:00', 'bicycle', '', '', '347', 'Damka', '', 'Barangay 598', 'Sampaloc, City of Manila', 'NCR, First District', 1016, 'DE3', 'MHAH', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(118, 389, 'MIRANDA_NIKKO', 'Miranda', 'Nikko', 'Nikko', 'nikkomiranda', 'MPM', '', 'DE3', '1992-03-16', 'M', 'Single', '2015-06-01', 'miranda_n-kdt/P/KHI', 'pic_389.jpg', 0.4, '06:00', 'motorCycle', '', '', '987', 'Sunnyvale St.', 'Parkplace', 'San Isidro', 'Cainta', 'Rizal', 1900, 'DE3', 'MPM', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(119, 390, 'GARCIA_CHRISTIAN JOSEPH', 'Garcia', 'Christian Joseph', 'Anjo', 'cmgarcia', 'ENV', '', 'DE3', '1991-02-10', 'M', 'Married', '2015-06-01', 'garcia_c-kdt/P/KHI', 'pic_390.jpg', 1.0, '07:30', 'publicTransportation', '', 'Dominga Dorm', 'NA', 'Dominga Street', 'NA', 'Barangay 45', 'Pasay City', 'NCR, Fourth District', 1306, 'DE3', 'ENV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(120, 391, 'DALISAY_CATHERINE', 'Dalisay', 'Catherine', 'Cathy', 'catherine', 'ACT', '', 'AA', '1984-09-30', 'F', 'Married', '2015-08-06', 'austria-kdt/P/KHI', 'pic_391.jpg', 0.0, '07:00', 'carpool', 'Christopher Abuan', 'Unit 2L ', '10 Goldendale ave', '', 'Goldendale subd', 'Tinajeros', 'City of Malabon', 'NCR, Third District', 1470, 'AA', 'ACT', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(121, 393, 'DE SOTTO_FRANCIS JOHN', 'De Sotto', 'Francis John', 'Kiko', 'francis', 'MHAH', '', 'DE3', '1990-11-05', 'M', 'Single', '2015-10-01', 'desotto-kdt/P/KHI', 'pic_393.jpg', 0.0, '06:00', 'motorCycle', '', '223', '', '', '', 'Sapang Putik', 'San Ildefonso', 'Bulacan', 3010, 'DE2', 'MHAH', '1', '2022-03-31', '', 0, '2022-08-01', 0, 0, 0, 0),
(122, 394, 'BANTA_LEAH MARIEL', 'Banta', 'Leah Mariel', 'Leah', 'leah', 'MHAH', '', 'DE2', '1992-10-15', 'F', 'Single', '2015-10-01', 'banta-kdt/P/KHI', 'pic_394.jpg', 0.0, '07:00', 'publicTransportation', '', '7234', '', 'J.Victor', '', 'Pio Del Pilar', 'City of Makati', 'NCR, Fourth District', 1230, 'DE2', 'MHAH', '0', '2022-07-27', 'Erwin Tan', 0, '2022-05-08', 0, 0, 0, 0),
(123, 395, 'VILLANUEVA_GLADYS ', 'Villanueva', 'Gladys ', 'Gladys', 'Gladys', 'ENV', '', 'DE2', '1993-02-26', 'F', 'Single', '2015-10-01', 'villanueva-kdt/P/KHI', 'pic_395.jpg', 0.0, '', '', '', '', '', '', '', '', '', '', 0, 'DE2', 'ENV', '0', '2022-03-31', '', 0, '2021-11-01', 0, 0, 0, 0),
(124, 396, 'LACSA_JOHN', 'Lacsa', 'John', 'John', 'lacsa', 'MHAH', '', 'DE3', '1993-01-16', 'M', 'Single', '2015-10-01', 'lacsa-kdt/P/KHI', 'pic_396.jpg', 0.2, '06:00', 'Tony', '05:45/15:00', '3504', '', 'Gen. V. Lucban', '', 'Bangkal', 'City of Makati', 'NCR, Fourth District', 1233, 'DE3', 'MHAH', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(125, 397, 'CANTOS_RENIEL', 'Cantos', 'Reniel', 'Reniel', 'ren', 'BOI', '', 'DE2', '1993-03-11', 'M', 'Single', '2015-10-01', 'cantos-kdt/P/KHI', 'pic_397.jpg', 0.0, '', '', '', '', '', '', '', '', '', '', 0, 'DE2', 'BOI', '0', '2022-03-31', '', 0, '2022-02-18', 0, 0, 0, 0),
(126, 398, 'STA. ANA_Arnulfo', 'Sta. Ana', 'Arnulfo', 'Arnold', 'kuyaarnold', 'ADM', '', 'DRM', '1965-03-02', 'M', 'Married', '2016-04-01', '', 'pic_398.jpg', 0.0, '06:00', 'publicTransportation', '', '', '3-A, Lot 63', '', '', 'Francisco Reyes', 'Gen. Mariano Alvarez', 'Cavite', 4117, 'DRM', 'ADM', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(127, 401, 'LAUREANO_MIKI ANTONIO', 'Laureano', 'Miki Antonio', 'Miki', 'mikilaureano', 'ENV', '', 'DE3', '1993-05-06', 'M', 'Married', '2016-07-01', 'laureano_m-kdt/P/KHI', 'pic_401.jpg', 0.0, '07:00', 'motorCycle', '', '', '167B', 'Gov. Pascual St.', '', 'San Jose (Pob.)', 'City of Navotas', 'NCR, Third District', 1485, 'DE3', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(128, 402, 'ORNIDO_MARVIN JOHN', 'Ornido', 'Marvin John', 'Marvz', 'marvz', 'BOI', '', 'DE3', '1992-09-17', 'M', 'Single', '2016-07-01', 'ornido-kdt/P/KHI', 'pic_402.jpg', 1.3, '08:00', 'motorCycle', '', '', 'Block 8 Lot 3', 'Franc Lane', 'Ecotrend Villas', 'Zapote', 'City of Las Piñas', 'NCR, Fourth District', 1742, 'DE3', 'BOI', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(129, 403, 'MANGALIMAN_LAARNI', 'Mangaliman', 'Laarni', 'Lani', 'laarni', 'CEM', '', 'DE3', '1993-09-04', 'F', 'Married', '2016-07-01', 'tumamao-kdt/P/KHI', 'pic_403.jpg', 0.0, '', '', '', '', '', '', '', '', '', '', 0, 'DE3', 'CEM', '1', '2022-07-27', 'Erwin Tan', 0, '2022-11-05', 0, 0, 0, 0),
(130, 404, 'ARGENTE_GENE OWEN', 'Argente', 'Gene Owen', 'Owen', 'geneowen', 'ENV', '', 'DE3', '1991-08-17', 'M', 'Single', '2016-07-01', 'argente-kdt/P/KHI', 'pic_404.jpg', 1.4, '07:10', 'publicTransportation', '', '', '173F', 'M. Santos', '', 'Barangay 25', 'Pasay City', 'NCR, Fourth District', 1300, 'DE3', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(131, 406, 'TUMBAGA_Jefferson', 'Tumbaga', 'Jefferson', 'Jep', 'tumbaga-kdt', 'CEM', '', 'DE3', '1993-07-22', 'M', 'Married', '2016-07-01', 'tumbaga-kdt/P/KHI', 'pic_406.jpg', 1.5, '07:00', 'publicTransportation', '', 'Sophias Place', '509', 'B Vizcarra St.', 'Malibay', 'Barangay 169', 'Pasay City', 'NCR, Fourth District', 1300, 'DE3', 'CEM', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(132, 407, 'VILLATUYA_RUSSEL', 'Villatuya', 'Russel', 'Russel', 'rcvillatuya', 'EE', '', 'DE3', '1992-08-07', 'M', 'Single', '2016-07-01', 'villatuya-kdt/P/KHI', 'pic_407.jpg', 0.0, '07:00', 'publicTransportation', '', '', '30-5C ', 'Dalandan St.', 'San Isidro Subd.', 'Pamplona Uno', 'City of Las Piñas', 'NCR, Fourth District', 1742, 'DE3', 'EE', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(133, 409, 'DELA CRUZ_EARVIN JAMES', 'Dela Cruz', 'Earvin James', 'EJ', 'earvinjames', 'SYS', '', 'SE3', '1993-04-03', 'M', 'Single', '2016-07-01', 'delacruz-kdt/P/KHI', 'pic_409.jpg', 0.0, '06:15', 'motorCycle', '', '', '45', 'M Fernando St', 'Wawa', 'Tangos South', 'City of Navotas', 'NCR, Third District', 1489, 'SE3', 'SYS', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 4, 0, 1),
(134, 410, 'PARRA_ELY', 'Parra', 'Ely', 'Ely', 'elyparra', 'BOI', '', 'DE2', '1994-07-11', 'M', 'Single', '2017-03-01', 'parra-kdt/P/KHI', 'pic_410.jpg', 0.0, '08:00', 'publicTransportation', '', 'Unit 8 Raniola Apt', '45', 'Perla Street', '', 'Barangay 8', 'Pasay City', 'NCR, Fourth District', 1306, 'DE2', 'BOI', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(135, 411, 'ILAO_MARYLOU', 'Ilao', 'Marylou', 'Malou', 'malou', 'ENV', '', 'DE2', '1991-10-13', 'F', 'Single', '2017-03-01', 'manalo-kdt/P/KHI', 'pic_411.jpg', 1.7, '07:30', 'publicTransportation', '', '1FL', '1742', 'F. Guizon Street', '', 'Kasilawan', 'City of Makati', 'NCR, Fourth District', 1206, 'DE2', 'ENV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(136, 412, 'RIVERA_REENAN', 'Rivera', 'Reenan', 'Reenan', 'reenan', 'ENV', '', 'DE2', '1992-10-01', 'M', 'Single', '2017-03-01', 'rivera-kdt/P/KHI', 'pic_412.jpg', 0.0, '06:30', 'publicTransportation', '', '', '173F', 'M. Santos', '', 'Barangay 25', 'Pasay City', 'NCR, Fourth District', 1300, 'DE2', 'ENV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0);
INSERT INTO `emp_prof` (`fldID`, `fldEmployeeNum`, `fldName`, `fldSurname`, `fldFirstname`, `fldNick`, `fldUser`, `fldGroup`, `fldGroups`, `fldDesig`, `fldBirthDate`, `fldGender`, `fldStatus`, `fldDateHired`, `fldLotus`, `fldPic`, `fldOthers`, `fldStartTime`, `fldMOT`, `fldRemarks`, `fldUnit`, `fldHouse`, `fldStreet`, `fldSub`, `fldBrgy`, `fldCity`, `fldProv`, `fldZip`, `fldDesigStamp`, `fldGroupStamp`, `fldActiveStamp`, `fldStampDate`, `fldChecker`, `fldActive`, `fldResignDate`, `fldUpload`, `fldAccess`, `fldAccessCommute`, `fldMRRSReserve`) VALUES
(137, 413, 'BUZETA_WENDY', 'Buzeta', 'Wendy', 'Wendy', 'wendz', 'MHAH', '', 'DE2', '1991-01-22', 'F', 'Single', '2017-03-01', 'anorico-kdt/P/KHI', 'pic_413.jpg', 3.2, '07:30', 'publicTransportation', '', '', '173F', 'M. Santos', 'Leveriza', 'Barangay 25', 'Pasay City', 'NCR, Fourth District', 1300, 'DE2', 'MHAH', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(138, 414, 'ANTONIO_WILHELM DENNIS', 'Antonio', 'Wilhelm Dennis', 'Lem', 'wilhelm', 'ENV', '', 'DE2', '1994-08-05', 'M', 'Single', '2017-03-01', 'antonio-kdt/P/KHI', 'pic_414.jpg', 0.0, '06:30', 'publicTransportation', '', '', 'Block 15 Lot 6B', 'Chico', 'Doña Josefa Village', 'Almanza Uno', 'City of Las Piñas', 'NCR, Fourth District', 1750, 'DE2', 'ENV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(139, 415, 'ASTRERA_PHILIP JHON', 'Astrera', 'Philip Jhon', 'Philip', 'philipj', 'ENV', '', 'DE2', '1995-11-23', 'M', 'Single', '2017-03-01', 'astrera-kdt/P/KHI', 'pic_415.jpg', 0.0, '07:30', 'publicTransportation', '', 'Unit 12', '1045A', 'Quintos Sr. St.', '', 'Barangay 505', 'Sampaloc, City of Manila', 'NCR, First District', 1008, 'DE2', 'ENV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(140, 416, 'FLORESCA_GENE PHILIP', 'Floresca', 'Gene Philip', 'Gene', 'gene', 'ETCL', '', 'DE2', '1992-11-20', 'M', 'Single', '2017-03-01', 'floresca-kdt/P/KHI', 'pic_416.jpg', 0.0, '06:30', 'publicTransportation', '', '', '', 'Santander St.', 'Villa Roma 6', 'Lias', 'Marilao', 'Bulacan', 3019, 'DE2', 'CEM', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(141, 417, 'BINAY-AN_DARYL', 'Binay-an', 'Daryl', 'Daryl', 'darylb', 'MHAH', 'MHAH', 'DE2', '1994-10-24', 'M', 'Single', '2017-03-01', 'binayan-kdt/P/KHI', 'pic_417.jpg', 0.0, '07:30', 'publicTransportation', '', '77L', '', 'C. Jose', '', 'Barangay 162', 'Pasay City', 'NCR, Fourth District', 1300, 'DE2', 'MHAH', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(142, 419, 'MESIAS_MERIAM', 'Mesias', 'Meriam', 'Yamie', 'meriam', 'ADM', '', 'AAR', '1985-08-15', 'F', 'Single', '2017-09-04', 'mesias-kdt/P/KHI', 'pic_419.jpg', 0.0, '07:00', 'carpool', 'Christopher Abuan', '', '21L', 'Esguerra St.', '', 'Flores', 'City of Malabon', 'NCR, Third District', 1400, 'AAR', 'ADM', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(143, 420, 'BENEDICTO_ALVIN', 'Benedicto', 'Alvin', 'Vin', 'vin', 'ENV', '', 'DE2', '1994-10-20', 'M', 'Single', '2018-07-02', 'benedicto-kdt/P/KHI', 'pic_420.jpg', 1.0, '06:30', 'publicTransportation', '', '', '335', 'Taylo', '', 'Barangay 55', 'Pasay City', 'NCR, Fourth District', 1800, 'DE1', 'ENV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(144, 421, 'NAZAR_JOHN JACOB', 'Nazar', 'John Jacob', 'Jacob', 'jjnazar', 'MHAH', '', 'DE2', '1996-01-28', 'M', 'Single', '2018-07-02', 'nazar-kdt/P/KHI', 'pic_421.jpg', 0.4, '07:00', 'motorCycle', '', '201', '3615', 'Magistrado Arellano', 'Bacood', 'Barangay 612', 'Sampaloc, City of Manila', 'NCR, First District', 1016, 'DE2', 'MHAH', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(145, 422, 'PIMENTEL_LUCKY BOY', 'Pimentel', 'Lucky Boy', 'Lux', 'lux', 'ENV', '', 'DE2', '1996-10-20', 'M', 'Single', '2018-07-02', 'pimentel-kdt/P/KHI', 'pic_422.jpg', 0.5, '06:30', 'carpool', 'John David Ducay', 'Rm. 8 Ranola Apartment', '45', 'Perla St.', '', 'Barangay 8', 'Pasay City', 'NCR, Fourth District', 1305, 'DE2', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(146, 423, 'CARO_RENSON', 'Caro', 'Renson', 'Renson', 'rensonc', 'ENV', '', 'DE2', '1995-01-15', 'M', 'Single', '2018-07-02', 'caro-kdt/P/KHI', 'pic_423.jpg', 1.0, '06:00', 'publicTransportation', '', '', '728', 'P Santos', 'Malibay', 'Barangay 169', 'Pasay City', 'NCR, Fourth District', 1300, 'DE2', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(147, 424, 'PEREZ_RENZEL', 'Perez', 'Renzel', 'Renzel', 'renzel', 'MHAH', '', 'DE2', '1994-09-09', 'M', 'Single', '2018-07-02', 'perez_r-kdt/P/KHI', 'pic_424.jpg', 0.8, '08:30', 'motorCycle', '', '', '11', 'Urrutia Avenue', '', 'Gen. T. De Leon', 'City of Valenzuela', 'NCR, Third District', 1442, 'DE2', 'MHAH', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(148, 425, 'BELEN_MARVIN', 'Belen', 'Marvin', 'Marvin', 'mbelen', 'ENV', '', 'DE2', '1994-09-22', 'M', 'Single', '2018-07-02', 'belen_m-kdt/P/KHI', 'pic_425.jpg', 1.5, '06:30', 'publicTransportation', '', '', '', 'S. De Guzman St.', '', 'Barangay 165', 'Pasay City', 'NCR, Fourth District', 1300, 'DE2', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(149, 426, 'TUAZON_KING LOUIS', 'Tuazon', 'King Louis', 'King', 'kdtuazon', 'BOI', '', 'DE2', '1992-04-14', 'M', 'Single', '2018-07-02', 'tuazon-kdt/P/KHI', 'pic_426.jpg', 3.8, '06:45', 'publicTransportation', '', '', '173F', 'M.Santos Leveriza', '', 'Barangay 25', 'Pasay City', 'NCR, Fourth District', 1300, 'DE2', 'BOI', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(150, 427, 'FERNANDEZ_JULIUS', 'Fernandez', 'Julius', 'Julius', 'julius', 'MHAH', '', 'DE2', '1994-01-02', 'M', 'Single', '2018-07-02', 'fernandez-kdt/P/KHI', 'pic_427.jpg', 1.7, '08:15', 'bicycle', '', '77L', '77', 'C.Jose', '', 'Barangay 166', 'Pasay City', 'NCR, Fourth District', 1300, 'DE2', 'MHAH', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(151, 428, 'VELASCO_VRYAN', 'Velasco', 'Vryan', 'Vryan', 'vryan', 'ENV', '', 'DE2', '1993-10-05', 'M', 'Single', '2018-07-02', 'velasco-kdt/P/KHI', 'pic_428.jpg', 1.3, '08:00', 'ownCar', '', 'EJ & Levi Bldg.', '2996', 'H. Santos', '', 'Carmona', 'City of Makati', 'NCR, Fourth District', 1207, 'DE1', 'ENV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(152, 429, 'MORALITA_DENMARK', 'Moralita', 'Denmark', 'Denmark', 'dmoralita', 'ENV', '', 'DE2', '1994-09-10', 'M', 'Single', '2018-07-02', 'moralita-kdt/P/KHI', 'pic_429.jpg', 0.5, '06:30', 'publicTransportation', '', 'Unit 4B Eva\'s Apartment', '', '', '', 'Barangay 165', 'Pasay City', 'NCR, Fourth District', 1709, 'DE2', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(153, 430, 'UCOL_ZENDY GRACE', 'Ucol', 'Zendy Grace', 'Zendy', 'zendy', 'ENV', '', 'DE2', '1995-08-13', 'F', 'Single', '2018-07-02', 'ucol-kdt/P/KHI', 'pic_430.jpg', 0.3, '08:30', 'publicTransportation', '', '3FL, Veloso Building', '#30', 'Magnolia St.', 'Maricaban', 'Barangay 184', 'Pasay City', 'NCR, Fourth District', 1300, 'DE2', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(154, 432, 'MACARAAN_CHRISTIAN', 'Macaraan', 'Christian', 'Christian', 'cmacaraan', 'ENV', '', 'DE2', '1993-12-24', 'M', 'Single', '2018-07-02', 'macaraan-kdt/P/KHI', 'pic_432.jpg', 2.0, '08:30', 'motorCycle', '', 'N/A', 'BLOCK 10 LOT 6', 'N/A', 'Amaia Scape General Trias', 'Santiago', 'City of General Trias', 'Cavite', 4107, 'DE2', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(155, 433, 'RAMOS_ALYSSA', 'Ramos', 'Alyssa', 'Alyssa', 'alyssa', 'MHAH', '', 'DE2', '1995-09-04', 'F', 'Single', '2018-07-02', 'ramos-kdt/P/KHI', 'pic_433.jpg', 0.0, '07:00', 'publicTransportation', '', '', '1677A', 'Dian Street', '', 'San Isidro', 'City of Makati', 'NCR, Fourth District', 1234, 'DE2', 'MHAH', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(156, 434, 'PILIS_VILMER', 'Pilis', 'Vilmer', 'Vilmer', 'vilmer', 'ENV', '', 'DE2', '1993-09-12', 'M', 'Single', '2018-07-02', 'pilis-kdt/P/KHI', 'pic_434.jpg', 1.6, '07:00', 'carpool', 'Vryan Velasco', '1278 Residences', '1278', 'Batangas ', '', 'San Isidro', 'City of Makati', 'NCR, Fourth District', 1234, 'DE2', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(157, 435, 'BASIBAS_KERSTIN PAULA', 'Basibas', 'Kerstin Paula', 'Kerstin', 'kbasibas', 'ENV', '', 'DE2', '1995-02-03', 'F', 'Single', '2018-07-02', 'basibas-kdt/P/KHI', 'pic_435.jpg', 0.8, '06:00', 'carpool', 'Aldrin Guico', '', '37', 'Perla Street', '', 'Barangay 8', 'Pasay City', 'NCR, Fourth District', 1300, 'DE2', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(158, 436, 'VIÑAS_EUGENE', 'Viñas', 'Eugene', 'Eugene', 'eugene', 'ENV', '', 'DE2', '1994-03-15', 'M', 'Single', '2018-07-02', 'vinas-kdt/P/KHI', 'pic_436.jpg', 1.4, '06:30', 'bicycle', '', '53H', '', 'J.Ruiz Street', '', 'Salapan', 'City of San Juan', 'NCR, Second District', 1500, 'DE2', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(159, 437, 'CALLORES_DICK FRANCIS', 'Callores', 'Dick Francis', 'Dick', 'dickfrancis', 'ENV', '', 'DE2', '1993-10-27', 'M', 'Single', '2018-07-02', 'callores-kdt/P/KHI', 'pic_437.jpg', 1.7, '08:30', 'bicycle', '', 'Cruz Appartment', '77L', 'Clemante Jose', 'Malibay', 'Barangay 166', 'Pasay City', 'NCR, Fourth District', 1300, 'DE1', 'ENV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(160, 438, 'REYES_JUAN CARLOS', 'Reyes', 'Juan Carlos', 'JC', 'jc', 'ENV', '', 'DE2', '1994-09-19', 'M', 'Single', '2018-07-02', 'reyes_jc-kdt/P/KHI', 'pic_438.jpg', 1.7, '06:00', 'carpool', 'Jasper Dimaapi', '', '93', '', '', 'Malagasang I-B', 'City of Imus', 'Cavite', 4103, 'DE2', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(161, 439, 'ARROYO_Micah Camille', 'Arroyo', 'Micah Camille', 'Micah', 'arroyo-kdt', 'IT', '', 'IT-E2', '1997-09-13', 'F', 'Single', '2018-07-02', 'arroyo-kdt/P/KHI', 'pic_439.jpg', 0.0, '07:00', 'publicTransportation', '', 'Bldg. 3', 'Sapari Condo.', 'Osmeña Highway', '', 'Barangay 769', 'Santa Ana, City of Manila', 'NCR, First District', 1017, 'IT-E1', 'IT', '1', '2022-03-31', '', 1, NULL, 0, 4, 0, 1),
(162, 440, 'PANGINBAYAN_Rochelle', 'Panginbayan', 'Rochelle', 'Chelle', 'panginbayan-kdt', 'IT', '', 'IT-E2', '1997-07-20', 'F', 'Single', '2018-07-02', 'panginbayan-kdt/P/KHI', 'pic_440.jpg', 0.0, '06:30', 'carpool', 'John David Ducay', 'Unit C3', '179', 'Porvenir St.', 'N/A', 'Barangay 20', 'Pasay City', 'NCR, Fourth District', 1302, 'IT-E1', 'IT', '1', '2022-03-31', '', 1, NULL, 0, 4, 0, 1),
(163, 444, 'TOBIAS_KENNETH', 'Tobias', 'Kenneth', 'Ken', 'ken', 'CIV', '', 'DE2', '1996-01-26', 'M', 'Single', '2018-10-01', 'tobias_k-kdt/P/KHI', 'pic_444.jpg', 0.0, '07:20', 'publicTransportation', '', '', '54', 'k6', '', 'West Kamias', 'Quezon City', 'NCR, Second District', 1102, 'DE2', 'CIV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(164, 445, 'HONRADO_RUTH ANNE', 'Honrado', 'Ruth Anne', 'Ruth', 'ruth', 'ANA', 'ANA', 'DE2', '1992-04-09', 'F', 'Single', '2018-10-01', 'honrado-kdt/P/KHI', 'pic_445.jpg', 0.0, '06:00', 'carpool', 'Jasper Dimaapi', '317', '', 'CBI SITE', '', 'Anabu I-B', 'City of Imus', 'Cavite', 4103, 'DE2', 'ANA', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(165, 446, 'TAKENAKA_YUKIHIRO', 'Takenaka', 'Yukihiro', '', 'takenaka_yu', 'ADM', '', 'KDTP', '1965-11-25', 'M', '', '2016-11-25', 'takenaka_yu-kdt/P/KHI', 'pic_446.jpg', 0.0, '07:30', 'Tony', '07:15/16:30', 'SixSenses Residence', '6H, Tower 2', 'Diosdado Macapagal Blvd', '-', 'Barangay 76', 'Pasay City', 'NCR, Fourth District', 1300, 'KDTP', 'ADM', '1', '2022-03-31', '', 1, NULL, 1, 4, 1, 0),
(166, 447, 'MEDRANO_MARCO', 'Medrano', 'Marco', 'Marco', 'maco', 'PIP', '', 'DE1', '1997-10-04', 'M', 'Single', '2019-07-01', 'medrano-kdt/P/KHI', 'pic_447.jpg', 0.0, '06:30', 'publicTransportation', '', '', '79', 'J. Marzan ', '', 'Barangay 422', 'Sampaloc, City of Manila', 'NCR, First District', 1013, 'DE1', 'PIP', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(167, 448, 'BUSTON_CHERRY MAE ', 'Buston', 'Cherry Mae ', 'Che', 'che', 'PIP', '', 'DE1', '1996-03-08', 'F', 'Single', '2019-07-01', 'soliven-kdt/P/KHI', 'pic_448.jpg', 0.0, '07:00', 'publicTransportation', '', '', 'LOT 18 BLOCK 152', 'ARAGO STREET', '', 'Central Bicutan', 'City of Taguig', 'NCR, Fourth District', 1630, 'DE1', 'PIP', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(168, 449, 'VIADO_MEYRVIN', 'Viado', 'Meyrvin', 'Meyrvin', 'meyrvin', 'PIP', 'PIP/DXT', 'DE1', '1996-05-11', 'M', 'Single', '2019-07-01', 'viado-kdt/P/KHI', 'pic_449.jpg', 0.0, '08:00', 'publicTransportation', '', 'Aina\'s Space Condominium', '1226', 'J. Barlin Street', '', 'Barangay 465', 'Sampaloc, City of Manila', 'NCR, First District', 1015, 'DE1', 'PIP', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(169, 450, 'CASEM_KIMBERLY', 'Casem', 'Kimberly', 'Kim', 'kimmy', 'PIP', '', 'DE1', '1995-04-19', 'F', 'Single', '2019-07-01', 'casem-kdt/P/KHI', 'pic_450.jpg', 0.0, '06:30', 'publicTransportation', '', 'Crestly Bldg.', '37', 'Perla St.', '', 'Barangay 8', 'Pasay City', 'NCR, Fourth District', 1300, 'DE1', 'PIP', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(170, 451, 'GUIAO _NEIL STEPHEN ', 'Guiao ', 'Neil Stephen ', 'Neil', 'guiao', 'PIP', '', 'ADE', '1995-10-22', 'M', 'Single', '2019-07-01', 'guiao-kdt/P/KHI', 'pic_451.jpg', 0.0, '', '', '', '', '', '', '', '', '', '', 0, 'ADE', 'PIP', '0', '2022-03-31', '', 0, '2022-03-23', 0, 0, 0, 0),
(171, 452, 'NIGOS_SCOTTEE JAIRUS', 'Nigos', 'Scottee Jairus', 'Scottee', 'scotty', 'ANA', 'ANA/DXT', 'DE1', '1997-10-28', 'M', 'Single', '2019-07-01', 'nigos-kdt/P/KHI', 'pic_452.jpg', 0.0, '07:30', 'publicTransportation', '', '14E San Lorenzo Place', 'Tower 3', 'Chino Roces Ave., EDSA Cor.', 'NA', 'Bangkal', 'City of Makati', 'NCR, Fourth District', 1233, 'DE1', 'ANA', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(172, 454, 'ARMAS_KENN JOHN', 'Armas', 'Kenn John', 'Ken', 'armas', 'BOI', '', 'DE1', '1994-06-01', 'M', 'Single', '2019-07-01', 'armas-kdt/P/KHI', 'pic_454.jpg', 0.0, '08:00', 'publicTransportation', '', 'PNR Dorm', '-', 'Gen San Miguel St.', 'Sangandaan', 'Barangay 5', 'City of Caloocan', 'NCR, Third District', 1408, 'DE1', 'BOI', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(173, 455, 'MANALO_VINCEN', 'Manalo', 'Vincen', 'Vincen', 'vincen', 'ENV', '', 'DE1', '1996-06-01', 'M', 'Single', '2019-07-01', 'manalo_v-kdt/P/KHI', 'pic_455.jpg', 0.9, '06:30', 'publicTransportation', '', '308 Studio A Residences', '', 'Mariveles Street', '', 'Highway Hills', 'City of Mandaluyong', 'NCR, Second District', 1550, 'ADE', 'ENV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(174, 456, 'RIVERA_MAX VINCENT', 'Rivera', 'Max Vincent', 'Max', 'maxxs', 'ENV', '', 'DE1', '1995-05-14', 'M', 'Single', '2019-07-01', 'rivera_m-kdt/P/KHI', 'pic_456.jpg', 0.0, '08:00', 'motorCycle', '', '', '214', 'Santan St.', '', 'Wawa', 'City of Taguig', 'NCR, Fourth District', 1636, 'DE1', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(175, 459, 'CUTARAN_RENNEL MAE', 'Cutaran', 'Rennel Mae', 'Rennel', 'rennel', 'ENV', '', 'ADE', '1997-12-11', 'F', 'Single', '2021-07-12', 'cutaran-kdt/P/KHI', 'pic_459.jpg', 0.0, '07:00', 'carpool', 'Joseph Michael Macalalad', 'Bautista Pad', 'Lot 28 Blk 13', 'Cordillera St.', '', 'Pinagsama', 'City of Taguig', 'NCR, Fourth District', 1630, 'ADE', 'ENV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(176, 460, 'BERONGOY_EURJHON', 'Berongoy', 'Eurjhon', 'Eur', 'eurjhon', 'ENV', '', 'ADE', '1998-08-19', 'M', 'Single', '2021-07-12', 'berongoy-kdt/P/KHI', 'pic_460.jpg', 0.0, '06:00', 'carpool', 'Lorenzo Diaz', '481', '', 'F. Legaspi', '', 'Maybunga', 'City of Pasig', 'NCR, Second District', 1607, 'ADE', 'ENV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(177, 461, 'BAYQUEN_Hannah Millace', 'Bayquen', 'Hannah Millace', 'Hannah', 'bayquen-kdt', 'ENV', '', 'ADE', '1997-05-20', 'F', 'Single', '2021-07-12', 'bayquen-kdt/P/KHI', 'pic_461.jpg', 0.0, '07:00', 'publicTransportation', '', '', 'Solano Hills', 'Villonco St.', '', 'Sucat', 'City of Muntinlupa', 'NCR, Fourth District', 1770, 'ADE', 'ENV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(178, 462, 'SANTOS_LUIZE NICOLE', 'Santos', 'Luize Nicole', 'Lui', 'luize', 'ENV', '', 'ADE', '1998-10-08', 'M', 'Single', '2021-07-12', 'santos-kdt/P/KHI', 'pic_462.jpg', 0.0, '06:00', 'publicTransportation', '', '', 'A-55', 'Ramos Village', '', 'Manggahan', 'City of Pasig', 'NCR, Second District', 1611, 'ADE', 'ENV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(179, 463, 'REYES_RIZCHELLE', 'Reyes', 'Rizchelle', 'Riz', 'riz', 'ENV', '', 'ADE', '1999-11-14', 'F', 'Single', '2021-07-12', 'reyes_r-kdt/P/KHI', 'pic_463.jpg', 0.0, '06:00', 'publicTransportation', '', 'NA', '519', 'Vergel St.', 'NA', 'Barangay 113', 'Pasay City', 'NCR, Fourth District', 1300, 'ADE', 'ENV', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(180, 464, 'COQUIA_Joshua Mari', 'Coquia', 'Joshua Mari', 'Joshua', 'coquia-kdt', 'SYS', 'SYS/ENV/EE/IT', 'ASE', '1999-08-15', 'M', 'Single', '2021-07-12', 'coquia-kdt/P/KHI', 'pic_464.jpg', 0.0, '06:00', 'publicTransportation', '', '', '79-G', '15th Avenue', '', 'Socorro', 'Quezon City', 'NCR, Second District', 1109, 'ASE', 'SYS', '1', '2022-03-31', '', 1, NULL, 1, 4, 1, 1),
(181, 465, 'PETATE_Felix Edwin', 'Petate', 'Felix Edwin', 'Felix', 'petate-kdt', 'SYS', 'SYS/ENV/EE/IT', 'SE1', '1992-03-14', 'M', 'Single', '2021-07-12', 'petate-kdt/P/KHI', 'pic_465.jpg', 5.7, '06:00', 'publicTransportation', '', '', '1840 J', 'Champaca St.', 'Kahilum 1', 'Barangay 870', 'Pandacan, City of Manila', 'NCR, First District', 1011, 'SE1', 'SYS', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 1, 4, 1, 1),
(182, 466, 'AGANAN_Alvin John', 'Aganan', 'Alvin John', 'Alvin', 'aganan-kdt', 'SYS', '', 'ASE', '1998-07-28', 'M', 'Single', '2021-07-12', 'aganan-kdt/P/KHI', 'pic_466.jpg', 0.4, '08:00', 'motorCycle', '', 'Unit P', '43', 'Mindanao Avenue', 'N/A', 'Bagong Pag-asa', 'Quezon City', 'NCR, Second District', 1128, 'ASE', 'SYS', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(183, 467, 'CAMUNGGOL_ALDRIN JERICK', 'Camunggol', 'Aldrin Jerick', 'Aldrin', 'aldrin', 'BOI', '', 'ADE', '1999-04-01', 'M', 'Single', '2021-07-12', 'camunggol-kdt/P/KHI', 'pic_467.jpg', 0.3, '06:00', 'publicTransportation', '', '', '620', 'Gamban', '', 'Barangay 138', 'Pasay City', 'NCR, Fourth District', 1300, 'ADE', 'BOI', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(184, 468, 'GAMEZ_AARON GODFREY', 'Gamez', 'Aaron Godfrey', 'Ron', 'aarongamez', 'MIL', '', 'ADE', '1998-08-08', 'M', 'Single', '2021-07-12', 'gamez-kdt/P/KHI', 'pic_468.jpg', 0.0, '07:30', 'publicTransportation', '', '', '2086', 'Capt. M. Reyes', '', 'Pio Del Pilar', 'City of Makati', 'NCR, Fourth District', 1230, 'ADE', 'MIL', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(185, 10008, 'CHIBA_TATSUROU', 'Chiba', 'Tatsurou', '', 'chiba_ta', '-', '', 'ADE', '0000-00-00', 'M', '', '0000-00-00', '', 'pic_10008.jpg', 0.0, '', '', '', '', '', '', '', '', '', '', 0, 'ADE', '-', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(186, 10018, 'UENO_RYOSUKE', 'Ueno', 'Ryosuke', '', 'ueno_r', '-', '', 'DM', '0000-00-00', 'M', '', '0000-00-00', '', 'pic_10018.jpg', 0.0, '', '', '', '', '', '', '', '', '', '', 0, 'DM', '-', '1', '2022-03-31', '', 1, NULL, 0, 4, 1, 0),
(187, 10035, 'IWAMURA_MUNECHIYO', 'Iwamura', 'Munechiyo', '', 'iwamura_m', '-', '', 'SV', '0000-00-00', 'M', '', '0000-00-00', '', 'pic_10035.jpg', 0.0, '', '', '', '', '', '', '', '', '', '', 0, 'SV', '-', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(188, 446, 'PRESIDENT_KDT', 'President', 'Kdt', '', 'president', 'ADM', '', 'KDTP', '1965-11-25', 'M', 'Single', '0000-00-00', 'takenaka_yu-kdt/P/KHI', 'pic_446.jpg', 0.0, '07:30', 'Tony', '07:15/16:30', 'SixSenses Residence', '6H, Tower 2', 'Diosdado Macapagal Blvd', '-', 'Barangay 76', 'Pasay City', 'NCR, Fourth District', 1300, 'KDTP', 'ADM', '1', '2022-03-31', '', 1, NULL, 1, 4, 1, 0),
(189, 446, 'PRESIDENT_KDT', 'President', 'Kdt', '', 'kdtpresident', 'ADM', '', 'KDTP', '1965-11-25', 'M', 'Single', '0000-00-00', 'takenaka_yu-kdt/P/KHI', 'pic_446.jpg', 0.0, '07:30', 'Tony', '07:15/16:30', 'SixSenses Residence', '6H, Tower 2', 'Diosdado Macapagal Blvd', '-', 'Barangay 76', 'Pasay City', 'NCR, Fourth District', 1300, 'KDTP', 'ADM', '1', '2022-03-31', '', 1, NULL, 1, 4, 1, 0),
(190, 30001, 'Yonezawa_', 'Yonezawa', '', '', 'yonezawa-bnc', 'KHI-ITS', '', '-', '0000-00-00', 'M', '-', '0000-00-00', '-', '-', 0.0, '', '', '', '', '', '', '', '', '', '', 0, '-', 'KHI-ITS', '1', '2022-03-31', '', 1, NULL, 0, 0, 0, 0),
(192, 20002, 'AMPIG_Rommel', 'Ampig', 'Rommel', 'Rommel', 'rommel', 'MIL', 'MIL/CEM/MPM/ETCL', 'CTE', '1972-01-15', 'M', 'Married', '2022-04-01', 'ampig-kdt/P/KHI', 'pic_2002.jpg', 24.2, '08:00', 'publicTransportation', '', '', 'Blk 21 Lot 5', '', 'Crystal East Valley', 'Mambog', 'Binangonan', 'Rizal', 1940, 'CTE', 'MIL', '1', '2022-04-19', 'Ernesto Veloso', 1, NULL, 1, 3, 0, 0),
(193, 20001, 'LAUREANO_Antonio', 'Laureano', 'Antonio', 'Toni', 'toni', 'ADM', '', 'CSAD', '1956-07-05', 'M', 'Married', '2021-07-01', 'laureano-kdt/P/KHI', 'pic_2001.jpg', 32.2, '07:00', 'Rick', '06:00/16:00', '-', '13 ', 'P. GABRIEL', '-', 'San Jose (Pob.)', 'City of Navotas', 'NCR, Third District', 1409, 'CSAD', 'ADM', '1', '2022-04-19', 'Ernesto Veloso', 1, NULL, 1, 4, 1, 0),
(194, 469, 'Arabilla Jr._Joel', 'Arabilla Jr.', 'Joel', 'joel', 'joelarabilla', 'MIL', '', 'ADE', '1999-08-12', 'M', 'Single', '2022-07-01', 'arabilla-kdt/P/KHI', 'pic_469.jpg', 0.0, '07:00', 'publicTransportation', '', '', '840', 'Oroquieta', '', 'Barangay 310', 'Santa Cruz, City of Manila', 'NCR, First District', 1014, 'PDE', 'MIL', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(195, 470, 'Leguin_Aries', 'Leguin', 'Aries', 'Aries', 'ariesleguin', 'MHAH', '', 'ADE', '1999-05-11', 'M', 'Single', '2022-07-01', 'leguin-kdt/P/KHI', 'pic_470.jpg', 1.0, '07:00', 'publicTransportation', '', '2647-B', 'N/A', 'Cabrera', 'N/A', 'Barangay 1117', 'Pasay City', 'NCR, Fourth District', 0, 'PDE', 'MHAH', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(196, 471, 'Chavez_Mark Rian', 'Chavez', 'Mark Rian', 'Mark Rian', 'markrian', 'PIP', '', 'ADE', '1997-09-15', 'M', 'Single', '2022-07-01', 'chavez-kdt/P/KHI', 'pic_471.jpg', 0.0, '07:00', 'publicTransportation', '', '810 & Lindonburg Residences', '691', 'M.V. Delos Santos', '', 'Barangay 400', 'Sampaloc, City of Manila', 'NCR, First District', 1008, 'PDE', 'PIP', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(197, 472, 'Lazaro_Nelson', 'Lazaro', 'Nelson', 'nelson', 'nelson', 'CEM', '', 'ADE', '1993-07-14', 'M', 'Single', '2022-07-01', 'lazaro_n-kdt/P/KHI', 'pic_472.jpg', 0.0, '07:00', 'publicTransportation', '', 'N/A', '27', 'BUENAVENTURA', 'N/A', 'Tangos North', 'City of Navotas', 'NCR, Third District', 1489, 'PDE', 'CEM', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(198, 473, 'Domaoal_Kenneth', 'Domaoal', 'Kenneth', 'Kenneth', 'kennethdomaoal', 'ENV', '', 'ADE', '1998-07-28', 'M', 'Single', '2022-07-01', 'domaoal-kdt/P/KHI', 'pic_473.jpg', 0.7, '07:00', 'publicTransportation', '', '', '1901 K Interior 29', 'Zamora St', '', 'Barangay 842', 'Pandacan, City of Manila', 'NCR, First District', 1011, 'PDE', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(199, 474, 'Segovia_Nicole Alysson', 'Segovia', 'Nicole Alysson', 'Nicole ', 'nicole', 'ENV', '', 'ADE', '1996-01-23', 'F', 'Single', '2022-07-01', 'segovia-kdt/P/KHI', 'pic_474.jpg', 2.3, '07:00', 'publicTransportation', '', '1821 Cityland MET II', '', 'Cor. Dela Rosa St.', '', 'Pio Del Pilar', 'City of Makati', 'NCR, Fourth District', 1230, 'PDE', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(200, 475, 'Del Rosario_Jay-R', 'Del Rosario', 'Jay-R', 'Jay-R', 'jayr', 'PIP', '', 'ADE', '1999-04-27', 'M', 'Single', '2022-07-01', 'delrosario-kdt/P/KHI', 'pic_475.jpg', 0.0, '07:00', 'motorCycle', '', '617', '', ' FLEXIHOMES', 'BLISS', 'Rosario', 'City of Pasig', 'NCR, Second District', 1609, 'PDE', 'PIP', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(201, 486, 'Maximo_Carl Rey', 'Maximo', 'Carl Rey', 'Carl Rey', 'carlrey', 'CHE', '', 'ADE', '1994-11-16', 'M', 'Single', '2022-07-01', 'maximo-kdt/P/KHI', 'pic_486.jpg', 0.0, '06:30', 'publicTransportation', '', '', 'Blk-139 Lot12', 'Rajah Sumakwel', '', 'Upper Bicutan', 'City of Taguig', 'NCR, Fourth District', 1633, 'PDE', 'CHE', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(202, 477, 'Callanta_Von Joemar', 'Callanta', 'Von Joemar', 'Von Joemar', 'vonjoemar', 'PIP', '', 'ADE', '1997-07-12', 'M', 'Single', '2022-07-01', 'callanta-kdt/P/KHI', 'pic_477.jpg', 0.0, '', '', '', '', '', '', '', '', '', '', 0, 'PDE', 'PIP', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(203, 478, 'Bamba_Angelo Justin', 'Bamba', 'Angelo Justin', 'Angelo Justin', 'angelobamba', 'MHAH', '', 'ADE', '1996-09-27', 'M', 'Single', '2022-07-01', 'bamba-kdt/P/KHI', 'pic_478.jpg', 0.2, '07:00', 'publicTransportation', '', '', '46', 'Senegal', 'Greenheights Phase 3', 'Nangka', 'City of Marikina', 'NCR, Second District', 1808, 'PDE', 'MHAH', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(204, 479, 'Abella_Sean Vinze', 'Abella', 'Sean Vinze', 'Sean Vinze', 'seanvinze', 'ENV', '', 'ADE', '1998-12-03', 'M', 'Single', '2022-07-01', 'abella-kdt/P/KHI', 'pic_479.jpg', 0.0, '07:00', 'publicTransportation', '', '', '', '', '', 'Malibay', 'Pasay City', 'NCR, Fourth District', 1300, 'PDE', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(205, 480, 'Tamayo_Christian Mari', 'Tamayo', 'Christian Mari', 'Christian Mari', 'christianmari', 'BOI', '', 'ADE', '1998-12-29', 'M', 'Single', '2022-07-01', 'tamayo-kdt/P/KHI', 'pic_480.jpg', 0.0, '06:30', 'publicTransportation', '', '', '18', 'Sampaguita A', 'Sun Valley', 'Barangay 197', 'Pasay City', 'NCR, Fourth District', 1301, 'PDE', 'BOI', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(206, 481, 'Tan Pian_John Meynard', 'Tan Pian', 'John Meynard', 'John Meynard', 'johnmeynard', 'ENV', '', 'ADE', '1998-10-05', 'M', 'Single', '2022-07-01', 'tanpian-kdt/P/KHI', 'pic_481.jpg', 0.0, '07:00', 'publicTransportation', '', '105b', 'zone 7', 'samson road', 'na', 'Barangay 73', 'City of Caloocan', 'NCR, Third District', 1421, 'PDE', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(207, 482, 'Ramirez_Xavier Dwight', 'Ramirez', 'Xavier Dwight', 'Xavier Dwight', 'xavierdwight', 'PIP', '', 'ADE', '1998-12-17', 'M', 'Single', '2022-07-01', 'ramirez-kdt/P/KHI', 'pic_482.jpg', 0.0, '06:00', 'publicTransportation', '', '1754', 'B.', 'Perfecto', '', 'Barangay 53', 'Tondo I/II, City of Manila', 'NCR, First District', 1012, 'PDE', 'PIP', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(208, 483, 'Bautista_Anne Wilyn', 'Bautista', 'Anne Wilyn', 'Anne Wilyn', 'annewilyn', 'ENV', '', 'ADE', '1998-12-17', 'F', 'Single', '2022-07-01', 'bautista_anne-kdt/P/KHI', 'pic_483.jpg', 0.0, '07:00', 'publicTransportation', '', '', '2647-B', 'Cabrera Street', '', 'Barangay 117', 'Pasay City', 'NCR, Fourth District', 1300, 'PDE', 'ENV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(209, 484, 'Jonson_Edgar Joseph', 'Jonson', 'Edgar Joseph', 'Edgar', 'edgar', 'EE', '', 'ADE', '1997-08-31', 'M', 'Single', '2022-07-01', 'jonson-kdt/P/KHI', 'pic_484.jpg', 0.0, '07:00', 'publicTransportation', '', '', '137', '3RD STREET', '', 'Barangay 111', 'City of Caloocan', 'NCR, Third District', 1400, 'PDE', 'EE', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(210, 485, 'Pangilinan_Seanne Kyle', 'Pangilinan', 'Seanne Kyle', 'Seanne Kyle', 'seannekyle', 'CIV', '', 'ADE', '1999-09-09', 'M', 'Single', '2022-07-01', 'pangilinan-kdt/P/KHI', 'pic_485.jpg', 0.0, '07:00', 'publicTransportation', '', '559A', '559A', 'Vicente Cruz', '', 'Barangay 448', 'Sampaloc, City of Manila', 'NCR, First District', 1008, 'PDE', 'CIV', '1', '2022-07-27', 'Erwin Tan', 1, NULL, 0, 0, 0, 0),
(211, 487, 'MEDRANO_Collene Keith', 'Medrano', 'Collene Keith', 'Collene', 'medrano_c-kdt', 'SYS', 'SYS/ENV/EE/IT', 'ASE', '1999-01-13', 'F', 'Single', '2022-08-15', 'medrano_c-kdt/P/KHI', 'pic_487.jpg', 0.0, '06:00', 'publicTransportation', '', '', '14', 'San Juan', '', 'Gulod', 'Quezon City', 'NCR, Second District', 1117, '', '', '', NULL, '', 1, NULL, 1, 4, 1, 1),
(212, 488, 'Gulam_Glenda Ann', 'Gulam', 'Glenda Ann', 'Glenda', 'Glenda', 'SYS', '', 'PSE', '2000-03-27', 'F', 'Single', '2022-08-15', 'gulam-kdt/P/KHI', 'pic_488.jpg', 0.0, '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', NULL, '', 0, '2023-01-31', 0, 0, 0, 0),
(213, 489, 'Fortus_Domini', 'Fortus', 'Domini', 'domini', 'domini', 'MHAH', '', 'DE2', '1993-07-12', 'M', 'Single', '2023-01-16', 'fortus_d-kdt/P/KHI', 'pic_489.jpg', 0.0, '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', NULL, '', 1, NULL, 0, 0, 0, 0),
(214, 490, 'Usal_Ryan Christopher', 'Usal', 'Ryan Christopher', 'Ryan', 'usal-kdt', 'MHAH', '', 'PDE', '2023-02-06', 'M', 'Single', '2023-03-01', 'usal-kdt/P/KHI', 'pic_490.jpg', 0.0, '07:00', 'publicTransportation', '', '', '121 Int 1', 'Loreto St.', '', 'Barangay 419', 'Sampaloc, City of Manila', 'NCR, First District', 1008, '', '', '', NULL, '', 1, NULL, 0, 0, 0, 0),
(215, 491, 'Villamil_Ronald Louie', 'Villamil', 'Ronald Louie', 'Ronal', 'villamil-kdt', 'MHAH', '', 'PDE', '2023-02-06', 'M', 'Single', '2023-03-01', 'villamil-kdt/P/KHI', 'pic_491.jpg', 0.0, '07:00', 'publicTransportation', '', '', '7567', 'J. de leon ', '', 'San Dionisio', 'City of Parañaque', 'NCR, Fourth District', 1700, '', '', '', NULL, '', 1, NULL, 0, 0, 0, 0),
(216, 492, 'Villaruel_Jayron', 'Villaruel', 'Jayron', 'Jayron', 'villaruel-kdt', 'MHAH', '', 'PDE', '2023-02-06', 'M', 'Single', '2023-03-01', 'villaruel-kdt/P/KHI', 'pic_492.jpg', 0.0, '07:00', 'publicTransportation', '', '', 'Lot 1 block 11', '', 'Dreamland', 'Hagonoy', 'City of Taguig', 'NCR, Fourth District', 1630, '', '', '', NULL, '', 1, NULL, 0, 0, 0, 0),
(217, 493, 'Bedonia_Bryan James', 'Bedonia', 'Bryan James', 'Bryan', 'bedonia-kdt', 'MHAH', '', 'PDE', '2023-02-06', 'M', 'Single', '2023-03-01', 'bedonia-kdt/P/KHI', 'pic_493.jpg', 0.0, '07:00', 'publicTransportation', '', '', 'Block 3 Lot 31', '', 'ACM Phase 9', 'Alapan I-A', 'City of Imus', 'Cavite', 4103, '', '', '', NULL, '', 1, NULL, 0, 0, 0, 0),
(218, 494, 'Montaniel_John Carlos', 'Montaniel', 'John Carlos', 'John ', 'montaniel-kdt', 'MHAH', '', 'PDE', '2023-02-06', 'M', 'Single', '2023-03-01', 'montaniel-kdt/P/KHI', 'pic_494.jpg', 0.0, '07:00', 'publicTransportation', '', '', '2126', 'San Andres Ext.', '', 'Barangay 780', 'Santa Ana, City of Manila', 'NCR, First District', 1009, '', '', '', NULL, '', 1, NULL, 0, 0, 0, 0),
(219, 495, 'RODRIGUEZ_Nicole', 'Rodriguez', 'Nicole', 'Nicole', 'rodriguez-kdt', 'MHAH', '', 'PDE', '2023-02-06', 'F', 'Single', '2023-03-01', 'rodriguez-kdt/P/KHI', 'pic_495.jpg', 0.0, '07:00', 'publicTransportation', '', '', '1744', 'E.Jorge ', '', 'Barangay 898', 'Santa Ana, City of Manila', 'NCR, First District', 1009, '', '', '', NULL, '', 1, NULL, 0, 0, 0, 0),
(220, 496, 'Tana_Marc Jullian', 'Tana', 'Marc Jullian', 'Marc', 'tana-kdt', 'MHAH', '', 'PDE', '2023-02-06', 'M', 'Single', '2023-03-01', 'tana-kdt/P/KHI', 'pic_496.jpg', 0.0, '07:00', 'motorCycle', '', '', '118-A', '13TH AVENUE', '', 'Socorro', 'Quezon City', 'NCR, Second District', 1109, '', '', '', NULL, '', 1, NULL, 0, 0, 0, 0),
(223, 20003, 'CAVEIRO_Vincent', 'Caveiro', 'Vincent', 'Vince', 'caveiro-kdt', 'PIP', '', 'CSE', '1986-01-02', 'M', 'Married', '2023-04-01', 'caveiro-kdt/P/KHI', 'pic_20003.jpg', 0.0, '', '', '', '', '', '', '', '', '', '', NULL, '', '', '', NULL, '', 1, NULL, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_categories`
--

CREATE TABLE `tbl_categories` (
  `ID` int(11) NOT NULL,
  `CategoryName` varchar(255) DEFAULT NULL,
  `CategoryType` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_categories`
--

INSERT INTO `tbl_categories` (`ID`, `CategoryName`, `CategoryType`) VALUES
(1, 'Cement Plant', 'Plant'),
(2, 'Chemical Plant', 'Plant'),
(3, 'FGD Plant', 'Plant'),
(4, 'Oil and Gas', 'Plant'),
(5, 'Power Plant', 'Plant'),
(6, 'ANSHUN POWER PLANT', 'Project'),
(7, 'ANTAM LINE 4', 'Project'),
(8, 'ANTAM Fe-Ni Smelting Project', 'Project'),
(9, 'Butson Cement Plant', 'Project'),
(10, 'CAM PH', 'Project'),
(11, 'Dingzhou Power Plant FGD', 'Project'),
(12, 'Fatima (MFC)', 'Project'),
(13, 'FATIMA 327B62T1', 'Project'),
(14, 'Fe-Ni Smelting Plant', 'Project'),
(15, 'FGD-NEDO ORIGINAL', 'Project'),
(16, 'HALMAHERA', 'Project'),
(17, 'HPA-AN Coal Conversion', 'Project'),
(18, 'Ichthys LNG', 'Project'),
(19, 'KOBE 11', 'Project'),
(20, 'KOMATSU', 'Project'),
(21, 'MCFPP Mindanao Project', 'Project'),
(22, 'MeOH Feed', 'Project'),
(23, 'NIttetsu-Sumikin Cement', 'Project'),
(24, 'NZ UREA', 'Project'),
(25, 'P-11 CEMENT PLANT', 'Project'),
(26, 'SAUDI FGD PLANT(MHI)', 'Project'),
(27, 'SNNC II', 'Project'),
(28, 'SNNC Fe-Ni Smelting Plant (2007)', 'Project'),
(29, 'SNNC Smelting Plant (2006)', 'Project'),
(30, 'Souryu Cement', 'Project'),
(31, 'Sukagawa Project', 'Project'),
(32, 'Taiheiyo', 'Project'),
(33, 'TETOUAN Extension Plant', 'Project'),
(34, 'Thai Binh FGD', 'Project'),
(35, 'Turkmenistan GTG', 'Project'),
(36, 'Turkmenistan in Mary', 'Project'),
(37, 'TURKMENISTAN CEMENT PLANT', 'Project'),
(38, 'Uong Bi FGD Plant', 'Project');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_groups`
--

CREATE TABLE `tbl_groups` (
  `ID` int(11) NOT NULL,
  `GroupCode` varchar(15) NOT NULL,
  `GroupName` varchar(100) NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_groups`
--

INSERT INTO `tbl_groups` (`ID`, `GroupCode`, `GroupName`, `Status`) VALUES
(1, 'ACT', 'Accounting Group', 'Active'),
(2, 'ADM', 'Admin', 'Active'),
(3, 'ANA', 'Analysis Group', 'Active'),
(4, 'ASH', 'Ash Handling Group', 'Active'),
(5, 'CHE', 'Chemical Group', 'Active'),
(6, 'CIV', 'Civil Group', 'Active'),
(7, 'CM', 'Cement Group', 'Active'),
(8, 'CRY', 'Cryogenic Group', 'Active'),
(9, 'ECS', 'Electrical Control System', 'Active'),
(10, 'EE1', 'Electrical Engineering 1 ', 'Active'),
(11, 'EE2', 'Electrical Engineering 2', 'Active'),
(12, 'ENE', 'Energy Group', 'Active'),
(13, 'ENV', 'Environmental Group', 'Active'),
(14, 'ETCL', 'EarthTechnica Co., Ltd. Group', 'Active'),
(15, 'IT', 'IT Group', 'Active'),
(16, 'MCH', 'Machinery Group', 'Active'),
(17, 'MH', 'Material Handling Group', 'Active'),
(18, 'MIL', 'Mill Group', 'Active'),
(19, 'MNG', 'Managerial Group', 'Active'),
(20, 'PIP', 'Piping Group', 'Active'),
(21, 'SYS', 'Systems Group', 'Active'),
(22, 'TEG', 'Tunneling Equipment Group', 'Active'),
(23, 'SHI', 'Ship Group', 'Active'),
(24, 'EE', 'Electrical Engineering Group', 'Active'),
(25, 'INT', 'Inventor Team', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tags`
--

CREATE TABLE `tbl_tags` (
  `ID` int(11) NOT NULL,
  `TagName` varchar(255) DEFAULT NULL,
  `TagType` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_tags`
--

INSERT INTO `tbl_tags` (`ID`, `TagName`, `TagType`) VALUES
(1, 'Coriolis Flowmeter', NULL),
(2, 'Diff. Press.Transmitter  (Capilary tube)', NULL),
(3, 'Differential Pressure Transmitter', NULL),
(4, 'Displacer Type Level Instrument (Servo Type)', NULL),
(5, 'Flow Nozzle', NULL),
(6, 'Gas Analyzer', NULL),
(7, 'Gas Analyzer Density Meter', NULL),
(8, 'Gas Analyzer Infrared and TCD', NULL),
(9, 'Gas Analyzer Paramagnetic Oxygen', NULL),
(10, 'Gas Chromatograph', NULL),
(11, 'Gas Detector (Diffusion Type)', NULL),
(12, 'Hydrastep Level Meter', NULL),
(13, 'Infrared Analyzer', NULL),
(14, 'Interface Level Meter Gauge', NULL),
(15, 'Interface Level Meter Transmitter', NULL),
(16, 'K Thermocouple & Transmitter (Head Mounted)', NULL),
(17, 'K Thermocouple & Transmitter (Multi Point)', NULL),
(18, 'K Thermocouple & Transmitter (Remote)', NULL),
(19, 'Level Gauge', NULL),
(20, 'Liquid Analyzer Conductivity meter', NULL),
(21, 'Liquid Analyzer pH meter', NULL),
(22, 'Local Elect Receiver Indicator', NULL),
(23, 'N Thermocouple & Transmitter (Head Mounted)', NULL),
(24, 'N Thermocouple & Transmitter (Remote)', NULL),
(25, 'Orifice', NULL),
(26, 'Pressure Gauge', NULL),
(27, 'Pressure Switch', NULL),
(28, 'Pressure Transmitter', NULL),
(29, 'Pressure Transmitter (Capilary tube)', NULL),
(30, 'Radar Type Level Instrument', NULL),
(31, 'Temperature Gauge', NULL),
(32, 'Temperature Sensor (Infrared Television System)', NULL),
(33, 'Ultrasonic Flowmeter (Gas)', NULL),
(34, 'Ultrasonic Flowmeter (Liquid)', NULL),
(35, 'Variable Area Flowmeter', NULL),
(36, 'Venturi Tube', NULL),
(37, 'Vortex Flowmeter', NULL),
(38, 'Zirconia Oxygen', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_uploads`
--

CREATE TABLE `tbl_uploads` (
  `ID` int(11) NOT NULL,
  `FileName` varchar(100) DEFAULT NULL,
  `FileNameDB` varchar(50) DEFAULT NULL,
  `DateUploaded` date DEFAULT NULL,
  `DateCaptured` datetime DEFAULT NULL,
  `Uploader` varchar(20) DEFAULT NULL,
  `FileType` varchar(10) DEFAULT NULL,
  `FileSize` int(11) DEFAULT NULL,
  `Status` varchar(30) DEFAULT NULL,
  `Tags` varchar(1000) DEFAULT NULL,
  `Categories` varchar(500) DEFAULT NULL,
  `PlantType` varchar(50) DEFAULT NULL,
  `ProjectName` varchar(200) DEFAULT NULL,
  `BusinessUnit` varchar(10) DEFAULT NULL,
  `Notes` varchar(500) DEFAULT NULL,
  `forPhotoDB` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_uploads`
--

INSERT INTO `tbl_uploads` (`ID`, `FileName`, `FileNameDB`, `DateUploaded`, `DateCaptured`, `Uploader`, `FileType`, `FileSize`, `Status`, `Tags`, `Categories`, `PlantType`, `ProjectName`, `BusinessUnit`, `Notes`, `forPhotoDB`) VALUES
(1, 'aa.sql', '20230601_121402_3559_E466.pptx', '2023-06-01', '0000-00-00 00:00:00', 'alvinjohn', 'document', 5110060, 'Approved', '[\"Differential Pressure Transmitter\"]', NULL, 'FGD Plant', 'Fatima (MFC)', 'ANA', '', 0),
(2, 'aa.sql', '20230601_121402_9963_E466.sql', '2023-06-01', '0000-00-00 00:00:00', 'alvinjohn', 'others', 1269657, 'Approved', '[\"Gas Analyzer\"]', NULL, 'Power Plant', 'Butson Cement Plant', 'CRY', '', 0),
(3, 'Cloud Nav.pdf', '20230601_121402_5685_E466.pdf', '2023-06-01', '0000-00-00 00:00:00', 'alvinjohn', 'document', 465737, 'Rejected', '[\"Differential Pressure Transmitter\"]', NULL, 'FGD Plant', 'Fe-Ni Smelting Plant', 'ASH', '', 0),
(4, 'EDMon.gif', '20230601_121402_3858_E466.gif', '2023-06-01', '0000-00-00 00:00:00', 'alvinjohn', 'picture', 598905, 'Approved', '[\"Gas Analyzer\"]', NULL, 'Chemical Plant', 'Dingzhou Power Plant FGD', 'ASH', '', 0),
(5, 'EDMon.mp4', '20230601_121403_4147_E466.mp4', '2023-06-01', '0000-00-00 00:00:00', 'alvinjohn', 'video', 427694, 'Approved', '[\"Gas Analyzer Density Meter\"]', NULL, 'Cement Plant', 'Ichthys LNG', 'ASH', '', 0),
(6, 'flight group details.xlsx', '20230601_121403_5611_E466.xlsx', '2023-06-01', '0000-00-00 00:00:00', 'alvinjohn', 'document', 14686, 'Approved', '[\"Gas Analyzer\"]', NULL, 'Chemical Plant', 'CAM PH', 'ASH', '', 0),
(7, 'FORMAT_DataPrivacy_AND_CybereasonConsentForm_R1.pdf', '20230601_121403_5967_E466.pdf', '2023-06-01', '0000-00-00 00:00:00', 'alvinjohn', 'document', 1017112, 'Approved', '[\"Gas Analyzer Density Meter\"]', NULL, 'FGD Plant', 'Butson Cement Plant', 'CHE', '', 0),
(8, 'sql.txt', '20230601_121403_7617_E466.txt', '2023-06-01', '0000-00-00 00:00:00', 'alvinjohn', 'document', 2079, 'Waiting to Tag', NULL, NULL, NULL, NULL, 'Group', NULL, 0),
(9, 'SWIMS.docx', '20230601_121403_5514_E466.docx', '2023-06-01', '0000-00-00 00:00:00', 'alvinjohn', 'document', 11833, 'Waiting to Tag', NULL, NULL, NULL, NULL, 'Group', NULL, 0),
(10, '8.png', '20230601_122858_6311_E466.png', '2023-06-01', '0000-00-00 00:00:00', 'alvinjohn', 'picture', 57792, 'Waiting to Tag', NULL, NULL, NULL, NULL, 'Group', NULL, 0),
(11, '8.png', '20230601_122912_2787_E466.png', '2023-06-01', '0000-00-00 00:00:00', 'alvinjohn', 'picture', 57792, 'Waiting to Tag', NULL, NULL, NULL, NULL, 'Group', NULL, 0),
(12, '9.png', '20230601_122912_5170_E466.png', '2023-06-01', '0000-00-00 00:00:00', 'alvinjohn', 'picture', 293386, 'Waiting to Tag', NULL, NULL, NULL, NULL, 'Group', NULL, 0),
(13, '10.png', '20230601_122912_8874_E466.png', '2023-06-01', '0000-00-00 00:00:00', 'alvinjohn', 'picture', 37875, 'Waiting to Tag', NULL, NULL, NULL, NULL, 'Group', NULL, 0),
(14, '11.jfif', '20230601_122912_1825_E466.jfif', '2023-06-01', '0000-00-00 00:00:00', 'alvinjohn', 'picture', 17144, 'Waiting to Tag', NULL, NULL, NULL, NULL, 'Group', NULL, 0),
(15, '12.jfif', '20230601_122912_2371_E466.jfif', '2023-06-01', '0000-00-00 00:00:00', 'alvinjohn', 'picture', 13552, 'Waiting to Tag', NULL, NULL, NULL, NULL, 'Group', NULL, 0),
(16, 'Cloud Nav.pdf', '20230601_123029_7349_E466.pdf', '2023-06-01', '0000-00-00 00:00:00', 'alvinjohn', 'document', 465737, 'Approved', '[\"Flow Nozzle\"]', NULL, 'Cement Plant', 'Dingzhou Power Plant FGD', 'ANA', '', 0),
(17, '20190111_103148.jpg', '20230601_124121_3221_E466.jpg', '2023-06-01', '2019-01-11 10:31:47', 'alvinjohn', 'picture', 2732412, 'Waiting to Tag', NULL, NULL, NULL, NULL, 'Group', NULL, 0),
(18, '20190111_103414.jpg', '20230601_124121_5053_E466.jpg', '2023-06-01', '2019-01-11 10:34:14', 'alvinjohn', 'picture', 3633868, 'Waiting to Tag', NULL, NULL, NULL, NULL, 'Group', NULL, 0),
(19, '20190111_104333.jpg', '20230601_124121_7514_E466.jpg', '2023-06-01', '2019-01-11 10:43:33', 'alvinjohn', 'picture', 3696047, 'Waiting to Tag', NULL, NULL, NULL, NULL, 'Group', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `ID` int(11) NOT NULL,
  `EmpID` int(11) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `NickName` varchar(20) DEFAULT NULL,
  `UserName` varchar(20) DEFAULT NULL,
  `KDTGroup` varchar(100) DEFAULT NULL,
  `Designation` varchar(20) DEFAULT NULL,
  `BirthDate` date DEFAULT NULL,
  `Gender` varchar(1) DEFAULT NULL,
  `MaritalStatus` varchar(15) DEFAULT NULL,
  `DateHired` date DEFAULT NULL,
  `EmailLotus` varchar(50) DEFAULT NULL,
  `Picture` varchar(50) DEFAULT NULL,
  `Status` varchar(20) NOT NULL DEFAULT 'Active',
  `DateResign` date DEFAULT NULL,
  `UserAccess` varchar(20) NOT NULL DEFAULT 'Tagger'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`ID`, `EmpID`, `LastName`, `FirstName`, `NickName`, `UserName`, `KDTGroup`, `Designation`, `BirthDate`, `Gender`, `MaritalStatus`, `DateHired`, `EmailLotus`, `Picture`, `Status`, `DateResign`, `UserAccess`) VALUES
(1, 7, 'Laureano', 'Antonio', 'Toni', 'toni1', 'ADM', 'CSAD', '1956-07-05', 'M', 'Married', '1989-05-11', 'laureano-kdt/P/KHI', 'pic_7.jpg', 'Resigned', '2021-07-01', 'Tagger'),
(2, 8, 'Panado', 'Evangeline', 'Van', 'van', 'ADM', 'DM', '1960-07-03', 'F', 'Married', '1990-06-11', 'panado-g1/P/KHI', 'pic_8.jpg', 'Active', NULL, 'Tagger'),
(3, 10, 'Tan', 'Erwin', 'TAN', 'khi', 'ANA/ADM/CIV/EE/PIP/IT/SYS/MNG/ETCL', 'SM', '1965-12-20', 'M', 'Married', '1989-05-11', 'tan-g1/P/KHI', 'pic_10.jpg', 'Active', NULL, 'Tagger'),
(4, 18, 'Matibag', 'Erwilson', 'Wilson', 'wilson', 'ANA/IT/SYS/MNG', 'DM', '1972-10-16', 'M', 'Married', '1995-06-01', 'matibag-kdt/P/KHI', 'pic_18.jpg', 'Active', NULL, 'Tagger'),
(5, 21, 'Santos', 'Roberto', 'Bert', 'kuyabert', 'ADM', 'MJ', '1962-10-14', 'M', 'Married', '1996-09-01', '', 'pic_21.jpg', 'Active', NULL, 'Tagger'),
(6, 25, 'Derigay', 'Oliver', 'Oliver', 'OLIVER', 'CHE/CRY/CEM/MIL/ETCL/MPM/MNG', 'DM', '1971-10-21', 'M', 'Married', '1997-01-06', 'derigay-g1/P/KHI', 'pic_25.jpg', 'Active', NULL, 'Tagger'),
(7, 30, 'Abuan', 'Christopher', 'Fher', 'fher', 'MHAH/MNG', 'DM', '1975-12-06', 'M', 'Married', '1997-01-09', 'abuan-kdt/P/KHI', 'pic_30.jpg', 'Active', NULL, 'Tagger'),
(8, 34, 'Corpuz', 'Antonio', 'Tony', 'bosstony', 'ADM', 'DR2', '1965-12-14', 'M', 'Married', '1997-02-01', '', 'pic_34.jpg', 'Active', NULL, 'Tagger'),
(9, 37, 'Llanes', 'Ferdinand', 'Ferdie', 'llanes', 'BOI/INT/MNG', 'DM', '1969-10-31', 'M', 'Married', '1997-08-15', 'llanes-kdt/P/KHI', 'pic_37.jpg', 'Active', NULL, 'Tagger'),
(10, 40, 'Cabello', 'Aristeo', 'Aris', 'aris', 'ENV/MNG', 'DM', '1976-01-24', 'M', 'Married', '1997-10-16', 'cabello-kdt/P/KHI', 'pic_40.jpg', 'Active', NULL, 'Tagger'),
(11, 43, 'Ampig', 'Rommel', 'Rommel', 'rommel1', 'MIL/CEM/MPM/ETCL', 'DM', '1972-01-15', 'M', 'Married', '1998-01-15', 'ampig-kdt/P/KHI', 'pic_43.jpg', 'Resigned', '2022-04-01', 'Tagger'),
(12, 55, 'Perez', 'April', 'April', 'april', 'ACT', 'SA', '1976-04-09', 'F', 'Single', '1998-03-23', 'perez-kdt/P/KHI', 'pic_55.jpg', 'Active', NULL, 'Tagger'),
(13, 61, 'Balisbis Jr.', 'Cezar', 'Czar', 'czar', 'ANA/SYS/IT', 'AM', '1974-09-18', 'M', 'Married', '1998-04-16', 'balisbis-kdt/P/KHI', 'pic_61.jpg', 'Active', NULL, 'Tagger'),
(14, 101, 'Soriano', 'Sharon Ann', 'Ann', 'soriano-kdt', 'ADM', 'ASS', '1976-12-12', 'F', 'Married', '2007-03-03', 'soriano-kdt/P/KHI', 'pic_101.jpg', 'Active', NULL, 'Tagger'),
(15, 104, 'Veloso', 'Ernesto', 'Lou', 'LOU', 'MNG/ENV/BOI', 'SM', '1967-03-24', 'M', 'Married', '2000-07-03', 'veloso-kdt/P/KHI', 'pic_104.jpg', 'Active', NULL, 'Tagger'),
(16, 107, 'Diaz', 'Lorenzo', 'Lorenz', 'etuc', 'CEM/ETCL/MPM/MIL', 'AM', '1974-11-06', 'M', 'Married', '2000-10-16', 'diaz-kdt/P/KHI', 'pic_107.jpg', 'Active', NULL, 'Tagger'),
(17, 117, 'Vitalicio', 'Mae Anne', 'Mae', 'vitalicio-kdt', 'ENV', 'AM', '1976-11-28', 'F', 'Single', '2002-07-01', 'vitalicio-kdt/P/KHI', 'pic_117.jpg', 'Active', NULL, 'Tagger'),
(18, 121, 'Derigay', 'Arlene', 'Arlene', 'arlene', 'ADM', 'AAR', '1977-11-20', 'F', 'Married', '2002-01-02', 'magno-kdt/P/KHI', 'pic_121.jpg', 'Active', NULL, 'Tagger'),
(19, 122, 'Fabia', 'Roderick', 'Rick', 'kuyarick', 'ADM', 'DR', '1970-03-08', 'M', 'Married', '2004-08-18', '', 'pic_122.jpg', 'Active', NULL, 'Tagger'),
(20, 134, 'Becina', 'Artemio Roel', 'Brix', 'brix', 'EE/CIV/PIP/DXT/MNG', 'DM', '1978-04-10', 'M', 'Married', '2002-09-02', 'becina-kdt/P/KHI', 'pic_134.jpg', 'Active', NULL, 'Tagger'),
(21, 145, 'Baradas', 'Ryan', 'Ryan', 'ryan', 'CRY', 'SSV', '1981-03-25', 'M', 'Married', '2005-04-18', 'baradas-kdt/P/KHI', 'pic_145.jpg', 'Active', NULL, 'Tagger'),
(22, 158, 'Valdez', 'Ramir', 'Ramir', 'ramir', 'EE/MNG', 'DM', '1965-11-25', 'M', 'Married', '2006-04-03', 'valdez-kdt/P/KHI', 'pic_158.jpg', 'Active', NULL, 'Tagger'),
(23, 172, 'Viray', 'Jermaine', 'Maine', 'maine', 'MHAH', 'SSV', '1982-09-20', 'F', 'Married', '2006-05-15', 'marasigan-kdt/P/KHI', 'pic_172.jpg', 'Resigned', '2022-12-31', 'Tagger'),
(24, 173, 'Aguilar', 'John Isaac', 'Ice', 'ice', 'EE', 'SSV', '1983-12-24', 'M', 'Married', '2006-05-22', 'aguilar-kdt/P/KHI', 'pic_173.jpg', 'Active', NULL, 'Tagger'),
(25, 174, 'Apostol', 'Roel Boy', 'Putol', 'roel', 'EE', 'SSV', '1983-06-20', 'M', 'Married', '2006-08-22', 'apostol-kdt/P/KHI', 'pic_174.jpg', 'Active', NULL, 'Tagger'),
(26, 185, 'De Jesus', 'Ryan', 'Ryan', 'ryanm', 'PIP', 'SSV', '1982-08-25', 'M', 'Married', '2006-11-16', 'dejesus-kdt/P/KHI', 'pic_185.jpg', 'Active', NULL, 'Tagger'),
(27, 194, 'Castuera', 'Maxwell', 'Max', 'max', 'MHAH', 'SSV', '1980-03-07', 'M', 'Single', '2007-01-02', 'castuera-kdt/P/KHI', 'pic_194.jpg', 'Active', NULL, 'Tagger'),
(28, 209, 'Leal Jr.', 'Ernesto', 'Leal', 'ernesto', 'CEM/ETCL/MPM', 'SSV', '1982-09-28', 'M', 'Married', '2007-03-01', 'leal-kdt/P/KHI', 'pic_209.jpg', 'Active', NULL, 'Tagger'),
(29, 212, 'Lazaro', 'Edmon', 'Mon', 'edmon', 'SYS', 'SSS', '1984-10-20', 'M', 'Married', '2007-03-21', 'lazaro-kdt/P/KHI', 'pic_212.jpg', 'Active', NULL, 'Tagger'),
(30, 215, 'Palmones', 'Michael', 'Mike', 'michaelp', 'CEM', 'SSV', '1979-12-12', 'M', 'Single', '2007-03-21', 'palmones-kdt/P/KHI', 'pic_215.jpg', 'Active', NULL, 'Tagger'),
(31, 221, 'Camato Jr.', 'Gerardo', 'Gerald', 'gerard', 'ENV', 'SSV', '1984-10-14', 'M', 'Married', '2007-05-16', 'camato-kdt/P/KHI', 'pic_221.jpg', 'Active', NULL, 'Tagger'),
(32, 222, 'Beltran', 'Jeffrey', 'Jeff', 'jeffrey', 'MIL', 'SSV', '1983-12-30', 'M', 'Single', '2007-05-16', 'beltran-kdt/P/KHI', 'pic_222.jpg', 'Active', NULL, 'Tagger'),
(33, 223, 'Pahel', 'Jobert', 'Jobs', 'jobert', 'MIL', 'SSV', '1982-08-21', 'M', 'Married', '2007-05-16', 'pahel-kdt/P/KHI', 'pic_223.jpg', 'Active', NULL, 'Tagger'),
(34, 224, 'Desoloc', 'Blessel', 'Bles', 'bles', 'ENV', 'SSV', '1985-03-29', 'F', 'Single', '2007-05-16', 'desoloc-kdt/P/KHI', 'pic_224.jpg', 'Active', NULL, 'Tagger'),
(35, 226, 'Gulapa', 'Francis Martee', 'Martee', 'martee', 'EE', 'SSV', '1985-01-23', 'M', 'Married', '2007-05-16', 'gulapa-kdt/P/KHI', 'pic_226.jpg', 'Active', NULL, 'Tagger'),
(36, 230, 'Oliveros', 'Mark Anthony', 'Mark', 'mark', 'MHAH', 'SV', '1983-04-16', 'M', 'Married', '2007-06-25', 'oliveros-kdt/P/KHI', 'pic_230.jpg', 'Active', NULL, 'Tagger'),
(37, 238, 'Sese', 'Joseph Ferdinand', 'Joseph', 'sese', 'ENV', 'SV', '1973-09-11', 'M', 'Married', '2007-08-16', 'sese-kdt/P/KHI', 'pic_238.jpg', 'Active', NULL, 'Tagger'),
(38, 240, 'Miranda', 'Christian Jay', 'Chris', 'christian', 'CEM', 'SV', '1983-08-25', 'M', 'Married', '2007-08-16', 'miranda-kdt/P/KHI', 'pic_240.jpg', 'Active', NULL, 'Tagger'),
(39, 243, 'Ramos', 'Sheena', 'Shin', 'sheena', 'ACT', 'SAA', '1985-09-03', 'F', 'Married', '2007-12-03', 'serdina-kdt/P/KHI', 'pic_243.jpg', 'Active', NULL, 'Tagger'),
(40, 252, 'Araneta', 'Rex', 'Rex', 'araneta-kdt', 'CIV', 'SSV', '1983-05-16', 'M', 'Married', '2008-05-19', 'araneta-kdt/P/KHI', 'pic_252.jpg', 'Active', NULL, 'Tagger'),
(41, 256, 'Sahagun', 'Michelle', 'Cheng', 'cheng', 'INT/CEM', 'SV', '1982-05-20', 'F', 'Married', '2010-03-01', 'canalda-kdt/P/KHI', 'pic_256.jpg', 'Resigned', '2022-12-31', 'Tagger'),
(42, 257, 'Onod', 'Abeel', 'Abel', 'abel', 'MIL', 'SV', '1986-07-07', 'M', 'Married', '2010-03-01', 'onod-kdt/P/KHI', 'pic_257.jpg', 'Resigned', '2023-03-15', 'Tagger'),
(43, 259, 'Lucena', 'Rey', 'Rey', 'rey', 'CEM', 'SV', '1987-05-04', 'M', 'Married', '2010-03-01', 'lucena-kdt/P/KHI', 'pic_259.jpg', 'Active', NULL, 'Tagger'),
(44, 260, 'Verano', 'Ronald', 'RV', 'rv', 'ETCL', 'SV', '1984-07-11', 'M', 'Married', '2010-03-01', 'verano-kdt/P/KHI', 'pic_260.jpg', 'Active', NULL, 'Tagger'),
(45, 261, 'Villamor', 'Amor', 'Amor', 'amor', 'CHE', 'SV', '1984-09-15', 'M', 'Married', '2010-03-01', 'villamor-kdt/P/KHI', 'pic_261.jpg', 'Active', NULL, 'Tagger'),
(46, 262, 'Cantara', 'Mark Joel', 'Joel', 'cantara', 'MHAH', 'SV', '1984-01-20', 'M', 'Single', '2010-03-01', 'cantara-kdt/P/KHI', 'pic_262.jpg', 'Active', NULL, 'Tagger'),
(47, 263, 'Pascua', 'Henry', 'Henry', 'henry', 'MHAH', 'SV', '1984-06-19', 'M', 'Married', '2010-03-01', 'pascua-kdt/P/KHI', 'pic_263.jpg', 'Active', NULL, 'Tagger'),
(48, 264, 'Cular', 'Giulian Louis', 'Louis', 'louis', 'CRY', 'SDE', '1986-06-21', 'M', 'Single', '2010-03-01', 'cular-kdt/P/KHI', 'pic_264.jpg', 'Active', NULL, 'Tagger'),
(49, 265, 'Onod', 'Amalia', 'Amie', 'amie', 'ENV', 'SDE', '1989-07-05', 'F', 'Married', '2010-03-01', 'nodalo-kdt/P/KHI', 'pic_265.jpg', 'Resigned', '2023-03-15', 'Tagger'),
(50, 268, 'Sandoval', 'Dan Christian', 'Dan', 'sandoval', 'PIP/DXT', 'SV', '1985-10-06', 'M', 'Single', '2010-06-01', 'sandoval-kdt/P/KHI', 'pic_268.jpg', 'Active', NULL, 'Tagger'),
(51, 270, 'Caringal', 'Gian Carlo', 'Carlo', 'carlo', 'PIP', 'SV', '1985-12-15', 'M', 'Married', '2010-06-01', 'caringal-kdt/P/KHI', 'pic_270.jpg', 'Active', NULL, 'Tagger'),
(52, 272, 'Caveiro', 'Vincent', 'Vince', 'vince_resigned', 'PIP', 'SV', '1986-01-02', 'M', 'Married', '2010-06-01', 'caveiro-resigned/P/KHI', 'pic_272.jpg', 'Resigned', '2023-03-31', 'Tagger'),
(53, 279, 'Panopio', 'Luisito', 'Louie', 'lpanopio', 'MHAH', 'SV', '1984-02-27', 'M', 'Single', '2010-06-16', 'panopio-kdt/P/KHI', 'pic_279.jpg', 'Active', NULL, 'Tagger'),
(54, 281, 'Cura', 'Leonard Ryan', 'Ryan', 'cura', 'CHE', 'SV', '1986-12-08', 'M', 'Married', '2010-06-16', 'cura-kdt/P/KHI', 'pic_281.jpg', 'Active', NULL, 'Tagger'),
(55, 283, 'Cenizal', 'Ma. Evangeline', 'Vangie', 'adami', 'EE', 'SV', '1986-10-22', 'F', 'Married', '2010-06-16', 'adami-kdt/P/KHI', 'pic_283.jpg', 'Active', NULL, 'Tagger'),
(56, 284, 'Cidro', 'James Eric', 'Jim', 'james', 'EE/DXT', 'SV', '1987-10-18', 'M', 'Married', '2010-06-16', 'cidro-kdt/P/KHI', 'pic_284.jpg', 'Active', NULL, 'Tagger'),
(57, 288, 'Godoy', 'Jhon Ray', 'Jhon', 'jhon', 'EE', 'SV', '1989-01-10', 'M', 'Married', '2011-01-03', 'godoy-kdt/P/KHI', 'pic_288.jpg', 'Active', NULL, 'Tagger'),
(58, 290, 'Ariap', 'Jomanil', 'Joma', 'joma', 'CRY', 'SDE', '1988-06-27', 'M', 'Single', '2011-01-03', 'ariap-kdt/P/KHI', 'pic_290.jpg', 'Active', NULL, 'Tagger'),
(59, 291, 'Llosala', 'Rowel', 'Wel', 'rowel', 'CHE', 'SV', '1988-02-26', 'M', 'Married', '2011-01-03', 'llosala-kdt/P/KHI', 'pic_291.jpg', 'Active', NULL, 'Tagger'),
(60, 293, 'Dimaapi', 'Jasper', 'Jasper', 'jasper', 'ETCL', 'SV', '1989-05-16', 'M', 'Single', '2011-01-03', 'dimaapi-kdt/P/KHI', 'pic_293.jpg', 'Active', NULL, 'Tagger'),
(61, 295, 'Moreno', 'Rex', 'Rex', 'moreno', 'MHAH', 'AM', '1981-03-27', 'M', 'Single', '2011-05-02', 'moreno-kdt/P/KHI', 'pic_295.jpg', 'Active', NULL, 'Tagger'),
(62, 296, 'Macalalad', 'Joseph Michael', 'Joseph', 'macalalad', 'ENV', 'AM', '1981-02-16', 'M', 'Married', '2011-05-02', 'macalalad-kdt/P/KHI', 'pic_296.jpg', 'Active', NULL, 'Tagger'),
(63, 299, 'Cano', 'Bryan Jay', 'Bryan', 'cano-kdt', 'BOI/INT', 'SV', '1988-08-12', 'M', 'Single', '2011-08-01', 'cano-kdt/P/KHI', 'pic_299.jpg', 'Active', NULL, 'Tagger'),
(64, 301, 'Lina', 'Dominador Joshua', 'Josh', 'lina-kdt', 'BOI/INT', 'SDE', '1989-07-03', 'M', 'Single', '2011-08-01', 'lina-kdt/P/KHI', 'pic_301.jpg', 'Active', NULL, 'Tagger'),
(65, 302, 'Sampaga', 'Louie', 'Louie', 'sampaga', 'EE/DXT', 'SDE', '1987-12-02', 'M', 'Married', '2012-01-16', 'sampaga-kdt/P/KHI', 'pic_302.jpg', 'Active', NULL, 'Tagger'),
(66, 304, 'Mundo', 'Daisy', 'Daisy', 'daisy', 'ENV/CHE', 'DE3', '1979-01-18', 'F', 'Single', '2012-01-16', 'mundo-kdt/P/KHI', 'pic_304.jpg', 'Resigned', '2021-11-01', 'Tagger'),
(67, 305, 'Escueta', 'Roderick', 'Eric', 'roderick', 'PIP', 'SDE', '1981-02-09', 'M', 'Married', '2012-01-16', 'escueta-kdt/P/KHI', 'pic_305.jpg', 'Active', NULL, 'Tagger'),
(68, 306, 'Belen', 'Kervin', 'Kervin', 'kervin', 'PIP/DXT', 'SDE', '1988-07-23', 'M', 'Married', '2012-01-16', 'belen-kdt/P/KHI', 'pic_306.jpg', 'Active', NULL, 'Tagger'),
(69, 307, 'Ballon', 'Veronica', 'Vec', 'mendoza-kdt', 'IT', 'IT-SV', '1989-12-10', 'F', 'Married', '2012-05-07', 'mendoza-kdt/P/KHI', 'pic_307.jpg', 'Active', NULL, 'Tagger'),
(70, 310, 'Tumaob', 'Ferdinand', 'Tommy', 'tommy', 'MIL', 'SDE', '1984-12-18', 'M', 'Married', '2012-05-16', 'tumaob-kdt/P/KHI', 'pic_310.jpg', 'Active', NULL, 'Tagger'),
(71, 311, 'Penetrante Jr.', 'Jorge', 'JR', 'jorge', 'BOI', 'SV', '1986-10-28', 'M', 'Single', '2012-05-16', 'penetrante-kdt/P/KHI', 'pic_311.jpg', 'Active', NULL, 'Tagger'),
(72, 312, 'Lucas', 'Adelbert', 'Adel', 'adel', 'BOI', 'SDE', '1988-08-18', 'M', 'Single', '2012-05-16', 'lucas-kdt/P/KHI', 'pic_312.jpg', 'Active', NULL, 'Tagger'),
(73, 313, 'Agustines', 'Albert', 'Albert', 'albert', 'EE/DXT', 'SDE', '1987-07-24', 'M', 'Single', '2012-05-16', 'agustines-kdt/P/KHI', 'pic_313.jpg', 'Active', NULL, 'Tagger'),
(74, 314, 'Sangalang', 'Dickenson', 'Dick', 'dickenson', 'EE', 'SDE', '1983-11-17', 'M', 'Married', '2012-05-16', 'sangalang_d-kdt/P/KHI', 'pic_314.jpg', 'Active', NULL, 'Tagger'),
(75, 316, 'Bautista Jr.', 'Celso', 'Ceejay', 'cj', 'CEM', 'SDE', '1991-05-23', 'M', 'Single', '2013-02-16', 'bautista-kdt/P/KHI', 'pic_316.jpg', 'Active', NULL, 'Tagger'),
(76, 320, 'Escueta Jr.', 'Juanito', 'Jeck', 'jeckzay', 'EE', 'DE3', '1984-03-23', 'M', 'Married', '2013-02-16', 'escueta_j-kdt/P/KHI', 'pic_320.jpg', 'Active', NULL, 'Tagger'),
(77, 321, 'Bigtas', 'Keith Charm', 'Charm', 'charm', 'EE', 'DE3', '1985-03-26', 'F', 'Single', '2013-02-16', 'bigtas-kdt/P/KHI', 'pic_321.jpg', 'Active', NULL, 'Tagger'),
(78, 322, 'Dela Rosa', 'Ester', 'Tets', 'ester', 'EE', 'SDE', '1987-02-28', 'F', 'Single', '2013-02-16', 'delarosa-kdt/P/KHI', 'pic_322.jpg', 'Active', NULL, 'Tagger'),
(79, 323, 'Borlagon', 'Alvin Jan', 'Vin', 'vhin', 'BOI', 'SDE', '1990-01-29', 'M', 'Married', '2013-02-16', 'borlagon-kdt/P/KHI', 'pic_323.jpg', 'Active', NULL, 'Tagger'),
(80, 328, 'Calleja', 'Nomer', 'PIPOY', 'nomer', 'BOI', 'SDE', '1989-04-11', 'M', 'Married', '2013-05-02', 'calleja-kdt/P/KHI', 'pic_328.jpg', 'Active', NULL, 'Tagger'),
(81, 329, 'Marqueses', 'Jeff Edward', 'JEFF', 'je', 'BOI', 'SDE', '1988-11-01', 'M', 'Married', '2013-05-02', 'marqueses_j-kdt/P/KHI', 'pic_329.jpg', 'Active', NULL, 'Tagger'),
(82, 330, 'Omiz', 'Gilbert Jason', 'GILBERT', 'bert', 'PIP', 'SDE', '1991-04-03', 'M', 'Single', '2013-08-01', 'omiz-kdt/P/KHI', 'pic_330.jpg', 'Active', NULL, 'Tagger'),
(83, 332, 'De Guzman', 'Christopher', 'CHRIS', 'chrisdegz', 'ENV', 'SDE', '1990-09-22', 'M', 'Single', '2013-08-01', 'deguzman-kdt/P/KHI', 'pic_332.jpg', 'Resigned', '2021-11-01', 'Tagger'),
(84, 333, 'Mataum', 'Michael', 'KEL', 'kel', 'PIP/DXT', 'SDE', '1989-06-30', 'M', 'Single', '2013-08-01', 'mataum-kdt/P/KHI', 'pic_333.jpg', 'Active', NULL, 'Tagger'),
(85, 334, 'Miranda', 'Julemir', 'JUN JUN', 'miranda_j-kdt', 'ENV', 'SDE', '1987-08-26', 'M', 'Single', '2013-08-01', 'miranda_j-kdt/P/KHI', 'pic_334.jpg', 'Active', NULL, 'Tagger'),
(86, 335, 'Ballon', 'Al John', 'AL JOHN', 'aljohn', 'MHAH', 'SDE', '1989-07-09', 'M', 'Married', '2013-08-01', 'ballon-kdt/P/KHI', 'pic_335.jpg', 'Active', NULL, 'Tagger'),
(87, 338, 'Bulan Jr.', 'Rosbelt', 'ROS', 'ross', 'ENV/DXT', 'SDE', '1990-03-14', 'M', 'Single', '2013-10-01', 'bulan-kdt/P/KHI', 'pic_338.jpg', 'Active', NULL, 'Tagger'),
(88, 344, 'Patron', 'Edilaine Marose', 'EM', 'em', 'CHE', 'DE3', '1992-01-24', 'F', 'Single', '2014-01-02', 'patron-kdt/P/KHI', 'pic_344.jpg', 'Active', NULL, 'Tagger'),
(89, 345, 'Caunga', 'Rustum Oliver', 'RUSTUM', 'rocaunga', 'CRY', 'DE3', '1990-06-29', 'M', 'Single', '2014-01-02', 'caunga-kdt/P/KHI', 'pic_345.jpg', 'Active', NULL, 'Tagger'),
(90, 346, 'Bio', 'Marie Eleonor', 'MARIE', 'yhelle', 'EE', 'DE3', '1991-04-15', 'F', 'Married', '2014-01-02', 'mirabel-kdt/P/KHI', 'pic_346.jpg', 'Active', NULL, 'Tagger'),
(91, 348, 'Tobias', 'Jeoffer', 'JEOFF', 'jltobias', 'ENV', 'DE3', '1990-07-24', 'M', 'Single', '2014-04-01', 'tobias-kdt/P/KHI', 'pic_348.jpg', 'Resigned', '2023-02-13', 'Tagger'),
(92, 350, 'Cajes', 'Joseph', 'DODONG', 'josephcc', 'CRY', 'DE3', '1990-03-22', 'M', 'Married', '2014-04-01', 'cajes-kdt/P/KHI', 'pic_350.jpg', 'Active', NULL, 'Tagger'),
(93, 352, 'Ducay', 'John David', 'DAVID', 'johndavid', 'ENV', 'DE3', '1989-08-28', 'M', 'Married', '2014-04-01', 'ducay-kdt/P/KHI', 'pic_352.jpg', 'Active', NULL, 'Tagger'),
(94, 353, 'Torio', 'Raffy', 'RAFFY', 'raffy', 'SYS/SHI', 'SSE', '1989-02-02', 'M', 'Single', '2014-04-01', 'torio-kdt/P/KHI', 'pic_353.jpg', 'Resigned', '2022-07-18', 'Tagger'),
(95, 355, 'De Jesus', 'Jommuel', 'JOM', 'jommuel', 'SYS', 'SE3', '1992-01-29', 'M', 'Single', '2014-04-01', 'dejesus_j-kdt/P/KHI', 'pic_355.jpg', 'Active', NULL, 'Tagger'),
(96, 356, 'Sumayop', 'Lian Marie', 'LIAN', 'lian', 'EE', 'DE3', '1991-02-07', 'F', 'Married', '2014-04-01', 'cabradilla-kdt/P/KHI', 'pic_356.jpg', 'Active', NULL, 'Tagger'),
(97, 357, 'Sanao', 'Jomari', 'JOM', 'jomari', 'PIP', 'DE3', '1992-11-19', 'M', 'Married', '2014-06-02', 'sanao-kdt/P/KHI', 'pic_357.jpg', 'Active', NULL, 'Tagger'),
(98, 358, 'Sanao', 'Roxanne May', 'XANXAN', 'xanxane', 'PIP', 'DE3', '1991-03-11', 'F', 'Married', '2014-06-02', 'velez-kdt/P/KHI', 'pic_358.jpg', 'Active', NULL, 'Tagger'),
(99, 364, 'Bitang', 'Kim Brian', 'Kim', 'Kimbrian', 'ENV', 'DE3', '1992-02-15', 'F', 'Single', '2014-09-01', 'bitang-kdt/P/KHI', 'pic_364.jpg', 'Resigned', '2021-11-01', 'Tagger'),
(100, 365, 'Magnaye', 'Lara Joy', 'LARA', 'lara', 'ENV', 'DE3', '1991-09-17', 'F', 'Married', '2014-09-01', 'dimaculangan-kdt/P/KHI', 'pic_365.jpg', 'Resigned', '2021-11-01', 'Tagger'),
(101, 367, 'Mendoza', 'Marcial', 'MARCY', 'marci', 'ENV', 'DE3', '1990-05-24', 'M', 'Married', '2014-09-01', 'mendoza_m-kdt/P/KHI', 'pic_367.jpg', 'Active', NULL, 'Tagger'),
(102, 370, 'Nopra', 'Charis Candy', 'CANDY', 'candy', 'IT', 'IT-SE', '1992-04-14', 'F', 'Single', '2014-09-01', 'nopra-kdt/P/KHI', 'pic_370.jpg', 'Active', NULL, 'Tagger'),
(103, 371, 'Cordova', 'Ysabel', 'Ysay', 'ysay', 'MHAH', 'DE3', '1991-01-19', 'F', 'Single', '2015-02-02', 'cordova-kdt/P/KHI', 'pic_371.jpg', 'Active', NULL, 'Tagger'),
(104, 372, 'Frane', 'Gerald Christopher', 'Gerald', 'gerald', 'EE', 'DE3', '1991-12-01', 'M', 'Single', '2015-02-02', 'frane-kdt/P/KHI', 'pic_372.jpg', 'Active', NULL, 'Tagger'),
(105, 373, 'Sabarillo', 'Nelmar Bong', 'Bong', 'bong', 'CRY', 'DE3', '1993-04-22', 'M', 'Single', '2015-02-02', 'sabarillo-kdt/P/KHI', 'pic_373.jpg', 'Active', NULL, 'Tagger'),
(106, 374, 'Fortus', 'Domini', 'Domini', 'domini_resign', 'TEG', 'DE3', '1993-07-12', 'M', 'Single', '2015-02-02', 'fortus-kdt/P/KHI', 'pic_374.jpg', 'Resigned', '2022-03-15', 'Tagger'),
(107, 376, 'Manaog', 'Karen Lorraine', 'Karen', 'karenv', 'EE', 'DE3', '1990-10-19', 'F', 'Married', '2015-02-02', 'vallestero-kdt/P/KHI', 'pic_376.jpg', 'Active', NULL, 'Tagger'),
(108, 377, 'Guico', 'Aldrin', 'Gibo', 'gibo', 'MHAH', 'DE3', '1991-08-11', 'M', 'Single', '2015-02-02', 'guico-kdt/P/KHI', 'pic_377.jpg', 'Active', NULL, 'Tagger'),
(109, 378, 'Montalbo', 'Jennelyn', 'Jen', 'jhen', 'MHAH', 'DE3', '1989-12-04', 'F', 'Married', '2015-02-02', 'reyes_j-kdt/P/KHI', 'pic_378.jpg', 'Resigned', '2021-11-01', 'Tagger'),
(110, 381, 'Flores', 'Angelo', 'Angelo', 'gelo', 'MHAH', 'DE3', '1990-06-19', 'M', 'Single', '2015-02-02', 'flores_a-kdt/P/KHI', 'pic_381.jpg', 'Active', NULL, 'Tagger'),
(111, 382, 'Marquez', 'Arvin David', 'Arvin', 'arvin', 'CIV', 'DE3', '1991-11-19', 'M', 'Married', '2015-05-11', 'marquez-kdt/P/KHI', 'pic_382.jpg', 'Active', NULL, 'Tagger'),
(112, 383, 'Bellen', 'Abegail', 'Abby', 'bellenabi', 'CIV', 'DE3', '1990-05-16', 'F', 'Single', '2015-05-11', 'bellen-kdt/P/KHI', 'pic_383.jpg', 'Active', NULL, 'Tagger'),
(113, 384, 'Gallardo', 'Al Shariff', 'Al', 'al', 'ANA', 'DE3', '1993-06-14', 'M', 'Single', '2015-05-11', 'gallardo-kdt/P/KHI', 'pic_384.jpg', 'Active', NULL, 'Tagger'),
(114, 385, 'Perez', 'Jeremia', 'Mia', 'mia', 'CIV', 'DE3', '1990-09-18', 'F', 'Single', '2015-05-11', 'perez_j-kdt/P/KHI', 'pic_385.jpg', 'Active', NULL, 'Tagger'),
(115, 386, 'Tan', 'Dennis', 'Dennis', 'dennistan', 'MPM', 'DE3', '1990-07-26', 'M', 'Single', '2015-06-01', 'tan_d-kdt/P/KHI', 'pic_386.jpg', 'Active', NULL, 'Tagger'),
(116, 387, 'Balgoma', 'Ramil', 'Ram', 'rbalgoma', 'MHAH', 'DE3', '1992-11-17', 'M', 'Single', '2015-06-01', 'balgoma-kdt/P/KHI', 'pic_387.jpg', 'Active', NULL, 'Tagger'),
(117, 388, 'Gupit', 'Bernico', 'Bernie', 'bernico', 'MHAH', 'DE3', '1992-03-16', 'M', 'Single', '2015-06-01', 'gupit-kdt/P/KHI', 'pic_388.jpg', 'Active', NULL, 'Tagger'),
(118, 389, 'Miranda', 'Nikko', 'Nikko', 'nikkomiranda', 'MPM', 'DE3', '1992-03-16', 'M', 'Single', '2015-06-01', 'miranda_n-kdt/P/KHI', 'pic_389.jpg', 'Active', NULL, 'Tagger'),
(119, 390, 'Garcia', 'Christian Joseph', 'Anjo', 'cmgarcia', 'ENV', 'DE3', '1991-02-10', 'M', 'Married', '2015-06-01', 'garcia_c-kdt/P/KHI', 'pic_390.jpg', 'Active', NULL, 'Tagger'),
(120, 391, 'Dalisay', 'Catherine', 'Cathy', 'catherine', 'ACT', 'AA', '1984-09-30', 'F', 'Married', '2015-08-06', 'austria-kdt/P/KHI', 'pic_391.jpg', 'Active', NULL, 'Tagger'),
(121, 393, 'De Sotto', 'Francis John', 'Kiko', 'francis', 'MHAH', 'DE3', '1990-11-05', 'M', 'Single', '2015-10-01', 'desotto-kdt/P/KHI', 'pic_393.jpg', 'Resigned', '2022-08-01', 'Tagger'),
(122, 394, 'Banta', 'Leah Mariel', 'Leah', 'leah', 'MHAH', 'DE2', '1992-10-15', 'F', 'Single', '2015-10-01', 'banta-kdt/P/KHI', 'pic_394.jpg', 'Resigned', '2022-05-08', 'Tagger'),
(123, 395, 'Villanueva', 'Gladys ', 'Gladys', 'Gladys', 'ENV', 'DE2', '1993-02-26', 'F', 'Single', '2015-10-01', 'villanueva-kdt/P/KHI', 'pic_395.jpg', 'Resigned', '2021-11-01', 'Tagger'),
(124, 396, 'Lacsa', 'John', 'John', 'lacsa', 'MHAH', 'DE3', '1993-01-16', 'M', 'Single', '2015-10-01', 'lacsa-kdt/P/KHI', 'pic_396.jpg', 'Active', NULL, 'Tagger'),
(125, 397, 'Cantos', 'Reniel', 'Reniel', 'ren', 'BOI', 'DE2', '1993-03-11', 'M', 'Single', '2015-10-01', 'cantos-kdt/P/KHI', 'pic_397.jpg', 'Resigned', '2022-02-18', 'Tagger'),
(126, 398, 'Sta. Ana', 'Arnulfo', 'Arnold', 'kuyaarnold', 'ADM', 'DRM', '1965-03-02', 'M', 'Married', '2016-04-01', '', 'pic_398.jpg', 'Active', NULL, 'Tagger'),
(127, 401, 'Laureano', 'Miki Antonio', 'Miki', 'mikilaureano', 'ENV', 'DE3', '1993-05-06', 'M', 'Married', '2016-07-01', 'laureano_m-kdt/P/KHI', 'pic_401.jpg', 'Active', NULL, 'Tagger'),
(128, 402, 'Ornido', 'Marvin John', 'Marvz', 'marvz', 'BOI', 'DE3', '1992-09-17', 'M', 'Single', '2016-07-01', 'ornido-kdt/P/KHI', 'pic_402.jpg', 'Active', NULL, 'Tagger'),
(129, 403, 'Mangaliman', 'Laarni', 'Lani', 'laarni', 'CEM', 'DE3', '1993-09-04', 'F', 'Married', '2016-07-01', 'tumamao-kdt/P/KHI', 'pic_403.jpg', 'Resigned', '2022-11-05', 'Tagger'),
(130, 404, 'Argente', 'Gene Owen', 'Owen', 'geneowen', 'ENV', 'DE3', '1991-08-17', 'M', 'Single', '2016-07-01', 'argente-kdt/P/KHI', 'pic_404.jpg', 'Active', NULL, 'Tagger'),
(131, 406, 'Tumbaga', 'Jefferson', 'Jep', 'tumbaga-kdt', 'CEM', 'DE3', '1993-07-22', 'M', 'Married', '2016-07-01', 'tumbaga-kdt/P/KHI', 'pic_406.jpg', 'Active', NULL, 'Tagger'),
(132, 407, 'Villatuya', 'Russel', 'Russel', 'rcvillatuya', 'EE', 'DE3', '1992-08-07', 'M', 'Single', '2016-07-01', 'villatuya-kdt/P/KHI', 'pic_407.jpg', 'Active', NULL, 'Tagger'),
(133, 409, 'Dela Cruz', 'Earvin James', 'EJ', 'earvinjames', 'SYS', 'SE3', '1993-04-03', 'M', 'Single', '2016-07-01', 'delacruz-kdt/P/KHI', 'pic_409.jpg', 'Active', NULL, 'Tagger'),
(134, 410, 'Parra', 'Ely', 'Ely', 'elyparra', 'BOI', 'DE2', '1994-07-11', 'M', 'Single', '2017-03-01', 'parra-kdt/P/KHI', 'pic_410.jpg', 'Active', NULL, 'Tagger'),
(135, 411, 'Ilao', 'Marylou', 'Malou', 'malou', 'ENV', 'DE2', '1991-10-13', 'F', 'Single', '2017-03-01', 'manalo-kdt/P/KHI', 'pic_411.jpg', 'Active', NULL, 'Tagger'),
(136, 412, 'Rivera', 'Reenan', 'Reenan', 'reenan', 'ENV', 'DE2', '1992-10-01', 'M', 'Single', '2017-03-01', 'rivera-kdt/P/KHI', 'pic_412.jpg', 'Active', NULL, 'Tagger'),
(137, 413, 'Buzeta', 'Wendy', 'Wendy', 'wendz', 'MHAH', 'DE2', '1991-01-22', 'F', 'Single', '2017-03-01', 'anorico-kdt/P/KHI', 'pic_413.jpg', 'Active', NULL, 'Tagger'),
(138, 414, 'Antonio', 'Wilhelm Dennis', 'Lem', 'wilhelm', 'ENV', 'DE2', '1994-08-05', 'M', 'Single', '2017-03-01', 'antonio-kdt/P/KHI', 'pic_414.jpg', 'Active', NULL, 'Tagger'),
(139, 415, 'Astrera', 'Philip Jhon', 'Philip', 'philipj', 'ENV', 'DE2', '1995-11-23', 'M', 'Single', '2017-03-01', 'astrera-kdt/P/KHI', 'pic_415.jpg', 'Active', NULL, 'Tagger'),
(140, 416, 'Floresca', 'Gene Philip', 'Gene', 'gene', 'ETCL', 'DE2', '1992-11-20', 'M', 'Single', '2017-03-01', 'floresca-kdt/P/KHI', 'pic_416.jpg', 'Active', NULL, 'Tagger'),
(141, 417, 'Binay-an', 'Daryl', 'Daryl', 'darylb', 'MHAH', 'DE2', '1994-10-24', 'M', 'Single', '2017-03-01', 'binayan-kdt/P/KHI', 'pic_417.jpg', 'Active', NULL, 'Tagger'),
(142, 419, 'Mesias', 'Meriam', 'Yamie', 'meriam', 'ADM', 'AAR', '1985-08-15', 'F', 'Single', '2017-09-04', 'mesias-kdt/P/KHI', 'pic_419.jpg', 'Active', NULL, 'Tagger'),
(143, 420, 'Benedicto', 'Alvin', 'Vin', 'vin', 'ENV', 'DE2', '1994-10-20', 'M', 'Single', '2018-07-02', 'benedicto-kdt/P/KHI', 'pic_420.jpg', 'Active', NULL, 'Tagger'),
(144, 421, 'Nazar', 'John Jacob', 'Jacob', 'jjnazar', 'MHAH', 'DE2', '1996-01-28', 'M', 'Single', '2018-07-02', 'nazar-kdt/P/KHI', 'pic_421.jpg', 'Active', NULL, 'Tagger'),
(145, 422, 'Pimentel', 'Lucky Boy', 'Lux', 'lux', 'ENV', 'DE2', '1996-10-20', 'M', 'Single', '2018-07-02', 'pimentel-kdt/P/KHI', 'pic_422.jpg', 'Active', NULL, 'Tagger'),
(146, 423, 'Caro', 'Renson', 'Renson', 'rensonc', 'ENV', 'DE2', '1995-01-15', 'M', 'Single', '2018-07-02', 'caro-kdt/P/KHI', 'pic_423.jpg', 'Active', NULL, 'Tagger'),
(147, 424, 'Perez', 'Renzel', 'Renzel', 'renzel', 'MHAH', 'DE2', '1994-09-09', 'M', 'Single', '2018-07-02', 'perez_r-kdt/P/KHI', 'pic_424.jpg', 'Active', NULL, 'Tagger'),
(148, 425, 'Belen', 'Marvin', 'Marvin', 'mbelen', 'ENV', 'DE2', '1994-09-22', 'M', 'Single', '2018-07-02', 'belen_m-kdt/P/KHI', 'pic_425.jpg', 'Active', NULL, 'Tagger'),
(149, 426, 'Tuazon', 'King Louis', 'King', 'kdtuazon', 'BOI', 'DE2', '1992-04-14', 'M', 'Single', '2018-07-02', 'tuazon-kdt/P/KHI', 'pic_426.jpg', 'Active', NULL, 'Tagger'),
(150, 427, 'Fernandez', 'Julius', 'Julius', 'julius', 'MHAH', 'DE2', '1994-01-02', 'M', 'Single', '2018-07-02', 'fernandez-kdt/P/KHI', 'pic_427.jpg', 'Active', NULL, 'Tagger'),
(151, 428, 'Velasco', 'Vryan', 'Vryan', 'vryan', 'ENV', 'DE2', '1993-10-05', 'M', 'Single', '2018-07-02', 'velasco-kdt/P/KHI', 'pic_428.jpg', 'Active', NULL, 'Tagger'),
(152, 429, 'Moralita', 'Denmark', 'Denmark', 'dmoralita', 'ENV', 'DE2', '1994-09-10', 'M', 'Single', '2018-07-02', 'moralita-kdt/P/KHI', 'pic_429.jpg', 'Active', NULL, 'Tagger'),
(153, 430, 'Ucol', 'Zendy Grace', 'Zendy', 'zendy', 'ENV', 'DE2', '1995-08-13', 'F', 'Single', '2018-07-02', 'ucol-kdt/P/KHI', 'pic_430.jpg', 'Active', NULL, 'Tagger'),
(154, 432, 'Macaraan', 'Christian', 'Christian', 'cmacaraan', 'ENV', 'DE2', '1993-12-24', 'M', 'Single', '2018-07-02', 'macaraan-kdt/P/KHI', 'pic_432.jpg', 'Active', NULL, 'Tagger'),
(155, 433, 'Ramos', 'Alyssa', 'Alyssa', 'alyssa', 'MHAH', 'DE2', '1995-09-04', 'F', 'Single', '2018-07-02', 'ramos-kdt/P/KHI', 'pic_433.jpg', 'Active', NULL, 'Tagger'),
(156, 434, 'Pilis', 'Vilmer', 'Vilmer', 'vilmer', 'ENV', 'DE2', '1993-09-12', 'M', 'Single', '2018-07-02', 'pilis-kdt/P/KHI', 'pic_434.jpg', 'Active', NULL, 'Tagger'),
(157, 435, 'Basibas', 'Kerstin Paula', 'Kerstin', 'kbasibas', 'ENV', 'DE2', '1995-02-03', 'F', 'Single', '2018-07-02', 'basibas-kdt/P/KHI', 'pic_435.jpg', 'Active', NULL, 'Tagger'),
(158, 436, 'Viñas', 'Eugene', 'Eugene', 'eugene', 'ENV', 'DE2', '1994-03-15', 'M', 'Single', '2018-07-02', 'vinas-kdt/P/KHI', 'pic_436.jpg', 'Active', NULL, 'Tagger'),
(159, 437, 'Callores', 'Dick Francis', 'Dick', 'dickfrancis', 'ENV', 'DE2', '1993-10-27', 'M', 'Single', '2018-07-02', 'callores-kdt/P/KHI', 'pic_437.jpg', 'Active', NULL, 'Tagger'),
(160, 438, 'Reyes', 'Juan Carlos', 'JC', 'jc', 'ENV', 'DE2', '1994-09-19', 'M', 'Single', '2018-07-02', 'reyes_jc-kdt/P/KHI', 'pic_438.jpg', 'Active', NULL, 'Tagger'),
(161, 439, 'Arroyo', 'Micah Camille', 'Micah', 'arroyo-kdt', 'IT', 'IT-E2', '1997-09-13', 'F', 'Single', '2018-07-02', 'arroyo-kdt/P/KHI', 'pic_439.jpg', 'Active', NULL, 'Tagger'),
(162, 440, 'Panginbayan', 'Rochelle', 'Chelle', 'panginbayan-kdt', 'IT', 'IT-E2', '1997-07-20', 'F', 'Single', '2018-07-02', 'panginbayan-kdt/P/KHI', 'pic_440.jpg', 'Active', NULL, 'Tagger'),
(163, 444, 'Tobias', 'Kenneth', 'Ken', 'ken', 'CIV', 'DE2', '1996-01-26', 'M', 'Single', '2018-10-01', 'tobias_k-kdt/P/KHI', 'pic_444.jpg', 'Active', NULL, 'Tagger'),
(164, 445, 'Honrado', 'Ruth Anne', 'Ruth', 'ruth', 'ANA', 'DE2', '1992-04-09', 'F', 'Single', '2018-10-01', 'honrado-kdt/P/KHI', 'pic_445.jpg', 'Active', NULL, 'Tagger'),
(165, 446, 'Takenaka', 'Yukihiro', '', 'takenaka_yu', 'ADM', 'KDTP', '1965-11-25', 'M', '', '2016-11-25', 'takenaka_yu-kdt/P/KHI', 'pic_446.jpg', 'Active', NULL, 'Tagger'),
(166, 447, 'Medrano', 'Marco', 'Marco', 'maco', 'PIP', 'DE1', '1997-10-04', 'M', 'Single', '2019-07-01', 'medrano-kdt/P/KHI', 'pic_447.jpg', 'Active', NULL, 'Tagger'),
(167, 448, 'Buston', 'Cherry Mae ', 'Che', 'che', 'PIP', 'DE1', '1996-03-08', 'F', 'Single', '2019-07-01', 'soliven-kdt/P/KHI', 'pic_448.jpg', 'Active', NULL, 'Tagger'),
(168, 449, 'Viado', 'Meyrvin', 'Meyrvin', 'meyrvin', 'PIP/DXT', 'DE1', '1996-05-11', 'M', 'Single', '2019-07-01', 'viado-kdt/P/KHI', 'pic_449.jpg', 'Active', NULL, 'Tagger'),
(169, 450, 'Casem', 'Kimberly', 'Kim', 'kimmy', 'PIP', 'DE1', '1995-04-19', 'F', 'Single', '2019-07-01', 'casem-kdt/P/KHI', 'pic_450.jpg', 'Active', NULL, 'Tagger'),
(170, 451, 'Guiao ', 'Neil Stephen ', 'Neil', 'guiao', 'PIP', 'ADE', '1995-10-22', 'M', 'Single', '2019-07-01', 'guiao-kdt/P/KHI', 'pic_451.jpg', 'Resigned', '2022-03-23', 'Tagger'),
(171, 452, 'Nigos', 'Scottee Jairus', 'Scottee', 'scotty', 'ANA/DXT', 'DE1', '1997-10-28', 'M', 'Single', '2019-07-01', 'nigos-kdt/P/KHI', 'pic_452.jpg', 'Active', NULL, 'Tagger'),
(172, 454, 'Armas', 'Kenn John', 'Ken', 'armas', 'BOI', 'DE1', '1994-06-01', 'M', 'Single', '2019-07-01', 'armas-kdt/P/KHI', 'pic_454.jpg', 'Active', NULL, 'Tagger'),
(173, 455, 'Manalo', 'Vincen', 'Vincen', 'vincen', 'ENV', 'DE1', '1996-06-01', 'M', 'Single', '2019-07-01', 'manalo_v-kdt/P/KHI', 'pic_455.jpg', 'Active', NULL, 'Tagger'),
(174, 456, 'Rivera', 'Max Vincent', 'Max', 'maxxs', 'ENV', 'DE1', '1995-05-14', 'M', 'Single', '2019-07-01', 'rivera_m-kdt/P/KHI', 'pic_456.jpg', 'Active', NULL, 'Tagger'),
(175, 459, 'Cutaran', 'Rennel Mae', 'Rennel', 'rennel', 'ENV', 'ADE', '1997-12-11', 'F', 'Single', '2021-07-12', 'cutaran-kdt/P/KHI', 'pic_459.jpg', 'Active', NULL, 'Tagger'),
(176, 460, 'Berongoy', 'Eurjhon', 'Eur', 'eurjhon', 'ENV', 'ADE', '1998-08-19', 'M', 'Single', '2021-07-12', 'berongoy-kdt/P/KHI', 'pic_460.jpg', 'Active', NULL, 'Tagger'),
(177, 461, 'Bayquen', 'Hannah Millace', 'Hannah', 'bayquen-kdt', 'ENV', 'ADE', '1997-05-20', 'F', 'Single', '2021-07-12', 'bayquen-kdt/P/KHI', 'pic_461.jpg', 'Active', NULL, 'Tagger'),
(178, 462, 'Santos', 'Luize Nicole', 'Lui', 'luize', 'ENV', 'ADE', '1998-10-08', 'M', 'Single', '2021-07-12', 'santos-kdt/P/KHI', 'pic_462.jpg', 'Active', NULL, 'Tagger'),
(179, 463, 'Reyes', 'Rizchelle', 'Riz', 'riz', 'ENV', 'ADE', '1999-11-14', 'F', 'Single', '2021-07-12', 'reyes_r-kdt/P/KHI', 'pic_463.jpg', 'Active', NULL, 'Tagger'),
(180, 464, 'Coquia', 'Joshua Mari', 'Joshua', 'coquia-kdt', 'SYS/ENV/EE/IT', 'ASE', '1999-08-15', 'M', 'Single', '2021-07-12', 'coquia-kdt/P/KHI', 'pic_464.jpg', 'Active', NULL, 'Tagger'),
(181, 465, 'Petate', 'Felix Edwin', 'Felix', 'petate-kdt', 'SYS/ENV/EE/IT', 'SE1', '1992-03-14', 'M', 'Single', '2021-07-12', 'petate-kdt/P/KHI', 'pic_465.jpg', 'Active', NULL, 'Tagger'),
(182, 466, 'Aganan', 'Alvin John', 'Alvin', 'aganan-kdt', 'SYS', 'ASE', '1998-07-28', 'M', 'Single', '2021-07-12', 'aganan-kdt/P/KHI', 'pic_466.jpg', 'Active', NULL, 'Tagger'),
(183, 467, 'Camunggol', 'Aldrin Jerick', 'Aldrin', 'aldrin', 'BOI', 'ADE', '1999-04-01', 'M', 'Single', '2021-07-12', 'camunggol-kdt/P/KHI', 'pic_467.jpg', 'Active', NULL, 'Tagger'),
(184, 468, 'Gamez', 'Aaron Godfrey', 'Ron', 'aarongamez', 'MIL', 'ADE', '1998-08-08', 'M', 'Single', '2021-07-12', 'gamez-kdt/P/KHI', 'pic_468.jpg', 'Active', NULL, 'Tagger'),
(185, 10008, 'Chiba', 'Tatsurou', '', 'chiba_ta', '-', 'ADE', '0000-00-00', 'M', '', '0000-00-00', '', 'pic_10008.jpg', 'Active', NULL, 'Tagger'),
(186, 10018, 'Ueno', 'Ryosuke', '', 'ueno_r', '-', 'DM', '0000-00-00', 'M', '', '0000-00-00', '', 'pic_10018.jpg', 'Active', NULL, 'Tagger'),
(187, 10035, 'Iwamura', 'Munechiyo', '', 'iwamura_m', '-', 'SV', '0000-00-00', 'M', '', '0000-00-00', '', 'pic_10035.jpg', 'Active', NULL, 'Tagger'),
(188, 446, 'President', 'Kdt', '', 'president', 'ADM', 'KDTP', '1965-11-25', 'M', 'Single', '0000-00-00', 'takenaka_yu-kdt/P/KHI', 'pic_446.jpg', 'Active', NULL, 'Tagger'),
(189, 446, 'President', 'Kdt', '', 'kdtpresident', 'ADM', 'KDTP', '1965-11-25', 'M', 'Single', '0000-00-00', 'takenaka_yu-kdt/P/KHI', 'pic_446.jpg', 'Active', NULL, 'Tagger'),
(190, 30001, 'Yonezawa', '', '', 'yonezawa-bnc', 'KHI-ITS', '-', '0000-00-00', 'M', '-', '0000-00-00', '-', '-', 'Active', NULL, 'Tagger'),
(192, 20002, 'Ampig', 'Rommel', 'Rommel', 'rommel', 'MIL/CEM/MPM/ETCL', 'CTE', '1972-01-15', 'M', 'Married', '2022-04-01', 'ampig-kdt/P/KHI', 'pic_2002.jpg', 'Active', NULL, 'Tagger'),
(193, 20001, 'Laureano', 'Antonio', 'Toni', 'toni', 'ADM', 'CSAD', '1956-07-05', 'M', 'Married', '2021-07-01', 'laureano-kdt/P/KHI', 'pic_2001.jpg', 'Active', NULL, 'Tagger'),
(194, 469, 'Arabilla Jr.', 'Joel', 'joel', 'joelarabilla', 'MIL', 'ADE', '1999-08-12', 'M', 'Single', '2022-07-01', 'arabilla-kdt/P/KHI', 'pic_469.jpg', 'Active', NULL, 'Tagger'),
(195, 470, 'Leguin', 'Aries', 'Aries', 'ariesleguin', 'MHAH', 'ADE', '1999-05-11', 'M', 'Single', '2022-07-01', 'leguin-kdt/P/KHI', 'pic_470.jpg', 'Active', NULL, 'Tagger'),
(196, 471, 'Chavez', 'Mark Rian', 'Mark Rian', 'markrian', 'PIP', 'ADE', '1997-09-15', 'M', 'Single', '2022-07-01', 'chavez-kdt/P/KHI', 'pic_471.jpg', 'Active', NULL, 'Tagger'),
(197, 472, 'Lazaro', 'Nelson', 'nelson', 'nelson', 'CEM', 'ADE', '1993-07-14', 'M', 'Single', '2022-07-01', 'lazaro_n-kdt/P/KHI', 'pic_472.jpg', 'Active', NULL, 'Tagger'),
(198, 473, 'Domaoal', 'Kenneth', 'Kenneth', 'kennethdomaoal', 'ENV', 'ADE', '1998-07-28', 'M', 'Single', '2022-07-01', 'domaoal-kdt/P/KHI', 'pic_473.jpg', 'Active', NULL, 'Tagger'),
(199, 474, 'Segovia', 'Nicole Alysson', 'Nicole ', 'nicole', 'ENV', 'ADE', '1996-01-23', 'F', 'Single', '2022-07-01', 'segovia-kdt/P/KHI', 'pic_474.jpg', 'Active', NULL, 'Tagger'),
(200, 475, 'Del Rosario', 'Jay-R', 'Jay-R', 'jayr', 'PIP', 'ADE', '1999-04-27', 'M', 'Single', '2022-07-01', 'delrosario-kdt/P/KHI', 'pic_475.jpg', 'Active', NULL, 'Tagger'),
(201, 486, 'Maximo', 'Carl Rey', 'Carl Rey', 'carlrey', 'CHE', 'ADE', '1994-11-16', 'M', 'Single', '2022-07-01', 'maximo-kdt/P/KHI', 'pic_486.jpg', 'Active', NULL, 'Tagger'),
(202, 477, 'Callanta', 'Von Joemar', 'Von Joemar', 'vonjoemar', 'PIP', 'ADE', '1997-07-12', 'M', 'Single', '2022-07-01', 'callanta-kdt/P/KHI', 'pic_477.jpg', 'Active', NULL, 'Tagger'),
(203, 478, 'Bamba', 'Angelo Justin', 'Angelo Justin', 'angelobamba', 'MHAH', 'ADE', '1996-09-27', 'M', 'Single', '2022-07-01', 'bamba-kdt/P/KHI', 'pic_478.jpg', 'Active', NULL, 'Tagger'),
(204, 479, 'Abella', 'Sean Vinze', 'Sean Vinze', 'seanvinze', 'ENV', 'ADE', '1998-12-03', 'M', 'Single', '2022-07-01', 'abella-kdt/P/KHI', 'pic_479.jpg', 'Active', NULL, 'Tagger'),
(205, 480, 'Tamayo', 'Christian Mari', 'Christian Mari', 'christianmari', 'BOI', 'ADE', '1998-12-29', 'M', 'Single', '2022-07-01', 'tamayo-kdt/P/KHI', 'pic_480.jpg', 'Active', NULL, 'Tagger'),
(206, 481, 'Tan Pian', 'John Meynard', 'John Meynard', 'johnmeynard', 'ENV', 'ADE', '1998-10-05', 'M', 'Single', '2022-07-01', 'tanpian-kdt/P/KHI', 'pic_481.jpg', 'Active', NULL, 'Tagger'),
(207, 482, 'Ramirez', 'Xavier Dwight', 'Xavier Dwight', 'xavierdwight', 'PIP', 'ADE', '1998-12-17', 'M', 'Single', '2022-07-01', 'ramirez-kdt/P/KHI', 'pic_482.jpg', 'Active', NULL, 'Tagger'),
(208, 483, 'Bautista', 'Anne Wilyn', 'Anne Wilyn', 'annewilyn', 'ENV', 'ADE', '1998-12-17', 'F', 'Single', '2022-07-01', 'bautista_anne-kdt/P/KHI', 'pic_483.jpg', 'Active', NULL, 'Tagger'),
(209, 484, 'Jonson', 'Edgar Joseph', 'Edgar', 'edgar', 'EE', 'ADE', '1997-08-31', 'M', 'Single', '2022-07-01', 'jonson-kdt/P/KHI', 'pic_484.jpg', 'Active', NULL, 'Tagger'),
(210, 485, 'Pangilinan', 'Seanne Kyle', 'Seanne Kyle', 'seannekyle', 'CIV', 'ADE', '1999-09-09', 'M', 'Single', '2022-07-01', 'pangilinan-kdt/P/KHI', 'pic_485.jpg', 'Active', NULL, 'Tagger'),
(211, 487, 'Medrano', 'Collene Keith', 'Collene', 'medrano_c-kdt', 'SYS/ENV/EE/IT', 'ASE', '1999-01-13', 'F', 'Single', '2022-08-15', 'medrano_c-kdt/P/KHI', 'pic_487.jpg', 'Active', NULL, 'Tagger'),
(212, 488, 'Gulam', 'Glenda Ann', 'Glenda', 'Glenda', 'SYS', 'PSE', '2000-03-27', 'F', 'Single', '2022-08-15', 'gulam-kdt/P/KHI', 'pic_488.jpg', 'Resigned', '2023-01-31', 'Tagger'),
(213, 489, 'Fortus', 'Domini', 'domini', 'domini', 'MHAH', 'DE2', '1993-07-12', 'M', 'Single', '2023-01-16', 'fortus_d-kdt/P/KHI', 'pic_489.jpg', 'Active', NULL, 'Tagger'),
(214, 490, 'Usal', 'Ryan Christopher', 'Ryan', 'usal-kdt', 'MHAH', 'PDE', '2023-02-06', 'M', 'Single', '2023-03-01', 'usal-kdt/P/KHI', 'pic_490.jpg', 'Active', NULL, 'Tagger'),
(215, 491, 'Villamil', 'Ronald Louie', 'Ronal', 'villamil-kdt', 'MHAH', 'PDE', '2023-02-06', 'M', 'Single', '2023-03-01', 'villamil-kdt/P/KHI', 'pic_491.jpg', 'Active', NULL, 'Tagger'),
(216, 492, 'Villaruel', 'Jayron', 'Jayron', 'villaruel-kdt', 'MHAH', 'PDE', '2023-02-06', 'M', 'Single', '2023-03-01', 'villaruel-kdt/P/KHI', 'pic_492.jpg', 'Active', NULL, 'Tagger'),
(217, 493, 'Bedonia', 'Bryan James', 'Bryan', 'bedonia-kdt', 'MHAH', 'PDE', '2023-02-06', 'M', 'Single', '2023-03-01', 'bedonia-kdt/P/KHI', 'pic_493.jpg', 'Active', NULL, 'Tagger'),
(218, 494, 'Montaniel', 'John Carlos', 'John ', 'montaniel-kdt', 'MHAH', 'PDE', '2023-02-06', 'M', 'Single', '2023-03-01', 'montaniel-kdt/P/KHI', 'pic_494.jpg', 'Active', NULL, 'Tagger'),
(219, 495, 'Rodriguez', 'Nicole', 'Nicole', 'rodriguez-kdt', 'MHAH', 'PDE', '2023-02-06', 'F', 'Single', '2023-03-01', 'rodriguez-kdt/P/KHI', 'pic_495.jpg', 'Active', NULL, 'Tagger'),
(220, 496, 'Tana', 'Marc Jullian', 'Marc', 'tana-kdt', 'MHAH', 'PDE', '2023-02-06', 'M', 'Single', '2023-03-01', 'tana-kdt/P/KHI', 'pic_496.jpg', 'Active', NULL, 'Tagger'),
(223, 20003, 'Caveiro', 'Vincent', 'Vince', 'caveiro-kdt', 'PIP', 'CSE', '1986-01-02', 'M', 'Married', '2023-04-01', 'caveiro-kdt/P/KHI', 'pic_20003.jpg', 'Active', NULL, 'Tagger');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `emp_prof`
--
ALTER TABLE `emp_prof`
  ADD PRIMARY KEY (`fldID`);

--
-- Indexes for table `tbl_categories`
--
ALTER TABLE `tbl_categories`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_groups`
--
ALTER TABLE `tbl_groups`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_tags`
--
ALTER TABLE `tbl_tags`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_uploads`
--
ALTER TABLE `tbl_uploads`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `emp_prof`
--
ALTER TABLE `emp_prof`
  MODIFY `fldID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=224;

--
-- AUTO_INCREMENT for table `tbl_categories`
--
ALTER TABLE `tbl_categories`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tbl_groups`
--
ALTER TABLE `tbl_groups`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tbl_tags`
--
ALTER TABLE `tbl_tags`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tbl_uploads`
--
ALTER TABLE `tbl_uploads`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=224;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
