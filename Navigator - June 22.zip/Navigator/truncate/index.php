<?php

require "../includes/connect.php";

$sql = "TRUNCATE tbl_uploads";


if($conn->query($sql) === TRUE)
{
    echo "Truncated Successfully!";
}else{
    echo "Error: $conn->error";
}

$conn->close();
?>