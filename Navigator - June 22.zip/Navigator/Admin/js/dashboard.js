
let data_uploads = new Array();

$(document).ready(function(){
    
    fLoad_Defaults();

    function fLoad_Defaults()
    {
        $.post('../includes/get_data.php',
        {
            table_name: "tbl_uploads" 
        },
        function(data, status){
            data_uploads = JSON.parse(data);
            fLoad_Counters();
        });
    }



    function fLoad_Counters()
    {
        let data = data_uploads;
        let ctr_waitingToTag = 0;
        let ctr_forChecking = 0;
        let ctr_approved = 0;
        let ctr_rejected = 0;
        let ctr_unknown = 0;


        $.each(data, function(index, value){

            switch(value.Status)
            {
                case "Waiting to Tag": ctr_waitingToTag++; break;
                case "For Checking": ctr_forChecking++; break;
                case "Approved": ctr_approved++; break;
                case "Rejected": ctr_rejected++; break;
                default: ctr_unknown++; break;
            }
        });

        console.log(ctr_waitingToTag);
        console.log(ctr_approved);
        console.log(ctr_forChecking);
        console.log(ctr_rejected);
        console.log(ctr_unknown);

        $('#val_forChecking').text(ctr_forChecking);
        $('#val_approved').text(ctr_approved);
        $('#val_rejected').text(ctr_rejected);
        $('#val_waitingToTag').text(ctr_waitingToTag);



    }

});