// Call the dataTables jQuery plugin
$(document).ready(function () {

  var outside = require();
  // $('#dataTable').DataTable();
  $('#dataTable').DataTable({
    autoFill: true
  });

  // let dataa = {
  //   "employees": [
  //     { "firstName": "John", "lastName": "Doe" },
  //     { "firstName": "Anna", "lastName": "Smith" },
  //     { "firstName": "Peter", "lastName": "Jones" }
  //   ]
  // };

  // $('#dataTable').DataTable().row().remove().draw();
  // $('#dataTable').DataTable().row().remove().draw();
  
  // $('#dataTable').DataTable({
  //     data: dataa,
  //     columns: [
  //       {
  //         dataa: 'firstName'
  //       },
  //       {
  //         dataa: 'lastName'
  //       }
  //     ]
  // });

  $('#dataTable').DataTable();




  $('#hello').click(function(){
    console.log($('#dataTable tbody tr').length);
    let len = $('#dataTable tbody tr').length;
    for(i=0; i<len; i++)
    {
      $('#dataTable').DataTable().row().remove().draw();
    }
  });

});



