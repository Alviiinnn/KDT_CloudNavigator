<?php

require "connect.php";
$request = mysqli_escape_string($conn, $_POST['request']);
$id = mysqli_escape_string($conn, $_POST['clientID']);

if($request == "Delete_Uploaded")
{
    $sql = "DELETE from tbl_uploads WHERE FileNameDB = '$id' ";
    fnDelete_inDB($sql);
}


function fnDelete_inDB($sql)
{
    require "connect.php";

    if($conn->query($sql) === TRUE){
        echo "Success! Deleted in Database"; //Do not remove the "Success" key word. It is used in JS
    }else{
        echo "Error Deletion: ".$conn->error;
    }


    $conn->close();
}

?>