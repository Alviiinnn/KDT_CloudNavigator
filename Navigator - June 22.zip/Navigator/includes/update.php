<?php

require "connect.php";

$request = mysqli_real_escape_string($conn, $_POST['request']);

if ($request == "update_fileTagging"){
    Update_FileTagging();
}

if ($request == "update_photoTagging"){
    Update_PhotoTagging();
}

if($request == "update_status"){
    Update_Status();
}





function Update_FileTagging()
{
    require "connect.php";

    $fileID      = mysqli_real_escape_string($conn, $_POST['id']);
    $fileName    = mysqli_real_escape_string($conn, $_POST['newName']);
    $KDTGroup    = mysqli_real_escape_string($conn, $_POST['kdtGroup']);
    $plantType    = mysqli_real_escape_string($conn, $_POST['plant']);
    $projectName    = mysqli_real_escape_string($conn, $_POST['project']);
    // $categories  = mysqli_real_escape_string($conn, $_POST['cat']); //refer to C0001
    $tags        = mysqli_real_escape_string($conn, $_POST['tags']);
    $notes       = mysqli_real_escape_string($conn, $_POST['notes']);

    $status = "For Checking";
    $fileType = (explode('.', $fileID))[1];
    // $fileName = $fileName.".".$fileType; //CAUSE OF BUG 3 MAY 31, 2023

    $sql = "UPDATE tbl_uploads 
            SET FileName = '$fileName', 
            Status = '$status', 
            Tags = '$tags',
            PlantType = '$plantType',
            ProjectName = '$projectName',
            BusinessUnit = '$KDTGroup',
            Notes = '$notes',
            forPhotoDB = 0
            WHERE FileNameDB = '$fileID' ";

    Update_Database($sql, $fileID);
}


function Update_PhotoTagging()
{
    require "connect.php";

    $fileID      = mysqli_real_escape_string($conn, $_POST['id']);
    $fileName    = mysqli_real_escape_string($conn, $_POST['newName']);
    $KDTGroup    = mysqli_real_escape_string($conn, $_POST['kdtGroup']);
    $plantType  = mysqli_real_escape_string($conn, $_POST['plantType']);
    $projectName  = mysqli_real_escape_string($conn, $_POST['projectName']);
    $tags        = mysqli_real_escape_string($conn, $_POST['tags']);
    $notes       = mysqli_real_escape_string($conn, $_POST['notes']);

    $status = "For Checking";
    $fileType = (explode('.', $fileID))[1];
    $fileName = $fileName.".".$fileType;


    $sql = "UPDATE tbl_uploads 
            SET FileName = '$fileName', 
            Status = '$status', 
            Tags = '$tags',
            PlantType = '$plantType',
            ProjectName = '$projectName',
            BusinessUnit = '$KDTGroup',
            Notes = '$notes',
            forPhotoDB = 1
            WHERE FileNameDB = '$fileID' ";

    Update_Database($sql, $fileID);
}


function Update_Status()
{
    require "connect.php";

    $fileID = mysqli_real_escape_string($conn, $_POST['id']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);


    $sql = "UPDATE tbl_uploads 
            SET Status = '$status'
            WHERE FileNameDB = '$fileID' ";

    Update_Database($sql, $fileID);
}





function Update_Database($sql, $id)
{
    require "connect.php";

    if($conn->query($sql) === TRUE){
        echo $id;
    }else{
        echo "Error DB Update: ".$conn->error;  //DO NOT DELETE THE 'Error' WORD
    }

    $conn->close();
}





?>