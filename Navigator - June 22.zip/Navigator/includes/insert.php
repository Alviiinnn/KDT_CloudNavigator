<?php
    date_default_timezone_set("Asia/Manila");

    require "connect.php";
    require "uploadFiles.php";



    $sql = "INSERT INTO tbl_uploads (FileName, FileNameDB, DateUploaded, DateCaptured, Uploader, FileType, FileSize, Status, BusinessUnit) VALUES ";
    $datengayon = date("Y/m/d");

    for($ctr = 0; $ctr < count($arrFileNames); $ctr++)
    {
        $fileExt = pathinfo($arrFileNames[$ctr], PATHINFO_EXTENSION);
        $fileType = fxGet_FileType($fileExt);

        if($ctr == count($arrFileNames)-1){
            $sql .= "('$arrFileNames[$ctr]', '$arrFileDB[$ctr]', '$datengayon', '$arrMetaData[$ctr]', 'alvinjohn', '$fileType', '$arrFileSizes[$ctr]', 'Waiting to Tag', 'Group')";
        }else{
            $sql .= "('$arrFileNames[$ctr]', '$arrFileDB[$ctr]', '$datengayon', '$arrMetaData[$ctr]', 'alvinjohn', '$fileType', '$arrFileSizes[$ctr]', 'Waiting to Tag', 'Group'), ";
        }
    }


    function fxGet_FileType($ext){
        $pictures = ['jpg', 'jpeg', 'png', 'jfif', 'gif'];
        $documents = ['pdf', 'xlsx', 'ppt', 'pptx', 'doc', 'docx', 'txt'];
        $videos = ['mp4', 'avi', 'wmv'];

        if(in_array($ext, $pictures)){
            return "picture";
        }
        else if(in_array($ext, $documents)){
            return "document";
        }
        else if(in_array($ext, $videos)){
            return "video";
        }else{
            return "others";
        }
    }

    echo "<br><br>".$sql;


    if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
?>



