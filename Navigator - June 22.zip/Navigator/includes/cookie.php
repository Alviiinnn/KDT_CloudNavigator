<?php

echo $_COOKIE['uploadedFiles'];

?>