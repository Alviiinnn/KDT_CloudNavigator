<?php 
    // include "includes/dbconnect.php";
    if(isset($_COOKIE["newUser"])){
        header("Location: ./");
    }
?>


<!DOCTYPE html>
<html>
<title>User Not Found</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<body class="w3-black">
    <div class="w3-container w3-animate-top" align="center" style="padding-top: 100px;">
        <h1>ERROR: User Not Found!</h1>
        <p>BAGONG ERROR PHP</p><br>
        <!-- <p><i>NOTE: Macro Request Portal is can be open on your Default Browser.</i></p><br> -->
        <p style="opacity: 0.5;">\\kdts020\SOLUTIONSGrp\05_Documents\009 Web\001 sysWebRequestForm\runME</p>
    </div>

</body>
</html>