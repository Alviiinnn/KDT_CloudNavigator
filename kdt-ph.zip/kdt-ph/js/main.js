//#region GLOBALS
switch (document.location.hostname)
{
        case 'kdt-ph':
            rootFolder = '//kdt-ph/'; 
            break;
        case 'localhost' :
            rootFolder = '//localhost/'; 
            break;
        default : 
            rootFolder = '//kdt-ph/';
            break;
}
var empDetails=[];
checkLogin();
//#endregion

//#region BINDS
$(document).ready(function(){
    $('#linkName').html(`${empDetails['empFName']} ${empDetails['empSName']}`);
    $('.fadeshop').hover(
		function(){
			$(this).find('.captionshop').fadeIn(150);
		},
		function(){
			$(this).find('.captionshop').fadeOut(150);
		}
	);
});

$(document).on('click','#logOutBut',function(){
    clickLogout();
});
$(document).on('click','#adminLink',function(){
    window.open("/AdminControls/EmployeeList","_self");
});

//#endregion

//#region FUNCTIONS
function checkLogin(){
    $.ajaxSetup({async: false});
    $.ajax(
        {
            url:"Includes/checkLogin.php",
            success: function(data){ //ajax to check if user is logged in
                empDetails=$.parseJSON(data);
                if(empDetails.length<1){
                    window.location.href=rootFolder+'/KDTPortalLogin'; //if result is 0, redirect to log in page
                }
                adminAccess();
            }
        }
        );
    $.ajaxSetup({async: true});
}
function adminAccess(){//check if user has access to jmc
  $.post("ajax/checkAdminAccess.php",
  {
    empNum:empDetails['empNum']
  },
    function (data) {
      if(data.trim()==1){
          $('#nameLink').append(`<a href='#' id='adminLink'>Admin</a>`);
      }
    }
  );
}

function clickLogout(){
	if (confirm('Are you sure you want to logout?')) { // Save it!                    
		window.open("logout.php","_self");
	} 
}
//#endregion
// var projID=$($(this).find('option:selected')).attr('proj-id');


//#region Easter Egg
var knmCount = 0;

document.addEventListener("keyup", (event) => {

    const code = ["ArrowUp", "ArrowUp", "ArrowDown", "ArrowDown", "ArrowLeft", "ArrowRight", "ArrowLeft", "ArrowRight"];
    var mBool = false;
    if(event.code == code[knmCount]){
        mBool = true;
    }
    if(mBool){
        knmCount++;
        if(knmCount == 8){
            alert('???');
        }else{
            return;
        }
    }
    else{
        knmCount = 0;
        return;
    }
})
//#endregion