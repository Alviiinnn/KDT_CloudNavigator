<?php
// $rawJSDateChange=filemtime("../js/main.js");
// $wrsJSVersion=date("Ymd",$rawJSDateChange);
// echo $wrsJSVersion;
$ajaxArr = $_REQUEST["busterCall"];
$titleName = $_REQUEST["titleName"];
$headString="<title>$titleName</title>
<meta name='viewport' content='width=device-width, initial-scale=1.0'>
<meta charset='UTF-8'>
<meta name='generator' content=''>
<link href='css/bootstrap.min.css' rel='stylesheet'>
<link href='css/style.css' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Dosis:200,300,400,500,600,700' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Roboto:200,300,400,500,600,700' rel='stylesheet'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>
<link rel='icon' type='image/x-icon' href='images/logo.jfif' >
<script src='js/jquery.js'></script><!--COMMON-->
<script src='js/anim.js'></script>";
$addString = "";
//ADD TO ULI SA HEADSTRING BAT DI NAGANA
// <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
foreach($ajaxArr AS $element){
    switch(explode("/",$element)[0]){
        case "js":
            $version = date("YmdHis",filemtime("../$element"));
            $addString .= "<script src='$element?version=$version'></script>";
            break;
        case "css":
            $version = date("YmdHis",filemtime("../$element"));
            $addString .= "<link rel='stylesheet' type='text/css' href='$element?v=$version'>";
            break;
    }
}
echo $headString.$addString;
?>